<?php
/**
 * Web-Based cPanel Installation Wizard
 * Ministry of Health — State Department for Medical Services (PP-SDOMS)
 * Native PHP 8.1+ & MySQL (No Node.js)
 */

$step = (int)($_GET['step'] ?? 1);
$error = '';
$success = '';

// Check prerequisites
$php_version_ok = version_compare(PHP_VERSION, '8.1.0', '>=');
$pdo_mysql_ok = extension_loaded('pdo_mysql');
$json_ok = extension_loaded('json');
$mbstring_ok = extension_loaded('mbstring');
$writable_dir = is_writable(__DIR__);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['run_install'])) {
    $db_host = trim($_POST['db_host'] ?? 'localhost');
    $db_port = trim($_POST['db_port'] ?? '3306');
    $db_name = trim($_POST['db_name'] ?? '');
    $db_user = trim($_POST['db_user'] ?? '');
    $db_pass = trim($_POST['db_pass'] ?? '');
    $admin_email = trim($_POST['admin_email'] ?? 'admin@health.go.ke');
    $admin_pass = trim($_POST['admin_pass'] ?? 'ChangeMe@2026');

    if (empty($db_name) || empty($db_user)) {
        $error = 'Please provide Database Name and Database Username.';
    } else {
        try {
            // 1. Test Connection
            $dsn = "mysql:host={$db_host};port={$db_port};charset=utf8mb4";
            $pdo = new PDO($dsn, $db_user, $db_pass, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
            ]);

            // Create database if not exists
            $pdo->exec("CREATE DATABASE IF NOT EXISTS `{$db_name}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            $pdo->exec("USE `{$db_name}`");

            // 2. Execute SQL Schema
            $schema_file = __DIR__ . '/public/database/schema.sql';
            if (!file_exists($schema_file)) {
                $schema_file = __DIR__ . '/database/schema.sql';
            }

            if (file_exists($schema_file)) {
                $sql = file_get_contents($schema_file);
                // Strip multi-line comments and split by semicolon
                $pdo->exec($sql);
            }

            // 3. Update or Insert Admin User
            $hashed = password_hash($admin_pass, PASSWORD_BCRYPT);
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$admin_email]);
            $exists = $stmt->fetchColumn();

            if ($exists) {
                $upd = $pdo->prepare("UPDATE users SET password_hash = ?, is_admin = 1, can_edit = 1, can_upload = 1, can_approve = 1 WHERE email = ?");
                $upd->execute([$hashed, $admin_email]);
            } else {
                $ins = $pdo->prepare("INSERT INTO users (full_name, email, password_hash, role, directorate, can_upload, can_edit, can_approve, is_admin) VALUES (?, ?, ?, ?, ?, 1, 1, 1, 1)");
                $ins->execute(['System Administrator', $admin_email, $hashed, 'Administrator', 'Headquarters']);
            }

            // 4. Write .env file
            $env_content = "DB_DRIVER=mysql\n";
            $env_content .= "DB_HOST={$db_host}\n";
            $env_content .= "DB_PORT={$db_port}\n";
            $env_content .= "DB_NAME={$db_name}\n";
            $env_content .= "DB_USER={$db_user}\n";
            $env_content .= "DB_PASS={$db_pass}\n";
            $env_content .= "HOST=0.0.0.0\n";

            file_put_contents(__DIR__ . '/.env', $env_content);

            $step = 3;
            $success = 'Installation completed successfully! You can now log in to the system.';
        } catch (PDOException $e) {
            $error = 'MySQL Connection or Import Failed: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PP-SDOMS cPanel Web Installer</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&family=JetBrains+Mono:wght@500;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: #f1f5f9;
            color: #1e293b;
            margin: 0;
            padding: 40px 20px;
            display: flex;
            justify-content: center;
        }
        .installer-card {
            background: #ffffff;
            border-radius: 12px;
            max-width: 680px;
            width: 100%;
            box-shadow: 0 10px 30px rgba(0,0,0,0.08);
            border: 1px solid #e2e8f0;
            overflow: hidden;
        }
        .header {
            background: #0d47a1;
            color: white;
            padding: 24px;
            text-align: center;
        }
        .body {
            padding: 28px;
        }
        .step-badge {
            background: #e0f2fe;
            color: #0369a1;
            font-weight: 800;
            font-size: 0.75rem;
            padding: 4px 10px;
            border-radius: 12px;
            display: inline-block;
            margin-bottom: 12px;
        }
        .check-item {
            display: flex;
            justify-content: space-between;
            padding: 10px 14px;
            border-bottom: 1px solid #f1f5f9;
            font-size: 0.85rem;
        }
        .form-group {
            margin-bottom: 16px;
        }
        label {
            display: block;
            font-size: 0.78rem;
            font-weight: 700;
            margin-bottom: 4px;
            text-transform: uppercase;
        }
        input {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid #cbd5e1;
            border-radius: 6px;
            font-size: 0.85rem;
            box-sizing: border-box;
        }
        .btn {
            background: #0d47a1;
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 6px;
            font-weight: 700;
            cursor: pointer;
            width: 100%;
            font-size: 0.9rem;
        }
        .btn:hover {
            background: #0a3880;
        }
        .alert-error {
            background: #fef2f2;
            color: #b91c1c;
            border: 1px solid #f87171;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 20px;
            font-size: 0.85rem;
        }
        .alert-success {
            background: #ecfdf5;
            color: #065f46;
            border: 1px solid #6ee7b7;
            padding: 16px;
            border-radius: 6px;
            margin-bottom: 20px;
            font-size: 0.9rem;
            text-align: center;
        }
    </style>
</head>
<body>

<div class="installer-card">
    <div class="header">
        <h2 style="margin: 0; font-size: 1.25rem; font-weight: 800;">STATE DEPARTMENT FOR MEDICAL SERVICES</h2>
        <p style="margin: 4px 0 0; opacity: 0.85; font-size: 0.8rem;">PP-SDOMS cPanel One-Click Installation Wizard</p>
    </div>

    <div class="body">
        <?php if (!empty($error)): ?>
            <div class="alert-error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <?php if ($step === 1): ?>
            <span class="step-badge">STEP 1 OF 3: PRE-FLIGHT SERVER CHECK</span>
            <h3 style="margin: 0 0 16px; font-size: 1.1rem; font-weight: 800;">Verify Server Prerequisites</h3>

            <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; margin-bottom: 20px;">
                <div class="check-item">
                    <span>PHP Version (>= 8.1.0)</span>
                    <strong style="color: <?= $php_version_ok ? '#10b981' : '#ef4444' ?>;">
                        <?= PHP_VERSION ?> (<?= $php_version_ok ? 'PASS' : 'FAIL' ?>)
                    </strong>
                </div>
                <div class="check-item">
                    <span>PDO MySQL Driver (pdo_mysql)</span>
                    <strong style="color: <?= $pdo_mysql_ok ? '#10b981' : '#ef4444' ?>;">
                        <?= $pdo_mysql_ok ? 'ENABLED (PASS)' : 'MISSING (FAIL)' ?>
                    </strong>
                </div>
                <div class="check-item">
                    <span>JSON Extension</span>
                    <strong style="color: <?= $json_ok ? '#10b981' : '#ef4444' ?>;">
                        <?= $json_ok ? 'ENABLED (PASS)' : 'MISSING (FAIL)' ?>
                    </strong>
                </div>
                <div class="check-item">
                    <span>Multibyte String (mbstring)</span>
                    <strong style="color: <?= $mbstring_ok ? '#10b981' : '#ef4444' ?>;">
                        <?= $mbstring_ok ? 'ENABLED (PASS)' : 'MISSING (FAIL)' ?>
                    </strong>
                </div>
                <div class="check-item" style="border-bottom: none;">
                    <span>Directory Write Permissions</span>
                    <strong style="color: <?= $writable_dir ? '#10b981' : '#f59e0b' ?>;">
                        <?= $writable_dir ? 'WRITABLE (PASS)' : 'READ-ONLY (WARNING)' ?>
                    </strong>
                </div>
            </div>

            <a href="/install.php?step=2" class="btn" style="display: block; text-align: center; text-decoration: none;">
                Continue to Database Configuration &rarr;
            </a>

        <?php elseif ($step === 2): ?>
            <span class="step-badge">STEP 2 OF 3: DATABASE CONFIGURATION</span>
            <h3 style="margin: 0 0 16px; font-size: 1.1rem; font-weight: 800;">MySQL Database Credentials</h3>

            <form method="POST" action="/install.php?step=2">
                <input type="hidden" name="run_install" value="1">

                <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 12px;">
                    <div class="form-group">
                        <label>Database Host</label>
                        <input type="text" name="db_host" value="localhost" required>
                    </div>
                    <div class="form-group">
                        <label>Port</label>
                        <input type="text" name="db_port" value="3306" required>
                    </div>
                </div>

                <div class="form-group">
                    <label>Database Name (e.g. cpaneluser_mohsdms)</label>
                    <input type="text" name="db_name" value="mohsdms" required>
                </div>

                <div class="form-group">
                    <label>Database Username</label>
                    <input type="text" name="db_user" value="root" required>
                </div>

                <div class="form-group">
                    <label>Database Password</label>
                    <input type="password" name="db_pass" placeholder="Enter MySQL Password">
                </div>

                <hr style="border: 0; border-top: 1px solid #e2e8f0; margin: 20px 0;">

                <div class="form-group">
                    <label>Initial Administrator Email</label>
                    <input type="email" name="admin_email" value="admin@health.go.ke" required>
                </div>

                <div class="form-group">
                    <label>Initial Administrator Password</label>
                    <input type="text" name="admin_pass" value="ChangeMe@2026" required>
                </div>

                <button type="submit" class="btn">Execute Installation &amp; Seed Database</button>
            </form>

        <?php elseif ($step === 3): ?>
            <span class="step-badge">STEP 3 OF 3: COMPLETE</span>
            <div class="alert-success">
                <h3 style="margin: 0 0 8px; font-size: 1.1rem; font-weight: 800;">🎉 Installation Successful!</h3>
                <p style="margin: 0; font-size: 0.85rem;">The MySQL tables have been populated, the configuration has been saved, and your administrative account is ready.</p>
            </div>

            <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 18px; margin-bottom: 20px; font-size: 0.85rem;">
                <div><strong>Login URL:</strong> <code>index.php</code></div>
                <div><strong>Admin Email:</strong> <code>admin@health.go.ke</code></div>
                <div><strong>Password:</strong> <code>ChangeMe@2026</code></div>
            </div>

            <a href="/index.php" class="btn" style="display: block; text-align: center; text-decoration: none;">
                Go to PP-SDOMS Login Portal &rarr;
            </a>
        <?php endif; ?>
    </div>
</div>

</body>
</html>
