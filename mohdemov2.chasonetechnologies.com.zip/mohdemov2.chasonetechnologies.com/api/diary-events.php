<?php
/** Diary calendar data and entry create / update / delete API. */
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
require_once __DIR__ . '/../config/db.php';
require_auth();

function diary_json(int $status, array $body): void {
    http_response_code($status);
    echo json_encode($body, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

/**
 * Validate the create/update payload and return clean values.
 * $existing is the current DB row when updating (null when creating).
 */
function diary_validate(PDO $pdo, array $payload, ?array $existing): array {
    $title = trim((string)($payload['title'] ?? ''));
    $date = trim((string)($payload['entry_date'] ?? ''));
    $time = trim((string)($payload['entry_time'] ?? ''));
    $category = trim((string)($payload['category'] ?? 'General'));
    $priority = trim((string)($payload['priority'] ?? 'Medium'));
    // Diary categories plus the activity types used by the Activities & Events module (same diary_events table).
    $categories = ['Meeting', 'Task', 'Deadline', 'Event', 'General', 'Field Visit', 'Ministerial Event', 'Executive Inspection', 'Training', 'Other'];
    $statuses = ['UPCOMING', 'ONGOING', 'COMPLETED', 'CANCELLED'];
    $status = strtoupper(trim((string)($payload['status'] ?? ($existing['status'] ?? 'UPCOMING'))));
    $priorities = ['Low', 'Medium', 'High', 'Critical'];
    $nairobiTimezone = new DateTimeZone('Africa/Nairobi');
    $parsedDate = DateTimeImmutable::createFromFormat('!Y-m-d', $date, $nairobiTimezone);
    $titleLength = function_exists('mb_strlen') ? mb_strlen($title) : strlen($title);

    if ($title === '' || $titleLength > 255) diary_json(422, ['success' => false, 'error' => 'Enter a title (up to 255 characters).']);
    if (!$parsedDate || $parsedDate->format('Y-m-d') !== $date) diary_json(422, ['success' => false, 'error' => 'Choose a valid date.']);

    // An existing entry may keep its own (past) date; any other date must be today or later.
    $todayInNairobi = new DateTimeImmutable('today', $nairobiTimezone);
    $keepsOwnDate = $existing !== null && $existing['event_date'] === $date;
    if ($parsedDate < $todayInNairobi && !$keepsOwnDate) {
        diary_json(422, ['success' => false, 'error' => 'Diary entries can’t be scheduled for a past date. Choose today or a future date.']);
    }

    if ($time !== '' && !preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d$/', $time)) diary_json(422, ['success' => false, 'error' => 'Choose a valid time.']);

    // Legacy values already stored on the entry (e.g. "Field Visit") are allowed to stay.
    $categoryOk = in_array($category, $categories, true) || ($existing !== null && $existing['event_type'] === $category);
    $priorityOk = in_array($priority, $priorities, true) || ($existing !== null && $existing['priority'] === $priority);
    $statusOk = in_array($status, $statuses, true) || ($existing !== null && strtoupper((string)$existing['status']) === $status);
    if (!$statusOk) diary_json(422, ['success' => false, 'error' => 'Choose a valid status.']);
    if (!$categoryOk || !$priorityOk) diary_json(422, ['success' => false, 'error' => 'Choose a valid category and priority.']);

    // Projects: project_ids[] (new) or project_id (old single field).
    $ids = $payload['project_ids'] ?? [];
    if (!is_array($ids)) $ids = [];
    if (!$ids && !empty($payload['project_id'])) $ids = [$payload['project_id']];
    $ids = array_values(array_unique(array_filter(array_map('intval', $ids), function ($v) { return $v > 0; })));
    // Meetings and corporate business are diary-only entries, not project activities.
    if (strcasecmp($category, 'Meeting') === 0 || preg_match('/corporate business/i', $title . ' ' . (string)($payload['content'] ?? ''))) $ids = [];
    if (count($ids) > 50) diary_json(422, ['success' => false, 'error' => 'Too many projects selected (50 at most).']);
    if ($ids) {
        $in = implode(',', array_fill(0, count($ids), '?'));
        $check = $pdo->prepare("SELECT COUNT(*) FROM projects WHERE id IN ($in)");
        $check->execute($ids);
        if ((int)$check->fetchColumn() !== count($ids)) diary_json(422, ['success' => false, 'error' => 'One or more selected projects no longer exist.']);
    }

    return [
        'title' => $title,
        'content' => trim((string)($payload['content'] ?? '')),
        'category' => $category,
        'date' => $date,
        'time' => $time !== '' ? $time : null,
        'priority' => $priority,
        'status' => $status,
        'location' => trim((string)($payload['location'] ?? '')) ?: null,
        'host' => trim((string)($payload['host'] ?? '')) ?: null,
        'attendees' => trim((string)($payload['attendees'] ?? '')) ?: null,
        'project_ids' => $ids,
    ];
}

/** Replace the entry's project links. diary_events.project_id mirrors the first one (legacy column). */
function diary_sync_projects(PDO $pdo, int $eventId, array $ids): void {
    $pdo->prepare('DELETE FROM diary_event_projects WHERE event_id = ?')->execute([$eventId]);
    if (!$ids) return;
    $insert = $pdo->prepare('INSERT INTO diary_event_projects (event_id, project_id) VALUES (?, ?)');
    foreach ($ids as $projectId) $insert->execute([$eventId, $projectId]);
}

function diary_sync_attendee_requests(PDO $pdo, int $eventId, string $attendees, int $creatorId): void {
    $psUsers = $pdo->query("SELECT id, full_name FROM users WHERE role LIKE '%Principal Secretary%' OR role='PS'")->fetchAll(PDO::FETCH_ASSOC);
    $pdo->prepare("DELETE FROM diary_attendee_responses WHERE event_id=? AND response_status='pending'")->execute([$eventId]);
    if ($attendees === '') return;
    foreach ($psUsers as $ps) {
        $name = trim((string)$ps['full_name']);
        $isNamed = $name !== '' && stripos($attendees, $name) !== false;
        $isPsToken = count($psUsers) === 1 && preg_match('/\bPS\b|Principal Secretary/i', $attendees);
        if (!$isNamed && !$isPsToken) continue;
        $pdo->prepare("INSERT INTO diary_attendee_responses (event_id, recipient_user_id, creator_user_id, response_status, remarks, responded_at) VALUES (?,?,?,'pending',NULL,NULL) ON DUPLICATE KEY UPDATE creator_user_id=VALUES(creator_user_id), response_status='pending', remarks=NULL, responded_at=NULL")
            ->execute([$eventId, (int)$ps['id'], $creatorId]);
    }
}

if (!$db_connected || !$pdo) diary_json(503, ['success' => false, 'error' => 'The diary database is unavailable.']);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$pdo->exec("CREATE TABLE IF NOT EXISTS diary_attendee_responses (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, event_id INT NOT NULL, recipient_user_id INT NOT NULL,
    creator_user_id INT NOT NULL, response_status VARCHAR(20) NOT NULL DEFAULT 'pending', remarks TEXT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, responded_at DATETIME NULL,
    UNIQUE KEY uq_diary_attendee_response (event_id, recipient_user_id),
    KEY idx_diary_attendee_recipient_status (recipient_user_id, response_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
try {
    if ($method === 'GET') {
        $month = (int)($_GET['month'] ?? date('n'));
        $year = (int)($_GET['year'] ?? date('Y'));
        if ($month < 1 || $month > 12 || $year < 2000 || $year > 2100) diary_json(400, ['success' => false, 'error' => 'Choose a valid month and year.']);
        $start = sprintf('%04d-%02d-01', $year, $month);
        $end = (new DateTimeImmutable($start))->modify('+1 month')->format('Y-m-d');
        $stmt = $pdo->prepare("SELECT e.id, e.title, e.description AS content, e.event_type AS category,
                e.event_date AS entry_date, e.event_time AS entry_time, e.location, e.host,
                e.attendees, e.status, e.priority
            FROM diary_events e
            WHERE e.event_date >= ? AND e.event_date < ?
            ORDER BY e.event_date, e.event_time, e.id");
        $stmt->execute([$start, $end]);
        $entries = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Attach an attendance response request only to the listed Principal Secretary's entries.
        $currentUserId = (int)(get_current_user_data()['id'] ?? 0);
        if ($entries && $currentUserId > 0) {
            try {
                $eventIds = array_map('intval', array_column($entries, 'id'));
                $marks = implode(',', array_fill(0, count($eventIds), '?'));
                $request = $pdo->prepare("SELECT event_id, id, response_status FROM diary_attendee_responses WHERE recipient_user_id=? AND event_id IN ($marks)");
                $request->execute(array_merge([$currentUserId], $eventIds));
                $requestMap = [];
                foreach ($request->fetchAll(PDO::FETCH_ASSOC) as $response) $requestMap[(int)$response['event_id']] = $response;
                foreach ($entries as &$entry) {
                    $response = $requestMap[(int)$entry['id']] ?? null;
                    if ($response && $response['response_status'] === 'pending') $entry['attendance_request'] = ['id'=>(int)$response['id'], 'status'=>'pending'];
                }
                unset($entry);
            } catch (Throwable $ignored) { /* Attendance response support is initialized on first write. */ }
        }

        // Attach all linked projects to each entry.
        $projectsByEvent = [];
        if ($entries) {
            $eventIds = array_column($entries, 'id');
            $in = implode(',', array_fill(0, count($eventIds), '?'));
            $links = $pdo->prepare("SELECT dep.event_id, p.id, p.programme_title, p.sub_programme
                FROM diary_event_projects dep JOIN projects p ON p.id = dep.project_id
                WHERE dep.event_id IN ($in)
                ORDER BY p.programme_title, p.sub_programme");
            $links->execute($eventIds);
            foreach ($links->fetchAll(PDO::FETCH_ASSOC) as $row) {
                // Same label the project picker uses; sub_programme alone was the old display name.
                $label = trim(($row['programme_title'] ?? '') . ' — ' . ($row['sub_programme'] ?? ''), ' —');
                $projectsByEvent[$row['event_id']][] = ['id' => (int)$row['id'], 'title' => $label];
            }
        }
        foreach ($entries as &$entry) {
            $projects = $projectsByEvent[$entry['id']] ?? [];
            $entry['id'] = (int)$entry['id'];
            $entry['projects'] = $projects;
            // Legacy single-project fields = first linked project.
            $entry['project_id'] = $projects ? $projects[0]['id'] : null;
            $entry['project_title'] = $projects ? $projects[0]['title'] : null;
        }
        unset($entry);
        diary_json(200, ['success' => true, 'entries' => $entries]);
    }

    if ($method === 'POST') {
        $token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
        if (!verify_csrf_token($token)) diary_json(403, ['success' => false, 'error' => 'Your session token expired. Refresh the page and try again.']);
        $payload = json_decode(file_get_contents('php://input'), true);
        if (!is_array($payload)) diary_json(400, ['success' => false, 'error' => 'Invalid form data.']);
        $action = (string)($payload['action'] ?? 'create');

        if ($action === 'respond_attendance') {
            $currentUserId = (int)(get_current_user_data()['id'] ?? 0);
            $responseId = (int)($payload['response_id'] ?? 0);
            $remarks = trim((string)($payload['remarks'] ?? ''));
            if ($responseId < 1 || $remarks === '' || mb_strlen($remarks) > 5000) diary_json(422, ['success'=>false, 'error'=>'Add a short remark before excusing yourself.']);
            diary_sync_attendee_requests($pdo, 0, '', $currentUserId); // Ensure the table exists without creating a request.
            $stmt = $pdo->prepare("UPDATE diary_attendee_responses SET response_status='excused', remarks=?, responded_at=NOW() WHERE id=? AND recipient_user_id=? AND response_status='pending'");
            $stmt->execute([$remarks, $responseId, $currentUserId]);
            if ($stmt->rowCount() !== 1) diary_json(404, ['success'=>false, 'error'=>'That attendance request is no longer available.']);
            diary_json(200, ['success'=>true]);
        }

        if ($action === 'create') {
            $v = diary_validate($pdo, $payload, null);
            $pdo->beginTransaction();
            $stmt = $pdo->prepare("INSERT INTO diary_events
                (title, description, event_type, event_date, event_time, location, host, attendees, status, priority, project_id)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$v['title'], $v['content'], $v['category'], $v['date'], $v['time'], $v['location'], $v['host'], $v['attendees'], $v['status'], $v['priority'], $v['project_ids'][0] ?? null]);
            $id = (int)$pdo->lastInsertId();
            diary_sync_projects($pdo, $id, $v['project_ids']);
            diary_sync_attendee_requests($pdo, $id, (string)($v['attendees'] ?? ''), (int)(get_current_user_data()['id'] ?? 0));
            $pdo->commit();
            diary_json(201, ['success' => true, 'id' => $id]);
        }

        if ($action === 'update' || $action === 'delete') {
            $id = (int)($payload['id'] ?? 0);
            if ($id < 1) diary_json(400, ['success' => false, 'error' => 'Missing diary entry id.']);
            $current = $pdo->prepare('SELECT id, event_date, event_type, priority, status FROM diary_events WHERE id = ?');
            $current->execute([$id]);
            $existing = $current->fetch(PDO::FETCH_ASSOC);
            if (!$existing) diary_json(404, ['success' => false, 'error' => 'That diary entry no longer exists. Refresh the page.']);

            if ($action === 'update') {
                $v = diary_validate($pdo, $payload, $existing);
                $pdo->beginTransaction();
                $stmt = $pdo->prepare("UPDATE diary_events
                    SET title = ?, description = ?, event_type = ?, event_date = ?, event_time = ?,
                        location = ?, host = ?, attendees = ?, status = ?, priority = ?, project_id = ?
                    WHERE id = ?");
                $stmt->execute([$v['title'], $v['content'], $v['category'], $v['date'], $v['time'], $v['location'], $v['host'], $v['attendees'], $v['status'], $v['priority'], $v['project_ids'][0] ?? null, $id]);
                diary_sync_projects($pdo, $id, $v['project_ids']);
                diary_sync_attendee_requests($pdo, $id, (string)($v['attendees'] ?? ''), (int)(get_current_user_data()['id'] ?? 0));
                $pdo->commit();
                diary_json(200, ['success' => true, 'id' => $id]);
            }

            $pdo->beginTransaction();
            $pdo->prepare('DELETE FROM diary_event_projects WHERE event_id = ?')->execute([$id]);
            $pdo->prepare('DELETE FROM diary_events WHERE id = ?')->execute([$id]);
            $pdo->commit();
            diary_json(200, ['success' => true]);
        }

        diary_json(400, ['success' => false, 'error' => 'Unknown action.']);
    }

    header('Allow: GET, POST');
    diary_json(405, ['success' => false, 'error' => 'Method not allowed.']);
} catch (Throwable $e) {
    if ($pdo && $pdo->inTransaction()) $pdo->rollBack();
    error_log('Diary API error: ' . $e->getMessage());
    diary_json(500, ['success' => false, 'error' => 'Could not load or save the diary entry. Apply the diary project-link migration (database/diary_multi_projects.sql) if this is an older database.']);
}
