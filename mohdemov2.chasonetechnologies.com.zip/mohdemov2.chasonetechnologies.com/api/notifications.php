<?php
/** User-specific notifications for upcoming events, action points and diary attendance. */
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
require_once __DIR__ . '/../config/db.php';
require_auth();

$user = get_current_user_data();
$userId = (int)($user['id'] ?? 0);
$respond = static function (int $status, array $payload): void {
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
};
if (!$db_connected || !$pdo || $userId < 1) $respond(503, ['success' => false, 'error' => 'Notifications are unavailable.']);

try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS app_notifications (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        notification_key VARCHAR(190) NOT NULL,
        title VARCHAR(180) NOT NULL,
        message VARCHAR(500) NOT NULL,
        link VARCHAR(500) NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        read_at TIMESTAMP NULL DEFAULT NULL,
        UNIQUE KEY uq_app_notification_user_key (user_id, notification_key),
        KEY idx_app_notification_user_read (user_id, read_at, created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
        $payload = json_decode((string)file_get_contents('php://input'), true) ?: [];
        $token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? ($payload['csrf_token'] ?? '');
        if (!verify_csrf_token(is_string($token) ? $token : '')) $respond(419, ['success' => false, 'error' => 'Your session token expired. Refresh and try again.']);
        if (($payload['action'] ?? '') === 'mark_all_read') {
            $pdo->prepare('UPDATE app_notifications SET read_at=COALESCE(read_at,NOW()) WHERE user_id=?')->execute([$userId]);
        } elseif (($payload['action'] ?? '') === 'mark_read') {
            $id = (int)($payload['id'] ?? 0);
            $pdo->prepare('UPDATE app_notifications SET read_at=COALESCE(read_at,NOW()) WHERE id=? AND user_id=?')->execute([$id, $userId]);
        } else $respond(400, ['success' => false, 'error' => 'Unknown notification action.']);
        $count = $pdo->prepare('SELECT COUNT(*) FROM app_notifications WHERE user_id=? AND read_at IS NULL');
        $count->execute([$userId]);
        $respond(200, ['success' => true, 'unread_count' => (int)$count->fetchColumn()]);
    }

    $users = $pdo->query('SELECT id, full_name, email, role, is_admin FROM users')->fetchAll(PDO::FETCH_ASSOC);
    $admins = [];
    foreach ($users as $account) if (!empty($account['is_admin']) || strcasecmp((string)($account['role'] ?? ''), 'Administrator') === 0) $admins[] = (int)$account['id'];
    $insert = $pdo->prepare('INSERT IGNORE INTO app_notifications (user_id, notification_key, title, message, link, created_at) VALUES (?,?,?,?,?,NOW())');
    $nairobi = new DateTimeZone('Africa/Nairobi');
    $today = new DateTimeImmutable('today', $nairobi);
    $tomorrow = $today->modify('+1 day');
    $dateKeys = [$today->format('Y-m-d') => 'today', $tomorrow->format('Y-m-d') => 'tomorrow'];

    // Event reminders are posted to every active account on the event day and the day before.
    $eventQuery = $pdo->prepare('SELECT id, title, event_type, event_date, event_time FROM diary_events WHERE event_date IN (?,?)');
    $eventQuery->execute(array_keys($dateKeys));
    foreach ($eventQuery->fetchAll(PDO::FETCH_ASSOC) as $event) {
        $when = $dateKeys[(string)$event['event_date']] ?? 'soon';
        $message = (string)$event['title'] . ($when === 'today' ? ' is scheduled for today.' : ' is scheduled for tomorrow.');
        if (!empty($event['event_time'])) $message .= ' Time: ' . substr((string)$event['event_time'], 0, 5) . '.';
        foreach ($users as $account) $insert->execute([(int)$account['id'], 'event:' . (int)$event['id'] . ':' . $when, (string)$event['event_type'], $message, '/modules/events.php']);
    }

    // Administrators see all open action points; an assigned user sees items whose responsible
    // text contains that account's name or email, case-insensitively.
    $actionRows = $pdo->query("SELECT id, ref_no, person_responsible FROM action_points WHERE UPPER(status) NOT IN ('COMPLETED','CANCELLED')")->fetchAll(PDO::FETCH_ASSOC);
    foreach ($actionRows as $action) {
        $responsible = (string)($action['person_responsible'] ?? '');
        $message = 'Action item ' . (string)$action['ref_no'] . ' assigned to ' . $responsible;
        foreach ($admins as $adminId) $insert->execute([$adminId, 'action:' . (int)$action['id'], 'Action Point', $message, '/modules/actions.php']);
        foreach ($users as $account) {
            $accountId = (int)$account['id'];
            if (in_array($accountId, $admins, true)) continue;
            $name = trim((string)($account['full_name'] ?? ''));
            $email = trim((string)($account['email'] ?? ''));
            if (($name !== '' && stripos($responsible, $name) !== false) || ($email !== '' && stripos($responsible, $email) !== false)) {
                $insert->execute([$accountId, 'action:' . (int)$action['id'], 'Action Point', $message, '/modules/actions.php']);
            }
        }
    }

    // Notify a Principal Secretary when a diary entry lists their account as an attendee.
    try {
        $requests = $pdo->prepare("SELECT r.id, e.title, e.event_date FROM diary_attendee_responses r JOIN diary_events e ON e.id=r.event_id WHERE r.recipient_user_id=? AND r.response_status='pending'");
        $requests->execute([$userId]);
        foreach ($requests->fetchAll(PDO::FETCH_ASSOC) as $request) {
            $insert->execute([$userId, 'diary-attendance-request:' . (int)$request['id'], 'Diary attendance request',
                'You are listed as an attendee for “' . (string)$request['title'] . '” on ' . (string)$request['event_date'] . '.',
                '/modules/diary.php?date=' . rawurlencode((string)$request['event_date'])]);
        }
    } catch (Throwable $ignored) { /* Attendance notifications are available after diary response support is installed. */ }

    // A Principal Secretary's excuse and remarks go back to the account that created the diary entry.
    try {
        $excuses = $pdo->query("SELECT r.id, r.event_id, r.creator_user_id, r.remarks, r.responded_at, e.title
            FROM diary_attendee_responses r JOIN diary_events e ON e.id=r.event_id
            WHERE r.response_status='excused' AND r.creator_user_id IS NOT NULL")->fetchAll(PDO::FETCH_ASSOC);
        foreach ($excuses as $excuse) {
            $insert->execute([(int)$excuse['creator_user_id'], 'diary-excuse:' . (int)$excuse['id'], 'Diary attendance update',
                'A listed attendee excused themselves from “' . (string)$excuse['title'] . '”. Remarks: ' . ((string)$excuse['remarks'] ?: 'None provided.'),
                '/modules/diary.php?date=' . rawurlencode(substr((string)$excuse['responded_at'], 0, 10))]);
        }
    } catch (Throwable $ignored) { /* The diary response table is installed when the diary API is used. */ }

    $stmt = $pdo->prepare('SELECT id, title, message, link, created_at, (read_at IS NOT NULL) AS is_read FROM app_notifications WHERE user_id=? ORDER BY created_at DESC,id DESC LIMIT 30');
    $stmt->execute([$userId]);
    $notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $count = $pdo->prepare('SELECT COUNT(*) FROM app_notifications WHERE user_id=? AND read_at IS NULL');
    $count->execute([$userId]);
    $unread = (int)$count->fetchColumn();
    $respond(200, ['success' => true, 'count' => count($notifications), 'unread_count' => $unread, 'notifications' => $notifications]);
} catch (Throwable $error) {
    error_log('Notification API failed: ' . $error->getMessage());
    $respond(503, ['success' => false, 'error' => 'Notifications are temporarily unavailable.']);
}
