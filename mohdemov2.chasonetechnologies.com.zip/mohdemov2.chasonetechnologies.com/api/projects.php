<?php
/**
 * Projects API Endpoint
 * Ministry of Health — State Department for Medical Services (PP-SDOMS)
 * Native PHP 8.1+ & MySQL
 */
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/db.php';

$page = max(1, (int)($_GET['page'] ?? 1));
$limit = max(1, min(50, (int)($_GET['limit'] ?? 10)));
$offset = ($page - 1) * $limit;
$search = trim($_GET['search'] ?? '');
$status = $_GET['status'] ?? 'All';
$category = $_GET['category'] ?? 'All';

$projects = [];

if ($db_connected && $pdo) {
    try {
        $sql = "SELECT * FROM projects WHERE 1=1";
        $params = [];

        if (!empty($search)) {
            $sql .= " AND (sub_programme LIKE ? OR programme_title LIKE ? OR saga_name LIKE ? OR directorate_name LIKE ?)";
            $params[] = "%$search%";
            $params[] = "%$search%";
            $params[] = "%$search%";
            $params[] = "%$search%";
        }
        if ($status !== 'All') {
            $sql .= " AND status = ?";
            $params[] = $status;
        }
        if ($category !== 'All') {
            $sql .= " AND category = ?";
            $params[] = $category;
        }

        $sql .= " ORDER BY id DESC LIMIT $limit OFFSET $offset";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $projects = $stmt->fetchAll();

        echo json_encode(['success' => true, 'projects' => $projects, 'page' => $page]);
        exit;
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'projects' => [], 'page' => $page]);
        exit;
    }
}

http_response_code(503);
echo json_encode(['success' => false, 'projects' => [], 'page' => $page]);
