-- PP-SDOMS enhancement migration. BACK UP THE DATABASE before running.
-- Compatible with MariaDB 10.11 / MySQL 8+

ALTER TABLE users
  ADD COLUMN IF NOT EXISTS two_factor_enabled TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS two_factor_secret TEXT NULL;

ALTER TABLE kpis_and_sub_kpis
  ADD COLUMN IF NOT EXISTS remarks TEXT NULL;

ALTER TABLE diary_events
  ADD COLUMN IF NOT EXISTS created_by INT(11) DEFAULT NULL;

-- The deployed Reports module reads/writes these metadata columns; the supplied dump did not include them.
ALTER TABLE reports
  ADD COLUMN IF NOT EXISTS module VARCHAR(100) DEFAULT 'General',
  ADD COLUMN IF NOT EXISTS file_size VARCHAR(30) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS uploader_email VARCHAR(190) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS summary TEXT DEFAULT NULL;

CREATE TABLE IF NOT EXISTS notifications (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT(11) NOT NULL,
  title VARCHAR(180) NOT NULL,
  message TEXT NOT NULL,
  link VARCHAR(500) DEFAULT NULL,
  notification_type VARCHAR(50) NOT NULL DEFAULT 'system',
  source_key VARCHAR(190) DEFAULT NULL,
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  read_at DATETIME DEFAULT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_notification_user_source (user_id, source_key),
  KEY idx_notification_user_unread (user_id, is_read, created_at),
  CONSTRAINT fk_notifications_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS project_action_logs (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  project_id INT(11) NOT NULL,
  action_text TEXT NOT NULL,
  action_at DATETIME NOT NULL,
  created_by INT(11) DEFAULT NULL,
  created_by_name VARCHAR(150) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id), KEY idx_project_action_logs (project_id, action_at),
  CONSTRAINT fk_project_action_logs_project FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
  CONSTRAINT fk_project_action_logs_user FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS repository_documents (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  title VARCHAR(255) NOT NULL,
  document_category ENUM('Charter','Policy','Report','Mandate','Guideline','Other') NOT NULL DEFAULT 'Other',
  repository_type ENUM('system_upload','general_repository') NOT NULL DEFAULT 'system_upload',
  source_module VARCHAR(100) DEFAULT NULL,
  original_name VARCHAR(255) NOT NULL,
  stored_name VARCHAR(255) NOT NULL,
  mime_type VARCHAR(150) DEFAULT NULL,
  file_size BIGINT UNSIGNED NOT NULL DEFAULT 0,
  uploaded_by INT(11) DEFAULT NULL,
  uploaded_by_name VARCHAR(150) DEFAULT NULL,
  uploaded_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  description TEXT DEFAULT NULL,
  PRIMARY KEY (id), KEY idx_repository_type_category (repository_type, document_category),
  CONSTRAINT fk_repository_uploaded_by FOREIGN KEY (uploaded_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS diary_attendance_responses (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  event_id INT(11) NOT NULL,
  user_id INT(11) NOT NULL,
  response ENUM('PENDING','ACCEPTED','EXCUSED') NOT NULL DEFAULT 'PENDING',
  remarks TEXT DEFAULT NULL,
  responded_at DATETIME DEFAULT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id), UNIQUE KEY uq_diary_attendance (event_id, user_id),
  CONSTRAINT fk_diary_attendance_event FOREIGN KEY (event_id) REFERENCES diary_events(id) ON DELETE CASCADE,
  CONSTRAINT fk_diary_attendance_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS project_priority_history (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  project_id INT(11) NOT NULL,
  priority_score DECIMAL(6,2) NOT NULL,
  priority_tier ENUM('Low','Medium','High','Critical') NOT NULL,
  factors_json JSON DEFAULT NULL,
  calculated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id), KEY idx_priority_project (project_id, calculated_at),
  CONSTRAINT fk_priority_history_project FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Normalize legacy tier labels to the four requested categories.
UPDATE projects SET priority_tier = CASE
  WHEN LOWER(priority_tier) LIKE '%critical%' OR LOWER(priority_tier) LIKE '%tier 1%' THEN 'Critical'
  WHEN LOWER(priority_tier) LIKE '%high%' OR LOWER(priority_tier) LIKE '%tier 2%' THEN 'High'
  WHEN LOWER(priority_tier) LIKE '%medium%' OR LOWER(priority_tier) LIKE '%tier 3%' THEN 'Medium'
  WHEN LOWER(priority_tier) LIKE '%low%' OR LOWER(priority_tier) LIKE '%tier 4%' THEN 'Low'
  ELSE 'Medium' END;
