-- One-time migration: make delivery_units a registry of the SAGA records.
-- This intentionally replaces the legacy sub-programme delivery-unit rows.

ALTER TABLE `outputs`
  DROP FOREIGN KEY `outputs_ibfk_1`;

ALTER TABLE `delivery_units`
  DROP FOREIGN KEY `delivery_units_ibfk_1`;

ALTER TABLE `delivery_units`
  DROP INDEX `sub_programme_id`,
  CHANGE COLUMN `id` `delivery_init__id` varchar(50) NOT NULL,
  DROP COLUMN `sub_programme_id`,
  DROP COLUMN `lead_person`,
  MODIFY COLUMN `name` varchar(150) NOT NULL,
  ADD COLUMN `code` varchar(20) NOT NULL AFTER `name`,
  ADD COLUMN `description` text DEFAULT NULL AFTER `code`,
  ADD UNIQUE KEY `uq_delivery_units_code` (`code`);

DELETE FROM `delivery_units`;

INSERT INTO `delivery_units` (`delivery_init__id`, `name`, `code`, `description`)
SELECT CAST(`id` AS CHAR), `name`, `code`, `description`
FROM `sagas`;

-- The former outputs-to-delivery_units link referenced a different dataset.
-- Keep output history intact and leave that old relationship unenforced.
