-- =====================================================================
-- STATE DEPARTMENT FOR MEDICAL SERVICES (PP-SDOMS)
-- Comprehensive MySQL / MariaDB Schema & Initial Seed Dataset
-- =====================================================================

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS audit_logs;
DROP TABLE IF EXISTS monthly_progress;
DROP TABLE IF EXISTS performance_kpis;
DROP TABLE IF EXISTS reports;
DROP TABLE IF EXISTS diary_events;
DROP TABLE IF EXISTS meetings;
DROP TABLE IF EXISTS action_points;
DROP TABLE IF EXISTS projects;
DROP TABLE IF EXISTS outputs;
DROP TABLE IF EXISTS delivery_units;
DROP TABLE IF EXISTS sub_programmes;
DROP TABLE IF EXISTS programmes;
DROP TABLE IF EXISTS flagships;
DROP TABLE IF EXISTS users;
SET FOREIGN_KEY_CHECKS = 1;

-- ---------------------------------------------------------------------
-- 1. USERS & RBAC TABLE
-- ---------------------------------------------------------------------
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(150) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL DEFAULT 'Viewer',
    directorate VARCHAR(150) NOT NULL DEFAULT 'Health Systems',
    can_upload BOOLEAN DEFAULT TRUE,
    can_edit BOOLEAN DEFAULT FALSE,
    can_approve BOOLEAN DEFAULT FALSE,
    is_admin BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 2. PRIORITY FLAGSHIPS TABLE
-- ---------------------------------------------------------------------
CREATE TABLE flagships (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    lead_directorate VARCHAR(150) NOT NULL,
    progress_pct DECIMAL(5,2) DEFAULT 0.00,
    risk_level ENUM('Low', 'Medium', 'High', 'Severe') DEFAULT 'Low',
    priority_tier ENUM('Critical', 'High', 'Medium', 'Low') DEFAULT 'Medium',
    allocated_budget DECIMAL(15,2) DEFAULT 0.00,
    utilized_budget DECIMAL(15,2) DEFAULT 0.00,
    lead_officer VARCHAR(150),
    team_name VARCHAR(150),
    start_date DATE,
    target_date DATE,
    status VARCHAR(50) DEFAULT 'IN PROGRESS',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 3. PROGRAMMES & SUB-PROGRAMMES HIERARCHY
-- ---------------------------------------------------------------------
CREATE TABLE programmes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(50) NOT NULL,
    title VARCHAR(255) NOT NULL,
    objective TEXT,
    allocated_budget DECIMAL(15,2) DEFAULT 0.00,
    lead_officer VARCHAR(150)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE sub_programmes (
    id VARCHAR(50) PRIMARY KEY,
    programme_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    code VARCHAR(50),
    FOREIGN KEY (programme_id) REFERENCES programmes(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE delivery_units (
    id VARCHAR(50) PRIMARY KEY,
    sub_programme_id VARCHAR(50) NOT NULL,
    name VARCHAR(255) NOT NULL,
    lead_person VARCHAR(150),
    FOREIGN KEY (sub_programme_id) REFERENCES sub_programmes(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE outputs (
    id VARCHAR(50) PRIMARY KEY,
    delivery_unit_id VARCHAR(50) NOT NULL,
    title VARCHAR(255) NOT NULL,
    indicator VARCHAR(255),
    target_value VARCHAR(100),
    FOREIGN KEY (delivery_unit_id) REFERENCES delivery_units(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 4. PROJECTS & CAPITAL INVESTMENTS TABLE
-- ---------------------------------------------------------------------
CREATE TABLE projects (
    id INT AUTO_INCREMENT PRIMARY KEY,
    programme_title VARCHAR(255) NOT NULL,
    sub_programme VARCHAR(255) NOT NULL,
    description TEXT,
    remarks TEXT,
    category ENUM('Directorate', 'Saga', 'Division') NOT NULL DEFAULT 'Directorate',
    directorate_name VARCHAR(150),
    saga_name VARCHAR(150),
    division_name VARCHAR(150),
    delivery_unit VARCHAR(150),
    priority_tier VARCHAR(100) DEFAULT 'Tier 1 - High Priority',
    color VARCHAR(20) DEFAULT '#1976d2',
    flagship_id INT,
    start_date DATE,
    end_date DATE,
    status VARCHAR(50) DEFAULT 'IN PROGRESS',
    progress_status VARCHAR(50) DEFAULT 'On Track',
    progress_calculation_mode ENUM('kpi_derived', 'manual') DEFAULT 'kpi_derived',
    total_budget DECIMAL(15,2) DEFAULT 0.00,
    gok_financing DECIMAL(15,2) DEFAULT NULL,
    foreign_financing DECIMAL(15,2) DEFAULT NULL,
    funds_disbursed DECIMAL(15,2) DEFAULT 0.00,
    funds_utilized DECIMAL(15,2) DEFAULT 0.00,
    milestones_completed INT DEFAULT 0,
    milestones_total INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (flagship_id) REFERENCES flagships(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 5. ACTION POINTS TRACKER TABLE
-- ---------------------------------------------------------------------
CREATE TABLE action_points (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ref_no VARCHAR(50) NOT NULL UNIQUE,
    action_date DATE NOT NULL,
    meeting_title VARCHAR(255),
    issue TEXT NOT NULL,
    person_responsible VARCHAR(150) NOT NULL,
    timeline VARCHAR(100),
    status ENUM('ON TRACK', 'NOT STARTED', 'DELAYED', 'STALLED', 'COMPLETED', 'CANCELLED') DEFAULT 'ON TRACK',
    action TEXT NOT NULL,
    resolution_notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 6. MEETINGS & DONOR ENGAGEMENTS
-- ---------------------------------------------------------------------
CREATE TABLE meetings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    meeting_date DATE NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    financier VARCHAR(150),
    venue VARCHAR(150),
    attendees TEXT,
    agenda TEXT,
    decisions TEXT,
    document VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE reports (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(100) NOT NULL UNIQUE,
    title VARCHAR(255) NOT NULL,
    project VARCHAR(255),
    report_date DATE NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    visibility VARCHAR(50) DEFAULT 'Restricted',
    status VARCHAR(50) DEFAULT 'Pending',
    uploaded_by VARCHAR(150),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 7. DIARY & CALENDAR EVENTS
-- ---------------------------------------------------------------------
CREATE TABLE diary_events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    event_type VARCHAR(50) DEFAULT 'Event',
    event_date DATE NOT NULL,
    event_time VARCHAR(20),
    location VARCHAR(255),
    host VARCHAR(150),
    attendees TEXT,
    status VARCHAR(50) DEFAULT 'UPCOMING',
    priority VARCHAR(30) DEFAULT 'Medium',
    project_id INT NULL,
    INDEX idx_diary_project_id (project_id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 8. PERFORMANCE CONTRACT KPIS TABLE
-- ---------------------------------------------------------------------
CREATE TABLE performance_kpis (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(50) NOT NULL UNIQUE,
    kpi_name VARCHAR(255) NOT NULL,
    category VARCHAR(150) NOT NULL,
    delivery_unit VARCHAR(150),
    parent_kpi_name VARCHAR(255),
    sub_kpi_weight DECIMAL(5,2) DEFAULT 0.00,
    target_baseline VARCHAR(100),
    target_2025_26 VARCHAR(100),
    target_baseline_2026_27 VARCHAR(100),
    target_2027_28 VARCHAR(100),
    target_2028_29 VARCHAR(100),
    target_2029_30 VARCHAR(100),
    actual_2025_26 VARCHAR(100),
    current_achievement DECIMAL(5,2) DEFAULT 0.00,
    status VARCHAR(50) DEFAULT 'Achieved',
    remarks TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 9. MONTHLY PROGRESS RECORDS
-- ---------------------------------------------------------------------
CREATE TABLE monthly_progress (
    id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT NOT NULL,
    `year_month` VARCHAR(7) NOT NULL,
    kpi_code VARCHAR(50) NOT NULL,
    kpi_name VARCHAR(255) NOT NULL,
    weight DECIMAL(5,2) DEFAULT 0.00,
    progress_pct DECIMAL(5,2) DEFAULT 0.00,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 10. AUDIT TRAIL LOGS
-- ---------------------------------------------------------------------
CREATE TABLE audit_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_name VARCHAR(150) NOT NULL,
    user_email VARCHAR(150) NOT NULL,
    action VARCHAR(100) NOT NULL,
    module VARCHAR(100) NOT NULL,
    record_id INT,
    details TEXT,
    ip_address VARCHAR(45) DEFAULT '127.0.0.1',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================================
-- INITIAL SEED DATA
-- =====================================================================

INSERT INTO users (full_name, email, password_hash, role, directorate, can_upload, can_edit, can_approve, is_admin)
VALUES 
('System Administrator', 'admin@health.go.ke', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Administrator', 'Headquarters', TRUE, TRUE, TRUE, TRUE),
('Dr. Harry Kimtai, CBS', 'ps@medicalservices.go.ke', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Principal Secretary', 'Executive Office', TRUE, TRUE, TRUE, TRUE),
('Project Monitoring Officer', 'monitoring@health.go.ke', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Planning Director', 'Policy & Planning', TRUE, TRUE, FALSE, FALSE);
