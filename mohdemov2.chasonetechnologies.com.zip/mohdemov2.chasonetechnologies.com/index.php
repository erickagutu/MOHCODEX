<?php
/**
 * Ministerial System Login Portal
 * Ministry of Health — State Department for Medical Services (PP-SDOMS)
 * Native PHP 8.1+ & MySQL (No Node.js)
 */
require_once __DIR__ . '/config/db.php';
unset($_SESSION['login_2fa_user'], $_SESSION['totp_pending_secret']);

$error = '';
$message = '';

if (!empty($_SESSION['user'])) {
    header('Location: /dashboard.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = (string)($_POST['password'] ?? '');
    $token = $_POST['csrf_token'] ?? '';

    if (!verify_csrf_token($token)) {
        $error = 'Invalid security token. Please refresh and try again.';
    } elseif (!$db_connected || !$pdo) {
        $error = 'The account database is unavailable. Please contact the system administrator.';
    } elseif (!empty($_SESSION['login_email_2fa'])) {
        $pending = $_SESSION['login_email_2fa'];
        if (isset($_POST['admin_recover_email_2fa']) && !empty($pending['is_admin'])) {
            try {
                $pdo->prepare('UPDATE user_security_settings SET email_2fa_enabled = 0 WHERE user_id = ?')->execute([(int)$pending['user_id']]);
                $stmt = $pdo->prepare('SELECT * FROM users WHERE id = ?'); $stmt->execute([(int)$pending['user_id']]);
                $_SESSION['user'] = $stmt->fetch(); $_SESSION['last_login_prev'] = $_SESSION['pending_last_login'] ?? null;
                unset($_SESSION['login_email_2fa'], $_SESSION['pending_last_login']);
                log_audit_trail('ADMIN_EMAIL_2FA_RECOVERY', 'Auth', $pending['user_id'], 'Administrator disabled email verification after password-verified recovery');
                header('Location: /dashboard.php'); exit;
            } catch (Throwable $e) { $error = 'Unable to disable email verification. Please contact the system administrator.'; }
        } elseif (isset($_POST['resend_email_code'])) {
            if (time() - (int)$pending['last_sent'] < 60) $error = 'Wait one minute before requesting another code.';
            else {
                try {
                    $stmt = $pdo->prepare('SELECT email, full_name FROM users WHERE id = ?'); $stmt->execute([(int)$pending['user_id']]); $pendingUser = $stmt->fetch();
                    $newCode = (string)random_int(100000, 999999);
                    if ($pendingUser && send_email_verification_code($pendingUser['email'], $pendingUser['full_name'], $newCode)) {
                        $_SESSION['login_email_2fa']['code_hash'] = hash('sha256', $newCode);
                        $_SESSION['login_email_2fa']['expires_at'] = time() + 600;
                        $_SESSION['login_email_2fa']['last_sent'] = time();
                        $_SESSION['login_email_2fa']['attempts'] = 0;
                        $error = 'A new verification code was sent to your email address.';
                    } else $error = 'Could not send email. Contact the system administrator.';
                } catch (Throwable $e) { $error = 'Could not send email. Contact the system administrator.'; }
            }
        } elseif (time() > (int)$pending['expires_at']) {
            unset($_SESSION['login_email_2fa'], $_SESSION['pending_last_login']);
            $error = 'That code expired. Sign in again to request a new one.';
        } elseif ((int)$pending['attempts'] >= 5) {
            unset($_SESSION['login_email_2fa'], $_SESSION['pending_last_login']);
            $error = 'Too many incorrect codes. Sign in again to request a new one.';
        } else {
            $_SESSION['login_email_2fa']['attempts']++;
            $submittedCode = trim((string)($_POST['email_code'] ?? ''));
            if (preg_match('/^\d{6}$/', $submittedCode) && hash_equals($pending['code_hash'], hash('sha256', $submittedCode))) {
                $stmt = $pdo->prepare('SELECT * FROM users WHERE id = ?'); $stmt->execute([(int)$pending['user_id']]); $verifiedUser = $stmt->fetch();
                if ($verifiedUser) {
                    $_SESSION['user'] = $verifiedUser; $_SESSION['last_login_prev'] = $_SESSION['pending_last_login'] ?? null;
                    unset($_SESSION['login_email_2fa'], $_SESSION['pending_last_login']);
                    log_audit_trail('LOGIN', 'Auth', $verifiedUser['id'], 'User completed password and email verification');
                    header('Location: /dashboard.php'); exit;
                }
            }
            $error = 'The email verification code is invalid.';
            log_audit_trail('LOGIN_FAILED','Auth',(int)($pending['user_id']??0),'Invalid email verification code',['severity'=>'WARNING','metadata'=>['stage'=>'email_verification']]);
        }
    } elseif (empty($email) || trim($password) === '') {
        $error = 'Please enter both your email address and password.';
    } else {
        try {
            $stmt = $pdo->prepare('SELECT * FROM users WHERE LOWER(email) = LOWER(?) LIMIT 1');
            $stmt->execute([$email]); $user = $stmt->fetch();
            if ($user && password_verify($password, $user['password_hash'])) {
                $previousLogin = null;
                try { $pl = $pdo->prepare("SELECT created_at FROM audit_logs WHERE user_email = ? AND action = 'LOGIN' ORDER BY created_at DESC, id DESC LIMIT 1"); $pl->execute([$user['email']]); $previousLogin = $pl->fetchColumn() ?: null; } catch (Throwable $e) {}
                try { $security = $pdo->prepare('SELECT email_2fa_enabled FROM user_security_settings WHERE user_id = ?'); $security->execute([(int)$user['id']]); $email2faEnabled = (bool)$security->fetchColumn(); } catch (Throwable $e) { $email2faEnabled = false; }
                if ($email2faEnabled) {
                    $code = (string)random_int(100000, 999999);
                    if (send_email_verification_code($user['email'], $user['full_name'], $code)) {
                        $_SESSION['login_email_2fa'] = ['user_id' => (int)$user['id'], 'email' => $user['email'], 'is_admin' => (!empty($user['is_admin']) || strcasecmp((string)($user['role'] ?? ''), 'Administrator') === 0), 'code_hash' => hash('sha256', $code), 'expires_at' => time() + 600, 'last_sent' => time(), 'attempts' => 0];
                        $_SESSION['pending_last_login'] = $previousLogin;
                        $error = 'A verification code was sent to your account email.';
                    } else $error = 'Could not send the verification email. Check the server email configuration or contact the administrator.';
                } else {
                    $_SESSION['user'] = $user; $_SESSION['last_login_prev'] = $previousLogin;
                    log_audit_trail('LOGIN', 'Auth', $user['id'], 'User logged into PP-SDOMS from cPanel web portal');
                    header('Location: /dashboard.php'); exit;
                }
            } else {
                $error = 'Invalid email address or password.';
                log_audit_trail('LOGIN_FAILED','Auth',$user ? (int)$user['id'] : null,'Invalid sign-in credentials',['severity'=>'WARNING','metadata'=>['attempted_email'=>$email]]);
            }
        } catch (Throwable $e) { $error = 'Unable to verify credentials against the database.'; }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login — State Department for Medical Services (PP-SDOMS)</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/assets/css/stylelogin.css">
    <style>
        .login-wrapper {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(110deg, #f2f5fb 0%, #dfe6f1 48%, #cbd6e7 100%);
            padding: 24px 16px;
        }
        .login-shell { width: min(450px, 100%); }
    </style>
</head>
<body>

<div class="login-wrapper">
    <div class="login-shell">
        <div class="login-card">
            <header class="login-brand">
                <img src="/assets/images/kenya_coat_arms.png" alt="Coat of Arms of Kenya" onerror="this.src='/public/assets/images/kenya_coat_arms.png';">
                <h1>State Department for Medical Services</h1>
                <p>Performance Management Dashboard</p>
            </header>

            <?php if (!empty($error)): ?>
                <div class="login-error"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>

            <form method="POST" action="/index.php" class="login-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(get_csrf_token()) ?>">

                <?php if (empty($_SESSION['login_email_2fa'])): ?>
                <label for="login-email">Email Address</label>
                <div class="login-input-group">
                    <span class="login-input-icon" aria-hidden="true">
                        <svg viewBox="0 0 24 24"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>
                    </span>
                    <input id="login-email" type="email" name="email" required value="admin@health.go.ke" placeholder="name@health.go.ke" autocomplete="username">
                </div>
                <?php else: ?><p style="font-size:.82rem;color:#475569;">Enter the six-digit code sent to <strong><?= htmlspecialchars($_SESSION['login_email_2fa']['email']) ?></strong>.</p><?php endif; ?>

                <?php if (empty($_SESSION['login_email_2fa'])): ?>
                <label for="login-password">Password</label>
                <div class="login-input-group">
                    <span class="login-input-icon" aria-hidden="true">
                        <svg viewBox="0 0 24 24"><path d="M18 8h-1V6a5 5 0 0 0-10 0v2H6a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V10a2 2 0 0 0-2-2zM9 6a3 3 0 0 1 6 0v2H9zm3 11a2 2 0 1 1 0-4 2 2 0 0 1 0 4z"/></svg>
                    </span>
                    <input id="login-password" type="password" name="password" required placeholder="Enter your password" autocomplete="current-password">
                </div>
                <?php else: ?><label for="email-code">Email verification code</label><div class="login-input-group"><input id="email-code" type="text" name="email_code" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" required autocomplete="one-time-code" placeholder="6-digit code"></div><?php endif; ?>

                <button type="submit" class="login-submit">
                    <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M10.09 15.59 11.5 17l5-5-5-5-1.41 1.41L12.67 11H3v2h9.67zM19 3h-8a2 2 0 0 0-2 2v3h2V5h8v14h-8v-3H9v3a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2z"/></svg>
                    <?= empty($_SESSION['login_email_2fa']) ? 'Login' : 'Verify code' ?>
                </button>
                <?php if (!empty($_SESSION['login_email_2fa'])): ?><button type="submit" name="resend_email_code" value="1" formnovalidate class="login-submit" style="margin-top:8px;background:#64748b;">Resend verification code</button><?php endif; ?>
                <?php if (!empty($_SESSION['login_email_2fa']['is_admin'])): ?><button type="submit" name="admin_recover_email_2fa" value="1" formnovalidate class="login-submit" style="margin-top:8px;background:#64748b;">Can't access email? Turn off admin verification</button><?php endif; ?>
            </form>

            <p class="login-help">For account access, contact your system administrator.</p>
            <footer class="login-footer">
                &copy; <?= date('Y') ?> Government of Kenya.<br>All Rights Reserved.
                <div style="margin-top:8px;font-size:.68rem;"><a href="/install.php" style="color:#8a94a3;text-decoration:underline;">System setup</a></div>
            </footer>
        </div>
    </div>
</div>

</body>
</html>
