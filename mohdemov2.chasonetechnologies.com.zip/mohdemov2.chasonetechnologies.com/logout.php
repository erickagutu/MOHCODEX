<?php
/**
 * Logout Handler
 */
require_once __DIR__ . '/config/db.php';
log_audit_trail('LOGOUT', 'Auth', $_SESSION['user']['id'] ?? null, 'User logged out');
session_destroy();
header('Location: /index.php');
exit;
