/**
 * Client-side filtering + lazy loading for server-rendered tables.
 *
 * Markup contract:
 *   <table data-lazy-table data-page-size="10"> ... <tr data-lazy-row data-search="..." data-<key>="..."> ...
 *   Filters: <input data-lazy-filter="search"> or <select data-lazy-filter="<key>"> (value "All"/"" = no filter;
 *            compared with the row's data-<key> attribute).
 *   Optional: #lazyCount (text), #lazyMore (button), #lazySentinel (scroll trigger), #lazyEmpty (no results row)
 * Rows are revealed 10 at a time as the user scrolls (or clicks "Load more").
 */
(function () {
  'use strict';
  const table = document.querySelector('[data-lazy-table]');
  if (!table) return;

  const pageSize = parseInt(table.dataset.pageSize || '10', 10);
  const rows = Array.from(table.querySelectorAll('[data-lazy-row]'));
  const filters = Array.from(document.querySelectorAll('[data-lazy-filter]'));
  const countEl = document.getElementById('lazyCount');
  const moreBtn = document.getElementById('lazyMore');
  const sentinel = document.getElementById('lazySentinel');
  const emptyRow = document.getElementById('lazyEmpty');

  let matches = rows.slice();
  let shown = 0;

  function matchesFilters(row) {
    return filters.every((f) => {
      const key = f.dataset.lazyFilter;
      const val = (f.value || '').trim();
      if (!val || val === 'All') return true;
      if (key === 'search') return (row.dataset.search || '').includes(val.toLowerCase());
      return (row.dataset[key] || '') === val;
    });
  }

  function render() {
    rows.forEach((r) => { r.hidden = true; });
    matches.slice(0, shown).forEach((r) => { r.hidden = false; });

    const remaining = matches.length - shown;
    if (countEl) countEl.textContent = 'Showing ' + Math.min(shown, matches.length) + ' of ' + matches.length;
    if (emptyRow) emptyRow.hidden = matches.length !== 0;
    if (moreBtn) {
      moreBtn.hidden = remaining <= 0;
      moreBtn.textContent = 'Load more (' + Math.max(0, remaining) + ' remaining)';
    }
  }

  function loadMore() {
    if (shown >= matches.length) return;
    shown = Math.min(matches.length, shown + pageSize);
    render();
  }

  function applyFilters() {
    matches = rows.filter(matchesFilters);
    shown = Math.min(matches.length, pageSize);
    render();
  }

  filters.forEach((f) => {
    f.addEventListener(f.tagName === 'SELECT' ? 'change' : 'input', applyFilters);
  });
  if (moreBtn) moreBtn.addEventListener('click', loadMore);

  if (sentinel && 'IntersectionObserver' in window) {
    new IntersectionObserver((entries) => {
      if (entries.some((e) => e.isIntersecting)) loadMore();
    }, { rootMargin: '120px' }).observe(sentinel);
  }

  applyFilters();
})();
