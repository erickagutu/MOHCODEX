/* Shared modal state (used by the global open/close helpers and the form handler). */
const diaryModalState = { id: null, originalDate: '' };

document.addEventListener('DOMContentLoaded', () => {
    const now = new Date();
    let currentMonth = now.getMonth();
    let currentYear = now.getFullYear();
    let diaryEntries = [];
    let selectedDate = '';
    let selectedCategory = '';
    let pendingDeleteId = null;
    const grid = document.getElementById('calendarGrid');
    const monthDisplay = document.getElementById('calendarMonthDisplay');
    const details = document.getElementById('drawerProjectContent');
    const detailsModal = document.getElementById('diaryDetailsModal');
    const detailsBody = document.getElementById('diaryDetailsBody');
    const form = document.getElementById('newDiaryForm');
    const monthNames = ['January','February','March','April','May','June','July','August','September','October','November','December'];
    // Diary categories + the activity types of the Activities & Events module (both live in diary_events).
    const categories = ['Meeting','Task','Deadline','Event','General','Field Visit','Ministerial Event','Executive Inspection','Training','Other'];
    const statusLabel = value => { const v = String(value || '').toLowerCase(); return v ? v.charAt(0).toUpperCase() + v.slice(1) : ''; };
    let popupDate = '';
    let popupCategory = 'All';
    const appUrl = path => typeof window.appUrl === 'function' ? window.appUrl(path) : `/${String(path).replace(/^\/+/, '')}`;
    const categoryClass = value => {
        const known = categories.find(category => category.toLowerCase() === String(value || '').toLowerCase());
        return `event-cat-${(known || 'General').toLowerCase().replace(/\s+/g, '')}`;
    };
    const dateKey = (year, month, day) => `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    const localToday = () => {
        const today = new Date();
        return dateKey(today.getFullYear(), today.getMonth(), today.getDate());
    };

    /** POST JSON to the diary API (create / update / delete all go through POST + an "action" field). */
    async function postDiary(payload) {
        const response = await fetch(appUrl('api/diary-events.php'), {
            method: 'POST',
            headers: {'Content-Type': 'application/json', 'X-CSRF-Token': document.querySelector('meta[name="csrf-token"]')?.content || ''},
            body: JSON.stringify(payload)
        });
        let data = null;
        try { data = await response.json(); } catch (e) { /* non-JSON response */ }
        if (!response.ok || !data || !data.success) throw new Error((data && data.error) || 'The request could not be completed.');
        return data;
    }

    async function loadDiaryEntries(preferredSelection = null) {
        try {
            const response = await fetch(appUrl(`api/diary-events.php?month=${currentMonth + 1}&year=${currentYear}`));
            const data = await response.json();
            if (!response.ok || !data.success) throw new Error(data.error || 'Unable to load diary entries.');
            diaryEntries = data.entries || [];
            // After a save, highlight the saved date (the popup is not reopened automatically).
            if (preferredSelection) { selectedDate = preferredSelection.date; selectedCategory = ''; }
            renderCalendar();
            if (selectedDate) showDateDetails(selectedDate);
            else if (selectedCategory) filterDetailsByCategory(selectedCategory);
            else details.innerHTML = '<p class="diary-empty-note">Select a category on the calendar to view its entries.</p>';
        } catch (error) {
            if (details) details.innerHTML = `<p class="diary-empty-note">${escapeHTML(error.message)}</p>`;
        }
    }

    function renderCalendar() {
        if (!grid || !monthDisplay) return;
        monthDisplay.textContent = `${monthNames[currentMonth]} ${currentYear}`;
        grid.innerHTML = '';
        ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].forEach(day => {
            const heading = document.createElement('div');
            heading.className = 'calendar-day-header';
            heading.textContent = day;
            grid.appendChild(heading);
        });
        const firstWeekday = new Date(currentYear, currentMonth, 1).getDay();
        const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
        const previousMonthDays = new Date(currentYear, currentMonth, 0).getDate();
        for (let offset = firstWeekday - 1; offset >= 0; offset--) {
            const cell = document.createElement('div');
            cell.className = 'calendar-day-cell other-month';
            cell.innerHTML = `<span class="day-number">${previousMonthDays - offset}</span>`;
            grid.appendChild(cell);
        }
        for (let day = 1; day <= daysInMonth; day++) {
            const date = dateKey(currentYear, currentMonth, day);
            const entries = diaryEntries.filter(entry => entry.entry_date === date);
            const cell = document.createElement('div');
            cell.className = `calendar-day-cell${date === selectedDate ? ' selected' : ''}${entries.length ? ' has-event' : ''}`;
            cell.dataset.date = date;
            const categoryList = [...new Set(entries.map(entry => entry.category || 'General'))];
            const chips = categoryList.map(category => `<button type="button" class="calendar-event-pill ${categoryClass(category)}" data-date="${date}" data-category="${escapeHTML(category)}" aria-label="Show ${escapeHTML(category)} entries for ${date}">${escapeHTML(category)}</button>`).join('');
            cell.innerHTML = `<span class="day-number">${day}</span><div class="events-container">${chips}</div>`;
            cell.addEventListener('click', event => {
                if (event.target.closest('.calendar-event-pill')) return;
                selectedDate = date;
                selectedCategory = '';
                renderCalendar();
                showDateDetails(date);
                openDetailsModal(date, 'All');
            });
            grid.appendChild(cell);
        }
        const trailing = (7 - ((firstWeekday + daysInMonth) % 7)) % 7;
        for (let day = 1; day <= trailing; day++) {
            const cell = document.createElement('div');
            cell.className = 'calendar-day-cell other-month';
            cell.innerHTML = `<span class="day-number">${day}</span>`;
            grid.appendChild(cell);
        }
        grid.querySelectorAll('.calendar-event-pill').forEach(chip => chip.addEventListener('click', event => {
            event.stopPropagation();
            selectCategory(chip.dataset.date, chip.dataset.category);
        }));
    }

    /* ---------- Category popup ---------- */
    function selectCategory(date, category) {
        selectedDate = date;
        selectedCategory = category;
        renderCalendar();
        updateCategoryFilterButtons(category);
        openDetailsModal(date, category);
    }

    function formatLongDate(date) {
        return new Date(`${date}T00:00:00`).toLocaleDateString('en-GB', {day: '2-digit', month: 'short', year: 'numeric'});
    }

    /** Popup for a date: category tabs (All + each category present that day) and the entries of the active tab. */
    function openDetailsModal(date, category = 'All') {
        popupDate = date;
        const dayEntries = diaryEntries.filter(entry => entry.entry_date === date);
        const present = [...new Set(dayEntries.map(entry => entry.category || 'General'))];
        popupCategory = category === 'All' || present.includes(category) ? category : 'All';
        document.getElementById('diaryDetailsTitle').textContent = formatLongDate(date);
        renderDetailsPopup();
        detailsModal.classList.add('active');
        (detailsBody.closest('.modal-dialog')?.querySelector('.diary-details-tab.active') || document.getElementById('closeDiaryDetails')).focus();
    }

    function renderDetailsPopup() {
        const dayEntries = diaryEntries.filter(entry => entry.entry_date === popupDate);
        const present = [...new Set(dayEntries.map(entry => entry.category || 'General'))];
        const matches = popupCategory === 'All' ? dayEntries : dayEntries.filter(entry => (entry.category || 'General') === popupCategory);
        const tabsEl = document.getElementById('diaryDetailsTabs');
        const tab = (label, count, cls, active) => `<button type="button" role="tab" aria-selected="${active}" class="diary-details-tab ${cls}${active ? ' active' : ''}" data-tab-category="${escapeHTML(label)}">${escapeHTML(label)} <span class="diary-details-tab-count">${count}</span></button>`;
        tabsEl.innerHTML = dayEntries.length
            ? tab('All', dayEntries.length, 'event-cat-all', popupCategory === 'All') + present.map(c => tab(c, dayEntries.filter(e => (e.category || 'General') === c).length, categoryClass(c), popupCategory === c)).join('')
            : '';
        document.getElementById('diaryDetailsSubtitle').textContent = dayEntries.length
            ? `${matches.length} ${matches.length === 1 ? 'entry' : 'entries'}${popupCategory === 'All' ? '' : ' in ' + popupCategory} on this day`
            : 'Nothing is scheduled on this day.';
        detailsBody.innerHTML = matches.length
            ? matches.map(renderEntry).join('')
            : '<p class="diary-empty-note">No diary entries, activities or events on this date.</p>';
        detailsBody.scrollTop = 0;
        const footer = document.getElementById('diaryDetailsFooter');
        footer.innerHTML = popupDate >= localToday() ? `<button type="button" class="btn-primary-green" id="diaryDetailsAddBtn">＋ <span>Add entry for this day</span></button>` : '';
        document.getElementById('diaryDetailsAddBtn')?.addEventListener('click', () => { closeDetailsModal(); openNewDiaryModal(popupDate); });
    }

    document.getElementById('diaryDetailsTabs')?.addEventListener('click', event => {
        const button = event.target.closest('[data-tab-category]');
        if (!button) return;
        popupCategory = button.dataset.tabCategory;
        renderDetailsPopup();
        document.querySelector('#diaryDetailsTabs .diary-details-tab.active')?.focus();
    });

    function closeDetailsModal() {
        detailsModal?.classList.remove('active');
    }

    document.getElementById('closeDiaryDetails')?.addEventListener('click', closeDetailsModal);
    detailsModal?.addEventListener('click', event => {
        if (event.target.id === 'diaryDetailsModal') closeDetailsModal();
    });

    /* ---------- Bottom panel ---------- */
    function showDateDetails(date) {
        const matches = diaryEntries.filter(entry => entry.entry_date === date);
        updateCategoryFilterButtons('');
        if (!matches.length) {
            details.innerHTML = `<div class="diary-selected-context"><strong>${escapeHTML(date)}</strong></div><p class="diary-empty-note">No entries on this date. Use “New Diary Entry” to add one.</p>`;
            return;
        }
        const foundCategories = [...new Set(matches.map(entry => entry.category || 'General'))];
        details.innerHTML = `<div class="diary-selected-context"><strong>${escapeHTML(date)}</strong><span>Choose a category on this date to view its entries.</span></div><div class="diary-detail-category-list">${foundCategories.map(category => `<button type="button" class="calendar-event-pill ${categoryClass(category)}" data-category="${escapeHTML(category)}">${escapeHTML(category)}</button>`).join('')}</div>`;
        details.querySelectorAll('.calendar-event-pill').forEach(button => button.addEventListener('click', () => selectCategory(date, button.dataset.category)));
    }

    function updateCategoryFilterButtons(category) {
        document.querySelectorAll('[data-filter-category]').forEach(button => {
            const active = button.dataset.filterCategory === category;
            button.classList.toggle('active', active);
            button.setAttribute('aria-pressed', String(active));
        });
    }

    function filterDetailsByCategory(category) {
        selectedDate = '';
        selectedCategory = category;
        renderCalendar();
        updateCategoryFilterButtons(category);
        const matches = diaryEntries.filter(entry => (entry.category || 'General') === category);
        const heading = `<div class="diary-selected-context"><span class="calendar-event-pill ${categoryClass(category)}">${escapeHTML(category)}</span><span>${matches.length} ${matches.length === 1 ? 'entry' : 'entries'} this month</span></div>`;
        details.innerHTML = heading + (matches.length
            ? matches.map(renderEntry).join('')
            : '<p class="diary-empty-note">No entries in this category for the displayed month.</p>');
    }

    function entryProjects(entry) {
        if (Array.isArray(entry.projects) && entry.projects.length) return entry.projects;
        if (entry.project_id) return [{id: entry.project_id, title: entry.project_title || entry.programme_title || `Project #${entry.project_id}`}];
        return [];
    }

    function renderEntry(entry) {
        const corporateBusiness = /corporate business/i.test(`${entry.title || ''} ${entry.content || ''}`);
        const isMeeting = String(entry.category || '').toLowerCase() === 'meeting';
        const projects = (isMeeting || corporateBusiness) ? [] : entryProjects(entry);
        const projectCard = item => {
            const full = String(item.title || `Project #${item.id}`);
            const sep = full.indexOf(' — ');
            const programme = sep > -1 ? full.slice(0, sep) : '';
            const name = sep > -1 ? full.slice(sep + 3) : full;
            return `<li class="diary-linked-project-line"><span>${escapeHTML(full)}</span><a class="diary-linked-project-view" href="${appUrl(`modules/projects.php?id=${encodeURIComponent(item.id)}`)}">View details →</a></li>`;
        };
        const project = projects.length
            ? `<div class="diary-linked-projects"><div class="diary-linked-head"><span class="diary-linked-icon" aria-hidden="true">▣</span><strong>Linked ${projects.length === 1 ? 'project' : 'projects'}</strong><span class="diary-linked-count">${projects.length}</span></div><ul class="diary-linked-list">${projects.map(projectCard).join('')}</ul></div>`
            : `<div class="diary-unlinked-note">This entry is not linked to a project.</div>`;
        const detail = [entry.location && `<div><strong>Location:</strong> ${escapeHTML(entry.location)}</div>`, entry.host && `<div><strong>Host / Contact:</strong> ${escapeHTML(entry.host)}</div>`, entry.attendees && `<div><strong>Attendees:</strong> ${escapeHTML(entry.attendees)}</div>`].filter(Boolean).join('');
        const actions = entry.id ? `<span class="diary-entry-actions"><button type="button" class="diary-action-btn" data-diary-action="edit" data-entry-id="${escapeHTML(entry.id)}">Edit</button><button type="button" class="diary-action-btn danger" data-diary-action="delete" data-entry-id="${escapeHTML(entry.id)}">Delete</button></span>` : '';
        const location = String(entry.location || '').trim().toLowerCase();
        const outsideOffice = location !== '' && !/office|afya house|boardroom|headquarters/.test(location);
        const isDeadline = String(entry.category || '').toLowerCase() === 'deadline';
        const showActivitiesLink = !isMeeting && !isDeadline && !corporateBusiness && outsideOffice;
        const activitiesLink = showActivitiesLink ? `<a class="diary-events-ref" href="${appUrl(`modules/events.php#event-${encodeURIComponent(entry.id)}`)}">View in Activities &amp; Events →</a>` : '';
        const attendanceRequest = entry.attendance_request?.status === 'pending' ? `<section class="diary-attendance-request" style="margin-top:12px;padding:12px;background:#eff6ff;border:1px solid #bfdbfe;border-radius:9px;"><strong style="display:block;color:#1e3a8a;margin-bottom:6px;">You are listed as an attendee</strong><label style="display:block;font-size:.76rem;color:#334155;">Remarks<textarea data-attendance-remarks="${escapeHTML(entry.id)}" rows="2" maxlength="5000" style="display:block;width:100%;box-sizing:border-box;margin-top:5px;padding:8px;border:1px solid #cbd5e1;border-radius:6px;font:inherit;" placeholder="Add a brief reason for excusing yourself"></textarea></label><button type="button" data-diary-attendance="${escapeHTML(entry.attendance_request.id)}" data-entry-id="${escapeHTML(entry.id)}" style="margin-top:8px;background:#1d4ed8;color:#fff;border:0;border-radius:6px;padding:7px 11px;font-weight:800;cursor:pointer;">Excuse myself</button></section>` : '';
        return `<article class="diary-entry-detail"><div class="diary-entry-topline"><span class="${categoryClass(entry.category)}">${escapeHTML(entry.category || 'General')}</span><span>${escapeHTML(formatLongDate(entry.entry_date))} · ${escapeHTML(String(entry.entry_time || 'Time not set').slice(0, 5))} · ${escapeHTML(entry.priority || 'Medium')} priority</span>${entry.status ? `<span class="diary-status-badge status-${escapeHTML(String(entry.status).toLowerCase())}">${escapeHTML(statusLabel(entry.status))}</span>` : ''}${actions}</div><h4>${escapeHTML(entry.title)}</h4>${entry.content ? `<p>${escapeHTML(entry.content)}</p>` : ''}${detail ? `<div class="diary-entry-meta">${detail}</div>` : ''}${project}${activitiesLink}${attendanceRequest}</article>`;
    }

    /* ---------- Edit / delete (popup and bottom panel) ---------- */
    const handleEntryAction = event => {
        const button = event.target.closest('[data-diary-action]');
        if (!button) return;
        const entry = diaryEntries.find(item => String(item.id) === button.dataset.entryId);
        if (!entry) return;
        closeDetailsModal();
        if (button.dataset.diaryAction === 'edit') openEditDiaryModal(entry);
        else openDeleteModal(entry);
    };
    details?.addEventListener('click', handleEntryAction);
    detailsBody?.addEventListener('click', handleEntryAction);
    detailsBody?.addEventListener('click', async event => {
        const button = event.target.closest('[data-diary-attendance]');
        if (!button) return;
        const remarks = detailsBody.querySelector(`[data-attendance-remarks="${button.dataset.entryId}"]`)?.value.trim() || '';
        button.disabled = true;
        try {
            await postDiary({action: 'respond_attendance', response_id: button.dataset.diaryAttendance, remarks});
            await loadDiaryEntries();
            openDetailsModal(popupDate, popupCategory);
        } catch (error) {
            button.disabled = false;
            const section = button.closest('.diary-attendance-request');
            let note = section?.querySelector('[role="alert"]');
            if (!note && section) { note = document.createElement('p'); note.setAttribute('role', 'alert'); note.style.color = '#b91c1c'; section.appendChild(note); }
            if (note) note.textContent = error.message;
        }
    });

    function openDeleteModal(entry) {
        pendingDeleteId = entry.id;
        document.getElementById('deleteDiaryText').textContent = `“${entry.title}” on ${formatLongDate(entry.entry_date)} will be permanently removed. This can’t be undone.`;
        document.getElementById('deleteDiaryError').hidden = true;
        document.getElementById('deleteDiaryModal').classList.add('active');
        document.getElementById('cancelDeleteBtn').focus();
    }
    function closeDeleteModal() {
        pendingDeleteId = null;
        document.getElementById('deleteDiaryModal')?.classList.remove('active');
    }
    document.getElementById('cancelDeleteBtn')?.addEventListener('click', closeDeleteModal);
    document.getElementById('deleteDiaryModal')?.addEventListener('click', event => {
        if (event.target.id === 'deleteDiaryModal') closeDeleteModal();
    });
    document.getElementById('confirmDeleteBtn')?.addEventListener('click', async () => {
        if (pendingDeleteId === null) return;
        const button = document.getElementById('confirmDeleteBtn');
        const errorBox = document.getElementById('deleteDiaryError');
        errorBox.hidden = true;
        button.disabled = true;
        try {
            await postDiary({action: 'delete', id: pendingDeleteId});
            closeDeleteModal();
            await loadDiaryEntries();
        } catch (error) {
            errorBox.textContent = error.message;
            errorBox.hidden = false;
        } finally {
            button.disabled = false;
        }
    });

    /* ---------- Navigation / filters ---------- */
    document.getElementById('prevMonthBtn')?.addEventListener('click', () => {
        currentMonth--;
        if (currentMonth < 0) { currentMonth = 11; currentYear--; }
        selectedDate = ''; selectedCategory = '';
        details.innerHTML = '<p class="diary-empty-note">Loading diary entries…</p>';
        loadDiaryEntries();
    });
    document.getElementById('nextMonthBtn')?.addEventListener('click', () => {
        currentMonth++;
        if (currentMonth > 11) { currentMonth = 0; currentYear++; }
        selectedDate = ''; selectedCategory = '';
        details.innerHTML = '<p class="diary-empty-note">Loading diary entries…</p>';
        loadDiaryEntries();
    });
    document.getElementById('clearDiarySelection')?.addEventListener('click', () => {
        selectedDate = ''; selectedCategory = '';
        renderCalendar();
        updateCategoryFilterButtons('');
        details.innerHTML = '<p class="diary-empty-note">Select a category on the calendar to view its entries.</p>';
    });
    document.querySelectorAll('[data-filter-category]').forEach(button => button.addEventListener('click', () => {
        // Clicking the active category again clears the filter.
        if (button.getAttribute('aria-pressed') === 'true') { document.getElementById('clearDiarySelection')?.click(); return; }
        filterDetailsByCategory(button.dataset.filterCategory);
    }));
    document.getElementById('addDiaryEntryBtn')?.addEventListener('click', () => openNewDiaryModal(selectedDate || localToday()));

    /* ---------- Create / update ---------- */
    form?.addEventListener('submit', async event => {
        event.preventDefault();
        const errorBox = document.getElementById('diaryFormError');
        const submitBtn = document.getElementById('diarySubmitBtn');
        errorBox.hidden = true;
        const dateInput = document.getElementById('diaryDate');
        const today = localToday();
        const isEdit = diaryModalState.id !== null;
        // When editing, an entry that is already in the past may keep its own date.
        const keepingOwnDate = isEdit && dateInput.value === diaryModalState.originalDate;
        if (!dateInput.value || (dateInput.value < today && !keepingOwnDate)) {
            errorBox.textContent = 'Diary entries can’t be scheduled for a past date. Choose today or a future date.';
            errorBox.hidden = false;
            dateInput.focus();
            return;
        }
        const payload = {
            action: isEdit ? 'update' : 'create',
            title: document.getElementById('diaryTitle').value.trim(),
            content: document.getElementById('diaryContent').value.trim(),
            entry_date: dateInput.value,
            entry_time: document.getElementById('diaryTime').value,
            category: document.getElementById('diaryCategory').value,
            priority: document.getElementById('diaryPriority').value,
            status: document.getElementById('diaryStatus').value,
            project_ids: selectedProjectIds(),
            location: document.getElementById('diaryLocation').value.trim(),
            host: document.getElementById('diaryHost').value.trim(),
            attendees: document.getElementById('diaryAttendees').value.trim()
        };
        if (isEdit) payload.id = diaryModalState.id;
        submitBtn.disabled = true;
        try {
            await postDiary(payload);
            closeNewDiaryModal();
            currentYear = Number(payload.entry_date.slice(0, 4));
            currentMonth = Number(payload.entry_date.slice(5, 7)) - 1;
            await loadDiaryEntries({date: payload.entry_date, category: payload.category});
        } catch (error) {
            errorBox.textContent = error.message;
            errorBox.hidden = false;
        } finally {
            submitBtn.disabled = false;
        }
    });

    document.getElementById('newDiaryModal')?.addEventListener('click', event => {
        if (event.target.id === 'newDiaryModal') closeNewDiaryModal();
    });
    document.addEventListener('keydown', event => {
        if (event.key === 'Escape') { closeDetailsModal(); closeNewDiaryModal(); closeDeleteModal(); }
    });

    initProjectPicker();
    // Deep link from Activities & Events: diary.php?date=YYYY-MM-DD[&category=Field+Visit]
    const params = new URLSearchParams(window.location.search);
    const linkedDate = params.get('date') || '';
    if (/^\d{4}-\d{2}-\d{2}$/.test(linkedDate)) {
        currentYear = Number(linkedDate.slice(0, 4));
        currentMonth = Number(linkedDate.slice(5, 7)) - 1;
        loadDiaryEntries().then(() => {
            selectedDate = linkedDate;
            renderCalendar();
            openDetailsModal(linkedDate, params.get('category') || 'All');
        });
    } else {
        loadDiaryEntries();
    }
});

/* ================= Project multi-select ================= */
function initProjectPicker() {
    const list = document.getElementById('diaryProjectList');
    const search = document.getElementById('diaryProjectSearch');
    if (!list) return;
    list.addEventListener('change', renderSelectedProjects);
    search?.addEventListener('input', filterProjectOptions);
    // Enter in the search box must not submit the whole form.
    search?.addEventListener('keydown', event => { if (event.key === 'Enter') event.preventDefault(); });
    document.getElementById('diaryProjectSelected')?.addEventListener('click', event => {
        const remove = event.target.closest('[data-remove-project]');
        if (!remove) return;
        const box = [...list.querySelectorAll('input[type="checkbox"]')].find(input => input.value === remove.dataset.removeProject);
        if (box) { box.checked = false; renderSelectedProjects(); }
    });
}
function filterProjectOptions() {
    const query = (document.getElementById('diaryProjectSearch')?.value || '').trim().toLowerCase();
    let visible = 0;
    document.querySelectorAll('#diaryProjectList .diary-project-option').forEach(option => {
        const show = !query || (option.dataset.search || '').includes(query);
        option.hidden = !show;
        if (show) visible++;
    });
    const none = document.getElementById('diaryProjectNoMatch');
    if (none) none.hidden = visible > 0;
}
function selectedProjectIds() {
    return [...document.querySelectorAll('#diaryProjectList input[type="checkbox"]:checked')].map(input => Number(input.value));
}
function setSelectedProjects(ids) {
    const wanted = new Set((ids || []).map(String));
    document.querySelectorAll('#diaryProjectList input[type="checkbox"]').forEach(input => { input.checked = wanted.has(input.value); });
    const search = document.getElementById('diaryProjectSearch');
    if (search) search.value = '';
    filterProjectOptions();
    renderSelectedProjects();
}
function renderSelectedProjects() {
    const holder = document.getElementById('diaryProjectSelected');
    const hint = document.getElementById('diaryProjectHint');
    const checked = [...document.querySelectorAll('#diaryProjectList input[type="checkbox"]:checked')];
    if (holder) {
        holder.innerHTML = checked.map(input => {
            const label = input.parentElement.querySelector('span')?.textContent || `Project #${input.value}`;
            return `<span class="diary-project-chip" title="${escapeHTML(label)}"><span>${escapeHTML(label)}</span><button type="button" data-remove-project="${escapeHTML(input.value)}" aria-label="Remove ${escapeHTML(label)}">×</button></span>`;
        }).join('');
    }
    if (hint) hint.textContent = checked.length ? `${checked.length} project${checked.length === 1 ? '' : 's'} linked.` : 'No project linked — this will be a standalone entry.';
}

/* ================= Modal helpers ================= */
function todayString() {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}
function setDiaryModalMode(isEdit) {
    document.getElementById('diaryModalTitle').textContent = isEdit ? 'Edit Diary Entry' : 'Schedule New Diary Entry';
    const subtitle = document.getElementById('diaryModalSubtitle');
    if (subtitle) subtitle.textContent = isEdit ? 'Update the activity, schedule and linked projects.' : 'Capture the activity, schedule and project details.';
    document.getElementById('diarySubmitBtn').textContent = isEdit ? 'Save Changes' : 'Save Diary Entry';
}
function resetDiaryForm() {
    document.getElementById('newDiaryForm').reset();
    document.querySelectorAll('#diaryCategory option[data-temp], #diaryPriority option[data-temp], #diaryStatus option[data-temp]').forEach(option => option.remove());
    setSelectedProjects([]);
    document.getElementById('diaryFormError').hidden = true;
}
function ensureOption(select, value) {
    if (value && ![...select.options].some(option => option.value === value)) {
        const option = new Option(value, value);
        option.dataset.temp = '1';
        select.add(option);
    }
}
function showDiaryModal() {
    document.getElementById('newDiaryModal').classList.add('active');
    document.getElementById('diaryTitle').focus();
}

function openNewDiaryModal(dateStr) {
    if (!document.getElementById('newDiaryModal')) return;
    diaryModalState.id = null;
    diaryModalState.originalDate = '';
    resetDiaryForm();
    setDiaryModalMode(false);
    const today = todayString();
    const dateInput = document.getElementById('diaryDate');
    dateInput.min = today;
    dateInput.value = dateStr && dateStr >= today ? dateStr : today;
    document.getElementById('diaryTime').value = '09:00';
    showDiaryModal();
}
function openNewDiaryModalWithDate(dateStr) { openNewDiaryModal(dateStr); }

function openEditDiaryModal(entry) {
    if (!document.getElementById('newDiaryModal') || !entry) return;
    diaryModalState.id = entry.id;
    diaryModalState.originalDate = entry.entry_date;
    resetDiaryForm();
    setDiaryModalMode(true);
    const today = todayString();
    const dateInput = document.getElementById('diaryDate');
    // Allow the entry's own (possibly past) date to stay; any new date must still be today or later.
    dateInput.min = entry.entry_date < today ? entry.entry_date : today;
    dateInput.value = entry.entry_date;
    document.getElementById('diaryTitle').value = entry.title || '';
    document.getElementById('diaryTime').value = entry.entry_time ? String(entry.entry_time).slice(0, 5) : '';
    const category = document.getElementById('diaryCategory');
    ensureOption(category, entry.category);          // e.g. legacy values like "Field Visit"
    category.value = entry.category || 'General';
    const priority = document.getElementById('diaryPriority');
    ensureOption(priority, entry.priority);
    priority.value = entry.priority || 'Medium';
    const statusSel = document.getElementById('diaryStatus');
    ensureOption(statusSel, String(entry.status || 'UPCOMING').toUpperCase());
    statusSel.value = String(entry.status || 'UPCOMING').toUpperCase();
    document.getElementById('diaryLocation').value = entry.location || '';
    document.getElementById('diaryHost').value = entry.host || '';
    document.getElementById('diaryAttendees').value = entry.attendees || '';
    document.getElementById('diaryContent').value = entry.content || '';
    const ids = Array.isArray(entry.projects) && entry.projects.length ? entry.projects.map(p => p.id) : (entry.project_id ? [entry.project_id] : []);
    setSelectedProjects(ids);
    showDiaryModal();
}
function closeNewDiaryModal() { document.getElementById('newDiaryModal')?.classList.remove('active'); }
function escapeHTML(value) {
    return String(value ?? '').replace(/[&<>"']/g, character => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[character]));
}
