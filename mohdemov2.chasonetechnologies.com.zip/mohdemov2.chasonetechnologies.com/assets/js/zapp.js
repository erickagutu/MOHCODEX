/**
 * Global Application JavaScript
 * Ministry of Health — State Department for Medical Services (PP-SDOMS)
 */

document.addEventListener('DOMContentLoaded', () => {
    // Dismiss modals when clicking on overlay
    document.querySelectorAll('.modal-overlay').forEach(modal => {
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.classList.remove('active');
            }
        });
    });

    // Close button event handlers
    document.querySelectorAll('.modal-close-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const modal = btn.closest('.modal-overlay');
            if (modal) modal.classList.remove('active');
        });
    });

    const notificationButton = document.getElementById('notificationButton');
    const notificationPanel = document.getElementById('notificationPanel');
    const notificationList = document.getElementById('notificationList');
    const notificationBadge = document.getElementById('notificationBadge');
    const notificationSummary = document.getElementById('notificationSummary');
    const markAllButton = document.getElementById('notificationMarkAll');
    const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '';

    if (!notificationButton || !notificationPanel || !notificationList) return;

    const apiUrl = window.appUrl ? window.appUrl('api/notifications.php') : 'api/notifications.php';
    const setUnreadCount = (count) => {
        const unread = Math.max(0, Number(count) || 0);
        notificationBadge.textContent = unread > 99 ? '99+' : String(unread);
        notificationBadge.hidden = unread === 0;
        notificationButton.setAttribute('aria-label', `System notifications${unread ? `, ${unread} unread` : ''}`);
        notificationSummary.textContent = unread ? `${unread} unread` : 'You are all caught up';
    };

    const renderNotifications = (notifications) => {
        notificationList.replaceChildren();
        if (!notifications.length) {
            const empty = document.createElement('p');
            empty.className = 'notification-empty';
            empty.textContent = 'No notifications yet.';
            notificationList.appendChild(empty);
            return;
        }

        notifications.forEach((notification) => {
            const link = document.createElement('a');
            const isRead = Number(notification.is_read) === 1;
            link.className = `notification-item${isRead ? '' : ' unread'}`;
            link.href = notification.link || '#';
            link.dataset.notificationId = String(notification.id);
            link.dataset.href = notification.link || '';

            const dot = document.createElement('span');
            dot.className = 'notification-item-dot';
            dot.setAttribute('aria-hidden', 'true');

            const content = document.createElement('span');
            content.className = 'notification-item-content';

            const title = document.createElement('span');
            title.className = 'notification-item-title';
            title.textContent = notification.title || 'Notification';

            const message = document.createElement('span');
            message.className = 'notification-item-message';
            message.textContent = notification.message || '';

            const time = document.createElement('span');
            time.className = 'notification-item-time';
            const timestamp = notification.created_at ? new Date(String(notification.created_at).replace(' ', 'T')) : null;
            time.textContent = timestamp && !Number.isNaN(timestamp.getTime())
                ? timestamp.toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' })
                : '';

            content.append(title, message, time);
            link.append(dot, content);
            notificationList.appendChild(link);
        });
    };

    const loadNotifications = async () => {
        try {
            const response = await fetch(apiUrl, {
                credentials: 'same-origin',
                headers: { Accept: 'application/json' }
            });
            const data = await response.json();
            if (!response.ok || !data.success) throw new Error(data.error || 'Unable to load notifications.');
            setUnreadCount(data.unread_count);
            renderNotifications(Array.isArray(data.notifications) ? data.notifications : []);
        } catch (error) {
            notificationSummary.textContent = 'Could not load updates';
            notificationList.replaceChildren();
            const message = document.createElement('p');
            message.className = 'notification-empty';
            message.textContent = 'Notifications are temporarily unavailable.';
            notificationList.appendChild(message);
        }
    };

    const postNotificationAction = async (action, id) => {
        const response = await fetch(apiUrl, {
            method: 'POST',
            credentials: 'same-origin',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-Token': csrfToken,
                Accept: 'application/json'
            },
            body: JSON.stringify({ action, id })
        });
        const data = await response.json();
        if (!response.ok || !data.success) throw new Error(data.error || 'Could not update notification.');
        setUnreadCount(data.unread_count);
    };

    notificationButton.addEventListener('click', async () => {
        const isOpen = notificationButton.getAttribute('aria-expanded') === 'true';
        notificationButton.setAttribute('aria-expanded', String(!isOpen));
        notificationPanel.hidden = isOpen;
        if (!isOpen) await loadNotifications();
    });

    notificationList.addEventListener('click', async (event) => {
        const target = event.target instanceof Element ? event.target.closest('.notification-item') : null;
        if (!target) return;
        event.preventDefault();
        const href = target.dataset.href || '';
        try {
            await postNotificationAction('mark_read', target.dataset.notificationId);
            await loadNotifications();
        } catch (error) {
            // Keep the notification panel usable if a read-state update fails.
        }
        if (href) window.location.assign(href);
    });

    if (markAllButton) {
        markAllButton.addEventListener('click', async () => {
            try {
                await postNotificationAction('mark_all_read');
                await loadNotifications();
            } catch (error) {
                notificationSummary.textContent = 'Could not update notifications';
            }
        });
    }

    document.addEventListener('click', (event) => {
        if (event.target instanceof Node
            && !notificationPanel.contains(event.target)
            && !notificationButton.contains(event.target)) {
            notificationPanel.hidden = true;
            notificationButton.setAttribute('aria-expanded', 'false');
        }
    });

    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && !notificationPanel.hidden) {
            notificationPanel.hidden = true;
            notificationButton.setAttribute('aria-expanded', 'false');
            notificationButton.focus();
        }
    });

    loadNotifications();
});
