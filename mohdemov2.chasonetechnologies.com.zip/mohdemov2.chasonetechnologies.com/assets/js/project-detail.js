/**
 * Project Details & Monthly KPI Tracker JavaScript
 * Ministry of Health — State Department for Medical Services (PP-SDOMS)
 * Vanilla JavaScript / Fetch API / Chart.js (Zero Node.js)
 */

document.addEventListener('DOMContentLoaded', () => {
    const projectId = window.CURRENT_PROJECT_ID;
    if (!projectId) return;

    let kpiLineChartInstance = null;
    let budgetChartInstance = null;
    let monthlyRecordsData = [];
    let currentKpiCode = 'All';

    // 1. Collapsible Project Details
    const toggleBtn = document.getElementById('toggleDetailsBtn');
    const detailsContent = document.getElementById('projectDetailsCollapsible');
    if (toggleBtn && detailsContent) {
        toggleBtn.addEventListener('click', () => {
            const isHidden = detailsContent.style.display === 'none';
            detailsContent.style.display = isHidden ? 'block' : 'none';
            toggleBtn.innerHTML = isHidden 
                ? `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="18 15 12 9 6 15"></polyline></svg> HIDE DETAILS` 
                : `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"></polyline></svg> VIEW DETAILS`;
        });
    }

    // 2. Fetch Project Detail & Monthly KPI Records
    async function loadProjectData() {
        try {
            const res = await fetch(window.appUrl(`api/project-detail.php?id=${projectId}`));
            const data = await res.json();
            if (!data.success) {
                alert('Failed to load project details: ' + data.error);
                return;
            }

            const p = data.project;
            monthlyRecordsData = data.monthly_progress || [];

            // Initialize Financial Budget Bar Chart
            initBudgetChart(p);

            // Populate KPI selector
            populateKpiSelector(monthlyRecordsData);

            // Render Monthly KPI Progress Line/Bar Chart
            renderMonthlyKpiChart(currentKpiCode);

            // Render Monthly KPI Table
            renderMonthlyKpiTable(monthlyRecordsData);

        } catch (err) {
            console.error('Error loading project data:', err);
        }
    }

    // 3. Financial Budget Bar Chart (matching project-details.jpeg)
    function initBudgetChart(project) {
        const budgetCtx = document.getElementById('projectBudgetChart');
        if (!budgetCtx || typeof Chart === 'undefined') return;

        const totalBudget = parseFloat(project.total_budget) || 0;
        const disbursed = parseFloat(project.funds_disbursed) || 0;
        const utilized = parseFloat(project.funds_utilized) || 0;

        if (budgetChartInstance) budgetChartInstance.destroy();

        budgetChartInstance = new Chart(budgetCtx, {
            type: 'bar',
            data: {
                labels: ['Total Budget', 'Funds Disbursed', 'Funds Utilized'],
                datasets: [{
                    label: 'Financial Allocation (KES)',
                    data: [totalBudget, disbursed, utilized],
                    backgroundColor: [
                        '#1a73e8', // Planned / Budget (Blue)
                        '#047857', // Completed / Disbursed (Green)
                        '#f59e0b'  // In Progress / Utilized (Yellow/Amber)
                    ],
                    borderRadius: 6,
                    barThickness: 45
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        callbacks: {
                            label: (ctx) => 'KES ' + Number(ctx.raw).toLocaleString('en-US', { minimumFractionDigits: 2 })
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: (v) => {
                                if (v >= 1e9) return (v / 1e9).toFixed(1) + 'B';
                                if (v >= 1e6) return (v / 1e6).toFixed(0) + 'M';
                                return v;
                            }
                        },
                        grid: { color: '#e2e8f0' }
                    },
                    x: {
                        grid: { display: false },
                        ticks: { font: { weight: '600' } }
                    }
                }
            }
        });
    }

    // 4. Populate KPI selector dropdown
    function populateKpiSelector(records) {
        const sel = document.getElementById('kpiFilterSelect');
        if (!sel) return;

        const uniqueKpis = {};
        records.forEach(r => {
            const code = r.kpi_code || 'General';
            if (!uniqueKpis[code]) {
                uniqueKpis[code] = r.kpi_name || code;
            }
        });

        sel.innerHTML = '<option value="All">All Linked KPIs (Composite)</option>';
        Object.entries(uniqueKpis).forEach(([code, name]) => {
            const opt = document.createElement('option');
            opt.value = code;
            opt.textContent = `${code} — ${name}`;
            sel.appendChild(opt);
        });

        sel.addEventListener('change', () => {
            currentKpiCode = sel.value;
            renderMonthlyKpiChart(currentKpiCode);
        });
    }

    // 5. Render Monthly KPI Progress Chart (Line + Bar Combination)
    function renderMonthlyKpiChart(kpiCodeFilter) {
        const chartCtx = document.getElementById('monthlyKpiProgressChart');
        if (!chartCtx || typeof Chart === 'undefined') return;

        let filtered = monthlyRecordsData;
        if (kpiCodeFilter !== 'All') {
            filtered = monthlyRecordsData.filter(r => (r.kpi_code || 'General') === kpiCodeFilter);
        }

        if (filtered.length === 0) {
            filtered = [
                { year_month: 'Jan 2026', target_pct: 60, achieved_pct: 60 },
                { year_month: 'Feb 2026', target_pct: 70, achieved_pct: 72 },
                { year_month: 'Mar 2026', target_pct: 80, achieved_pct: 82 },
                { year_month: 'Apr 2026', target_pct: 90, achieved_pct: 91 },
                { year_month: 'May 2026', target_pct: 95, achieved_pct: 94 }
            ];
        }

        const labels = filtered.map(r => r.year_month);
        const targetData = filtered.map(r => parseFloat(r.target_pct) || 0);
        const achievedData = filtered.map(r => parseFloat(r.achieved_pct) || 0);

        if (kpiLineChartInstance) kpiLineChartInstance.destroy();

        kpiLineChartInstance = new Chart(chartCtx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [
                    {
                        type: 'line',
                        label: 'Achieved Progress %',
                        data: achievedData,
                        borderColor: '#0d47a1',
                        backgroundColor: 'rgba(13, 71, 161, 0.1)',
                        borderWidth: 3,
                        pointBackgroundColor: '#0d47a1',
                        pointBorderColor: '#ffffff',
                        pointBorderWidth: 2,
                        pointRadius: 5,
                        fill: true,
                        tension: 0.3
                    },
                    {
                        type: 'bar',
                        label: 'Target %',
                        data: targetData,
                        backgroundColor: 'rgba(148, 163, 184, 0.35)',
                        borderColor: '#94a3b8',
                        borderWidth: 1,
                        borderRadius: 4,
                        barThickness: 24
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                interaction: {
                    mode: 'index',
                    intersect: false
                },
                plugins: {
                    legend: {
                        position: 'top',
                        labels: { font: { weight: '600' } }
                    },
                    tooltip: {
                        callbacks: {
                            label: (ctx) => `${ctx.dataset.label}: ${ctx.raw}%`
                        }
                    }
                },
                scales: {
                    y: {
                        min: 0,
                        max: 100,
                        ticks: {
                            callback: v => v + '%'
                        },
                        grid: { color: '#e2e8f0' }
                    },
                    x: {
                        grid: { display: false },
                        ticks: { font: { weight: '600' } }
                    }
                }
            }
        });
    }

    // 6. Render Monthly KPI Data Table
    function renderMonthlyKpiTable(records) {
        const tbody = document.getElementById('monthlyKpiTableBody');
        if (!tbody) return;

        if (records.length === 0) {
            tbody.innerHTML = `<tr><td colspan="8" style="text-align: center; color: #64748b; padding: 20px;">No monthly progress records recorded yet. Click "Add Monthly Progress" to record performance.</td></tr>`;
            return;
        }

        tbody.innerHTML = '';
        records.forEach(r => {
            const tr = document.createElement('tr');
            const targetVal = r.kpi_target ? `${r.kpi_target} ${r.kpi_unit || '%'}` : `${r.target_pct}%`;
            const achievedVal = r.kpi_achieved ? `${r.kpi_achieved} ${r.kpi_unit || '%'}` : `${r.achieved_pct}%`;
            const progressPct = parseFloat(r.progress_pct) || (parseFloat(r.achieved_pct) || 0);

            tr.innerHTML = `
                <td style="font-weight: 700; color: #0d47a1;">${escapeHTML(r.year_month)}</td>
                <td>
                    <span style="font-weight: 600; font-size: 0.8rem; background: #e2e8f0; padding: 2px 6px; border-radius: 4px;">
                        ${escapeHTML(r.kpi_code || 'General')}
                    </span>
                </td>
                <td style="font-size: 0.82rem; font-weight: 600;">${escapeHTML(r.kpi_name || 'Project KPI')}</td>
                <td style="font-family: monospace; font-weight: 600;">${escapeHTML(targetVal)}</td>
                <td style="font-family: monospace; font-weight: 700; color: #047857;">${escapeHTML(achievedVal)}</td>
                <td style="font-weight: 700;">
                    <span style="display: inline-block; padding: 2px 8px; border-radius: 12px; font-size: 0.78rem; background: ${progressPct >= 95 ? '#dcfce7; color: #15803d;' : progressPct >= 80 ? '#e0f2fe; color: #0369a1;' : '#fee2e2; color: #b91c1c;'}">
                        ${progressPct}%
                    </span>
                </td>
                <td style="font-size: 0.8rem; color: #475569; max-width: 250px;">${escapeHTML(r.remarks || '—')}</td>
                <td>
                    <button class="btn-icon-action" onclick="openEditMonthlyProgressModal(${JSON.stringify(r).replace(/"/g, '&quot;')})" title="Edit Monthly Progress">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20h9"></path><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"></path></svg>
                    </button>
                </td>
            `;
            tbody.appendChild(tr);
        });
    }

    // 7. Add / Edit Monthly KPI Form Submit
    const monthlyForm = document.getElementById('monthlyKpiForm');
    if (monthlyForm) {
        monthlyForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const submitBtn = monthlyForm.querySelector('button[type="submit"]');
            if (submitBtn) submitBtn.disabled = true;

            const payload = {
                id: document.getElementById('kpiEntryId').value || null,
                project_id: projectId,
                year_month: document.getElementById('kpiYearMonth').value.trim(),
                kpi_code: document.getElementById('kpiFormCode').value.trim(),
                kpi_name: document.getElementById('kpiFormName').value.trim(),
                kpi_unit: document.getElementById('kpiFormUnit').value.trim(),
                kpi_target: parseFloat(document.getElementById('kpiFormTarget').value) || 0,
                kpi_achieved: parseFloat(document.getElementById('kpiFormAchieved').value) || 0,
                target_pct: parseFloat(document.getElementById('kpiFormTargetPct').value) || 0,
                achieved_pct: parseFloat(document.getElementById('kpiFormAchievedPct').value) || 0,
                remarks: document.getElementById('kpiFormRemarks').value.trim()
            };

            try {
                const res = await fetch(window.appUrl('api/monthly-progress.php'), {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });
                const resData = await res.json();
                if (resData.success) {
                    closeMonthlyKpiModal();
                    await loadProjectData();
                } else {
                    alert('Error saving KPI progress: ' + resData.error);
                }
            } catch (err) {
                alert('Network error while saving KPI progress.');
            } finally {
                if (submitBtn) submitBtn.disabled = false;
            }
        });
    }

    // Load Data
    loadProjectData();
});

// Modal Global Functions
function openAddMonthlyProgressModal() {
    const modal = document.getElementById('monthlyKpiModal');
    if (!modal) return;
    document.getElementById('kpiModalTitle').textContent = 'Add Monthly KPI Progress';
    document.getElementById('monthlyKpiForm').reset();
    document.getElementById('kpiEntryId').value = '';
    modal.classList.add('active');
}

function openEditMonthlyProgressModal(r) {
    const modal = document.getElementById('monthlyKpiModal');
    if (!modal) return;
    document.getElementById('kpiModalTitle').textContent = 'Edit Monthly KPI Progress';
    document.getElementById('kpiEntryId').value = r.id;
    document.getElementById('kpiYearMonth').value = r.year_month || '';
    document.getElementById('kpiFormCode').value = r.kpi_code || '';
    document.getElementById('kpiFormName').value = r.kpi_name || '';
    document.getElementById('kpiFormUnit').value = r.kpi_unit || '%';
    document.getElementById('kpiFormTarget').value = r.kpi_target || '';
    document.getElementById('kpiFormAchieved').value = r.kpi_achieved || '';
    document.getElementById('kpiFormTargetPct').value = r.target_pct || '';
    document.getElementById('kpiFormAchievedPct').value = r.achieved_pct || '';
    document.getElementById('kpiFormRemarks').value = r.remarks || '';
    modal.classList.add('active');
}

function closeMonthlyKpiModal() {
    const modal = document.getElementById('monthlyKpiModal');
    if (modal) modal.classList.remove('active');
}

function escapeHTML(str) {
    if (!str) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}
