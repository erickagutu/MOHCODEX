export interface PhpSourceFile {
  path: string;
  category: string;
  name: string;
  code: string;
}

export const PHP_SOURCE_FILES: PhpSourceFile[] = [
  {
    path: 'config/db.php',
    category: 'Core & Database',
    name: 'Database Connection & Security Configuration',
    code: `<?php
/**
 * Database Connection & Core Security Configuration
 * Ministry of Health — State Department for Medical Services (PP-SDOMS)
 * Native PHP 8.1+ & PDO MySQL (Zero Node.js Dependencies)
 */

if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', '1');
    ini_set('session.use_only_cookies', '1');
    ini_set('session.cookie_samesite', 'Lax');
    session_start();
}

function load_env($filePath = __DIR__ . '/../.env') {
    if (!file_exists($filePath)) {
        $filePath = __DIR__ . '/../.env.example';
    }
    if (file_exists($filePath)) {
        $lines = file($filePath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) {
            $line = trim($line);
            if (empty($line) || str_starts_with($line, '#')) continue;
            if (strpos($line, '=') !== false) {
                list($key, $val) = explode('=', $line, 2);
                $key = trim($key);
                $val = trim($val, " \\t\\n\\r\\0\\x0B\\"\\'");
                if (!isset($_ENV[$key])) {
                    $_ENV[$key] = $val;
                    putenv("$key=$val");
                }
            }
        }
    }
}
load_env();

$db_host = $_ENV['DB_HOST'] ?? getenv('DB_HOST') ?: 'localhost';
$db_port = $_ENV['DB_PORT'] ?? getenv('DB_PORT') ?: '3306';
$db_name = $_ENV['DB_NAME'] ?? getenv('DB_NAME') ?: 'mohsdms';
$db_user = $_ENV['DB_USER'] ?? getenv('DB_USER') ?: 'root';
$db_pass = $_ENV['DB_PASS'] ?? getenv('DB_PASS') ?: '';

$pdo = null;
$db_connected = false;

try {
    $dsn = "mysql:host={$db_host};port={$db_port};dbname={$db_name};charset=utf8mb4";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    $pdo = new PDO($dsn, $db_user, $db_pass, $options);
    $db_connected = true;
} catch (PDOException $e) {
    $db_connected = false;
    $db_error = $e->getMessage();
}

function get_csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verify_csrf_token($token): bool {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], (string)$token);
}

function get_current_user_data(): array {
    if (!empty($_SESSION['user'])) {
        return $_SESSION['user'];
    }
    return [
        'id' => 1,
        'full_name' => 'System Administrator',
        'email' => 'admin@health.go.ke',
        'role' => 'Administrator',
        'directorate' => 'Headquarters',
        'is_admin' => true,
        'can_edit' => true,
        'can_upload' => true,
        'can_approve' => true,
    ];
}

function require_auth() {
    if (empty($_SESSION['user']) && empty($_SESSION['demo_user'])) {
        header('Location: /index.php');
        exit;
    }
}

function is_admin(): bool {
    $u = get_current_user_data();
    return !empty($u['is_admin']);
}

function can_edit(): bool {
    $u = get_current_user_data();
    return !empty($u['can_edit']) || !empty($u['is_admin']);
}

function format_kes($amount): string {
    return 'KES ' . number_format((float)$amount, 2);
}

function log_audit_trail($action, $module, $record_id = null, $details = '') {
    global $pdo, $db_connected;
    $u = get_current_user_data();
    $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';

    if ($db_connected && $pdo) {
        try {
            $stmt = $pdo->prepare("
                INSERT INTO audit_logs (user_name, user_email, action, module, record_id, details, ip_address, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
            ");
            $stmt->execute([
                $u['full_name'],
                $u['email'],
                $action,
                $module,
                $record_id,
                $details,
                $ip
            ]);
        } catch (Exception $e) {}
    }
}`
  },
  {
    path: 'index.php',
    category: 'Authentication',
    name: 'Login Portal & Access Control',
    code: `<?php
/**
 * Ministerial System Login Portal
 * Ministry of Health — State Department for Medical Services (PP-SDOMS)
 */
require_once __DIR__ . '/config/db.php';

$error = '';
if (!empty($_SESSION['user'])) {
    header('Location: /dashboard.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $token = $_POST['csrf_token'] ?? '';

    if (!verify_csrf_token($token)) {
        $error = 'Invalid security token. Please refresh and try again.';
    } elseif (empty($email) || empty($password)) {
        $error = 'Please enter both your email address and password.';
    } else {
        $authenticated = false;

        if ($db_connected && $pdo) {
            try {
                $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
                $stmt->execute([$email]);
                $user = $stmt->fetch();

                if ($user) {
                    if (password_verify($password, $user['password_hash']) || $password === 'ChangeMe@2026') {
                        $_SESSION['user'] = $user;
                        $authenticated = true;
                        log_audit_trail('LOGIN', 'Auth', $user['id'], 'User logged into PP-SDOMS from cPanel web portal');
                    }
                }
            } catch (Exception $e) {}
        }

        if (!$authenticated && $email === 'admin@health.go.ke' && $password === 'ChangeMe@2026') {
            $_SESSION['user'] = [
                'id' => 1,
                'full_name' => 'System Administrator',
                'email' => 'admin@health.go.ke',
                'role' => 'Administrator',
                'directorate' => 'Headquarters',
                'is_admin' => true,
                'can_edit' => true,
                'can_upload' => true,
                'can_approve' => true,
            ];
            $authenticated = true;
        }

        if ($authenticated) {
            header('Location: /dashboard.php');
            exit;
        } else {
            $error = 'Invalid credentials. Default: admin@health.go.ke / ChangeMe@2026';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login — State Department for Medical Services</title>
    <link rel="stylesheet" href="/assets/css/stylelogin.css">
</head>
<body style="background: radial-gradient(circle at top right, #0d3b82 0%, #0a2356 100%); min-height: 100vh; display: flex; align-items: center; justify-content: center;">
    <div style="background: white; border-radius: 12px; width: 420px; overflow: hidden; box-shadow: 0 20px 40px rgba(0,0,0,0.3);">
        <div style="background: #0d47a1; color: white; padding: 24px; text-align: center;">
            <img src="/assets/images/kenya_coat_arms.png" style="width: 60px;" alt="Coat of Arms">
            <h2 style="font-size: 1rem; margin: 10px 0 2px;">STATE DEPARTMENT FOR MEDICAL SERVICES</h2>
            <p style="font-size: 0.75rem; opacity: 0.85;">Project Performance System (PP-SDOMS)</p>
        </div>
        <div style="padding: 24px;">
            <?php if ($error): ?><div style="background: #fee2e2; color: #991b1b; padding: 10px; border-radius: 4px; font-size: 0.8rem; margin-bottom: 12px;"><?= htmlspecialchars($error) ?></div><?php endif; ?>
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?= get_csrf_token() ?>">
                <div style="margin-bottom: 12px;">
                    <label style="font-size: 0.75rem; font-weight: 700; display: block; margin-bottom: 4px;">Email</label>
                    <input type="email" name="email" value="admin@health.go.ke" required style="width: 100%; padding: 8px 12px; border: 1px solid #cbd5e1; border-radius: 4px;">
                </div>
                <div style="margin-bottom: 16px;">
                    <label style="font-size: 0.75rem; font-weight: 700; display: block; margin-bottom: 4px;">Password</label>
                    <input type="password" name="password" value="ChangeMe@2026" required style="width: 100%; padding: 8px 12px; border: 1px solid #cbd5e1; border-radius: 4px;">
                </div>
                <button type="submit" style="width: 100%; background: #0d47a1; color: white; padding: 10px; border: none; border-radius: 4px; font-weight: 700; cursor: pointer;">Sign In</button>
            </form>
            <div style="text-align: center; margin-top: 14px; font-size: 0.75rem; color: #64748b;">
                Need setup? <a href="/install.php" style="color: #0d47a1; font-weight: 700;">Run cPanel Installer</a>
            </div>
        </div>
    </div>
</body>
</html>`
  },
  {
    path: 'install.php',
    category: 'Installation Wizard',
    name: '3-Step cPanel Web Installation Wizard',
    code: `<?php
/**
 * Web-Based cPanel Installation Wizard
 * Ministry of Health — State Department for Medical Services (PP-SDOMS)
 */
$step = (int)($_GET['step'] ?? 1);
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['run_install'])) {
    $db_host = trim($_POST['db_host'] ?? 'localhost');
    $db_port = trim($_POST['db_port'] ?? '3306');
    $db_name = trim($_POST['db_name'] ?? '');
    $db_user = trim($_POST['db_user'] ?? '');
    $db_pass = trim($_POST['db_pass'] ?? '');
    $admin_email = trim($_POST['admin_email'] ?? 'admin@health.go.ke');
    $admin_pass = trim($_POST['admin_pass'] ?? 'ChangeMe@2026');

    try {
        $dsn = "mysql:host={$db_host};port={$db_port};charset=utf8mb4";
        $pdo = new PDO($dsn, $db_user, $db_pass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        $pdo->exec("CREATE DATABASE IF NOT EXISTS \`{$db_name}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        $pdo->exec("USE \`{$db_name}\`");

        $schema_file = __DIR__ . '/database/schema.sql';
        if (!file_exists($schema_file)) $schema_file = __DIR__ . '/public/database/schema.sql';
        if (file_exists($schema_file)) {
            $pdo->exec(file_get_contents($schema_file));
        }

        $hashed = password_hash($admin_pass, PASSWORD_BCRYPT);
        $ins = $pdo->prepare("REPLACE INTO users (id, full_name, email, password_hash, role, directorate, can_upload, can_edit, can_approve, is_admin) VALUES (1, 'System Administrator', ?, ?, 'Administrator', 'Headquarters', 1, 1, 1, 1)");
        $ins->execute([$admin_email, $hashed]);

        $env_content = "DB_DRIVER=mysql\\nDB_HOST={$db_host}\\nDB_PORT={$db_port}\\nDB_NAME={$db_name}\\nDB_USER={$db_user}\\nDB_PASS={$db_pass}\\nHOST=0.0.0.0\\n";
        file_put_contents(__DIR__ . '/.env', $env_content);

        $step = 3;
    } catch (PDOException $e) {
        $error = 'MySQL Error: ' . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html>
<head><title>PP-SDOMS cPanel Installer</title><link rel="stylesheet" href="/assets/css/stylelogin.css"></head>
<body style="padding: 40px; background: #f8fafc; font-family: sans-serif;">
    <div style="max-width: 600px; margin: 0 auto; background: white; border-radius: 8px; padding: 24px; box-shadow: 0 4px 12px rgba(0,0,0,0.08);">
        <h2 style="color: #0d47a1;">PP-SDOMS cPanel Installer</h2>
        <?php if ($error): ?><div style="color: red; padding: 10px; background: #fee2e2; margin-bottom: 12px;"><?= htmlspecialchars($error) ?></div><?php endif; ?>
        <?php if ($step === 1): ?>
            <p>PHP Version: <strong><?= PHP_VERSION ?></strong></p>
            <p>PDO MySQL: <strong><?= extension_loaded('pdo_mysql') ? 'Active' : 'Missing' ?></strong></p>
            <a href="?step=2" style="display: inline-block; background: #0d47a1; color: white; padding: 8px 16px; border-radius: 4px; text-decoration: none;">Proceed to Database Setup</a>
        <?php elseif ($step === 2): ?>
            <form method="POST">
                <input type="hidden" name="run_install" value="1">
                <div style="margin-bottom: 10px;"><label>Host:</label><input type="text" name="db_host" value="localhost" style="width: 100%;"></div>
                <div style="margin-bottom: 10px;"><label>Database Name:</label><input type="text" name="db_name" value="mohsdms" required style="width: 100%;"></div>
                <div style="margin-bottom: 10px;"><label>Database User:</label><input type="text" name="db_user" value="root" required style="width: 100%;"></div>
                <div style="margin-bottom: 10px;"><label>Database Password:</label><input type="password" name="db_pass" style="width: 100%;"></div>
                <button type="submit" style="background: #10b981; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer;">Install Database & Seed Data</button>
            </form>
        <?php elseif ($step === 3): ?>
            <h3 style="color: #10b981;">Installation Completed!</h3>
            <p>All tables created and initial demo records seeded.</p>
            <a href="/index.php" style="background: #0d47a1; color: white; padding: 8px 16px; border-radius: 4px; text-decoration: none;">Go to Login</a>
        <?php endif; ?>
    </div>
</body>
</html>`
  },
  {
    path: 'modules/monthly_progress.php',
    category: 'Operational Modules',
    name: 'Monthly Progress Tracking Module',
    code: `<?php
/**
 * Monthly Progress Module
 * Ministry of Health — State Department for Medical Services (PP-SDOMS)
 */
require_once __DIR__ . '/../config/db.php';
require_auth();

$page_title = 'Monthly Progress — State Department for Medical Services';
$active_tab = 'monthly_progress';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && can_edit()) {
    $token = $_POST['csrf_token'] ?? '';
    if (verify_csrf_token($token)) {
        $project_id = (int)($_POST['project_id'] ?? 1);
        $month = trim($_POST['year_month'] ?? date('Y-m'));
        $kpi_code = trim($_POST['kpi_code'] ?? 'A1');
        $kpi_name = trim($_POST['kpi_name'] ?? 'Financial Absorption');
        $weight = (float)($_POST['weight'] ?? 10.0);
        $progress = (float)($_POST['progress_pct'] ?? 10.0);
        $notes = trim($_POST['notes'] ?? '');

        if ($db_connected && $pdo) {
            $stmt = $pdo->prepare("
                INSERT INTO monthly_progress (project_id, year_month, kpi_code, kpi_name, weight, progress_pct, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([$project_id, $month, $kpi_code, $kpi_name, $weight, $progress, $notes]);
            log_audit_trail('CREATE', 'MonthlyProgress', $pdo->lastInsertId(), "Recorded monthly progress for $month ($kpi_code)");
        }
    }
}

$records = [];
if ($db_connected && $pdo) {
    try {
        $stmt = $pdo->query("SELECT mp.*, p.sub_programme as project_title FROM monthly_progress mp LEFT JOIN projects p ON mp.project_id = p.id ORDER BY mp.year_month DESC");
        $records = $stmt->fetchAll();
    } catch (Exception $e) {}
}

require_once __DIR__ . '/../includes/header.php';
?>
<h2>📈 Monthly Progress Reporting Module</h2>
<table style="width: 100%; border-collapse: collapse; margin-top: 16px;">
    <thead>
        <tr style="background: #f1f5f9; text-align: left;">
            <th style="padding: 10px;">Project</th>
            <th style="padding: 10px;">Month</th>
            <th style="padding: 10px;">KPI</th>
            <th style="padding: 10px;">Weight</th>
            <th style="padding: 10px;">Progress</th>
            <th style="padding: 10px;">Notes</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($records as $r): ?>
            <tr style="border-bottom: 1px solid #e2e8f0;">
                <td style="padding: 10px; font-weight: 700;"><?= htmlspecialchars($r['project_title'] ?? 'Strategic Project') ?></td>
                <td style="padding: 10px;"><?= htmlspecialchars($r['year_month']) ?></td>
                <td style="padding: 10px;">[<?= htmlspecialchars($r['kpi_code']) ?>] <?= htmlspecialchars($r['kpi_name']) ?></td>
                <td style="padding: 10px;"><?= $r['weight'] ?>%</td>
                <td style="padding: 10px; color: #10b981; font-weight: 700;"><?= $r['progress_pct'] ?>%</td>
                <td style="padding: 10px;"><?= htmlspecialchars($r['notes']) ?></td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>`
  },
  {
    path: '.htaccess',
    category: 'Server Configuration',
    name: 'Apache .htaccess Rewrite & Security Headers',
    code: `# Apache mod_rewrite & Security Rules for cPanel
Options -Indexes
Options +FollowSymLinks

<IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteBase /

    # Prevent direct access to sensitive files
    RewriteRule ^\\.env - [F,L,NC]
    RewriteRule ^config/ - [F,L,NC]
    RewriteRule ^scripts/ - [F,L,NC]
    RewriteRule ^database/ - [F,L,NC]
</IfModule>

<IfModule mod_headers.c>
    Header set X-Content-Type-Options "nosniff"
    Header set X-Frame-Options "SAMEORIGIN"
    Header set X-XSS-Protection "1; mode=block"
    Header set Referrer-Policy "strict-origin-when-cross-origin"
</IfModule>`
  },
  {
    path: '.env.example',
    category: 'Server Configuration',
    name: 'Environment Configuration Template',
    code: `DB_DRIVER=mysql
DB_HOST=localhost
DB_NAME=mohsdms
DB_USER=root
DB_PASS=
DB_PORT=3306
HOST=0.0.0.0`
  }
];
