<?php
/** Run daily from cPanel Cron Jobs. Sends one reminder per user the day before and on the event date. */
if (PHP_SAPI !== 'cli') { http_response_code(403); exit('CLI only'); }
require_once __DIR__ . '/../config/db.php';
if (!$db_connected || !$pdo) { fwrite(STDERR,"Database connection unavailable\n"); exit(1); }
date_default_timezone_set('Africa/Nairobi');
$today=(new DateTimeImmutable('today'))->format('Y-m-d');
$tomorrow=(new DateTimeImmutable('tomorrow'))->format('Y-m-d');
$st=$pdo->prepare("SELECT id,title,event_date,event_time,location FROM diary_events WHERE event_date IN (?,?) AND UPPER(COALESCE(status,'UPCOMING')) NOT IN ('CANCELLED','COMPLETED')");
$st->execute([$today,$tomorrow]);
foreach($st->fetchAll(PDO::FETCH_ASSOC) as $event){
 $date=(string)$event['event_date']; $when=$date===$today?'today':'tomorrow';
 $time=!empty($event['event_time'])?' at '.substr((string)$event['event_time'],0,5):'';
 $location=!empty($event['location'])?' — '.(string)$event['location']:'';
 $title=$date===$today?'Event scheduled for today':'Upcoming event reminder';
 $message=(string)$event['title'].' is scheduled '.$when.$time.$location.'.';
 notify_all_users($title,$message,'/modules/events.php','event_reminder','event-'.$event['id'].'-'.$date);
}
echo "Processed event reminders for {$today}.\n";
