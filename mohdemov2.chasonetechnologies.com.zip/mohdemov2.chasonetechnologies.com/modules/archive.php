<?php
require_once __DIR__ . '/../config/db.php';
require_auth();
if (!is_admin()) { http_response_code(403); exit('Administrator access is required to view and restore archived records.'); }
$page_title = 'Archived Data & Restore — State Department for Medical Services';
$active_tab = 'administration';
$adminCurrentTab = 'archive';
$db = $pdo;
$notice = '';
$error = '';
$csrfToken = get_csrf_token();

if ($db) {
    try {
        if (!$db->query("SHOW COLUMNS FROM projects LIKE 'is_archived'")->fetch()) $db->exec('ALTER TABLE projects ADD COLUMN is_archived TINYINT(1) NOT NULL DEFAULT 0');
        if (!$db->query("SHOW COLUMNS FROM projects LIKE 'archived_at'")->fetch()) $db->exec('ALTER TABLE projects ADD COLUMN archived_at TIMESTAMP NULL DEFAULT NULL');
        if (!$db->query("SHOW COLUMNS FROM flagships LIKE 'is_archived'")->fetch()) $db->exec('ALTER TABLE flagships ADD COLUMN is_archived TINYINT(1) NOT NULL DEFAULT 0');
        if (!$db->query("SHOW COLUMNS FROM flagships LIKE 'archived_at'")->fetch()) $db->exec('ALTER TABLE flagships ADD COLUMN archived_at TIMESTAMP NULL DEFAULT NULL');
        if (!$db->query("SHOW COLUMNS FROM diary_events LIKE 'is_archived'")->fetch()) $db->exec('ALTER TABLE diary_events ADD COLUMN is_archived TINYINT(1) NOT NULL DEFAULT 0');
        if (!$db->query("SHOW COLUMNS FROM diary_events LIKE 'archived_at'")->fetch()) $db->exec('ALTER TABLE diary_events ADD COLUMN archived_at TIMESTAMP NULL DEFAULT NULL');
        if (!$db->query("SHOW COLUMNS FROM meetings LIKE 'is_archived'")->fetch()) $db->exec('ALTER TABLE meetings ADD COLUMN is_archived TINYINT(1) NOT NULL DEFAULT 0');
        if (!$db->query("SHOW COLUMNS FROM meetings LIKE 'archived_at'")->fetch()) $db->exec('ALTER TABLE meetings ADD COLUMN archived_at TIMESTAMP NULL DEFAULT NULL');
        if (!$db->query("SHOW COLUMNS FROM reports LIKE 'is_archived'")->fetch()) $db->exec('ALTER TABLE reports ADD COLUMN is_archived TINYINT(1) NOT NULL DEFAULT 0');
        if (!$db->query("SHOW COLUMNS FROM reports LIKE 'archived_at'")->fetch()) $db->exec('ALTER TABLE reports ADD COLUMN archived_at TIMESTAMP NULL DEFAULT NULL');
        $db->exec("CREATE TABLE IF NOT EXISTS deleted_items (
            id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, item_type VARCHAR(50) NOT NULL, item_id INT NOT NULL,
            item_title VARCHAR(255) DEFAULT NULL, item_data LONGTEXT DEFAULT NULL, deleted_by VARCHAR(150) DEFAULT NULL,
            ip_address VARCHAR(45) DEFAULT NULL, deleted_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            KEY idx_deleted_type_item (item_type,item_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    } catch (Throwable $e) { error_log('Archive table check failed: '.$e->getMessage()); }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) { http_response_code(403); exit('Invalid security token.'); }
    $archiveId = (int)($_POST['archive_id'] ?? 0);
    $archiveType = (string)($_POST['archive_type'] ?? '');
    try {
        if (!$db || $archiveId < 1) throw new RuntimeException('Invalid archive record.');
        if ($archiveType === 'project') {
            $st = $db->prepare('UPDATE projects SET is_archived=0, archived_at=NULL WHERE id=? AND is_archived=1');
            $st->execute([$archiveId]); if (!$st->rowCount()) throw new RuntimeException('Project is missing or already restored.');
            log_audit_trail('RESTORE','Projects',$archiveId,'Restored project from Archived Data.');
        } elseif ($archiveType === 'flagship') {
            $st = $db->prepare('UPDATE flagships SET is_archived=0, archived_at=NULL WHERE id=? AND is_archived=1');
            $st->execute([$archiveId]); if (!$st->rowCount()) throw new RuntimeException('Flagship is missing or already restored.');
            log_audit_trail('RESTORE','Flagships',$archiveId,'Restored flagship from Archived Data.');
        } elseif ($archiveType === 'action_point') {
            $st = $db->prepare('UPDATE action_points SET archived_at=NULL WHERE id=? AND archived_at IS NOT NULL');
            $st->execute([$archiveId]); if (!$st->rowCount()) throw new RuntimeException('Action point is missing or already restored.');
            log_audit_trail('RESTORE','Action Points',$archiveId,'Restored action point from Archived Data.');
        } elseif ($archiveType === 'event') {
            $st = $db->prepare('UPDATE diary_events SET is_archived=0, archived_at=NULL WHERE id=? AND is_archived=1');
            $st->execute([$archiveId]); if (!$st->rowCount()) throw new RuntimeException('Event is missing or already restored.');
            log_audit_trail('RESTORE','Activities & Events',$archiveId,'Restored event from Archived Data.');
        } elseif ($archiveType === 'meeting') {
            $st = $db->prepare('UPDATE meetings SET is_archived=0, archived_at=NULL WHERE id=? AND is_archived=1');
            $st->execute([$archiveId]); if (!$st->rowCount()) throw new RuntimeException('Meeting is missing or already restored.');
            log_audit_trail('RESTORE','Meetings',$archiveId,'Restored meeting from Archived Data.');
        } elseif ($archiveType === 'report') {
            $st = $db->prepare('UPDATE reports SET is_archived=0, archived_at=NULL WHERE id=? AND is_archived=1');
            $st->execute([$archiveId]); if (!$st->rowCount()) throw new RuntimeException('Report is missing or already restored.');
            log_audit_trail('RESTORE','Reports',$archiveId,'Restored report from Archived Data.');
        } elseif ($archiveType === 'deleted_item') {
            $db->beginTransaction();
            $st = $db->prepare("SELECT * FROM deleted_items WHERE id=? AND item_type='KPI Progress Record' FOR UPDATE");
            $st->execute([$archiveId]); $snapshot = $st->fetch(PDO::FETCH_ASSOC);
            if (!$snapshot) throw new RuntimeException('KPI snapshot is missing or already restored.');
            $data = json_decode((string)$snapshot['item_data'], true);
            if (!is_array($data)) throw new RuntimeException('The saved KPI snapshot is not valid JSON.');
            $columns = $db->query('SHOW COLUMNS FROM project_kpis')->fetchAll(PDO::FETCH_COLUMN);
            $row = array_intersect_key($data, array_flip($columns));
            if (!$row) throw new RuntimeException('The KPI snapshot has no columns supported by this database.');
            if (isset($row['id'])) {
                $exists = $db->prepare('SELECT 1 FROM project_kpis WHERE id=?');
                $exists->execute([$row['id']]);
                if ($exists->fetchColumn()) unset($row['id']);
            }
            $quote = chr(96);
            $quoted = array_map(static fn($name) => $quote.str_replace($quote,'',$name).$quote, array_keys($row));
            $sql = 'INSERT INTO project_kpis ('.implode(',', $quoted).') VALUES ('.implode(',', array_fill(0,count($row),'?')).')';
            $db->prepare($sql)->execute(array_values($row));
            $restoredId = (int)($row['id'] ?? $db->lastInsertId());
            $db->prepare('DELETE FROM deleted_items WHERE id=?')->execute([$archiveId]);
            $db->commit();
            log_audit_trail('RESTORE','KPI Progress',$restoredId,'Restored KPI snapshot: '.(string)$snapshot['item_title']);
        } else throw new RuntimeException('This archive type cannot be restored from this page.');
        header('Location: archive.php?restored=1'); exit;
    } catch (Throwable $e) {
        if ($db && $db->inTransaction()) $db->rollBack();
        error_log('Archive restore failed: '.$e->getMessage());
        $error = $e instanceof RuntimeException ? $e->getMessage() : 'Restore failed. Verify that the record does not conflict with current data.';
    }
}
if (isset($_GET['restored'])) $notice = 'Record restored successfully.';

$search = trim((string)($_GET['q'] ?? ''));
$type = (string)($_GET['type'] ?? '');
$from = trim((string)($_GET['from'] ?? ''));
$to = trim((string)($_GET['to'] ?? ''));
$page = max(1,(int)($_GET['page'] ?? 1)); $perPage = 50;
$validDate = static fn($v) => is_string($v) && preg_match('/^\d{4}-\d{2}-\d{2}$/',$v);
if (!$validDate($from)) $from=''; if (!$validDate($to)) $to='';
$sources = [
    "SELECT 'project' AS archive_type,p.id AS record_id,p.id AS archive_id,p.sub_programme AS title,COALESCE(p.archived_at,p.created_at) AS archived_at,(SELECT al.user_name FROM audit_logs al WHERE al.module='Projects' AND al.action='ARCHIVE' AND al.record_id=p.id ORDER BY al.created_at DESC LIMIT 1) AS deleted_by,'Projects' AS source FROM projects p WHERE p.is_archived=1",
    "SELECT 'flagship' AS archive_type,f.id AS record_id,f.id AS archive_id,f.title,COALESCE(f.archived_at,f.created_at) AS archived_at,(SELECT al.user_name FROM audit_logs al WHERE al.module='Flagships' AND al.action='ARCHIVE' AND al.record_id=f.id ORDER BY al.created_at DESC LIMIT 1) AS deleted_by,'Priority Flagships' AS source FROM flagships f WHERE f.is_archived=1",
    "SELECT 'action_point' AS archive_type,a.id AS record_id,a.id AS archive_id,COALESCE(NULLIF(a.issue,''),a.ref_no) AS title,COALESCE(a.archived_at,a.created_at) AS archived_at,(SELECT al.user_name FROM audit_logs al WHERE al.module IN ('Action Points','action_points') AND al.action='ARCHIVE' AND al.record_id=a.id ORDER BY al.created_at DESC LIMIT 1) AS deleted_by,'Action Points' AS source FROM action_points a WHERE a.archived_at IS NOT NULL",
    "SELECT 'event' AS archive_type,e.id AS record_id,e.id AS archive_id,e.title,COALESCE(e.archived_at,e.created_at) AS archived_at,(SELECT al.user_name FROM audit_logs al WHERE al.module='Activities & Events' AND al.action='ARCHIVE' AND al.record_id=e.id ORDER BY al.created_at DESC LIMIT 1) AS deleted_by,'Activities & Events' AS source FROM diary_events e WHERE e.is_archived=1",
    "SELECT 'meeting' AS archive_type,m.id AS record_id,m.id AS archive_id,m.title,COALESCE(m.archived_at,m.created_at) AS archived_at,(SELECT al.user_name FROM audit_logs al WHERE al.module='Meetings' AND al.action='ARCHIVE' AND al.record_id=m.id ORDER BY al.created_at DESC LIMIT 1) AS deleted_by,'Meetings' AS source FROM meetings m WHERE m.is_archived=1",
    "SELECT 'report' AS archive_type,r.id AS record_id,r.id AS archive_id,r.title,COALESCE(r.archived_at,r.created_at) AS archived_at,(SELECT al.user_name FROM audit_logs al WHERE al.module='Reports' AND al.action='ARCHIVE' AND al.record_id=r.id ORDER BY al.created_at DESC LIMIT 1) AS deleted_by,'Reports Repository' AS source FROM reports r WHERE r.is_archived=1",
    "SELECT CASE WHEN item_type='KPI Progress Record' THEN 'deleted_item' ELSE 'unsupported' END AS archive_type,item_id AS record_id,id AS archive_id,COALESCE(item_title,CONCAT(item_type,' #',item_id)) AS title,deleted_at AS archived_at,deleted_by,item_type AS source FROM deleted_items",
];
$where=[];$params=[];
if($search!==''){$where[]='(title LIKE :q_title OR source LIKE :q_source OR CAST(record_id AS CHAR) LIKE :q_id)';$params[':q_title']=$params[':q_source']=$params[':q_id']='%'.$search.'%';}
if($type!==''&&in_array($type,['project','flagship','action_point','event','meeting','report','deleted_item','unsupported'],true)){$where[]='archive_type=:type';$params[':type']=$type;}
if($from!==''){$where[]='archived_at>=:from';$params[':from']=$from.' 00:00:00';}
if($to!==''){$where[]='archived_at<:to';$params[':to']=(new DateTimeImmutable($to))->modify('+1 day')->format('Y-m-d').' 00:00:00';}
$sql='SELECT * FROM ('.implode(' UNION ALL ',$sources).') archived';
if($where)$sql.=' WHERE '.implode(' AND ',$where);
$total=0;$rows=[];$totalPages=1;$offset=0;
try {
    $count=$db->prepare('SELECT COUNT(*) FROM ('.$sql.') archive_count');$count->execute($params);$total=(int)$count->fetchColumn();$totalPages=max(1,(int)ceil($total/$perPage));$page=min($page,$totalPages);$offset=($page-1)*$perPage;
    $list=$db->prepare($sql.' ORDER BY archived_at DESC, record_id DESC LIMIT :lim OFFSET :off');
    foreach($params as $key=>$value)$list->bindValue($key,$value,PDO::PARAM_STR);
    $list->bindValue(':lim',$perPage,PDO::PARAM_INT);$list->bindValue(':off',$offset,PDO::PARAM_INT);$list->execute();$rows=$list->fetchAll(PDO::FETCH_ASSOC);
} catch(Throwable $e) { error_log('Archive list failed: '.$e->getMessage());$error=$error?:'Could not load the archive. Check that archive columns are available.'; }
$esc=static fn($v)=>htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');
$urlFor=static function(array $overrides=[]):string {$q=array_merge(['q'=>trim((string)($_GET['q']??'')),'type'=>trim((string)($_GET['type']??'')),'from'=>trim((string)($_GET['from']??'')),'to'=>trim((string)($_GET['to']??''))],$overrides);return 'archive.php?'.http_build_query(array_filter($q,static fn($v)=>$v!==''));};
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/admin_tabs.php';
?>
<div style="display:flex;flex-direction:column;gap:14px;">
<div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap"><div><h2 style="margin:0;color:#0f172a;font-size:1.3rem">Archived Data &amp; Restore</h2><p style="margin:5px 0;color:#64748b;font-size:.82rem">Browse recoverable project, flagship, action point, and KPI records.</p></div><a href="users.php" style="padding:8px 12px;background:#eff6ff;color:#1d4ed8;border-radius:6px;text-decoration:none;font-weight:800;font-size:.78rem">Administration</a></div>
<?php if($notice):?><div role="status" style="padding:10px;background:#dcfce7;color:#166534;border-radius:7px"><?=$esc($notice)?></div><?php endif;?>
<?php if($error):?><div role="alert" style="padding:10px;background:#fee2e2;color:#991b1b;border-radius:7px"><?=$esc($error)?></div><?php endif;?>
<form method="get" style="display:flex;gap:10px;flex-wrap:wrap;align-items:end;padding:12px;background:#fff;border:1px solid #e2e8f0;border-radius:8px">
<label>Search<input name="q" value="<?=$esc($search)?>" placeholder="Title, type, or ID"></label>
<label>Record type<select name="type"><option value="">All types</option><?php foreach(['project'=>'Projects','flagship'=>'Priority flagships','action_point'=>'Action points','event'=>'Activities & Events','meeting'=>'Meetings','report'=>'Reports','deleted_item'=>'Deleted KPI snapshots','unsupported'=>'Other deleted snapshots'] as $k=>$v):?><option value="<?=$esc($k)?>" <?=$type===$k?'selected':''?>><?=$esc($v)?></option><?php endforeach;?></select></label>
<label>From<input type="date" name="from" value="<?=$esc($from)?>"></label><label>To<input type="date" name="to" value="<?=$esc($to)?>"></label><button type="submit">Filter archive</button><a href="archive.php">Clear</a>
</form>
<section style="overflow:auto;background:#fff;border:1px solid #e2e8f0;border-radius:8px;padding:12px"><p style="margin:0 0 8px;font-size:.8rem;color:#64748b">Showing <?=$total?($offset+1):0?>–<?=min($offset+count($rows),$total)?> of <?=number_format($total)?> archived records</p>
<table style="width:100%;border-collapse:collapse;font-size:.8rem"><thead><tr style="text-align:left;background:#f8fafc"><th style="padding:10px">Type</th><th style="padding:10px">Record</th><th style="padding:10px">Archived</th><th style="padding:10px">Archived by</th><th style="padding:10px">Action</th></tr></thead><tbody>
<?php if(!$rows):?><tr><td colspan="5" style="padding:14px;color:#64748b">No archived records match these filters.</td></tr><?php else:foreach($rows as $row):?><tr style="border-top:1px solid #e2e8f0"><td style="padding:10px"><?=$esc($row['source'])?></td><td style="padding:10px"><strong><?=$esc($row['title'])?></strong><br><small>#<?=$esc($row['record_id'])?></small></td><td style="padding:10px"><?=$esc($row['archived_at'])?></td><td style="padding:10px"><?=$esc($row['deleted_by']??'—')?></td><td style="padding:10px"><?php if(in_array($row['archive_type'],['project','flagship','action_point','event','meeting','report','deleted_item'],true)):?><form method="post" onsubmit="return confirm('Restore this record?')"><input type="hidden" name="csrf_token" value="<?=$esc($csrfToken)?>"><input type="hidden" name="archive_type" value="<?=$esc($row['archive_type'])?>"><input type="hidden" name="archive_id" value="<?=(int)$row['archive_id']?>"><button type="submit" style="padding:7px 10px;background:#10b981;color:#fff;border:0;border-radius:5px;font-weight:800">Restore</button></form><?php else:?><span style="color:#64748b">Snapshot only</span><?php endif;?></td></tr><?php endforeach;endif;?>
</tbody></table>
<div style="display:flex;justify-content:space-between;align-items:center;margin-top:12px;font-size:.8rem;color:#64748b"><span>Page <?=$page?> of <?=$totalPages?></span><div><?php if($page>1):?><a href="<?=$esc($urlFor(['page'=>$page-1]))?>">Previous</a><?php endif;?> <?php if($page<$totalPages):?><a href="<?=$esc($urlFor(['page'=>$page+1]))?>">Next</a><?php endif;?></div></div></section>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
