<?php
/**
 * Activities & Events — ministerial agenda.
 * Uses the existing diary_events table and the site's shared header/footer.
 */
require_once __DIR__ . '/../config/db.php';
require_auth();

$page_title = 'Activities & Events — State Department for Medical Services';
$active_tab = 'events';
$can_add_events = can_edit();
$eventsArchiveReady = false;
if ($db_connected && $pdo) {
    try {
        if (!$pdo->query("SHOW COLUMNS FROM diary_events LIKE 'is_archived'")->fetch()) $pdo->exec('ALTER TABLE diary_events ADD COLUMN is_archived TINYINT(1) NOT NULL DEFAULT 0');
        if (!$pdo->query("SHOW COLUMNS FROM diary_events LIKE 'archived_at'")->fetch()) $pdo->exec('ALTER TABLE diary_events ADD COLUMN archived_at TIMESTAMP NULL DEFAULT NULL');
        $eventsArchiveReady = true;
    } catch (Throwable $e) { error_log('Event archive schema check failed: '.$e->getMessage()); }
}
$event_error = '';
$form_values = [];
$event_today = (new DateTimeImmutable('now', new DateTimeZone('Africa/Nairobi')))->format('Y-m-d');
$event_types = ['Field Visit', 'Executive Inspection', 'Training'];
$event_statuses = ['UPCOMING', 'ONGOING', 'COMPLETED', 'CANCELLED'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $form_values = $_POST;
    if (!$can_add_events) {
        http_response_code(403);
        exit('You do not have permission to add activities or events.');
    }

    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        http_response_code(419);
        $event_error = 'Your session expired. Refresh the page and try again.';
    } else {
        if (($_POST['form_action'] ?? '') === 'delete_event' && $db_connected && $pdo) {
            $deleteId = (int)($_POST['event_id'] ?? 0);
            if ($deleteId > 0 && $eventsArchiveReady) { $del = $pdo->prepare('UPDATE diary_events SET is_archived=1, archived_at=NOW() WHERE id = ? AND is_archived=0'); $del->execute([$deleteId]); log_audit_trail('ARCHIVE', 'Activities & Events', $deleteId, 'Archived activity/event'); header('Location: /modules/events.php?archived=1'); exit; }
        }
        $eventEditId = (int)($_POST['event_id'] ?? 0);
        $title = trim((string)($_POST['title'] ?? ''));
        $description = trim((string)($_POST['description'] ?? ''));
        $event_type = trim((string)($_POST['event_type'] ?? 'Meeting'));
        $event_date = trim((string)($_POST['event_date'] ?? ''));
        $event_time = trim((string)($_POST['event_time'] ?? ''));
        $location = trim((string)($_POST['location'] ?? ''));
        $host = trim((string)($_POST['host'] ?? ''));
        $attendees = trim((string)($_POST['attendees'] ?? ''));
        $requested_status = strtoupper(trim((string)($_POST['status'] ?? 'UPCOMING')));
        $status = $requested_status === 'CANCELLED' ? 'CANCELLED'
            : ($event_date < $event_today ? 'COMPLETED' : ($event_date === $event_today ? 'ONGOING' : 'UPCOMING'));
        $date_object = DateTimeImmutable::createFromFormat('!Y-m-d', $event_date);
        $valid_date = $date_object && $date_object->format('Y-m-d') === $event_date;
        $valid_time = $event_time === '' || preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d$/', $event_time);

        $title_length = function_exists('mb_strlen') ? mb_strlen($title) : strlen($title);
        if ($title === '' || $title_length > 255 || !$valid_date || !in_array($event_type, $event_types, true) || !in_array($status, $event_statuses, true) || !$valid_time) {
            $event_error = 'Check the required fields and try again. The title, activity type, date, time and status must be valid.';
        } elseif (!$db_connected || !$pdo) {
            $event_error = 'The database connection is unavailable. The activity was not saved.';
        } else {
            try {
                if (($_POST['form_action'] ?? '') === 'update_event' && $eventEditId > 0) {
                    $beforeStmt=$pdo->prepare('SELECT * FROM diary_events WHERE id=?');$beforeStmt->execute([$eventEditId]);$beforeEvent=$beforeStmt->fetch(PDO::FETCH_ASSOC);
                    if(!$beforeEvent)throw new RuntimeException('This activity no longer exists.');
                    $stmt = $pdo->prepare("UPDATE diary_events SET title=?, description=?, event_type=?, event_date=?, event_time=?, location=?, host=?, attendees=?, status=? WHERE id=?");
                    $stmt->execute([$title, $description !== '' ? $description : null, $event_type, $event_date, $event_time !== '' ? $event_time . ':00' : null, $location !== '' ? $location : null, $host !== '' ? $host : null, $attendees !== '' ? $attendees : null, $status, $eventEditId]);
                    audit_log_change('Activities & Events',$eventEditId,$beforeEvent,['title'=>$title,'description'=>$description!==''?$description:null,'event_type'=>$event_type,'event_date'=>$event_date,'event_time'=>$event_time!==''?$event_time.':00':null,'location'=>$location!==''?$location:null,'host'=>$host!==''?$host:null,'attendees'=>$attendees!==''?$attendees:null,'status'=>$status],'Updated activity: '.$title,['project_id'=>!empty($beforeEvent['project_id'])?(int)$beforeEvent['project_id']:null]);
                    header('Location: /modules/events.php?updated=1');
                } else {
                    $stmt = $pdo->prepare("INSERT INTO diary_events (title, description, event_type, event_date, event_time, location, host, attendees, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
                    $stmt->execute([$title, $description !== '' ? $description : null, $event_type, $event_date, $event_time !== '' ? $event_time . ':00' : null, $location !== '' ? $location : null, $host !== '' ? $host : null, $attendees !== '' ? $attendees : null, $status]);
                    log_audit_trail('CREATE', 'Activities & Events', $pdo->lastInsertId(), 'Created activity: ' . $title);
                    header('Location: /modules/events.php?created=1');
                }
                exit;
            } catch (Throwable $exception) {
                error_log('Activity/event creation failed: ' . $exception->getMessage());
                $event_error = 'The activity could not be saved. Please check the details and try again.';
            }
        }
    }
}

$events = [];
$load_error = false;
if ($db_connected && $pdo) {
    try {
        // Events scheduled for today move from Upcoming to Ongoing automatically.
        $statusUpdate = $pdo->prepare("UPDATE diary_events
            SET status = CASE WHEN event_date < ? THEN 'COMPLETED' WHEN event_date = ? THEN 'ONGOING' ELSE 'UPCOMING' END
            WHERE UPPER(COALESCE(status, '')) <> 'CANCELLED' AND is_archived=0");
        $statusUpdate->execute([$event_today, $event_today]);
        $events = $pdo->query('SELECT * FROM diary_events WHERE is_archived=0 ORDER BY event_date ASC, event_time ASC, id ASC')->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $exception) {
        $load_error = true;
    }
}
$types_in_data = array_values(array_unique(array_filter(array_map(static fn($row) => trim((string)($row['event_type'] ?? '')), $events))));
$years = [];
foreach ($events as $event_row) {
    $year_key = substr((string)($event_row['event_date'] ?? ''), 0, 4);
    if (preg_match('/^\d{4}$/', $year_key)) $years[$year_key] = $year_key;
}
krsort($years);
$upcoming_count = count(array_filter($events, static fn($row) => strtoupper((string)($row['status'] ?? '')) === 'UPCOMING'));
$completed_count = count(array_filter($events, static fn($row) => strtoupper((string)($row['status'] ?? '')) === 'COMPLETED'));
$field_visit_count = count(array_filter($events, static fn($row) => strcasecmp((string)($row['event_type'] ?? ''), 'Field Visit') === 0));
$e = static fn($value): string => htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');

require_once __DIR__ . '/../includes/header.php';
?>

<style>
/* Actions dropdown: diary, edit and delete options */
.event-card{position:relative;}
.event-card-actions{position:absolute;top:10px;right:10px;z-index:5;display:flex;justify-content:flex-end;margin:0;overflow:visible;}
.event-card-topline{padding-right:92px;}
.event-actions-toggle{display:inline-flex;align-items:center;gap:7px;background:#10b981!important;border:1px solid #10b981!important;color:#fff!important;}
.event-actions-toggle:hover,.event-actions-toggle[aria-expanded="true"]{background:#059669!important;border-color:#059669!important;}
.event-actions-menu{position:absolute;top:calc(100% + 5px);right:0;z-index:1000;min-width:155px;padding:5px;background:#1256ab;border:1px solid #0f4790;border-radius:8px;box-shadow:0 12px 28px rgba(15,35,65,.18);}
.event-actions-menu[hidden]{display:none;}
.event-actions-menu a,.event-actions-menu button{display:flex;width:100%;box-sizing:border-box;align-items:center;padding:9px 11px;border:0;border-bottom:1px solid rgba(255,255,255,.85);border-radius:0;background:transparent;color:#fff;text-decoration:none;text-align:left;font:inherit;font-size:.78rem;font-weight:700;cursor:pointer;}
.event-actions-menu form:last-child button,.event-actions-menu>a:last-child{border-bottom:0;}
.event-actions-menu a:hover,.event-actions-menu button:hover{background:#0f4790;color:#fff;}
.event-actions-menu form{margin:0;}
.module-page{min-height:calc(100vh - 190px);overflow:visible;}
.event-card{overflow:visible;}
.event-card-actions{overflow:visible;}
.event-agenda-row{position:relative;grid-template-columns:135px minmax(0,1fr) auto auto;padding-right:112px;}
.event-agenda-row .event-card-actions{top:10px;right:4px;}
@media (max-width:760px){.event-agenda-row{grid-template-columns:1fr;padding-right:100px;}.event-agenda-row .event-card-actions{top:10px;right:4px;}}
.event-calendar-overlay{position:fixed;inset:0;z-index:10000;display:flex;align-items:center;justify-content:center;padding:18px;background:rgba(15,23,42,.58);}
.event-calendar-overlay[hidden]{display:none;}
.event-calendar-dialog{width:min(1240px,100%);max-height:94vh;overflow:auto;background:#fff;border-radius:14px;box-shadow:0 24px 70px rgba(15,23,42,.3);padding:20px;}
.event-calendar-header{display:flex;justify-content:space-between;align-items:flex-start;gap:16px;border-bottom:1px solid #e2e8f0;padding-bottom:14px;}
.event-calendar-header h2{margin:0;color:#102b50;font-size:1.15rem;}
.event-calendar-header p{margin:4px 0 0;color:#64748b;font-size:.8rem;}
.event-calendar-close{border:0;background:transparent;color:#475569;font-size:1.8rem;line-height:1;cursor:pointer;}
.event-calendar-nav{display:flex;justify-content:space-between;gap:8px;margin:14px 0;}
.event-calendar-nav button{border:1px solid #cbd5e1;border-radius:7px;background:#f8fafc;color:#334155;padding:7px 11px;font-weight:700;cursor:pointer;}
.event-calendar-nav button:hover{background:#eff6ff;border-color:#93c5fd;color:#1d4ed8;}
.event-calendar-months{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;}
.event-calendar-month{min-width:0;border:1px solid #e2e8f0;border-radius:9px;padding:10px;}
.event-calendar-month>h3{margin:0 0 9px;text-align:center;color:#173354;font-size:.9rem;}
.event-calendar-weekdays,.event-calendar-days{display:grid;grid-template-columns:repeat(7,minmax(0,1fr));gap:3px;}
.event-calendar-weekdays{margin-bottom:4px;color:#64748b;text-align:center;font-size:.64rem;font-weight:800;}
.event-calendar-day{min-height:76px;min-width:0;padding:3px;border:1px solid #edf1f6;border-radius:5px;background:#fff;}
.event-calendar-day-number{display:block;margin-bottom:3px;color:#334155;font-size:.68rem;font-weight:800;text-align:right;}
.event-calendar-blank{min-height:76px;}
.event-calendar-event{display:block;width:100%;margin:2px 0;padding:3px 4px;border:0;border-radius:4px;background:#dbeafe;color:#1e40af;text-align:left;font-size:.6rem;font-weight:700;line-height:1.25;overflow-wrap:anywhere;cursor:pointer;}
.event-calendar-event:hover{background:#bfdbfe;color:#1e3a8a;}
.event-calendar-details{margin-top:16px;padding:14px 16px;border:1px solid #bfdbfe;border-radius:9px;background:#f8fbff;}
.event-calendar-details h3{margin:0;color:#173354;font-size:.95rem;}
.event-calendar-details>p{margin:6px 0 0;color:#64748b;font-size:.78rem;}
.event-calendar-detail-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px 16px;margin:12px 0 0;}
.event-calendar-detail-grid dt{color:#64748b;font-size:.66rem;font-weight:800;text-transform:uppercase;}
.event-calendar-detail-grid dd{margin:3px 0 0;color:#1e293b;font-size:.78rem;white-space:pre-wrap;overflow-wrap:anywhere;}
@media(max-width:900px){.event-calendar-months{grid-template-columns:1fr;}.event-calendar-month{max-width:none;}.event-calendar-day,.event-calendar-blank{min-height:54px;}.event-calendar-detail-grid{grid-template-columns:repeat(2,minmax(0,1fr));}}
@media(max-width:520px){.event-calendar-overlay{padding:8px;}.event-calendar-dialog{padding:13px;}.event-calendar-nav button{padding:7px;font-size:.7rem;}.event-calendar-detail-grid{grid-template-columns:1fr;}}
</style>

<main class="module-page">
  <div class="module-page-head">
    <div>
      <h2 class="module-page-title">Activities &amp; Events</h2>
      <p class="module-page-description">Ministerial engagements, field visits, stakeholder meetings and delivery milestones.</p>
    </div>
    <div class="module-page-actions">
      <a class="module-btn" href="/modules/diary.php">Open Diary calendar</a>
      <?php if ($can_add_events): ?><button type="button" class="module-btn module-btn-primary" id="eventAddButton">＋ Add activity</button><?php endif; ?>
      <div class="event-view-toggle" role="group" aria-label="Choose event layout">
        <button type="button" class="active" data-view="cards" aria-pressed="true">Cards</button>
        <button type="button" data-view="agenda" aria-pressed="false">List</button>
      </div>
      <button type="button" class="module-btn module-btn-small" id="eventCalendarOpen">Calendar</button>
    </div>
  </div>

  <?php if (isset($_GET['created'])): ?><div class="module-notice" role="status">The activity was added successfully.</div><?php endif; ?>
  <?php if ($event_error !== ''): ?><div class="module-error" role="alert"><?= $e($event_error) ?></div><?php endif; ?>
  <?php if ($load_error): ?><div class="module-error" role="alert">Activities could not be loaded from the database.</div><?php endif; ?>

  <?php
    // Each key-statistic card is a link that opens the list filtered to exactly what the card counts.
    $stat_filter = ['status' => strtoupper(trim((string)($_GET['status'] ?? ''))), 'type' => trim((string)($_GET['type'] ?? ''))];
    $stat_cards = [
      ['label' => 'Events on the agenda', 'value' => count($events), 'query' => [], 'hint' => 'View all events'],
      ['label' => 'Upcoming', 'value' => $upcoming_count, 'query' => ['status' => 'UPCOMING'], 'hint' => 'View upcoming events'],
      ['label' => 'Field visits', 'value' => $field_visit_count, 'query' => ['type' => 'Field Visit'], 'hint' => 'View field visits'],
      ['label' => 'Completed', 'value' => $completed_count, 'query' => ['status' => 'COMPLETED'], 'hint' => 'View completed events'],
    ];
  ?>
  <section class="module-summary-grid" aria-label="Events overview">
    <?php foreach ($stat_cards as $card):
      $is_active = (($card['query']['status'] ?? '') === $stat_filter['status']) && (($card['query']['type'] ?? '') === $stat_filter['type']);
      $href = '/modules/events.php' . ($card['query'] ? '?' . http_build_query($card['query']) : '') . '#eventList';
    ?>
      <a class="module-summary-card<?= $is_active ? ' is-active' : '' ?>" href="<?= $e($href) ?>" data-stat-link title="<?= $e($card['hint']) ?>">
        <div class="module-summary-label"><?= $e($card['label']) ?></div>
        <div class="module-summary-value"><?= (int)$card['value'] ?></div>
        <div class="module-summary-hint"><?= $e($card['hint']) ?> &rarr;</div>
      </a>
    <?php endforeach; ?>
  </section>

  <section class="module-panel" id="eventList" aria-label="Activities and events">
    <div class="module-toolbar">
      <div class="module-toolbar-group">
        <input class="module-search" type="search" id="eventSearch" placeholder="Search title, location, host or attendee…" aria-label="Search activities">
        <select class="module-select" id="eventTypeFilter" aria-label="Filter by activity type">
          <option value="">All activity types</option>
          <?php foreach (array_values(array_unique(array_merge($event_types, $types_in_data))) as $type): ?><option value="<?= $e($type) ?>"><?= $e($type) ?></option><?php endforeach; ?>
        </select>
        <select class="module-select" id="eventStatusFilter" aria-label="Filter by status">
          <option value="">All statuses</option>
          <?php foreach (array_values(array_unique(array_merge($event_statuses, array_map('strtoupper', array_column($events, 'status'))))) as $status): ?><option value="<?= $e($status) ?>"><?= $e(ucfirst(strtolower((string)$status))) ?></option><?php endforeach; ?>
        </select>
        <label class="event-month-label" for="eventMonthFilter">Month</label>
        <select class="module-select" id="eventMonthFilter" aria-label="Filter by month">
          <option value="">All months</option>
          <?php for ($month_number = 1; $month_number <= 12; $month_number++): ?><option value="<?= sprintf('%02d', $month_number) ?>"><?= $e(date('F', mktime(0, 0, 0, $month_number, 1, 2000))) ?></option><?php endfor; ?>
        </select>
        <label class="event-month-label" for="eventYearFilter">Year</label>
        <select class="module-select" id="eventYearFilter" aria-label="Filter by year">
          <option value="">All years</option>
          <?php foreach ($years as $year): ?><option value="<?= $e($year) ?>"><?= $e($year) ?></option><?php endforeach; ?>
        </select>
      </div>
      <div class="module-inline-note"><span id="eventVisibleCount"><?= count($events) ?></span> activities <button type="button" class="module-btn module-btn-small" id="eventFilterReset" hidden>Clear filters</button></div>
    </div>

    <div class="event-grid" id="eventCards">
      <?php foreach ($events as $event): ?>
        <?php
          $date_value = strtotime((string)$event['event_date']);
          $month_label = $date_value ? date('M', $date_value) : 'TBD';
          $day_label = $date_value ? date('d', $date_value) : '—';
          $date_label = $date_value ? date('d M Y', $date_value) : 'Date to be confirmed';
          $time_label = !empty($event['event_time']) ? date('g:i A', strtotime((string)$event['event_time'])) : 'Time to be confirmed';
          $status_lower = strtolower((string)($event['status'] ?? ''));
          $status_class = $status_lower === 'completed' ? 'is-done' : ($status_lower === 'cancelled' ? 'is-risk' : '');
          $search_value = strtolower(implode(' ', [(string)$event['title'], (string)($event['description'] ?? ''), (string)$event['event_type'], (string)($event['location'] ?? ''), (string)($event['host'] ?? ''), (string)($event['attendees'] ?? '')]));
        ?>
        <article id="event-<?= (int)$event['id'] ?>" class="event-card" data-search="<?= $e($search_value) ?>" data-type="<?= $e($event['event_type']) ?>" data-status="<?= $e($event['status']) ?>" data-month="<?= $e(substr((string)$event['event_date'], 5, 2)) ?>" data-year="<?= $e(substr((string)$event['event_date'], 0, 4)) ?>">
          <div class="event-date-block"><span class="event-date-month"><?= $e($month_label) ?></span><span class="event-date-day"><?= $e($day_label) ?></span></div>
          <div>
            <div class="event-card-topline"><span class="module-status"><?= $e($event['event_type']) ?></span><span class="module-status <?= $e($status_class) ?>"><?= $e(ucfirst(strtolower((string)$event['status']))) ?></span></div>
            <h3 class="event-card-title"><?= $e($event['title']) ?></h3>
            <?php if (!empty($event['description'])): ?><p class="event-card-description"><?= $e($event['description']) ?></p><?php endif; ?>
            <div class="event-card-meta">
              <div><strong><?= $e($date_label) ?></strong> · <?= $e($time_label) ?></div>
              <?php if (!empty($event['location'])): ?><div><strong>Location:</strong> <?= $e($event['location']) ?></div><?php endif; ?>
              <?php if (!empty($event['host'])): ?><div><strong>Host / chair:</strong> <?= $e($event['host']) ?></div><?php endif; ?>
              <?php if (!empty($event['attendees'])): ?><div><strong>Key attendees:</strong> <?= $e($event['attendees']) ?></div><?php endif; ?>
            </div>
            <div class="event-card-actions">
              <button type="button" class="module-btn module-btn-small event-actions-toggle" aria-haspopup="true" aria-expanded="false">Actions <span aria-hidden="true">▾</span></button>
              <div class="event-actions-menu" role="menu" hidden>
                <a role="menuitem" href="/modules/diary.php?date=<?= $e(substr((string)$event['event_date'],0,10)) ?>&amp;category=<?= urlencode((string)$event['event_type']) ?>">View in Diary</a>
                <?php if ($can_add_events): ?><button type="button" role="menuitem" class="event-edit" data-event="<?= $e(json_encode($event, JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_TAG|JSON_HEX_AMP)) ?>">Edit</button><form method="post" onsubmit="return confirm('Archive this activity? It will be available in Archived Data & Restore.')"><input type="hidden" name="csrf_token" value="<?= $e(get_csrf_token()) ?>"><input type="hidden" name="form_action" value="delete_event"><input type="hidden" name="event_id" value="<?= (int)$event['id'] ?>"><button role="menuitem" class="event-delete" type="submit">Archive</button></form><?php endif; ?>
              </div>
            </div>
          </div>
        </article>
      <?php endforeach; ?>
      <?php if (!$events): ?><div class="module-empty" style="grid-column:1/-1;">No ministerial activities or events have been added.</div><?php endif; ?>
    </div>

    <div class="event-agenda" id="eventAgenda">
      <?php foreach ($events as $event): ?>
        <?php
          $date_value = strtotime((string)$event['event_date']);
          $date_label = $date_value ? date('d M Y', $date_value) : 'Date to be confirmed';
          $time_label = !empty($event['event_time']) ? date('g:i A', strtotime((string)$event['event_time'])) : 'Time to be confirmed';
          $search_value = strtolower(implode(' ', [(string)$event['title'], (string)($event['description'] ?? ''), (string)$event['event_type'], (string)($event['location'] ?? ''), (string)($event['host'] ?? ''), (string)($event['attendees'] ?? '')]));
          $status_lower = strtolower((string)($event['status'] ?? ''));
        ?>
        <article id="event-agenda-<?= (int)$event['id'] ?>" class="event-agenda-row" data-search="<?= $e($search_value) ?>" data-type="<?= $e($event['event_type']) ?>" data-status="<?= $e($event['status']) ?>" data-month="<?= $e(substr((string)$event['event_date'], 5, 2)) ?>" data-year="<?= $e(substr((string)$event['event_date'], 0, 4)) ?>">
          <div class="event-agenda-date"><?= $e($date_label) ?><br><?= $e($time_label) ?></div>
          <div><div class="event-agenda-title"><?= $e($event['title']) ?></div><div class="event-agenda-location"><?= $e($event['event_type']) ?><?php if (!empty($event['location'])): ?> · <?= $e($event['location']) ?><?php endif; ?><?php if (!empty($event['host'])): ?> · Host: <?= $e($event['host']) ?><?php endif; ?></div><?php if (!empty($event['attendees'])): ?><div class="event-agenda-location">Attendees: <?= $e($event['attendees']) ?></div><?php endif; ?></div>
          <span class="module-status <?= $status_lower === 'completed' ? 'is-done' : ($status_lower === 'cancelled' ? 'is-risk' : '') ?>"><?= $e(ucfirst($status_lower)) ?></span>
          <div class="event-card-actions">
            <button type="button" class="module-btn module-btn-small event-actions-toggle" aria-haspopup="true" aria-expanded="false">Actions <span aria-hidden="true">▾</span></button>
            <div class="event-actions-menu" role="menu" hidden>
              <a role="menuitem" href="/modules/diary.php?date=<?= $e(substr((string)$event['event_date'],0,10)) ?>&amp;category=<?= urlencode((string)$event['event_type']) ?>">View in Diary</a>
              <?php if ($can_add_events): ?><button type="button" role="menuitem" class="event-edit" data-event="<?= $e(json_encode($event, JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_TAG|JSON_HEX_AMP)) ?>">Edit</button><form method="post" onsubmit="return confirm('Archive this activity? It will be available in Archived Data & Restore.')"><input type="hidden" name="csrf_token" value="<?= $e(get_csrf_token()) ?>"><input type="hidden" name="form_action" value="delete_event"><input type="hidden" name="event_id" value="<?= (int)$event['id'] ?>"><button role="menuitem" class="event-delete" type="submit">Archive</button></form><?php endif; ?>
            </div>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
    <div class="module-empty" id="eventNoResults" hidden>No activities match these filters.</div>
  </section>
</main>

<div class="event-calendar-overlay" id="eventCalendarPopup" hidden role="dialog" aria-modal="true" aria-labelledby="eventCalendarTitle">
  <section class="event-calendar-dialog">
    <header class="event-calendar-header">
      <div><h2 id="eventCalendarTitle">Activities &amp; Events Calendar</h2><p>Browse events by month and select one to view its details.</p></div>
      <button type="button" class="event-calendar-close" id="eventCalendarClose" aria-label="Close calendar">&times;</button>
    </header>
    <nav class="event-calendar-nav" aria-label="Calendar navigation">
      <button type="button" id="eventCalendarPrev">&larr; Previous month</button>
      <button type="button" id="eventCalendarToday">Today</button>
      <button type="button" id="eventCalendarNext">Next month &rarr;</button>
    </nav>
    <div class="event-calendar-months" id="eventCalendarMonths"></div>
    <section class="event-calendar-details" id="eventCalendarDetails" aria-live="polite">
      <h3>Event details</h3><p>Select an event from the calendar to see its details here.</p>
    </section>
  </section>
</div>

<?php if ($can_add_events): ?>
<div class="module-modal-overlay" id="addEventModal" role="dialog" aria-modal="true" aria-labelledby="addEventTitle">
  <div class="module-modal-card event-modal-card">
    <div class="module-modal-head"><h3 id="addEventTitle">Add activity or event</h3><button type="button" class="module-btn module-btn-small" id="eventModalClose" aria-label="Close form">Close</button></div>
    <form method="post" action="/modules/events.php">
      <input type="hidden" name="csrf_token" value="<?= $e(get_csrf_token()) ?>">
      <input type="hidden" name="form_action" id="eventFormAction" value="add_event"><input type="hidden" name="event_id" id="eventEditId" value="">
      <div class="module-modal-body"><div class="module-form-grid">
        <div class="module-form-field full"><label for="eventTitle">Title *</label><input class="module-input" id="eventTitle" name="title" maxlength="255" required value="<?= $e($form_values['title'] ?? '') ?>"></div>
        <div class="module-form-field"><label for="eventType">Activity type *</label><select class="module-select" id="eventType" name="event_type" required><?php foreach ($event_types as $type_option): ?><option value="<?= $e($type_option) ?>" <?= (($form_values['event_type'] ?? 'Meeting') === $type_option) ? 'selected' : '' ?>><?= $e($type_option) ?></option><?php endforeach; ?></select></div>
        <div class="module-form-field"><label for="eventStatus">Status (based on date)</label><select class="module-select" id="eventStatus" name="status" required><?php foreach ($event_statuses as $status_option): ?><option value="<?= $e($status_option) ?>" <?= (strtoupper((string)($form_values['status'] ?? 'UPCOMING')) === $status_option) ? 'selected' : '' ?>><?= $e(ucfirst(strtolower($status_option))) ?></option><?php endforeach; ?></select></div>
        <div class="module-form-field"><label for="eventDate">Date *</label><input class="module-input" id="eventDate" name="event_date" type="date" required value="<?= $e($form_values['event_date'] ?? '') ?>"></div>
        <div class="module-form-field"><label for="eventTime">Time</label><input class="module-input" id="eventTime" name="event_time" type="time" value="<?= $e($form_values['event_time'] ?? '') ?>"></div>
        <div class="module-form-field"><label for="eventLocation">Location</label><input class="module-input" id="eventLocation" name="location" maxlength="255" value="<?= $e($form_values['location'] ?? '') ?>"></div>
        <div class="module-form-field"><label for="eventHost">Host / chair</label><input class="module-input" id="eventHost" name="host" maxlength="150" value="<?= $e($form_values['host'] ?? '') ?>"></div>
        <div class="module-form-field full"><label for="eventAttendees">Key attendees</label><input class="module-input" id="eventAttendees" name="attendees" value="<?= $e($form_values['attendees'] ?? '') ?>"></div>
        <div class="module-form-field full"><label for="eventDescription">Description</label><textarea class="module-textarea" id="eventDescription" name="description"><?= $e($form_values['description'] ?? '') ?></textarea></div>
      </div></div>
      <div class="module-modal-footer"><button type="button" class="module-btn" id="eventModalCancel">Cancel</button><button type="submit" class="module-btn module-btn-primary">Save activity</button></div>
    </form>
  </div>
</div>
<?php endif; ?>

<script>
(() => {
  const calendarEvents = <?= json_encode(array_map(static fn($event) => [
    'id' => (int)$event['id'], 'title' => (string)$event['title'], 'event_date' => (string)$event['event_date'],
    'event_time' => (string)($event['event_time'] ?? ''), 'event_type' => (string)($event['event_type'] ?? ''),
    'status' => (string)($event['status'] ?? ''), 'location' => (string)($event['location'] ?? ''),
    'host' => (string)($event['host'] ?? ''), 'attendees' => (string)($event['attendees'] ?? ''),
    'description' => (string)($event['description'] ?? ''),
  ], $events), JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT) ?>;
  const calendarPopup = document.getElementById('eventCalendarPopup');
  const calendarMonths = document.getElementById('eventCalendarMonths');
  const calendarDetails = document.getElementById('eventCalendarDetails');
  let calendarStart = new Date(new Date().getFullYear(), new Date().getMonth() - 1, 1);
  const dateKey = date => `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}-${String(date.getDate()).padStart(2,'0')}`;
  const monthKey = date => `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}`;
  const closeCalendar = () => { calendarPopup.hidden = true; document.getElementById('eventCalendarOpen')?.focus(); };
  const showEventDetails = event => {
    calendarDetails.replaceChildren();
    const heading = document.createElement('h3'); heading.textContent = event.title; calendarDetails.appendChild(heading);
    const fields = [
      ['Date', new Date(`${event.event_date}T00:00:00`).toLocaleDateString('en-GB', {day:'2-digit', month:'short', year:'numeric'})],
      ['Time', event.event_time ? new Date(`2000-01-01T${event.event_time}`).toLocaleTimeString([], {hour:'numeric', minute:'2-digit'}) : 'Time to be confirmed'],
      ['Type', event.event_type], ['Status', event.status], ['Location', event.location], ['Host / chair', event.host],
      ['Attendees', event.attendees], ['Description', event.description]
    ];
    const grid = document.createElement('dl'); grid.className = 'event-calendar-detail-grid';
    fields.forEach(([label, value]) => { if (!value) return; const item = document.createElement('div'); const term = document.createElement('dt'); const detail = document.createElement('dd'); term.textContent = label; detail.textContent = value; item.append(term, detail); grid.appendChild(item); });
    calendarDetails.appendChild(grid);
  };
  const renderCalendar = () => {
    calendarMonths.replaceChildren();
    for (let offset = 0; offset < 3; offset++) {
      const monthDate = new Date(calendarStart.getFullYear(), calendarStart.getMonth() + offset, 1);
      const key = monthKey(monthDate); const month = document.createElement('section'); month.className = 'event-calendar-month';
      const title = document.createElement('h3'); title.textContent = monthDate.toLocaleDateString(undefined, {month:'long', year:'numeric'}); month.appendChild(title);
      const weekdays = document.createElement('div'); weekdays.className = 'event-calendar-weekdays';
      ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'].forEach(day => { const cell = document.createElement('span'); cell.textContent = day; weekdays.appendChild(cell); }); month.appendChild(weekdays);
      const days = document.createElement('div'); days.className = 'event-calendar-days';
      const firstDayOffset = (monthDate.getDay() + 6) % 7;
      for (let blank = 0; blank < firstDayOffset; blank++) { const empty = document.createElement('span'); empty.className = 'event-calendar-blank'; days.appendChild(empty); }
      const count = new Date(monthDate.getFullYear(), monthDate.getMonth()+1, 0).getDate();
      for (let number = 1; number <= count; number++) {
        const day = document.createElement('div'); day.className = 'event-calendar-day';
        const date = new Date(monthDate.getFullYear(), monthDate.getMonth(), number); const dayEvents = calendarEvents.filter(item => item.event_date.slice(0,7) === key && Number(item.event_date.slice(8,10)) === number);
        const label = document.createElement('span'); label.className = 'event-calendar-day-number'; label.textContent = String(number); day.appendChild(label);
        dayEvents.forEach(item => { const button = document.createElement('button'); button.type = 'button'; button.className = 'event-calendar-event'; button.textContent = `${item.event_time ? item.event_time.slice(0,5) + ' ' : ''}${item.title}`; button.title = `${item.title} — ${item.event_type}`; button.addEventListener('click', () => showEventDetails(item)); day.appendChild(button); });
        days.appendChild(day);
      }
      month.appendChild(days); calendarMonths.appendChild(month);
    }
  };
  document.getElementById('eventCalendarOpen')?.addEventListener('click', () => { renderCalendar(); calendarPopup.hidden = false; document.getElementById('eventCalendarClose').focus(); });
  document.getElementById('eventCalendarClose')?.addEventListener('click', closeCalendar);
  calendarPopup?.addEventListener('click', event => { if (event.target === calendarPopup) closeCalendar(); });
  document.getElementById('eventCalendarPrev')?.addEventListener('click', () => { calendarStart = new Date(calendarStart.getFullYear(), calendarStart.getMonth()-1, 1); renderCalendar(); });
  document.getElementById('eventCalendarNext')?.addEventListener('click', () => { calendarStart = new Date(calendarStart.getFullYear(), calendarStart.getMonth()+1, 1); renderCalendar(); });
  document.getElementById('eventCalendarToday')?.addEventListener('click', () => { calendarStart = new Date(new Date().getFullYear(), new Date().getMonth()-1, 1); renderCalendar(); });
  document.addEventListener('keydown', event => { if (event.key === 'Escape' && calendarPopup && !calendarPopup.hidden) closeCalendar(); });
  const search = document.getElementById('eventSearch');
  const type = document.getElementById('eventTypeFilter');
  const status = document.getElementById('eventStatusFilter');
  const month = document.getElementById('eventMonthFilter');
  const year = document.getElementById('eventYearFilter');
  const cards = [...document.querySelectorAll('#eventCards .event-card')];
  const agendaRows = [...document.querySelectorAll('#eventAgenda .event-agenda-row')];
  const cardsPanel = document.getElementById('eventCards');
  const agendaPanel = document.getElementById('eventAgenda');
  let activeView = 'cards';
  function applyFilters() {
    const query = (search?.value || '').trim().toLowerCase();
    const visible = node => ((!query || (node.dataset.search || '').includes(query))
      && (!type?.value || node.dataset.type === type.value)
      && (!status?.value || node.dataset.status === status.value)
      && (!month?.value || node.dataset.month === month.value)
      && (!year?.value || node.dataset.year === year.value));
    cards.forEach(node => { node.hidden = !visible(node); });
    agendaRows.forEach(node => { node.hidden = !visible(node); });
    const currentRows = activeView === 'cards' ? cards : agendaRows;
    const visibleCount = currentRows.filter(node => !node.hidden).length;
    document.getElementById('eventVisibleCount').textContent = visibleCount;
    document.getElementById('eventNoResults').hidden = visibleCount > 0;
  }
  document.querySelectorAll('.event-view-toggle button[data-view]').forEach(button => button.addEventListener('click', () => {
    document.querySelectorAll('.event-view-toggle button').forEach(item => { item.classList.remove('active'); item.setAttribute('aria-pressed', 'false'); });
    button.classList.add('active'); button.setAttribute('aria-pressed', 'true');
    activeView = button.dataset.view;
    cardsPanel.style.display = activeView === 'cards' ? 'grid' : 'none';
    agendaPanel.classList.toggle('active', activeView === 'agenda');
    applyFilters();
  }));
  const params = new URLSearchParams(window.location.search);
  const setSelect = (select, value) => {
    if (!select || !value) return;
    const wanted = value.toLowerCase();
    const match = [...select.options].find(option => option.value.toLowerCase() === wanted);
    if (match) select.value = match.value;
  };
  setSelect(type, params.get('type'));
  setSelect(status, params.get('status'));
  setSelect(month, (params.get('month') || '').padStart(2, '0'));
  setSelect(year, params.get('year'));
  if (search && params.get('q')) search.value = params.get('q');
  const resetButton = document.getElementById('eventFilterReset');
  const syncUrl = () => {
    const next = new URLSearchParams();
    if (search?.value.trim()) next.set('q', search.value.trim());
    if (type?.value) next.set('type', type.value);
    if (status?.value) next.set('status', status.value);
    if (month?.value) next.set('month', month.value);
    if (year?.value) next.set('year', year.value);
    const query = next.toString();
    history.replaceState(null, '', window.location.pathname + (query ? '?' + query : '') + window.location.hash);
    if (resetButton) resetButton.hidden = !query;
    document.querySelectorAll('[data-stat-link]').forEach(card => {
      const target = new URL(card.href, window.location.origin).searchParams;
      card.classList.toggle('is-active', (target.get('status') || '') === (status?.value || '') && (target.get('type') || '') === (type?.value || '') && !search?.value.trim() && !month?.value && !year?.value);
    });
  };
  const applyAndSync = () => { applyFilters(); syncUrl(); };
  [search, type, status, month, year].forEach(control => control?.addEventListener(control === search ? 'input' : 'change', applyAndSync));
  resetButton?.addEventListener('click', () => { [search, type, status, month, year].forEach(control => { if (control) control.value = ''; }); applyAndSync(); });
  applyAndSync();

  const modal = document.getElementById('addEventModal');
  const eventDateField = document.getElementById('eventDate');
  const eventStatusField = document.getElementById('eventStatus');
  const eventToday = <?= json_encode($event_today) ?>;
  const syncEventStatusToDate = () => {
    if (!eventDateField?.value || !eventStatusField || eventStatusField.value === 'CANCELLED') return;
    eventStatusField.value = eventDateField.value < eventToday ? 'COMPLETED' : (eventDateField.value === eventToday ? 'ONGOING' : 'UPCOMING');
  };
  eventDateField?.addEventListener('input', syncEventStatusToDate);
  eventDateField?.addEventListener('change', syncEventStatusToDate);
  eventStatusField?.addEventListener('change', () => { if (eventStatusField.value !== 'CANCELLED') syncEventStatusToDate(); });
  syncEventStatusToDate();
  const closeModal = () => modal?.classList.remove('active');
  const closeEventMenus = except => document.querySelectorAll('.event-actions-toggle').forEach(toggle => {
    if (toggle === except) return;
    toggle.setAttribute('aria-expanded', 'false');
    const menu = toggle.parentElement?.querySelector('.event-actions-menu');
    if (menu) menu.hidden = true;
    const item = toggle.closest('.event-card, .event-agenda-row');
    if (item) item.style.zIndex = '';
  });
  document.querySelectorAll('.event-actions-toggle').forEach(toggle => toggle.addEventListener('click', event => {
    event.stopPropagation();
    const menu = toggle.parentElement?.querySelector('.event-actions-menu');
    const open = toggle.getAttribute('aria-expanded') !== 'true';
    closeEventMenus(toggle);
    toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    if (menu) menu.hidden = !open;
    const item = toggle.closest('.event-card, .event-agenda-row');
    if (item) item.style.zIndex = open ? '10' : '';
  }));
  document.addEventListener('click', event => {
    if (!event.target.closest('.event-card-actions')) closeEventMenus(null);
  });
  document.addEventListener('keydown', event => { if (event.key === 'Escape') closeEventMenus(null); });
  document.getElementById('eventAddButton')?.addEventListener('click', () => { const form=modal?.querySelector('form'); form?.reset(); document.getElementById('eventFormAction').value='add_event'; document.getElementById('eventEditId').value=''; document.getElementById('addEventTitle').textContent='Add activity or event'; syncEventStatusToDate(); modal?.classList.add('active'); });
  document.querySelectorAll('.event-edit').forEach(button => button.addEventListener('click', () => { const d=JSON.parse(button.dataset.event); const set=(id,v)=>{const el=document.getElementById(id);if(el)el.value=v??'';}; set('eventTitle',d.title);set('eventType',d.event_type);set('eventStatus',String(d.status||'UPCOMING').toUpperCase());set('eventDate',d.event_date);syncEventStatusToDate();set('eventTime',String(d.event_time||'').slice(0,5));set('eventLocation',d.location);set('eventHost',d.host);set('eventAttendees',d.attendees);set('eventDescription',d.description);set('eventFormAction','update_event');set('eventEditId',d.id);document.getElementById('addEventTitle').textContent='Edit activity or event';modal?.classList.add('active'); }));
  document.getElementById('eventModalClose')?.addEventListener('click', closeModal);
  document.getElementById('eventModalCancel')?.addEventListener('click', closeModal);
  modal?.addEventListener('click', event => { if (event.target === modal) closeModal(); });
  document.addEventListener('keydown', event => { if (event.key === 'Escape') closeModal(); });
  if (modal && <?= $event_error !== '' ? 'true' : 'false' ?>) modal.classList.add('active');
})();
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
