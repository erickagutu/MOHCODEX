<?php
/**
 * Monthly Progress Module
 * Ministry of Health — State Department for Medical Services (PP-SDOMS)
 * Native PHP 8.1+ & MySQL (No Node.js)
 */
require_once __DIR__ . '/../config/db.php';
require_auth();

$page_title = 'Monthly Progress Tracking — State Department for Medical Services';
$active_tab = 'monthly_progress';

$flash_msg = '';
$action = $_GET['action'] ?? '';
$record_id = (int)($_GET['id'] ?? 0);

// Handle Delete Record
if ($action === 'delete' && $record_id > 0 && can_edit()) {
    $token = $_GET['csrf_token'] ?? '';
    if (verify_csrf_token($token)) {
        if ($db_connected && $pdo) {
            try {
                $stmt = $pdo->prepare("DELETE FROM monthly_progress WHERE id = ?");
                $stmt->execute([$record_id]);
                log_audit_trail('DELETE', 'MonthlyProgress', $record_id, "Deleted monthly progress entry #$record_id");
                $flash_msg = 'Monthly progress record deleted successfully.';
            } catch (Exception $e) {
                $flash_msg = 'Database error: ' . $e->getMessage();
            }
        } else {
            $flash_msg = 'Database connection unavailable; nothing was deleted.';
        }
    }
}

// Handle Add / Edit Monthly Progress Record
if ($_SERVER['REQUEST_METHOD'] === 'POST' && can_edit()) {
    $token = $_POST['csrf_token'] ?? '';
    if (verify_csrf_token($token)) {
        $edit_id = (int)($_POST['record_id'] ?? 0);
        $project_id = (int)($_POST['project_id'] ?? 0);
        $month = trim($_POST['year_month'] ?? date('Y-m'));
        $kpi_code = trim($_POST['kpi_code'] ?? '');
        $kpi_name = trim($_POST['kpi_name'] ?? '');
        $weight = (float)($_POST['weight'] ?? 0);
        $progress = (float)($_POST['progress_pct'] ?? 0);
        $notes = trim($_POST['notes'] ?? '');

        if ($db_connected && $pdo) {
            try {
                if ($edit_id > 0) {
                    $stmt = $pdo->prepare("
                        UPDATE monthly_progress 
                        SET project_id = ?, `year_month` = ?, kpi_code = ?, kpi_name = ?, weight = ?, progress_pct = ?, notes = ?
                        WHERE id = ?
                    ");
                    $stmt->execute([$project_id, $month, $kpi_code, $kpi_name, $weight, $progress, $notes, $edit_id]);
                    log_audit_trail('UPDATE', 'MonthlyProgress', $edit_id, "Updated monthly progress entry #$edit_id");
                    $flash_msg = 'Monthly progress record successfully updated in database.';
                } else {
                    $stmt = $pdo->prepare("
                        INSERT INTO monthly_progress (project_id, `year_month`, kpi_code, kpi_name, weight, progress_pct, notes)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    ");
                    $stmt->execute([$project_id, $month, $kpi_code, $kpi_name, $weight, $progress, $notes]);
                    $new_id = $pdo->lastInsertId();
                    log_audit_trail('CREATE', 'MonthlyProgress', $new_id, "Recorded monthly progress for project #$project_id: $month ($kpi_code)");
                    $flash_msg = 'Monthly progress record successfully saved to database.';
                }
            } catch (Exception $e) {
                $flash_msg = 'Database error: ' . $e->getMessage();
            }
        } else {
            $flash_msg = 'Database connection unavailable; progress was not saved.';
        }
    }
}

// Fetch projects for dropdown
$all_projects = [];
if ($db_connected && $pdo) {
    try {
        $stmt = $pdo->query("SELECT id, sub_programme FROM projects ORDER BY id ASC");
        $all_projects = $stmt->fetchAll();
    } catch (Exception $e) {}
}
// Fetch records from database
$records = [];
if ($db_connected && $pdo) {
    try {
        $stmt = $pdo->query("
            SELECT mp.*, p.sub_programme as project_title 
            FROM monthly_progress mp
            LEFT JOIN projects p ON mp.project_id = p.id
            ORDER BY mp.`year_month` DESC, mp.id DESC
        ");
        $records = $stmt->fetchAll();
    } catch (Exception $e) {}
}

// Build Gantt rows from the latest month present in monthly_progress.
$gantt_projects = [];
$gantt_reporting_month = null;
if ($db_connected && $pdo) {
    try {
        $gantt_reporting_month = $pdo->query("SELECT MAX(`year_month`) FROM monthly_progress")->fetchColumn() ?: null;
        if ($gantt_reporting_month !== null) {
            $stmt = $pdo->prepare("SELECT p.sub_programme AS name, p.delivery_unit AS du,
                    COALESCE(NULLIF(p.color, ''), '#1976d2') AS color,
                    SUM(mp.progress_pct) AS cumul_pct
                FROM projects p
                JOIN monthly_progress mp ON mp.project_id = p.id
                WHERE mp.`year_month` = ?
                GROUP BY p.id, p.sub_programme, p.delivery_unit, p.color
                ORDER BY p.sub_programme");
            $stmt->execute([$gantt_reporting_month]);
            $gantt_projects = $stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach ($gantt_projects as &$gantt_project) {
                $gantt_project['cumul_pct'] = max(0, min(100, (float)$gantt_project['cumul_pct']));
            }
            unset($gantt_project);
        }
    } catch (Exception $e) {
        $gantt_projects = [];
    }
}

require_once __DIR__ . '/../includes/header.php';
?>

<div style="display: flex; flex-direction: column; gap: 24px;">

    <!-- Module Header -->
    <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px; background: white; padding: 20px; border-radius: 12px; border: 1px solid #e2e8f0; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
        <div>
            <h2 style="font-size: 1.35rem; font-weight: 800; color: #0f172a; margin: 0; display: flex; align-items: center; gap: 10px;">
                <span style="display: inline-flex; align-items: center; justify-content: center; width: 32px; height: 32px; background: #dbeafe; color: #1d4ed8; border-radius: 8px;">📈</span>
                Monthly Progress Module 
            </h2>
            <p style="font-size: 0.82rem; color: #64748b; margin: 4px 0 0;">
                Add, edit, view, and delete monthly KPI progress updates and overall progress contributions.
            </p>
        </div>

        <?php if (can_edit()): ?>
            <button onclick="openAddProgressModal();" style="background: #10b981; color: white; border: none; padding: 10px 18px; border-radius: 8px; font-weight: 700; font-size: 0.82rem; cursor: pointer; display: flex; align-items: center; gap: 6px; box-shadow: 0 2px 4px rgba(16,185,129,0.2);">
                <span>+ Add Monthly Progress Update</span>
            </button>
        <?php endif; ?>
    </div>

    <?php if ($flash_msg): ?>
        <div style="background: #ecfdf5; border: 1px solid #10b981; color: #065f46; padding: 12px 16px; border-radius: 8px; font-size: 0.85rem; font-weight: 600;">
            <?= htmlspecialchars($flash_msg) ?>
        </div>
    <?php endif; ?>

    <!-- Monthly Progress Entries Table -->
    <div style="background: #ffffff; border-radius: 12px; border: 1px solid #e2e8f0; overflow: hidden; box-shadow: 0 2px 4px rgba(0,0,0,0.02);">
        <div style="background: #0d47a1; color: white; padding: 14px 20px; font-size: 0.85rem; font-weight: 800; display: flex; justify-content: space-between; align-items: center;">
            <span>Recorded Monthly KPI Progress Submissions (<?= count($records) ?> Records)</span>
            <span style="font-family: 'JetBrains Mono', monospace; font-size: 0.75rem; background: rgba(255,255,255,0.15); padding: 3px 8px; border-radius: 4px;">Table: monthly_progress</span>
        </div>
        <div style="overflow-x: auto;">
            <table style="width: 100%; border-collapse: collapse; font-size: 0.8rem; text-align: left;">
                <thead>
                    <tr style="background: #f8fafc; color: #475569; font-weight: 700; border-bottom: 2px solid #e2e8f0; text-transform: uppercase; font-size: 0.72rem;">
                        <th style="padding: 12px 16px;">Project Title</th>
                        <th style="padding: 12px 16px;">Month</th>
                        <th style="padding: 12px 16px;">KPI Code &amp; Name</th>
                        <th style="padding: 12px 16px; text-align: center;">Assigned Weight</th>
                        <th style="padding: 12px 16px; text-align: center;">Progress Contribution</th>
                        <th style="padding: 12px 16px;">Notes / Verification Evidence</th>
                        <th style="padding: 12px 16px; text-align: center;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($records)): ?><tr><td colspan="7" style="padding:24px;text-align:center;color:#64748b;">No monthly progress records are available in the database.</td></tr><?php endif; ?>
                    <?php foreach ($records as $r): ?>
                        <tr style="border-bottom: 1px solid #f1f5f9; hover: background #f8fafc;">
                            <td style="padding: 12px 16px; font-weight: 700; color: #0f172a;"><?= htmlspecialchars($r['project_title'] ?? 'Strategic Healthcare Project') ?></td>
                            <td style="padding: 12px 16px; font-family: 'JetBrains Mono', monospace; font-weight: 700; color: #0d47a1;"><?= htmlspecialchars($r['year_month']) ?></td>
                            <td style="padding: 12px 16px;">
                                <span style="background: #dbeafe; color: #1e40af; font-weight: 800; padding: 2px 6px; border-radius: 4px; font-size: 0.7rem; font-family: 'JetBrains Mono', monospace; margin-right: 6px;">[<?= htmlspecialchars($r['kpi_code']) ?>]</span>
                                <?= htmlspecialchars($r['kpi_name']) ?>
                            </td>
                            <td style="padding: 12px 16px; text-align: center; font-weight: 700; color: #b45309;"><?= $r['weight'] ?>%</td>
                            <td style="padding: 12px 16px; text-align: center;">
                                <span style="background: #ecfdf5; color: #065f46; font-weight: 800; padding: 4px 10px; border-radius: 12px; font-size: 0.75rem;">
                                    <?= $r['progress_pct'] ?>%
                                </span>
                            </td>
                            <td style="padding: 12px 16px; color: #475569; max-width: 280px;"><?= htmlspecialchars($r['notes']) ?></td>
                            <td style="padding: 12px 16px; text-align: center; white-space: nowrap;">
                                <?php if (can_edit()): ?>
                                    <button onclick='openEditProgressModal(<?= json_encode($r) ?>);' style="background: #f1f5f9; color: #1e293b; border: 1px solid #cbd5e1; padding: 4px 8px; border-radius: 4px; font-size: 0.72rem; font-weight: 700; cursor: pointer; margin-right: 4px;">Edit</button>
                                    <a href="/modules/monthly_progress.php?action=delete&id=<?= $r['id'] ?>&csrf_token=<?= htmlspecialchars(get_csrf_token()) ?>" onclick="return confirm('Delete this monthly progress update record?');" style="background: #fee2e2; color: #b91c1c; text-decoration: none; padding: 4px 8px; border-radius: 4px; font-size: 0.72rem; font-weight: 700;">Delete</a>
                                <?php else: ?>
                                    <span style="color: #94a3b8; font-size: 0.75rem;">View Only</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Gantt Chart of Overall Project Progress in % against Time of Completion (Month) -->
    <!-- Each project has a different color and indicates % achieved that month -->
    <div style="background: #ffffff; border-radius: 12px; border: 1px solid #e2e8f0; padding: 24px; box-shadow: 0 2px 4px rgba(0,0,0,0.02); display: flex; flex-direction: column; gap: 16px;">
        <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px; border-bottom: 1px solid #e2e8f0; padding-bottom: 14px;">
            <div>
                <h3 style="font-size: 1rem; font-weight: 800; color: #0f172a; margin: 0; display: flex; align-items: center; gap: 8px;">
                    📊 Gantt Chart: Overall Project Progress in % against Time of Completion (Month)
                </h3>
                <span style="font-size: 0.78rem; color: #64748b;">
                    Each project displays in its distinct designated color with an explicit indication in % of overall project progress achieved that month.
                </span>
            </div>
            <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 4px 10px; font-size: 0.75rem; font-weight: 700; color: #1e293b;">
                Reporting Month: <strong><?= $gantt_reporting_month ? htmlspecialchars(date('F Y', strtotime($gantt_reporting_month . '-01'))) : 'No records' ?></strong>
            </div>
        </div>

        <div style="display: flex; flex-direction: column; gap: 12px; padding-top: 4px;">
            <?php if (empty($gantt_projects)): ?><div style="padding:20px;text-align:center;color:#64748b;">No monthly progress records are available in the database.</div><?php endif; ?>
            <?php foreach ($gantt_projects as $gp): ?>
                <div style="display: grid; grid-template-columns: 220px 1fr 140px; align-items: center; gap: 14px; font-size: 0.78rem;">
                    <!-- Project Title and Color Badge -->
                    <div style="display: flex; align-items: center; gap: 8px; min-width: 0;">
                        <span style="display: inline-block; width: 12px; height: 12px; background: <?= $gp['color'] ?>; border-radius: 3px; flex-shrink: 0;"></span>
                        <div style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                            <strong style="color: #0f172a;"><?= htmlspecialchars($gp['name']) ?></strong>
                            <div style="font-size: 0.68rem; color: #64748b;"><?= htmlspecialchars($gp['du']) ?></div>
                        </div>
                    </div>

                    <!-- Horizontal Completion Bar with Monthly Achievement Tag -->
                    <div style="background: #f1f5f9; height: 26px; border-radius: 6px; overflow: hidden; position: relative; display: flex; align-items: center; border: 1px solid #e2e8f0;">
                        <!-- Cumulative progress bar -->
                        <div style="background: <?= $gp['color'] ?>; height: 100%; width: <?= $gp['cumul_pct'] ?>%; border-radius: 5px; opacity: 0.85; transition: width 0.5s ease;"></div>
                        
                        <!-- Percentage achieved this month badge -->
                        <div style="position: absolute; left: 10px; font-size: 0.72rem; font-weight: 800; color: #ffffff; text-shadow: 0 1px 2px rgba(0,0,0,0.4); font-family: 'JetBrains Mono', monospace; display: flex; align-items: center; gap: 6px;">
                            <span><?= number_format((float)$gp['cumul_pct'], 1) ?>% recorded this month</span>
                        </div>
                    </div>

                    <!-- Progress Status readout -->
                    <div style="text-align: right; font-family: 'JetBrains Mono', monospace; font-size: 0.78rem;">
                        <span style="font-weight: 800; color: #0f172a;"><?= $gp['cumul_pct'] ?>%</span>
                        <span style="color: #10b981; font-weight: 700; font-size: 0.7rem; margin-left: 4px;">(<?= htmlspecialchars($gantt_reporting_month ?? '') ?>)</span>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Scale Axis -->
        <div style="display: grid; grid-template-columns: 220px 1fr 140px; gap: 14px; border-top: 1px solid #e2e8f0; padding-top: 8px; font-size: 0.7rem; color: #64748b; font-family: 'JetBrains Mono', monospace;">
            <div></div>
            <div style="display: flex; justify-content: space-between;">
                <span>0%</span>
                <span>20%</span>
                <span>40%</span>
                <span>60%</span>
                <span>80%</span>
                <span>100% (Completion Target)</span>
            </div>
            <div></div>
        </div>

        <!-- Legend -->
        <div style="display: flex; flex-wrap: wrap; gap: 14px; background: #f8fafc; border: 1px solid #e2e8f0; padding: 12px; border-radius: 8px; font-size: 0.72rem;">
            <?php foreach ($gantt_projects as $gp): ?>
                <div style="display: flex; align-items: center; gap: 6px;">
                    <span style="display: inline-block; width: 10px; height: 10px; background: <?= $gp['color'] ?>; border-radius: 2px;"></span>
                    <span style="color: #334155; font-weight: 600;"><?= htmlspecialchars($gp['name']) ?></span>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

</div>

<!-- Modal: Add / Edit Monthly Progress -->
<div id="progressModal" style="display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 9999; align-items: center; justify-content: center; padding: 20px;">
    <div style="background: white; border-radius: 12px; max-width: 550px; width: 100%; padding: 24px; box-shadow: 0 20px 40px rgba(0,0,0,0.3);">
        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #e2e8f0; padding-bottom: 12px; margin-bottom: 16px;">
            <h3 id="modalTitle" style="margin: 0; font-size: 1.05rem; font-weight: 800; color: #0f172a;">Add Monthly Progress Update</h3>
            <button onclick="closeProgressModal();" style="background: none; border: none; font-size: 1.3rem; cursor: pointer; color: #64748b;">&times;</button>
        </div>

        <form method="POST" action="/modules/monthly_progress.php">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(get_csrf_token()) ?>">
            <input type="hidden" name="record_id" id="form_record_id" value="0">

            <div style="margin-bottom: 12px;">
                <label style="display: block; font-size: 0.75rem; font-weight: 700; margin-bottom: 4px; color: #334155;">Project</label>
                <select name="project_id" id="form_project_id" required style="width: 100%; padding: 8px 12px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.82rem;">
                    <?php foreach ($all_projects as $proj): ?>
                        <option value="<?= $proj['id'] ?>"><?= htmlspecialchars($proj['sub_programme']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div style="margin-bottom: 12px;">
                <label style="display: block; font-size: 0.75rem; font-weight: 700; margin-bottom: 4px; color: #334155;">Reporting Month (YYYY-MM)</label>
                <input type="month" name="year_month" id="form_year_month" value="<?= date('Y-m') ?>" required style="width: 100%; padding: 8px 12px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.82rem;">
            </div>

            <div style="display: grid; grid-template-columns: 1fr 2fr; gap: 12px; margin-bottom: 12px;">
                <div>
                    <label style="display: block; font-size: 0.75rem; font-weight: 700; margin-bottom: 4px; color: #334155;">KPI Code</label>
                    <input type="text" name="kpi_code" id="form_kpi_code" required style="width: 100%; padding: 8px 12px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.82rem;">
                </div>
                <div>
                    <label style="display: block; font-size: 0.75rem; font-weight: 700; margin-bottom: 4px; color: #334155;">KPI Indicator Name</label>
                    <input type="text" name="kpi_name" id="form_kpi_name" required style="width: 100%; padding: 8px 12px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.82rem;">
                </div>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 12px;">
                <div>
                    <label style="display: block; font-size: 0.75rem; font-weight: 700; margin-bottom: 4px; color: #334155;">Assigned Weight (%)</label>
                    <input type="number" step="0.5" name="weight" id="form_weight" required style="width: 100%; padding: 8px 12px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.82rem;">
                </div>
                <div>
                    <label style="display: block; font-size: 0.75rem; font-weight: 700; margin-bottom: 4px; color: #334155;">Progress Contribution (%)</label>
                    <input type="number" step="0.1" name="progress_pct" id="form_progress_pct" required style="width: 100%; padding: 8px 12px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.82rem;">
                </div>
            </div>

            <div style="margin-bottom: 16px;">
                <label style="display: block; font-size: 0.75rem; font-weight: 700; margin-bottom: 4px; color: #334155;">Operational Notes &amp; Verification Observations</label>
                <textarea name="notes" id="form_notes" rows="3" style="width: 100%; padding: 8px 12px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.82rem;" placeholder="Milestones achieved, challenges, verification evidence..."></textarea>
            </div>

            <div style="display: flex; justify-content: flex-end; gap: 10px;">
                <button type="button" onclick="closeProgressModal();" style="padding: 8px 16px; border: 1px solid #cbd5e1; background: white; border-radius: 6px; font-weight: 600; font-size: 0.8rem; cursor: pointer;">Cancel</button>
                <button type="submit" style="padding: 8px 18px; background: #0d47a1; color: white; border: none; border-radius: 6px; font-weight: 700; font-size: 0.8rem; cursor: pointer;">Save Progress Update</button>
            </div>
        </form>
    </div>
</div>

<script>
function openAddProgressModal() {
    document.getElementById('modalTitle').textContent = 'Add Monthly Progress Update';
    document.getElementById('form_record_id').value = '0';
    document.getElementById('form_year_month').value = new Date().toISOString().slice(0, 7);
    document.getElementById('form_kpi_code').value = '';
    document.getElementById('form_kpi_name').value = '';
    document.getElementById('form_weight').value = '';
    document.getElementById('form_progress_pct').value = '';
    document.getElementById('form_notes').value = '';
    document.getElementById('progressModal').style.display = 'flex';
}

function openEditProgressModal(rec) {
    document.getElementById('modalTitle').textContent = 'Edit Monthly Progress Update (#' + rec.id + ')';
    document.getElementById('form_record_id').value = rec.id;
    if (document.getElementById('form_project_id')) {
        document.getElementById('form_project_id').value = rec.project_id || '';
    }
    document.getElementById('form_year_month').value = rec.year_month || '';
    document.getElementById('form_kpi_code').value = rec.kpi_code || '';
    document.getElementById('form_kpi_name').value = rec.kpi_name || '';
    document.getElementById('form_weight').value = rec.weight ?? '';
    document.getElementById('form_progress_pct').value = rec.progress_pct ?? '';
    document.getElementById('form_notes').value = rec.notes || '';
    document.getElementById('progressModal').style.display = 'flex';
}

function closeProgressModal() {
    document.getElementById('progressModal').style.display = 'none';
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
