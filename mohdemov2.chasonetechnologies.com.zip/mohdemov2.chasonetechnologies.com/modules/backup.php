<?php
/**
 * cPanel & Backup Manager Module
 * Ministry of Health — State Department for Medical Services (PP-SDOMS)
 * Native PHP 8.1+ & MySQL (No Node.js)
 */
require_once __DIR__ . '/../config/db.php';
require_auth();

$page_title = 'Backup & Restore — State Department for Medical Services';
$active_tab = 'administration';
$adminCurrentTab = 'backup';

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/admin_tabs.php';
?>

<div role="status" style="padding:12px 15px;margin-bottom:18px;background:#fffbeb;color:#92400e;border:1px solid #fde68a;border-radius:8px;font-size:.82rem;line-height:1.5;"><strong>Backup capability status:</strong> This module currently provides deployment guidance and a schema download. Automated database/file backups, schedules, and restore operations are not configured in the application.</div>

<div style="display: flex; flex-direction: column; gap: 24px;">

    <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px;">
        <div>
            <h2 style="font-size: 1.25rem; font-weight: 800; color: #0f172a; margin: 0; display: flex; align-items: center; gap: 8px;">
                ⚙️ Backup &amp; Recovery Management
            </h2>
            <span style="font-size: 0.8rem; color: #64748b;">Backup deployment guidance and system recovery documentation</span>
        </div>

        <div style="display: flex; gap: 10px; flex-wrap: wrap;">
            <a href="/public/database/schema.sql" download="mohsdms_schema.sql" style="background: #10b981; color: white; text-decoration: none; padding: 8px 16px; border-radius: 6px; font-weight: 700; font-size: 0.8rem; display: flex; align-items: center; gap: 6px;">
                💾 Download MySQL Schema (.sql)
            </a>
            <a href="/install.php" style="background: #0d47a1; color: white; text-decoration: none; padding: 8px 16px; border-radius: 6px; font-weight: 700; font-size: 0.8rem; display: flex; align-items: center; gap: 6px;">
                🚀 Run Web Installer Wizard
            </a>
        </div>
    </div>

    <!-- cPanel Setup Checklist Cards -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 18px;">
        <div style="background: #ffffff; border-radius: 8px; border: 1px solid #e2e8f0; padding: 20px; box-shadow: 0 2px 4px rgba(0,0,0,0.02);">
            <h3 style="font-size: 0.95rem; font-weight: 800; color: #0f172a; margin: 0 0 12px; display: flex; align-items: center; gap: 8px;">
                ✅ cPanel Server Readiness
            </h3>
            <div style="font-size: 0.8rem; color: #334155; line-height: 1.8;">
                <div style="display: flex; justify-content: space-between; border-bottom: 1px solid #f1f5f9; padding: 6px 0;">
                    <span>Runtime Requirement</span>
                    <strong style="color: #0d47a1;">PHP 8.1 or 8.2</strong>
                </div>
                <div style="display: flex; justify-content: space-between; border-bottom: 1px solid #f1f5f9; padding: 6px 0;">
                    <span>Database Engine</span>
                    <strong style="color: #0d47a1;">MySQL 5.7+ / MariaDB 10.3+</strong>
                </div>
                <div style="display: flex; justify-content: space-between; border-bottom: 1px solid #f1f5f9; padding: 6px 0;">
                    <span>PHP Extensions</span>
                    <strong style="color: #10b981;">PDO, pdo_mysql, mbstring, json</strong>
                </div>
                <div style="display: flex; justify-content: space-between; border-bottom: 1px solid #f1f5f9; padding: 6px 0;">
                    <span>Node.js / NPM Requirement</span>
                    <strong style="color: #10b981;">0% (Zero Dependencies)</strong>
                </div>
                <div style="display: flex; justify-content: space-between; padding: 6px 0;">
                    <span>Target Folder</span>
                    <strong style="color: #0d47a1;">public_html/</strong>
                </div>
            </div>
        </div>

        <div style="background: #ffffff; border-radius: 8px; border: 1px solid #e2e8f0; padding: 20px; box-shadow: 0 2px 4px rgba(0,0,0,0.02);">
            <h3 style="font-size: 0.95rem; font-weight: 800; color: #0f172a; margin: 0 0 12px; display: flex; align-items: center; gap: 8px;">
                📋 4-Step cPanel Quick Installation
            </h3>
            <ol style="font-size: 0.8rem; color: #475569; padding-left: 18px; line-height: 1.8; margin: 0;">
                <li><strong>Upload to cPanel:</strong> Extract this code directly into your cPanel <code>public_html/</code> folder using cPanel File Manager.</li>
                <li><strong>Create Database:</strong> Go to cPanel &rarr; <em>MySQL Databases</em> and create a database (e.g. <code>mohsdms</code>) and user.</li>
                <li><strong>Import Schema:</strong> Open phpMyAdmin, select your database, and import <code>database/schema.sql</code> (or run <code>install.php</code>).</li>
                <li><strong>Update .env:</strong> Create <code>.env</code> with your DB credentials, then log in at <code>index.php</code> with <strong>admin@health.go.ke</strong> / <strong>ChangeMe@2026</strong>.</li>
            </ol>
        </div>
    </div>

    <!-- Deployment Guide Document Card -->
    <div style="background: #ffffff; border-radius: 8px; border: 1px solid #e2e8f0; padding: 24px; box-shadow: 0 2px 4px rgba(0,0,0,0.02);">
        <h3 style="font-size: 1rem; font-weight: 800; color: #0f172a; margin: 0 0 8px;">
            📖 Included System Documentation
        </h3>
        <p style="font-size: 0.8rem; color: #64748b; margin: 0 0 16px;">
            Detailed manuals for database triggers, cron backups, and multi-user privilege settings.
        </p>
        <div style="display: flex; gap: 12px; flex-wrap: wrap;">
            <a href="/docs/CPANEL_INSTALL_GUIDE.md" target="_blank" style="background: #f1f5f9; color: #0d47a1; text-decoration: none; padding: 8px 16px; border-radius: 6px; font-weight: 700; font-size: 0.78rem; border: 1px solid #cbd5e1;">
                📄 View cPanel Install Guide (Markdown)
            </a>
            <a href="/docs/SYSTEM_DOCUMENTATION.md" target="_blank" style="background: #f1f5f9; color: #0d47a1; text-decoration: none; padding: 8px 16px; border-radius: 6px; font-weight: 700; font-size: 0.78rem; border: 1px solid #cbd5e1;">
                📑 View System Technical Documentation
            </a>
        </div>
    </div>

</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
