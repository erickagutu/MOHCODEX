<?php
/**
 * Reports Repository & Performance Verification Module
 * Ministry of Health — State Department for Medical Services (PP-SDOMS)
 * Native PHP 8.1+ & MySQL (PDO)
 * Brand Colors: Primary Blue (#1a61c1), Health Green (#10b981)
 *
 * Capabilities:
 *  - Report Uploads with file validation and directory storage
 *  - Multi-criteria filtering (module, saga/directorate, status, classification, search, dates)
 *  - User RBAC: Admin & PS view all reports; other users view only own uploads or granted reports
 *  - Prompt-guided report generation from live system data
 *  - Document Rights Management (grant/revoke view and download rights)
 *  - System Activity Log tracking (VIEW, DOWNLOAD, DELETE, UPLOAD, RIGHTS) restricted to Admin & PS
 *  - Printable and downloadable report outputs
 */

require_once __DIR__ . '/../config/db.php';
require_auth();

if ($db_connected && $pdo) {
    try {
        if (!$pdo->query("SHOW COLUMNS FROM reports LIKE 'is_archived'")->fetch()) $pdo->exec('ALTER TABLE reports ADD COLUMN is_archived TINYINT(1) NOT NULL DEFAULT 0');
        if (!$pdo->query("SHOW COLUMNS FROM reports LIKE 'archived_at'")->fetch()) $pdo->exec('ALTER TABLE reports ADD COLUMN archived_at TIMESTAMP NULL DEFAULT NULL');
    } catch (Throwable $e) { error_log('Reports archive schema check failed: '.$e->getMessage()); }
}

$page_title = 'Reports Repository — State Department for Medical Services';
$active_tab = 'reports';

$current_user_id    = $_SESSION['user_id'] ?? 0;
$current_user_name  = $_SESSION['full_name'] ?? 'Authorized User';
$current_user_email = $_SESSION['email'] ?? '';
$current_user_role  = $_SESSION['role'] ?? 'Viewer';
$is_admin_account   = !empty($_SESSION['is_admin']) || ($current_user_role === 'Administrator');
$is_ps_account      = ($current_user_role === 'Principal Secretary') || 
                      (stripos($current_user_role, 'PS') !== false) || 
                      (strtolower($current_user_email) === 'ps@medicalservices.go.ke');

$can_view_all = $is_admin_account || $is_ps_account;

// Ensure upload directory exists
$upload_dir = __DIR__ . '/../assets/uploads/reports';
if (!is_dir($upload_dir)) {
    @mkdir($upload_dir, 0755, true);
}

// Active sub-tab
$current_subtab = $_GET['tab'] ?? 'repository';
if (in_array($current_subtab, ['generate_filter', 'migration'], true)) $current_subtab = 'repository';

$notice_msg = '';
$error_msg  = '';

// -------------------------------------------------------------
// HELPER: Log to audit_logs table
// -------------------------------------------------------------
function log_audit_event($pdo, $userName, $userEmail, $action, $module, $recordId, $details) {
    if (!$pdo) return;
    try {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
        $stmt = $pdo->prepare("INSERT INTO audit_logs (user_name, user_email, action, module, record_id, details, ip_address, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())");
        $stmt->execute([$userName, $userEmail, $action, $module, $recordId, $details, $ip]);
    } catch (Exception $e) {}
}

// -------------------------------------------------------------
// 1. HANDLE REPORT DOWNLOAD (with Audit Log tracking)
// -------------------------------------------------------------
if (isset($_GET['download']) && !empty($_GET['download']) && $pdo) {
    $rep_id = (int)$_GET['download'];
    try {
        $d_stmt = $pdo->prepare("SELECT * FROM reports WHERE id = ?");
        $d_stmt->execute([$rep_id]);
        $rep = $d_stmt->fetch(PDO::FETCH_ASSOC);

        if ($rep) {
            // Check permission if not superuser
            $allowed = $can_view_all || ($rep['uploaded_by'] === $current_user_name) || ($rep['visibility'] === 'Public');
            if (!$allowed) {
                $p_chk = $pdo->prepare("SELECT id FROM document_permissions WHERE report_id = ? AND (user_email = ? OR user_name = ?) AND can_download = 1");
                $p_chk->execute([$rep['id'], $current_user_email, $current_user_name]);
                if ($p_chk->fetch()) $allowed = true;
            }

            if ($allowed) {
                log_audit_event($pdo, $current_user_name, $current_user_email, 'DOWNLOAD', 'Reports', $rep['id'], "Downloaded report attachment: {$rep['file_name']} (Ref: {$rep['code']})");

                $file_path = $upload_dir . '/' . $rep['file_name'];
                if (file_exists($file_path)) {
                    header('Content-Description: File Transfer');
                    header('Content-Type: application/octet-stream');
                    header('Content-Disposition: attachment; filename="' . basename($rep['file_name']) . '"');
                    header('Content-Length: ' . filesize($file_path));
                    readfile($file_path);
                    exit;
                } else {
                    // Fallback for demo attachment
                    header('Content-Type: text/plain; charset=utf-8');
                    header('Content-Disposition: attachment; filename="' . basename($rep['file_name']) . '.txt"');
                    echo "REPUBLIC OF KENYA — MINISTRY OF HEALTH\nSTATE DEPARTMENT FOR MEDICAL SERVICES (PP-SDOMS)\n";
                    echo "========================================================================\n";
                    echo "Report Reference: " . $rep['code'] . "\n";
                    echo "Title: " . $rep['title'] . "\n";
                    echo "Project: " . $rep['project'] . "\n";
                    echo "Submission Date: " . $rep['report_date'] . "\n";
                    echo "Uploaded by: " . $rep['uploaded_by'] . "\n";
                    echo "Summary: " . ($rep['summary'] ?? 'Official document archive verified by PP-SDOMS.') . "\n";
                    exit;
                }
            } else {
                $error_msg = 'Access Denied: You do not have permission to download this classified document.';
            }
        }
    } catch (Exception $e) {
        $error_msg = 'Download error: ' . $e->getMessage();
    }
}

// -------------------------------------------------------------
// 2. HANDLE REPORT UPLOAD (POST)
// -------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'upload_report' && $pdo) {
    $title       = trim($_POST['title'] ?? '');
    $code        = trim($_POST['code'] ?? '');
    $project     = trim($_POST['project'] ?? '');
    $module_name = trim($_POST['module_name'] ?? 'General');
    $report_date = trim($_POST['report_date'] ?? date('Y-m-d'));
    $visibility  = trim($_POST['visibility'] ?? 'Restricted');
    $status      = trim($_POST['status'] ?? 'Pending Review');
    $summary     = trim($_POST['summary'] ?? '');

    if (empty($code)) {
        $code = 'MOH-REP-' . date('Y') . '-' . strtoupper(substr(uniqid(), -4));
    }

    if (empty($title)) {
        $error_msg = 'Document title is required.';
    } elseif (!isset($_FILES['report_file']) || $_FILES['report_file']['error'] !== UPLOAD_ERR_OK) {
        $error_msg = 'Please attach a valid document file (PDF, Excel, Word).';
    } else {
        $file_tmp  = $_FILES['report_file']['tmp_name'];
        $orig_name = basename($_FILES['report_file']['name']);
        $file_size = round($_FILES['report_file']['size'] / (1024 * 1024), 2) . ' MB';
        $file_ext  = strtolower(pathinfo($orig_name, PATHINFO_EXTENSION));
        $allowed   = ['pdf', 'xlsx', 'xls', 'docx', 'doc', 'csv'];

        if (!in_array($file_ext, $allowed)) {
            $error_msg = 'Invalid file extension. Allowed: PDF, XLSX, DOCX, CSV.';
        } else {
            $stored_name = 'rep_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.' . $file_ext;
            $destination = $upload_dir . '/' . $stored_name;

            if (move_uploaded_file($file_tmp, $destination)) {
                try {
                    $ins_stmt = $pdo->prepare("INSERT INTO reports 
                        (code, title, project, module, report_date, file_name, file_size, visibility, status, uploaded_by, uploader_email, summary, created_at)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
                    $ins_stmt->execute([
                        $code, $title, $project, $module_name, $report_date, $stored_name, $file_size, $visibility, $status, $current_user_name, $current_user_email, $summary
                    ]);
                    $new_report_id = $pdo->lastInsertId();

                    // If non-admin, grant self access
                    if (!$is_admin_account) {
                        try {
                            $p_stmt = $pdo->prepare("INSERT INTO document_permissions (report_id, user_email, user_name, role, can_view, can_download, granted_by, granted_at) VALUES (?, ?, ?, ?, 1, 1, 'Self (Upload)', NOW())");
                            $p_stmt->execute([$new_report_id, $current_user_email, $current_user_name, $current_user_role]);
                        } catch (Exception $pe) {}
                    }

                    // Audit Log
                    log_audit_event($pdo, $current_user_name, $current_user_email, 'UPLOAD', 'Reports', $new_report_id, "Uploaded statutory report: {$title} ({$stored_name})");

                    $notice_msg = "Report successfully registered and uploaded (Ref: {$code}).";
                } catch (Exception $e) {
                    $error_msg = "Database insert error: " . $e->getMessage();
                }
            } else {
                $error_msg = 'Failed to move uploaded document to storage directory.';
            }
        }
    }
}

// -------------------------------------------------------------
// 3. HANDLE REPORT DELETION (Admin / PS only, with Audit Log)
// -------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete_report' && $pdo) {
    if (!$can_view_all) {
        $error_msg = 'Unauthorized: Only Administrators and the Principal Secretary can delete reports.';
    } else {
        $del_id = (int)($_POST['report_id'] ?? 0);
        try {
            $f_stmt = $pdo->prepare("SELECT * FROM reports WHERE id = ?");
            $f_stmt->execute([$del_id]);
            $rep_del = $f_stmt->fetch(PDO::FETCH_ASSOC);

            if ($rep_del) {
                $del_stmt = $pdo->prepare("UPDATE reports SET is_archived=1, archived_at=NOW() WHERE id = ? AND is_archived=0");
                $del_stmt->execute([$del_id]);
                log_audit_event($pdo, $current_user_name, $current_user_email, 'ARCHIVE', 'Reports', $del_id, "Archived report: {$rep_del['title']} (Ref: {$rep_del['code']})");
                $notice_msg = "Report {$rep_del['code']} was archived and can be restored by an administrator.";
            }
        } catch (Exception $e) {
            $error_msg = "Error deleting report: " . $e->getMessage();
        }
    }
}

// -------------------------------------------------------------
// 4. HANDLE DOCUMENT RIGHTS UPDATE (Admin / PS only)
// -------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_rights' && $pdo) {
    if (!$can_view_all) {
        $error_msg = 'Unauthorized to modify document permissions.';
    } else {
        $report_id   = (int)($_POST['report_id'] ?? 0);
        $target_email= trim($_POST['user_email'] ?? '');
        $target_name = trim($_POST['user_name'] ?? '');
        $target_role = trim($_POST['user_role'] ?? 'Officer');
        $can_view    = isset($_POST['can_view']) ? 1 : 0;
        $can_download= isset($_POST['can_download']) ? 1 : 0;

        if ($report_id > 0 && !empty($target_email)) {
            try {
                $stmt = $pdo->prepare("INSERT INTO document_permissions (report_id, user_email, user_name, role, can_view, can_download, granted_by, granted_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
                    ON DUPLICATE KEY UPDATE can_view = VALUES(can_view), can_download = VALUES(can_download), role = VALUES(role), granted_by = VALUES(granted_by), granted_at = NOW()");
                $stmt->execute([$report_id, $target_email, $target_name, $target_role, $can_view, $can_download, $current_user_name]);

                log_audit_event($pdo, $current_user_name, $current_user_email, 'GRANT_RIGHTS', 'Document Rights', $report_id, "Updated document rights on Report #{$report_id} for {$target_name} ({$target_email})");
                $notice_msg = "Document access permissions updated for {$target_name}.";
            } catch (Exception $e) {
                $error_msg = "Error updating rights: " . $e->getMessage();
            }
        }
    }
}

// -------------------------------------------------------------
// 5. FILTER PARAMETERS
// -------------------------------------------------------------
$search_query   = trim($_GET['q'] ?? '');
$filter_status  = trim($_GET['status'] ?? '');
$filter_vis     = trim($_GET['visibility'] ?? '');
$filter_module  = trim($_GET['module'] ?? '');
$filter_project = trim($_GET['project'] ?? '');
$date_from      = trim($_GET['date_from'] ?? '');
$date_to        = trim($_GET['date_to'] ?? '');

// -------------------------------------------------------------
// 6. FETCH REPORTS WITH USER RIGHTS ENFORCEMENT
// -------------------------------------------------------------
$reports = [];
$stats   = ['total' => 0, 'approved' => 0, 'pending' => 0, 'accessible' => 0];

if ($db_connected && $pdo) {
    try {
        $where_clauses = ['r.is_archived = 0'];
        $params = [];

        if (!$can_view_all) {
            // Non-admin / non-PS: can only see own uploads OR reports where admin granted access OR public
            $where_clauses[] = "(r.uploaded_by = ? OR r.uploader_email = ? OR r.id IN (
                SELECT report_id FROM document_permissions WHERE (user_email = ? OR user_name = ?) AND can_view = 1
            ) OR r.visibility = 'Public')";
            $params[] = $current_user_name;
            $params[] = $current_user_email;
            $params[] = $current_user_email;
            $params[] = $current_user_name;
        }

        if (!empty($search_query)) {
            $where_clauses[] = "(r.code LIKE ? OR r.title LIKE ? OR r.project LIKE ? OR r.uploaded_by LIKE ?)";
            $wild = '%' . $search_query . '%';
            $params[] = $wild; $params[] = $wild; $params[] = $wild; $params[] = $wild;
        }
        if (!empty($filter_status)) {
            $where_clauses[] = "r.status = ?";
            $params[] = $filter_status;
        }
        if (!empty($filter_vis)) {
            $where_clauses[] = "r.visibility = ?";
            $params[] = $filter_vis;
        }
        if (!empty($filter_module)) {
            $where_clauses[] = "r.module = ?";
            $params[] = $filter_module;
        }
        if (!empty($filter_project)) {
            $where_clauses[] = "r.project LIKE ?";
            $params[] = '%' . $filter_project . '%';
        }
        if (!empty($date_from)) {
            $where_clauses[] = "r.report_date >= ?";
            $params[] = $date_from;
        }
        if (!empty($date_to)) {
            $where_clauses[] = "r.report_date <= ?";
            $params[] = $date_to;
        }

        $sql = "SELECT r.* FROM reports r";
        if (!empty($where_clauses)) {
            $sql .= " WHERE " . implode(' AND ', $where_clauses);
        }
        $sql .= " ORDER BY r.report_date DESC, r.id DESC";

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $reports = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Fetch counts
        $c_stmt = $pdo->query("SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN status = 'Approved' THEN 1 ELSE 0 END) as approved,
            SUM(CASE WHEN status = 'Pending' OR status = 'Pending Review' THEN 1 ELSE 0 END) as pending
            FROM reports WHERE is_archived=0");
        $counts = $c_stmt->fetch(PDO::FETCH_ASSOC);
        if ($counts) {
            $stats['total']    = (int)($counts['total'] ?? 0);
            $stats['approved'] = (int)($counts['approved'] ?? 0);
            $stats['pending']  = (int)($counts['pending'] ?? 0);
        }
        $stats['accessible'] = count($reports);

    } catch (Exception $e) {
        $reports = [];
    }
}

// -------------------------------------------------------------
// 7. FETCH USERS & PROJECTS FOR DROPDOWNS
// -------------------------------------------------------------
$all_users = [];
$all_projects = [];
$audit_trail_logs = [];

if ($db_connected && $pdo) {
    try {
        $u_stmt = $pdo->query("SELECT id, full_name, email, role, directorate, is_admin FROM users ORDER BY full_name ASC");
        $all_users = $u_stmt->fetchAll(PDO::FETCH_ASSOC);

        $pr_stmt = $pdo->query("SELECT id, sub_programme, programme_title, saga_name, directorate_name FROM projects ORDER BY sub_programme ASC");
        $all_projects = $pr_stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch activity logs if superuser and viewing activity_log tab
        if ($can_view_all && $current_subtab === 'activity_log') {
            $al_stmt = $pdo->query("SELECT * FROM audit_logs WHERE module IN ('Reports', 'Document Rights') ORDER BY created_at DESC LIMIT 100");
            $audit_trail_logs = $al_stmt->fetchAll(PDO::FETCH_ASSOC);
        }
    } catch (Exception $e) {}
}

// System-wide upload catalog. These queries only read document metadata; file access
// continues to use each module's existing permission checks and download routes.
$system_uploads = [];
$add_system_upload = static function (array $row) use (&$system_uploads): void {
    $row['uploaded_at'] = trim((string)($row['uploaded_at'] ?? ''));
    $row['uploaded_by'] = trim((string)($row['uploaded_by'] ?? '')) ?: 'Not recorded';
    $row['uploaded_email'] = trim((string)($row['uploaded_email'] ?? ''));
    $row['file_size'] = isset($row['file_size']) && is_numeric($row['file_size']) ? (int)$row['file_size'] : null;
    $system_uploads[] = $row;
};
if ($db_connected && $pdo) {
    try {
        foreach ($pdo->query("SELECT id, code, title, project, file_name, uploaded_by, uploader_email, created_at FROM reports WHERE is_archived=0 ORDER BY created_at DESC, id DESC")->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $add_system_upload(['module'=>'Reports', 'document'=>$r['file_name'], 'context'=>$r['title'], 'reference'=>$r['code'], 'uploaded_by'=>$r['uploaded_by'] ?? '', 'uploaded_email'=>$r['uploader_email'] ?? '', 'uploaded_at'=>$r['created_at'] ?? '', 'file_size'=>null]);
        }
    } catch (Throwable $e) { error_log('System uploads: reports metadata unavailable: ' . $e->getMessage()); }
    try {
        $meetingRows = $pdo->query("SELECT d.id, d.original_name, d.file_size, d.uploaded_by, d.uploaded_at, m.title AS context FROM meeting_documents d LEFT JOIN meetings m ON m.id=d.meeting_id ORDER BY d.uploaded_at DESC, d.id DESC")->fetchAll(PDO::FETCH_ASSOC);
        foreach ($meetingRows as $r) $add_system_upload(['module'=>'Meetings', 'document'=>$r['original_name'], 'context'=>$r['context'] ?? 'Meeting minutes', 'reference'=>'', 'uploaded_by'=>$r['uploaded_by'] ?? '', 'uploaded_at'=>$r['uploaded_at'] ?? '', 'file_size'=>$r['file_size'] ?? null]);
    } catch (Throwable $e) { error_log('System uploads: meeting document metadata unavailable: ' . $e->getMessage()); }
    try {
        foreach ($pdo->query("SELECT id, title, original_name, serial_no, financial_year, quarter, uploaded_by, created_at, file_size FROM pc_report_uploads ORDER BY created_at DESC, id DESC")->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $context = trim((string)($r['title'] ?? ''));
            if (!empty($r['serial_no'])) $context .= ($context !== '' ? ' · ' : '') . 'KPI ' . $r['serial_no'];
            if (!empty($r['financial_year'])) $context .= ($context !== '' ? ' · ' : '') . $r['financial_year'];
            $add_system_upload(['module'=>'Performance Contract', 'document'=>$r['original_name'], 'context'=>$context, 'reference'=>!empty($r['quarter']) ? 'Quarter ' . $r['quarter'] : '', 'uploaded_by'=>$r['uploaded_by'] ?? '', 'uploaded_at'=>$r['created_at'] ?? '', 'file_size'=>$r['file_size'] ?? null]);
        }
    } catch (Throwable $e) { error_log('System uploads: performance contract metadata unavailable: ' . $e->getMessage()); }
    try {
        $legacyRows = $pdo->query("SELECT m.id, m.title, m.document, m.created_at FROM meetings m WHERE m.document IS NOT NULL AND TRIM(m.document)<>'' AND NOT EXISTS (SELECT 1 FROM meeting_documents d WHERE d.meeting_id=m.id AND d.stored_name=m.document)")->fetchAll(PDO::FETCH_ASSOC);
        foreach ($legacyRows as $r) $add_system_upload(['module'=>'Meetings', 'document'=>basename((string)$r['document']), 'context'=>$r['title'], 'reference'=>'Legacy attachment', 'uploaded_by'=>'Not recorded', 'uploaded_at'=>$r['created_at'] ?? '', 'file_size'=>null]);
    } catch (Throwable $e) { /* Legacy meeting attachments may not exist in older schemas. */ }
}
usort($system_uploads, static fn($a, $b) => (strtotime($b['uploaded_at']) ?: 0) <=> (strtotime($a['uploaded_at']) ?: 0));
$system_upload_modules = array_values(array_unique(array_column($system_uploads, 'module')));
sort($system_upload_modules, SORT_NATURAL | SORT_FLAG_CASE);
$system_upload_accounts = [];
foreach ($all_users as $systemUser) {
    $role = trim((string)($systemUser['role'] ?? '')) ?: 'User';
    $name = trim((string)($systemUser['full_name'] ?? ''));
    $email = trim((string)($systemUser['email'] ?? ''));
    if ($name !== '') $system_upload_accounts[] = ['name'=>$name, 'email'=>$email, 'role'=>$role];
}
$system_upload_roles = array_values(array_unique(array_column($system_upload_accounts, 'role')));
sort($system_upload_roles, SORT_NATURAL | SORT_FLAG_CASE);
foreach ($system_uploads as &$uploadRow) {
    $uploadRow['account_role'] = 'Unassigned / legacy';
    $uploadRow['account_email'] = $uploadRow['uploaded_email'];
    foreach ($system_upload_accounts as $systemAccount) {
        $emailMatch = $uploadRow['uploaded_email'] !== '' && strcasecmp($systemAccount['email'], $uploadRow['uploaded_email']) === 0;
        $nameMatch = $uploadRow['uploaded_email'] === '' && strcasecmp($systemAccount['name'], $uploadRow['uploaded_by']) === 0;
        if ($emailMatch || $nameMatch) {
            $uploadRow['account_role'] = $systemAccount['role'];
            if ($uploadRow['account_email'] === '') $uploadRow['account_email'] = $systemAccount['email'];
            break;
        }
    }
}
unset($uploadRow);
$system_upload_query = trim((string)($_GET['su_q'] ?? ''));
$system_upload_module = trim((string)($_GET['su_module'] ?? ''));
$system_upload_account = trim((string)($_GET['su_account'] ?? ''));
$system_upload_from = trim((string)($_GET['su_from'] ?? ''));
$system_upload_to = trim((string)($_GET['su_to'] ?? ''));
$system_uploads = array_values(array_filter($system_uploads, static function (array $row) use ($system_upload_query, $system_upload_module, $system_upload_account, $system_upload_from, $system_upload_to): bool {
    if ($system_upload_module !== '' && $row['module'] !== $system_upload_module) return false;
    if (str_starts_with($system_upload_account, 'role:') && $row['account_role'] !== substr($system_upload_account, 5)) return false;
    if (str_starts_with($system_upload_account, 'user:') && strcasecmp($row['uploaded_by'], substr($system_upload_account, 5)) !== 0 && strcasecmp($row['account_email'], substr($system_upload_account, 5)) !== 0) return false;
    $stamp = $row['uploaded_at'] !== '' ? substr($row['uploaded_at'], 0, 10) : '';
    if ($system_upload_from !== '' && ($stamp === '' || $stamp < $system_upload_from)) return false;
    if ($system_upload_to !== '' && ($stamp === '' || $stamp > $system_upload_to)) return false;
    if ($system_upload_query !== '') {
        $haystack = strtolower(implode(' ', [(string)$row['module'], (string)$row['document'], (string)$row['context'], (string)$row['reference'], (string)$row['uploaded_by'], (string)$row['account_email'], (string)$row['account_role']]));
        if (!str_contains($haystack, strtolower($system_upload_query))) return false;
    }
    return true;
}));
$system_upload_total = count($system_uploads);
$system_upload_page_size = 25;
$system_upload_pages = max(1, (int)ceil($system_upload_total / $system_upload_page_size));
$system_upload_page = max(1, min($system_upload_pages, (int)($_GET['su_page'] ?? 1)));
$system_upload_page_rows = array_slice($system_uploads, ($system_upload_page - 1) * $system_upload_page_size, $system_upload_page_size);
$system_upload_page_url = static function (int $page) use ($system_upload_query, $system_upload_module, $system_upload_account, $system_upload_from, $system_upload_to): string {
    return 'reports.php?' . http_build_query(array_filter(['tab'=>'system_uploads', 'su_q'=>$system_upload_query, 'su_module'=>$system_upload_module, 'su_account'=>$system_upload_account, 'su_from'=>$system_upload_from, 'su_to'=>$system_upload_to, 'su_page'=>$page], static fn($value) => $value !== ''));
};

// Build a data-backed, downloadable report from the selected system modules.
$ai_report = null;
$ai_error = '';
$ai_selected_sources = ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'generate_ai_report') ? (array)($_POST['ai_sources'] ?? []) : ['projects'];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'generate_ai_report' && $db_connected && $pdo) {
    $ai_prompt = trim((string)($_POST['ai_prompt'] ?? ''));
    $ai_title = trim((string)($_POST['ai_title'] ?? '')) ?: 'System Data Report';
    $ai_from = trim((string)($_POST['ai_from'] ?? ''));
    $ai_to = trim((string)($_POST['ai_to'] ?? ''));
    $ai_sources = array_values(array_intersect((array)($_POST['ai_sources'] ?? []), ['projects','actions','events','meetings','reports']));
    if ($ai_prompt === '') $ai_error = 'Describe the report you want to generate.';
    elseif (!$ai_sources) $ai_error = 'Select at least one system data source.';
    else {
        $sourceDefinitions = [
            'projects'=>['label'=>'Projects & Programmes','sql'=>'SELECT project_code AS Reference, programme_title AS Programme, sub_programme AS Project, status AS Status, priority_tier AS Priority, overall_progress_pct AS Progress, total_budget AS Budget, funds_utilized AS Funds_Utilized, end_date AS Target_Date FROM projects WHERE is_archived=0','date'=>'created_at'],
            'actions'=>['label'=>'Action Points','sql'=>'SELECT ref_no AS Reference, meeting_title AS Meeting, issue AS Issue, person_responsible AS Responsible, status AS Status, timeline AS Due_Date FROM action_points WHERE 1=1','date'=>'action_date'],
            'events'=>['label'=>'Activities & Events','sql'=>'SELECT title AS Title, event_type AS Type, event_date AS Event_Date, status AS Status, priority AS Priority, location AS Location, host AS Host FROM diary_events WHERE 1=1','date'=>'event_date'],
            'meetings'=>['label'=>'Meetings','sql'=>'SELECT title AS Meeting, meeting_date AS Meeting_Date, venue AS Venue, attendees AS Attendees, agenda AS Agenda, decisions AS Decisions FROM meetings WHERE 1=1','date'=>'meeting_date'],
            'reports'=>['label'=>'Reports Repository','sql'=>'SELECT code AS Reference, title AS Title, project AS Project, report_date AS Report_Date, status AS Status, visibility AS Visibility, uploaded_by AS Uploaded_By, summary AS Summary FROM reports WHERE 1=1','date'=>'report_date'],
        ];
        $ai_report = ['title'=>$ai_title, 'prompt'=>$ai_prompt, 'generated_at'=>date('d M Y H:i'), 'sections'=>[]];
        foreach ($ai_sources as $sourceKey) {
            $definition = $sourceDefinitions[$sourceKey];
            $sql = $definition['sql'];
            $params = [];
            if ($sourceKey === 'reports' && !$can_view_all) {
                $sql .= " AND (visibility = 'Public' OR uploaded_by = ? OR uploader_email = ? OR id IN (SELECT report_id FROM document_permissions WHERE (user_email = ? OR user_name = ?) AND can_view = 1))";
                array_push($params, $current_user_name, $current_user_email, $current_user_email, $current_user_name);
            }
            if ($ai_from !== '') { $sql .= ' AND ' . $definition['date'] . ' >= ?'; $params[] = $ai_from; }
            if ($ai_to !== '') { $sql .= ' AND ' . $definition['date'] . ' <= ?'; $params[] = $ai_to; }
            $sql .= ' ORDER BY ' . $definition['date'] . ' DESC LIMIT 100';
            try {
                $statement = $pdo->prepare($sql);
                $statement->execute($params);
                $ai_report['sections'][] = ['label'=>$definition['label'], 'rows'=>$statement->fetchAll(PDO::FETCH_ASSOC)];
            } catch (Throwable $e) {
                error_log('Generate with AI data source ' . $sourceKey . ': ' . $e->getMessage());
                $ai_report['sections'][] = ['label'=>$definition['label'], 'rows'=>[], 'error'=>'This data source is unavailable in the current database.'];
            }
        }
        $ai_report['status_summary'] = [];
        foreach ($ai_report['sections'] as $section) {
            foreach ($section['rows'] as $record) {
                foreach (['Status', 'Priority'] as $summaryColumn) {
                    if (!empty($record[$summaryColumn])) {
                        $summaryValue = trim((string)$record[$summaryColumn]);
                        $ai_report['status_summary'][$summaryColumn][$summaryValue] = ($ai_report['status_summary'][$summaryColumn][$summaryValue] ?? 0) + 1;
                    }
                }
            }
        }
    }
}

require_once __DIR__ . '/../includes/header.php';
?>

<div style="display: flex; flex-direction: column; gap: 20px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">

    <!-- Heading Block (Exact original layout from reports.php) -->
    <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px;">
        <div>
            <h2 style="font-size: 1.25rem; font-weight: 800; color: #0f172a; margin: 0; display: flex; align-items: center; gap: 8px;">
                📑 Ministerial Reports &amp; Verification Repository
            </h2>
            <span style="font-size: 0.8rem; color: #64748b;">Statutory evaluation documentation, field inspection briefs, and audit attachments</span>
        </div>

        <!-- Action Buttons -->
        <div style="display: flex; gap: 8px; align-items: center; flex-wrap: wrap;">
            <?php if ($can_view_all): ?>
                <span style="background: #ecfdf5; color: #065f46; border: 1px solid #10b981; padding: 5px 10px; border-radius: 4px; font-size: 0.72rem; font-weight: 700;">
                    🛡️ <?= htmlspecialchars($current_user_role) ?> (Universal View)
                </span>
            <?php endif; ?>

            <button onclick="document.getElementById('uploadModal').style.display='flex';" 
                    style="background: #1a61c1; color: white; border: none; padding: 6px 14px; border-radius: 4px; font-size: 0.72rem; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; gap: 4px;">
                📤 Upload Report
            </button>
        </div>
    </div>

    <!-- Alert Notices -->
    <?php if ($notice_msg): ?>
        <div style="background: #ecfdf5; border-left: 4px solid #10b981; color: #065f46; padding: 10px 14px; border-radius: 4px; font-size: 0.78rem; font-weight: 600;">
            <?= htmlspecialchars($notice_msg) ?>
        </div>
    <?php endif; ?>
    <?php if ($error_msg): ?>
        <div style="background: #fef2f2; border-left: 4px solid #ef4444; color: #991b1b; padding: 10px 14px; border-radius: 4px; font-size: 0.78rem; font-weight: 600;">
            <?= htmlspecialchars($error_msg) ?>
        </div>
    <?php endif; ?>

    <!-- Sub-navigation Tabs -->
    <div style="display: flex; gap: 6px; border-bottom: 2px solid #e2e8f0; padding-bottom: 6px; overflow-x: auto;">
        <a href="reports.php?tab=repository" 
           style="padding: 6px 12px; text-decoration: none; font-size: 0.78rem; font-weight: 700; border-radius: 4px; <?= $current_subtab === 'repository' ? 'background: #1a61c1; color: white;' : 'color: #475569; background: #f8fafc;' ?>">
            📋 General Repository (<?= $stats['accessible'] ?>)
        </a>
        <a href="reports.php?tab=generate_prompt" 
           style="padding: 6px 12px; text-decoration: none; font-size: 0.78rem; font-weight: 700; border-radius: 4px; <?= $current_subtab === 'generate_prompt' ? 'background: #1a61c1; color: white;' : 'color: #475569; background: #f8fafc;' ?>">
            ✨ Generate with AI
        </a>
        <a href="reports.php?tab=system_uploads" 
           style="padding: 6px 12px; text-decoration: none; font-size: 0.78rem; font-weight: 700; border-radius: 4px; <?= $current_subtab === 'system_uploads' ? 'background: #1a61c1; color: white;' : 'color: #475569; background: #f8fafc;' ?>">
            🗂️ System Uploads (<?= $system_upload_total ?>)
        </a>
        <a href="document_rights.php" 
           style="padding: 6px 12px; text-decoration: none; font-size: 0.78rem; font-weight: 700; border-radius: 4px; <?= $current_subtab === 'rights' ? 'background: #1a61c1; color: white;' : 'color: #475569; background: #f8fafc;' ?>">
            🔑 Document Rights Matrix
        </a>
        <?php if ($can_view_all): ?>
            <a href="reports.php?tab=activity_log" 
               style="padding: 6px 12px; text-decoration: none; font-size: 0.78rem; font-weight: 700; border-radius: 4px; <?= $current_subtab === 'activity_log' ? 'background: #0f172a; color: white;' : 'color: #0f172a; background: #f1f5f9;' ?>">
                🛡️ System Activity Log (Admin/PS)
            </a>
        <?php endif; ?>
    </div>

    <!-- ========================================================================= -->
    <!-- TAB 1: REPORTS REPOSITORY (DEFAULT) -->
    <!-- ========================================================================= -->
    <?php if ($current_subtab === 'repository'): ?>
        <!-- KPI Indicators -->
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 12px;">
            <div style="background: white; border: 1px solid #e2e8f0; border-radius: 6px; padding: 12px; border-top: 3px solid #1a61c1;">
                <div style="font-size: 0.7rem; color: #64748b; font-weight: 700; text-transform: uppercase;">Accessible Documents</div>
                <div style="font-size: 1.4rem; font-weight: 800; color: #0f172a; margin-top: 2px;"><?= $stats['accessible'] ?></div>
                <div style="font-size: 0.68rem; color: #1a61c1;">Based on your credentials</div>
            </div>
            <div style="background: white; border: 1px solid #e2e8f0; border-radius: 6px; padding: 12px; border-top: 3px solid #10b981;">
                <div style="font-size: 0.7rem; color: #64748b; font-weight: 700; text-transform: uppercase;">Approved Reports</div>
                <div style="font-size: 1.4rem; font-weight: 800; color: #065f46; margin-top: 2px;"><?= $stats['approved'] ?></div>
                <div style="font-size: 0.68rem; color: #10b981;">Statutory certified</div>
            </div>
            <div style="background: white; border: 1px solid #e2e8f0; border-radius: 6px; padding: 12px; border-top: 3px solid #f59e0b;">
                <div style="font-size: 0.7rem; color: #64748b; font-weight: 700; text-transform: uppercase;">Pending Review</div>
                <div style="font-size: 1.4rem; font-weight: 800; color: #92400e; margin-top: 2px;"><?= $stats['pending'] ?></div>
                <div style="font-size: 0.68rem; color: #d97706;">Awaiting directorate sign-off</div>
            </div>
            <div style="background: white; border: 1px solid #e2e8f0; border-radius: 6px; padding: 12px; border-top: 3px solid #475569;">
                <div style="font-size: 0.7rem; color: #64748b; font-weight: 700; text-transform: uppercase;">Total In Database</div>
                <div style="font-size: 1.4rem; font-weight: 800; color: #334155; margin-top: 2px;"><?= $stats['total'] ?></div>
                <div style="font-size: 0.68rem; color: #64748b;">Entire PP-SDOMS catalog</div>
            </div>
        </div>

        <!-- Filter Form -->
        <div style="background: #ffffff; border-radius: 8px; border: 1px solid #e2e8f0; padding: 14px 18px;">
            <div style="font-size: 0.8rem; font-weight: 800; color: #1a61c1; margin-bottom: 10px;">
                🔍 Filter Reports by Module, Classification, Status &amp; Horizon
            </div>
            <form method="GET" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 10px; align-items: end;">
                <input type="hidden" name="tab" value="repository">
                <div>
                    <label style="display: block; font-size: 0.7rem; font-weight: 700; color: #475569; margin-bottom: 2px;">Search Keyword</label>
                    <input type="text" name="q" value="<?= htmlspecialchars($search_query) ?>" placeholder="Code, title, officer..." 
                           style="width: 100%; padding: 6px 8px; font-size: 0.75rem; border: 1px solid #cbd5e1; border-radius: 4px;">
                </div>
                <div>
                    <label style="display: block; font-size: 0.7rem; font-weight: 700; color: #475569; margin-bottom: 2px;">Module</label>
                    <select name="module" style="width: 100%; padding: 6px 8px; font-size: 0.75rem; border: 1px solid #cbd5e1; border-radius: 4px;">
                        <option value="">All Modules</option>
                        <option value="Projects" <?= $filter_module === 'Projects' ? 'selected' : '' ?>>Projects &amp; Programmes</option>
                        <option value="Flagships" <?= $filter_module === 'Flagships' ? 'selected' : '' ?>>Priority Flagships</option>
                        <option value="Action Points" <?= $filter_module === 'Action Points' ? 'selected' : '' ?>>Action Points</option>
                        <option value="Performance Contract" <?= $filter_module === 'Performance Contract' ? 'selected' : '' ?>>Performance Contract</option>
                        <option value="Meetings" <?= $filter_module === 'Meetings' ? 'selected' : '' ?>>Meetings</option>
                        <option value="Diary" <?= $filter_module === 'Diary' ? 'selected' : '' ?>>Diary &amp; Events</option>
                    </select>
                </div>
                <div>
                    <label style="display: block; font-size: 0.7rem; font-weight: 700; color: #475569; margin-bottom: 2px;">Review Status</label>
                    <select name="status" style="width: 100%; padding: 6px 8px; font-size: 0.75rem; border: 1px solid #cbd5e1; border-radius: 4px;">
                        <option value="">All Statuses</option>
                        <option value="Approved" <?= $filter_status === 'Approved' ? 'selected' : '' ?>>Approved</option>
                        <option value="Pending Review" <?= ($filter_status === 'Pending' || $filter_status === 'Pending Review') ? 'selected' : '' ?>>Pending Review</option>
                        <option value="Draft" <?= $filter_status === 'Draft' ? 'selected' : '' ?>>Draft</option>
                    </select>
                </div>
                <div>
                    <label style="display: block; font-size: 0.7rem; font-weight: 700; color: #475569; margin-bottom: 2px;">Classification</label>
                    <select name="visibility" style="width: 100%; padding: 6px 8px; font-size: 0.75rem; border: 1px solid #cbd5e1; border-radius: 4px;">
                        <option value="">All Classifications</option>
                        <option value="Public" <?= $filter_vis === 'Public' ? 'selected' : '' ?>>Public</option>
                        <option value="Restricted" <?= $filter_vis === 'Restricted' ? 'selected' : '' ?>>Restricted</option>
                        <option value="Confidential" <?= $filter_vis === 'Confidential' ? 'selected' : '' ?>>Confidential</option>
                        <option value="Directorate Only" <?= $filter_vis === 'Directorate Only' ? 'selected' : '' ?>>Directorate Only</option>
                    </select>
                </div>
                <div>
                    <label style="display: block; font-size: 0.7rem; font-weight: 700; color: #475569; margin-bottom: 2px;">From Date</label>
                    <input type="date" name="date_from" value="<?= htmlspecialchars($date_from) ?>" 
                           style="width: 100%; padding: 5px 8px; font-size: 0.75rem; border: 1px solid #cbd5e1; border-radius: 4px;">
                </div>
                <div style="display: flex; gap: 6px;">
                    <button type="submit" style="flex: 1; background: #1a61c1; color: white; border: none; padding: 7px 10px; border-radius: 4px; font-size: 0.75rem; font-weight: 700; cursor: pointer;">
                        Filter
                    </button>
                    <a href="reports.php" style="background: #f1f5f9; color: #475569; border: 1px solid #cbd5e1; text-decoration: none; padding: 7px 10px; border-radius: 4px; font-size: 0.75rem; font-weight: 700;">
                        Reset
                    </a>
                </div>
            </form>
        </div>

        <!-- Reports Table -->
        <div style="background: #ffffff; border-radius: 8px; border: 1px solid #e2e8f0; overflow: hidden; box-shadow: 0 2px 4px rgba(0,0,0,0.02);">
            <div style="overflow-x: auto;">
                <table style="width: 100%; border-collapse: collapse; font-size: 0.8rem; text-align: left;">
                    <thead>
                        <tr style="background: #f8fafc; color: #475569; font-weight: 700; border-bottom: 2px solid #e2e8f0; text-transform: uppercase; font-size: 0.72rem;">
                            <th style="padding: 12px 16px;">Report Code</th>
                            <th style="padding: 12px 16px;">Document Title &amp; Project Scope</th>
                            <th style="padding: 12px 16px;">Submission Date</th>
                            <th style="padding: 12px 16px;">Classification</th>
                            <th style="padding: 12px 16px;">Review Status</th>
                            <th style="padding: 12px 16px;">Access Mode</th>
                            <th style="padding: 12px 16px; text-align: right;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($reports)): ?>
                            <tr><td colspan="7" style="padding: 24px; text-align: center; color: #64748b;">No reports found matching your criteria.</td></tr>
                        <?php endif; ?>

                        <?php foreach ($reports as $r): ?>
                            <tr style="border-bottom: 1px solid #f1f5f9;">
                                <td style="padding: 14px 16px; font-family: 'JetBrains Mono', monospace; font-weight: 800; color: #1a61c1;">
                                    <?= htmlspecialchars($r['code']) ?>
                                </td>
                                <td style="padding: 14px 16px;">
                                    <div style="font-weight: 700; color: #0f172a;"><?= htmlspecialchars($r['title']) ?></div>
                                    <div style="font-size: 0.72rem; color: #64748b;">
                                        <?= htmlspecialchars($r['project'] ?? 'SDMS') ?> &bull; Submitted by: <?= htmlspecialchars($r['uploaded_by'] ?? 'MOH') ?>
                                    </div>
                                </td>
                                <td style="padding: 14px 16px; font-family: 'JetBrains Mono', monospace; font-size: 0.75rem;">
                                    <?= htmlspecialchars(($reportTs = strtotime((string)$r['report_date'])) ? date('d M Y', $reportTs) : (string)$r['report_date']) ?>
                                </td>
                                <td style="padding: 14px 16px;">
                                    <?php
                                        $vis_bg = '#f1f5f9'; $vis_color = '#334155';
                                        if ($r['visibility'] === 'Confidential') { $vis_bg = '#fef2f2'; $vis_color = '#991b1b'; }
                                        elseif ($r['visibility'] === 'Restricted') { $vis_bg = '#fffbeb'; $vis_color = '#92400e'; }
                                        elseif ($r['visibility'] === 'Public') { $vis_bg = '#ecfdf5'; $vis_color = '#065f46'; }
                                    ?>
                                    <span style="background: <?= $vis_bg ?>; color: <?= $vis_color ?>; font-size: 0.7rem; font-weight: 700; padding: 2px 8px; border-radius: 4px; border: 1px solid rgba(0,0,0,0.06);">
                                        <?= htmlspecialchars($r['visibility']) ?>
                                    </span>
                                </td>
                                <td style="padding: 14px 16px;">
                                    <span style="background: <?= $r['status'] === 'Approved' ? '#ecfdf5; color: #065f46;' : '#fef3c7; color: #92400e;' ?>; font-size: 0.7rem; font-weight: 800; padding: 3px 8px; border-radius: 10px;">
                                        <?= htmlspecialchars($r['status']) ?>
                                    </span>
                                </td>
                                <td style="padding: 14px 16px; font-size: 0.72rem;">
                                    <?php if ($can_view_all): ?>
                                        <span style="color: #1a61c1; font-weight: 700;">Admin / PS</span>
                                    <?php elseif (($r['uploaded_by'] ?? '') === $current_user_name): ?>
                                        <span style="color: #10b981; font-weight: 700;">Owner (Uploaded)</span>
                                    <?php else: ?>
                                        <span style="color: #475569; font-weight: 600;">Granted</span>
                                    <?php endif; ?>
                                </td>
                                <td style="padding: 14px 16px; text-align: right;">
                                    <div style="display: flex; gap: 6px; justify-content: flex-end;">
                                        <button onclick="previewReportBrief('<?= htmlspecialchars(addslashes($r['code'])) ?>', '<?= htmlspecialchars(addslashes($r['title'])) ?>', '<?= htmlspecialchars(addslashes($r['project'] ?? '')) ?>', '<?= htmlspecialchars(addslashes($r['report_date'])) ?>', '<?= htmlspecialchars(addslashes($r['uploaded_by'] ?? '')) ?>', '<?= htmlspecialchars(addslashes($r['summary'] ?? '')) ?>');" 
                                                style="background: #f1f5f9; color: #1a61c1; border: 1px solid #cbd5e1; padding: 4px 8px; border-radius: 4px; font-size: 0.72rem; font-weight: 700; cursor: pointer;">
                                            👁️ Brief
                                        </button>
                                        <a href="reports.php?download=<?= $r['id'] ?>" 
                                           style="background: #1a61c1; color: white; text-decoration: none; padding: 4px 10px; border-radius: 4px; font-size: 0.72rem; font-weight: 700; display: inline-flex; align-items: center; gap: 4px;">
                                            ⬇️ Download
                                        </a>
                                        <?php if ($can_view_all): ?>
                                            <form method="POST" style="display: inline;" onsubmit="return confirm('Delete report <?= htmlspecialchars($r['code']) ?>?');">
                                                <input type="hidden" name="action" value="delete_report">
                                                <input type="hidden" name="report_id" value="<?= $r['id'] ?>">
                                                <button type="submit" style="background: transparent; color: #dc2626; border: 1px solid #fecaca; padding: 4px 6px; border-radius: 4px; font-size: 0.72rem; cursor: pointer;">
                                                    🗑️
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

    <?php elseif ($current_subtab === 'system_uploads'): ?>
        <section style="background:#fff;border:1px solid #e2e8f0;border-radius:9px;padding:18px;box-shadow:0 2px 5px rgba(15,23,42,.04);">
            <div style="display:flex;justify-content:space-between;align-items:flex-end;gap:12px;flex-wrap:wrap;margin-bottom:14px;">
                <div><h3 style="margin:0;color:#0f172a;font-size:1rem;font-weight:800;">System Uploads</h3><p style="margin:4px 0 0;color:#64748b;font-size:.78rem;">Documents uploaded through Reports, Meetings, and Performance Contract modules.</p></div>
                <span style="color:#475569;font-size:.76rem;font-weight:700;"><?= $system_upload_total ?> document<?= $system_upload_total === 1 ? '' : 's' ?></span>
            </div>
            <form method="get" action="reports.php" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;align-items:end;margin-bottom:14px;padding:12px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;">
                <input type="hidden" name="tab" value="system_uploads">
                <label style="display:grid;gap:4px;color:#475569;font-size:.68rem;font-weight:800;text-transform:uppercase;">Search
                    <input type="search" name="su_q" value="<?= htmlspecialchars($system_upload_query) ?>" placeholder="Document, title, uploader…" style="width:100%;box-sizing:border-box;padding:8px 10px;border:1px solid #cbd5e1;border-radius:6px;font-size:.78rem;text-transform:none;">
                </label>
                <label style="display:grid;gap:4px;color:#475569;font-size:.68rem;font-weight:800;text-transform:uppercase;">Module
                    <select name="su_module" style="width:100%;box-sizing:border-box;padding:8px 10px;border:1px solid #cbd5e1;border-radius:6px;background:#fff;font-size:.78rem;text-transform:none;"><option value="">All modules</option><?php foreach ($system_upload_modules as $moduleOption): ?><option value="<?= htmlspecialchars($moduleOption) ?>" <?= $system_upload_module === $moduleOption ? 'selected' : '' ?>><?= htmlspecialchars($moduleOption) ?></option><?php endforeach; ?></select>
                </label>
                <label style="display:grid;gap:4px;color:#475569;font-size:.68rem;font-weight:800;text-transform:uppercase;">User Account
                    <select name="su_account" style="width:100%;box-sizing:border-box;padding:8px 10px;border:1px solid #cbd5e1;border-radius:6px;background:#fff;font-size:.78rem;text-transform:none;"><option value="">All accounts</option><optgroup label="RBAC categories"><?php foreach ($system_upload_roles as $roleOption): ?><option value="role:<?= htmlspecialchars($roleOption) ?>" <?= $system_upload_account === 'role:' . $roleOption ? 'selected' : '' ?>><?= htmlspecialchars($roleOption) ?></option><?php endforeach; ?><option value="role:Unassigned / legacy" <?= $system_upload_account === 'role:Unassigned / legacy' ? 'selected' : '' ?>>Unassigned / legacy</option></optgroup><optgroup label="Usernames"><?php foreach ($system_upload_accounts as $accountOption): ?><?php $accountValue = $accountOption['email'] !== '' ? $accountOption['email'] : $accountOption['name']; ?><option value="user:<?= htmlspecialchars($accountValue) ?>" <?= $system_upload_account === 'user:' . $accountValue ? 'selected' : '' ?>><?= htmlspecialchars($accountOption['name']) ?><?= $accountOption['email'] !== '' ? ' · ' . htmlspecialchars($accountOption['email']) : '' ?></option><?php endforeach; ?></optgroup></select>
                </label>
                <label style="display:grid;gap:4px;color:#475569;font-size:.68rem;font-weight:800;text-transform:uppercase;">Uploaded from
                    <input type="date" name="su_from" value="<?= htmlspecialchars($system_upload_from) ?>" style="width:100%;box-sizing:border-box;padding:7px 9px;border:1px solid #cbd5e1;border-radius:6px;font-size:.78rem;text-transform:none;">
                </label>
                <label style="display:grid;gap:4px;color:#475569;font-size:.68rem;font-weight:800;text-transform:uppercase;">Uploaded to
                    <input type="date" name="su_to" value="<?= htmlspecialchars($system_upload_to) ?>" style="width:100%;box-sizing:border-box;padding:7px 9px;border:1px solid #cbd5e1;border-radius:6px;font-size:.78rem;text-transform:none;">
                </label>
                <div style="display:flex;gap:7px;"><button type="submit" style="flex:1;padding:8px 12px;border:0;border-radius:6px;background:#1a61c1;color:#fff;font-size:.76rem;font-weight:800;cursor:pointer;">Filter</button><a href="reports.php?tab=system_uploads" style="display:inline-flex;align-items:center;padding:8px 11px;border:1px solid #cbd5e1;border-radius:6px;background:#fff;color:#475569;text-decoration:none;font-size:.76rem;font-weight:700;">Reset</a></div>
            </form>
            <div style="overflow-x:auto;border:1px solid #e2e8f0;border-radius:7px;">
                <table style="width:100%;min-width:820px;border-collapse:collapse;font-size:.78rem;text-align:left;">
                    <thead><tr style="background:#f1f5f9;color:#475569;font-size:.68rem;text-transform:uppercase;letter-spacing:.04em;"><th style="padding:11px 12px;">Module</th><th style="padding:11px 12px;">Document</th><th style="padding:11px 12px;">Record / Context</th><th style="padding:11px 12px;">Uploaded by</th><th style="padding:11px 12px;">Date &amp; time</th><th style="padding:11px 12px;text-align:right;">Size</th></tr></thead>
                    <tbody>
                    <?php if (!$system_upload_page_rows): ?><tr><td colspan="6" style="padding:28px;text-align:center;color:#64748b;">No uploaded documents match these filters.</td></tr><?php endif; ?>
                    <?php foreach ($system_upload_page_rows as $uploadRow): ?>
                        <tr style="border-top:1px solid #edf1f6;">
                            <td style="padding:11px 12px;"><span style="display:inline-flex;padding:4px 8px;border-radius:999px;background:#eff6ff;color:#1d4ed8;font-size:.67rem;font-weight:800;white-space:nowrap;"><?= htmlspecialchars($uploadRow['module']) ?></span></td>
                            <td style="padding:11px 12px;color:#0f172a;font-weight:750;overflow-wrap:anywhere;"><?= htmlspecialchars((string)$uploadRow['document']) ?></td>
                            <td style="padding:11px 12px;color:#475569;"><?= htmlspecialchars((string)$uploadRow['context']) ?><?= $uploadRow['reference'] !== '' ? '<div style="margin-top:3px;color:#64748b;font-size:.68rem;">' . htmlspecialchars((string)$uploadRow['reference']) . '</div>' : '' ?></td>
                            <td style="padding:11px 12px;color:#334155;"><div style="font-weight:700;white-space:nowrap;"><?= htmlspecialchars((string)$uploadRow['uploaded_by']) ?></div><?php if ($uploadRow['account_email'] !== '' || $uploadRow['account_role'] !== 'Unassigned / legacy'): ?><div style="margin-top:3px;color:#64748b;font-size:.66rem;white-space:nowrap;"><?= htmlspecialchars((string)$uploadRow['account_role']) ?><?= $uploadRow['account_email'] !== '' ? ' · ' . htmlspecialchars((string)$uploadRow['account_email']) : '' ?></div><?php endif; ?></td>
                            <td style="padding:11px 12px;color:#475569;white-space:nowrap;"><?php $uploadTs = $uploadRow['uploaded_at'] !== '' ? strtotime($uploadRow['uploaded_at']) : false; ?><?= $uploadTs ? htmlspecialchars(date('d M Y, H:i', $uploadTs)) : 'Not recorded' ?></td>
                            <td style="padding:11px 12px;text-align:right;color:#64748b;white-space:nowrap;"><?php if ($uploadRow['file_size'] === null): ?>—<?php elseif ($uploadRow['file_size'] >= 1048576): ?><?= number_format($uploadRow['file_size'] / 1048576, 1) ?> MB<?php elseif ($uploadRow['file_size'] >= 1024): ?><?= number_format($uploadRow['file_size'] / 1024, 0) ?> KB<?php else: ?><?= (int)$uploadRow['file_size'] ?> B<?php endif; ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php if ($system_upload_pages > 1): ?>
                <nav aria-label="System uploads pages" style="display:flex;justify-content:space-between;align-items:center;gap:10px;margin-top:12px;color:#64748b;font-size:.76rem;">
                    <span>Page <?= $system_upload_page ?> of <?= $system_upload_pages ?></span>
                    <div style="display:flex;gap:6px;"><?php if ($system_upload_page > 1): ?><a href="<?= htmlspecialchars($system_upload_page_url($system_upload_page - 1)) ?>" style="padding:6px 10px;border:1px solid #cbd5e1;border-radius:5px;color:#334155;text-decoration:none;">Previous</a><?php endif; ?><?php if ($system_upload_page < $system_upload_pages): ?><a href="<?= htmlspecialchars($system_upload_page_url($system_upload_page + 1)) ?>" style="padding:6px 10px;border:1px solid #cbd5e1;border-radius:5px;color:#334155;text-decoration:none;">Next</a><?php endif; ?></div>
                </nav>
            <?php endif; ?>
        </section>

    <!-- ========================================================================= -->
    <!-- TAB 2: GENERATE WITH AI -->
    <!-- ========================================================================= -->
    <?php elseif ($current_subtab === 'generate_prompt'): ?>
        <section style="background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:20px;">
            <div style="display:flex;justify-content:space-between;gap:14px;align-items:flex-start;flex-wrap:wrap;margin-bottom:16px;">
                <div><h3 style="margin:0 0 5px;color:#0f172a;font-size:1.05rem;font-weight:850;">✨ Generate with AI</h3><p style="margin:0;color:#64748b;font-size:.8rem;max-width:740px;line-height:1.5;">Choose live system data, describe the brief you need, then generate a formatted report you can download as a Word document or print to PDF.</p></div>
                <span style="padding:6px 9px;border-radius:99px;background:#ecfdf5;color:#047857;font-size:.68rem;font-weight:800;">Live system data</span>
            </div>
            <?php if ($ai_error !== ''): ?><div style="margin-bottom:12px;padding:10px 12px;border:1px solid #fecaca;border-radius:7px;background:#fef2f2;color:#991b1b;font-size:.78rem;"><?= htmlspecialchars($ai_error) ?></div><?php endif; ?>
            <form method="post" action="reports.php?tab=generate_prompt" style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:13px;padding:15px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;margin-bottom:18px;">
                <input type="hidden" name="action" value="generate_ai_report">
                <label style="display:grid;gap:5px;color:#334155;font-size:.72rem;font-weight:800;">Document title<input name="ai_title" required value="<?= htmlspecialchars($_POST['ai_title'] ?? '') ?>" placeholder="e.g. Quarterly Programme Performance Brief" style="padding:9px 10px;border:1px solid #cbd5e1;border-radius:6px;font:inherit;font-weight:400;"></label>
                <label style="display:grid;gap:5px;color:#334155;font-size:.72rem;font-weight:800;">Reporting period<div style="display:flex;gap:7px;"><input type="date" name="ai_from" value="<?= htmlspecialchars($_POST['ai_from'] ?? '') ?>" aria-label="From date" style="min-width:0;width:50%;padding:8px;border:1px solid #cbd5e1;border-radius:6px;"><input type="date" name="ai_to" value="<?= htmlspecialchars($_POST['ai_to'] ?? '') ?>" aria-label="To date" style="min-width:0;width:50%;padding:8px;border:1px solid #cbd5e1;border-radius:6px;"></div></label>
                <fieldset style="grid-column:1/-1;border:0;padding:0;margin:0;"><legend style="margin-bottom:7px;color:#334155;font-size:.72rem;font-weight:800;">System data to include</legend><div style="display:flex;gap:8px;flex-wrap:wrap;"><?php foreach (['projects'=>'Projects & Programmes','actions'=>'Action Points','events'=>'Activities & Events','meetings'=>'Meetings','reports'=>'Reports Repository'] as $sourceKey=>$sourceLabel): ?><label style="display:flex;align-items:center;gap:6px;padding:7px 9px;background:#fff;border:1px solid #cbd5e1;border-radius:6px;color:#334155;font-size:.73rem;"><input type="checkbox" name="ai_sources[]" value="<?= $sourceKey ?>" <?= in_array($sourceKey, $ai_selected_sources, true) ? 'checked' : '' ?>><?= htmlspecialchars($sourceLabel) ?></label><?php endforeach; ?></div></fieldset>
                <label style="grid-column:1/-1;display:grid;gap:5px;color:#334155;font-size:.72rem;font-weight:800;">What should the report focus on?<textarea name="ai_prompt" rows="3" required placeholder="Describe the analysis, questions, or audience. Example: Summarize progress, identify delayed actions, and highlight upcoming risks for the quarterly review." style="padding:9px 10px;border:1px solid #cbd5e1;border-radius:6px;font:inherit;font-weight:400;resize:vertical;"><?= htmlspecialchars($_POST['ai_prompt'] ?? '') ?></textarea></label>
                <div style="grid-column:1/-1;display:flex;justify-content:flex-end;"><button type="submit" style="border:0;border-radius:6px;padding:9px 16px;background:#1a61c1;color:#fff;font-size:.78rem;font-weight:800;cursor:pointer;">Generate document</button></div>
            </form>
            <?php if (is_array($ai_report)): ?>
                <div style="display:flex;justify-content:flex-end;gap:8px;margin-bottom:10px;"><button type="button" onclick="downloadAiReportDoc()" style="padding:8px 12px;border:1px solid #1a61c1;border-radius:6px;background:#fff;color:#1a61c1;font-size:.74rem;font-weight:800;cursor:pointer;">Download Word document</button><button type="button" onclick="window.print()" style="padding:8px 12px;border:0;border-radius:6px;background:#10b981;color:#fff;font-size:.74rem;font-weight:800;cursor:pointer;">Print / Save as PDF</button></div>
                <article id="generated-ai-report" style="padding:28px;border:1px solid #cbd5e1;border-radius:6px;background:#fff;color:#1e293b;line-height:1.5;">
                    <header style="text-align:center;border-bottom:2px solid #1a61c1;padding-bottom:13px;margin-bottom:18px;"><img src="/assets/images/kenya_coat_arms.png" alt="Coat of Arms of Kenya" style="display:block;width:54px;height:60px;object-fit:contain;margin:0 auto 7px;" onerror="this.src='/public/assets/images/kenya_coat_arms.png';"><div style="font-size:.72rem;font-weight:800;">REPUBLIC OF KENYA · MINISTRY OF HEALTH</div><div style="font-size:.88rem;font-weight:850;color:#1a61c1;">STATE DEPARTMENT FOR MEDICAL SERVICES</div></header>
                    <h1 style="font-size:1.3rem;margin:0 0 5px;color:#0f172a;"><?= htmlspecialchars($ai_report['title']) ?></h1><p style="margin:0 0 14px;color:#64748b;font-size:.75rem;">Generated <?= htmlspecialchars($ai_report['generated_at']) ?> · Prepared by <?= htmlspecialchars($current_user_name) ?></p>
                    <section style="margin:0 0 18px;padding:12px;background:#f8fafc;border-left:3px solid #1a61c1;"><strong>Report objective</strong><div style="margin-top:4px;font-size:.82rem;"><?= nl2br(htmlspecialchars($ai_report['prompt'])) ?></div></section>
                    <h2 style="font-size:.95rem;color:#0f172a;">Executive overview</h2><p style="font-size:.8rem;">This report compiles <?= array_sum(array_map(static fn($section) => count($section['rows']), $ai_report['sections'])) ?> live system records across <?= count($ai_report['sections']) ?> selected data sources for the requested analysis. The source sections below contain the underlying records for review.</p><?php if ($ai_report['status_summary']): ?><ul style="margin:8px 0 14px;padding-left:20px;font-size:.78rem;"><?php foreach ($ai_report['status_summary'] as $dimension=>$values): ?><li><strong><?= htmlspecialchars($dimension) ?> breakdown:</strong> <?php $summaryParts=[]; foreach ($values as $label=>$count) $summaryParts[] = $label . ' (' . $count . ')'; ?><?= htmlspecialchars(implode(' · ', $summaryParts)) ?></li><?php endforeach; ?></ul><?php endif; ?>
                    <?php foreach ($ai_report['sections'] as $section): ?><section style="margin-top:18px;page-break-inside:avoid;"><h2 style="font-size:.9rem;color:#1a61c1;border-bottom:1px solid #dbeafe;padding-bottom:6px;"><?= htmlspecialchars($section['label']) ?> <span style="font-size:.7rem;color:#64748b;font-weight:600;">(<?= count($section['rows']) ?> records<?= count($section['rows']) === 100 ? ', first 100 shown' : '' ?>)</span></h2><?php if (!empty($section['error'])): ?><p style="color:#b91c1c;font-size:.78rem;"><?= htmlspecialchars($section['error']) ?></p><?php elseif (!$section['rows']): ?><p style="color:#64748b;font-size:.78rem;">No records matched the selected period.</p><?php else: ?><div style="overflow-x:auto;"><table style="width:100%;border-collapse:collapse;font-size:.7rem;"><thead><tr style="background:#eff6ff;text-align:left;"><?php foreach (array_keys($section['rows'][0]) as $column): ?><th style="padding:7px;border:1px solid #dbe3ed;"><?= htmlspecialchars(str_replace('_',' ',(string)$column)) ?></th><?php endforeach; ?></tr></thead><tbody><?php foreach ($section['rows'] as $record): ?><tr><?php foreach ($record as $value): ?><td style="vertical-align:top;padding:7px;border:1px solid #e2e8f0;max-width:260px;overflow-wrap:anywhere;"><?= htmlspecialchars((string)($value ?? '—')) ?></td><?php endforeach; ?></tr><?php endforeach; ?></tbody></table></div><?php endif; ?></section><?php endforeach; ?>
                    <footer style="margin-top:24px;padding-top:10px;border-top:1px solid #cbd5e1;color:#64748b;font-size:.66rem;">Source: PP-SDOMS application database · Generated <?= htmlspecialchars($ai_report['generated_at']) ?></footer>
                </article>
                <style>
                    @media print {
                        @page { margin: 16mm; }
                        body * { visibility: hidden !important; }
                        #generated-ai-report, #generated-ai-report * { visibility: visible !important; }
                        #generated-ai-report { position: absolute !important; inset: 0 auto auto 0 !important; width: 100% !important; box-sizing: border-box !important; padding: 0 !important; border: 0 !important; box-shadow: none !important; }
                        #generated-ai-report table { page-break-inside: auto; }
                        #generated-ai-report tr { page-break-inside: avoid; page-break-after: auto; }
                        #generated-ai-report thead { display: table-header-group; }
                        #generated-ai-report tfoot { display: table-footer-group; }
                    }
                </style>
                <script>function downloadAiReportDoc(){const article=document.getElementById('generated-ai-report');const content='<!doctype html><html><head><meta charset="utf-8"><title>Generated report</title></head><body>'+article.innerHTML+'</body></html>';const blob=new Blob([content],{type:'application/msword'});const link=document.createElement('a');link.href=URL.createObjectURL(blob);link.download='<?= htmlspecialchars(preg_replace('/[^A-Za-z0-9_-]+/','_', $ai_report['title']), ENT_QUOTES) ?>.doc';link.click();setTimeout(()=>URL.revokeObjectURL(link.href),5000);}</script>
            <?php endif; ?>
        </section>

    <!-- ========================================================================= -->
    <!-- TAB 4: SYSTEM ACTIVITY LOG (Admin & PS only) -->
    <!-- ========================================================================= -->
    <?php elseif ($current_subtab === 'activity_log'): ?>
        <?php if (!$can_view_all): ?>
            <div style="background: #fef2f2; border: 1px solid #fecaca; border-radius: 8px; padding: 30px; text-align: center;">
                <h3 style="color: #991b1b; margin: 0 0 6px 0;">🔒 Access Restricted</h3>
                <p style="color: #7f1d1d; font-size: 0.8rem; margin: 0;">
                    System activity and document access audit logs are strictly restricted to System Administrators and the Principal Secretary.
                </p>
            </div>
        <?php else: ?>
            <div style="background: white; border: 1px solid #e2e8f0; border-radius: 8px; overflow: hidden;">
                <div style="background: #0f172a; color: white; padding: 12px 18px; font-size: 0.85rem; font-weight: 800; display: flex; justify-content: space-between; align-items: center;">
                    <span>🛡️ Ministerial Document Activity Log &amp; Audit Trail</span>
                    <span style="font-size: 0.72rem; color: #94a3b8; font-weight: normal;">Source: audit_logs</span>
                </div>
                <div style="overflow-x: auto;">
                    <table style="width: 100%; border-collapse: collapse; font-size: 0.75rem; text-align: left;">
                        <thead>
                            <tr style="background: #f8fafc; color: #475569; font-weight: 700; border-bottom: 2px solid #e2e8f0; text-transform: uppercase;">
                                <th style="padding: 10px 14px;">Timestamp</th>
                                <th style="padding: 10px 14px;">Officer</th>
                                <th style="padding: 10px 14px;">Action</th>
                                <th style="padding: 10px 14px;">IP Address</th>
                                <th style="padding: 10px 14px;">Details</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($audit_trail_logs)): ?>
                                <tr><td colspan="5" style="padding: 20px; text-align: center; color: #64748b;">No recent activity logs recorded.</td></tr>
                            <?php endif; ?>
                            <?php foreach ($audit_trail_logs as $al): ?>
                                <tr style="border-bottom: 1px solid #f1f5f9;">
                                    <td style="padding: 10px 14px; font-family: 'JetBrains Mono', monospace; font-size: 0.7rem; color: #64748b;"><?php $activityTs = strtotime((string)$al['created_at']); ?><?= htmlspecialchars($activityTs ? date('d M Y', $activityTs) : (string)$al['created_at']) ?></td>
                                    <td style="padding: 10px 14px; font-weight: 700; color: #0f172a;"><?= htmlspecialchars($al['user_name']) ?></td>
                                    <td style="padding: 10px 14px;">
                                        <?php
                                            $ab_bg = '#f1f5f9'; $ab_col = '#334155';
                                            if ($al['action'] === 'DOWNLOAD') { $ab_bg = '#ecfdf5'; $ab_col = '#065f46'; }
                                            elseif ($al['action'] === 'VIEW') { $ab_bg = '#eff6ff'; $ab_col = '#1e40af'; }
                                            elseif ($al['action'] === 'DELETE') { $ab_bg = '#fef2f2'; $ab_col = '#991b1b'; }
                                            elseif ($al['action'] === 'UPLOAD') { $ab_bg = '#fffbeb'; $ab_col = '#92400e'; }
                                        ?>
                                        <span style="background: <?= $ab_bg ?>; color: <?= $ab_col ?>; font-weight: 800; padding: 2px 6px; border-radius: 4px; font-size: 0.68rem;">
                                            <?= htmlspecialchars($al['action']) ?>
                                        </span>
                                    </td>
                                    <td style="padding: 10px 14px; font-family: monospace; color: #64748b;"><?= htmlspecialchars($al['ip_address']) ?></td>
                                    <td style="padding: 10px 14px; color: #334155;"><?= htmlspecialchars($al['details']) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>

    <!-- ========================================================================= -->
    <?php endif; ?>

</div>

<!-- Upload Report Modal -->
<div id="uploadModal" style="display: none; position: fixed; inset: 0; background: rgba(15, 23, 42, 0.6); z-index: 9999; justify-content: center; align-items: center; padding: 20px;">
    <div style="background: white; border-radius: 8px; width: 100%; max-width: 580px; max-height: 90vh; overflow-y: auto; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1); border: 1px solid #e2e8f0;">
        <div style="background: #1a61c1; color: white; padding: 12px 18px; display: flex; justify-content: space-between; align-items: center;">
            <h3 style="margin: 0; font-size: 0.9rem; font-weight: 800;">Upload Statutory Report / Verification Attachment</h3>
            <button onclick="document.getElementById('uploadModal').style.display='none';" style="background: transparent; border: none; color: white; font-size: 1.2rem; cursor: pointer;">&times;</button>
        </div>
        <form method="POST" enctype="multipart/form-data" style="padding: 18px; display: flex; flex-direction: column; gap: 12px;">
            <input type="hidden" name="action" value="upload_report">

            <div>
                <label style="display: block; font-size: 0.72rem; font-weight: 700; color: #334155; margin-bottom: 2px;">Document Title *</label>
                <input type="text" name="title" required placeholder="e.g. Q3 Progress Review on KNH Burns Unit"
                       style="width: 100%; padding: 7px 10px; font-size: 0.78rem; border: 1px solid #cbd5e1; border-radius: 4px;">
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                <div>
                    <label style="display: block; font-size: 0.72rem; font-weight: 700; color: #334155; margin-bottom: 2px;">Report Code</label>
                    <input type="text" name="code" placeholder="Leave empty for auto-generated"
                           style="width: 100%; padding: 7px 10px; font-size: 0.78rem; border: 1px solid #cbd5e1; border-radius: 4px;">
                </div>
                <div>
                    <label style="display: block; font-size: 0.72rem; font-weight: 700; color: #334155; margin-bottom: 2px;">Submission Date *</label>
                    <input type="date" name="report_date" value="<?= date('Y-m-d') ?>" required
                           style="width: 100%; padding: 6px 10px; font-size: 0.78rem; border: 1px solid #cbd5e1; border-radius: 4px;">
                </div>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                <div>
                    <label style="display: block; font-size: 0.72rem; font-weight: 700; color: #334155; margin-bottom: 2px;">Associated Project / Scope</label>
                    <select name="project" style="width: 100%; padding: 7px 10px; font-size: 0.78rem; border: 1px solid #cbd5e1; border-radius: 4px;">
                        <?php foreach ($all_projects as $pr): ?>
                            <option value="<?= htmlspecialchars($pr['sub_programme']) ?>"><?= htmlspecialchars($pr['sub_programme']) ?></option>
                        <?php endforeach; ?>
                        <option value="Consolidated SDMS Portfolio">Consolidated SDMS Portfolio</option>
                    </select>
                </div>
                <div>
                    <label style="display: block; font-size: 0.72rem; font-weight: 700; color: #334155; margin-bottom: 2px;">Classification</label>
                    <select name="visibility" style="width: 100%; padding: 7px 10px; font-size: 0.78rem; border: 1px solid #cbd5e1; border-radius: 4px;">
                        <option value="Restricted">Restricted</option>
                        <option value="Confidential">Confidential</option>
                        <option value="Public">Public</option>
                        <option value="Directorate Only">Directorate Only</option>
                    </select>
                </div>
            </div>

            <div>
                <label style="display: block; font-size: 0.72rem; font-weight: 700; color: #334155; margin-bottom: 2px;">Attach Document (PDF, XLSX, DOCX) *</label>
                <input type="file" name="report_file" required accept=".pdf,.xlsx,.xls,.docx,.doc,.csv"
                       style="width: 100%; padding: 6px 10px; font-size: 0.75rem; border: 1px dashed #1a61c1; border-radius: 4px; background: #f8fafc;">
            </div>

            <div>
                <label style="display: block; font-size: 0.72rem; font-weight: 700; color: #334155; margin-bottom: 2px;">Executive Summary / Remarks</label>
                <textarea name="summary" rows="2" placeholder="Key takeaways and findings for the Principal Secretary..."
                          style="width: 100%; padding: 6px 10px; font-size: 0.78rem; border: 1px solid #cbd5e1; border-radius: 4px;"></textarea>
            </div>

            <div style="display: flex; justify-content: flex-end; gap: 8px; margin-top: 6px;">
                <button type="button" onclick="document.getElementById('uploadModal').style.display='none';" 
                        style="background: #f1f5f9; color: #334155; border: 1px solid #cbd5e1; padding: 7px 14px; border-radius: 4px; font-size: 0.75rem; font-weight: 700; cursor: pointer;">
                    Cancel
                </button>
                <button type="submit" 
                        style="background: #1a61c1; color: white; border: none; padding: 7px 16px; border-radius: 4px; font-size: 0.75rem; font-weight: 700; cursor: pointer;">
                    Submit &amp; Save Document
                </button>
            </div>
        </form>
    </div>
</div>

<script>
function previewReportBrief(code, title, project, date, uploader, summary) {
    const reportDate = new Date(String(date || '').slice(0, 10) + 'T00:00:00');
    const formattedDate = !Number.isNaN(reportDate.getTime()) ? reportDate.toLocaleDateString('en-GB', {day:'2-digit', month:'short', year:'numeric'}) : date;
    alert("OFFICIAL STATUTORY DOCUMENT BRIEF\n--------------------------------\nReference: " + code + "\nTitle: " + title + "\nProject: " + project + "\nSubmission Date: " + formattedDate + "\nUploaded By: " + uploader + "\n\nAbstract:\n" + (summary ? summary : "Official verified brief stored in PP-SDOMS repository."));
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
