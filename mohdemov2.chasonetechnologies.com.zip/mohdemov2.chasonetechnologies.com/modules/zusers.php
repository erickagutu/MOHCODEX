<?php
/**
 * Users & RBAC Module
 * Ministry of Health — State Department for Medical Services (PP-SDOMS)
 * Native PHP 8.1+ & MySQL (No Node.js)
 */
require_once __DIR__ . '/../config/db.php';
require_auth();

$page_title = 'Users & RBAC — State Department for Medical Services';
$active_tab = 'users';

$users = [];
if ($db_connected && $pdo) {
    try {
        $stmt = $pdo->query("SELECT * FROM users ORDER BY id ASC");
        $users = $stmt->fetchAll();
    } catch (Exception $e) {}
}

require_once __DIR__ . '/../includes/header.php';
?>

<div style="display: flex; flex-direction: column; gap: 20px;">

    <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px;">
        <div>
            <h2 style="font-size: 1.25rem; font-weight: 800; color: #0f172a; margin: 0; display: flex; align-items: center; gap: 8px;">
                👥 Users &amp; Role-Based Access Control (RBAC)
            </h2>
            <span style="font-size: 0.8rem; color: #64748b;">Manage user authorization, ministerial permissions, and audit identities</span>
        </div>
    </div>

    <!-- Users Table -->
    <div style="background: #ffffff; border-radius: 8px; border: 1px solid #e2e8f0; overflow: hidden; box-shadow: 0 2px 4px rgba(0,0,0,0.02);">
        <div style="background: #0d47a1; color: white; padding: 12px 18px; font-size: 0.85rem; font-weight: 700;">
            Authorized Ministerial User Accounts
        </div>
        <div style="overflow-x: auto;">
            <table style="width: 100%; border-collapse: collapse; font-size: 0.8rem; text-align: left;">
                <thead>
                    <tr style="background: #f8fafc; color: #475569; font-weight: 700; border-bottom: 2px solid #e2e8f0; text-transform: uppercase; font-size: 0.72rem;">
                        <th style="padding: 12px 16px;">Full Name &amp; Email</th>
                        <th style="padding: 12px 16px;">Assigned Role</th>
                        <th style="padding: 12px 16px;">Directorate</th>
                        <th style="padding: 12px 16px;">Permissions Matrix</th>
                        <th style="padding: 12px 16px;">Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $u): ?>
                        <tr style="border-bottom: 1px solid #f1f5f9;">
                            <td style="padding: 14px 16px;">
                                <div style="font-weight: 700; color: #0f172a;"><?= htmlspecialchars($u['full_name']) ?></div>
                                <div style="font-family: 'JetBrains Mono', monospace; font-size: 0.72rem; color: #64748b;"><?= htmlspecialchars($u['email']) ?></div>
                            </td>
                            <td style="padding: 14px 16px; font-weight: 700; color: #0d47a1;">
                                <?= htmlspecialchars($u['role']) ?>
                            </td>
                            <td style="padding: 14px 16px; color: #334155;">
                                <?= htmlspecialchars($u['directorate']) ?>
                            </td>
                            <td style="padding: 14px 16px;">
                                <div style="display: flex; gap: 4px; flex-wrap: wrap;">
                                    <?php if (!empty($u['is_admin'])): ?><span style="background: #fee2e2; color: #991b1b; padding: 2px 6px; border-radius: 4px; font-size: 0.68rem; font-weight: 700;">Admin</span><?php endif; ?>
                                    <?php if (!empty($u['can_upload'])): ?><span style="background: #f1f5f9; color: #334155; padding: 2px 6px; border-radius: 4px; font-size: 0.68rem; border: 1px solid #cbd5e1;">Upload</span><?php endif; ?>
                                    <?php if (!empty($u['can_edit'])): ?><span style="background: #f1f5f9; color: #334155; padding: 2px 6px; border-radius: 4px; font-size: 0.68rem; border: 1px solid #cbd5e1;">Edit</span><?php endif; ?>
                                    <?php if (!empty($u['can_approve'])): ?><span style="background: #ecfdf5; color: #065f46; padding: 2px 6px; border-radius: 4px; font-size: 0.68rem; font-weight: 700;">Approve</span><?php endif; ?>
                                </div>
                            </td>
                            <td style="padding: 14px 16px;">
                                <span style="background: #ecfdf5; color: #065f46; padding: 3px 8px; border-radius: 10px; font-size: 0.7rem; font-weight: 700;">
                                    Active
                                </span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
