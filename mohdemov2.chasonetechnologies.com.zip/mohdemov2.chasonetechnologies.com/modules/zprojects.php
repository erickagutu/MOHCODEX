<?php
/**
 * Projects & Programmes Module
 * Ministry of Health — State Department for Medical Services (PP-SDOMS)
 * Native PHP 8.1+ & MySQL (No Node.js)
 */
require_once __DIR__ . '/../config/db.php';
require_auth();

$page_title = 'Projects & Programmes — State Department for Medical Services';
$page_stylesheets = ['/assets/css/projects-nav.css?v=20261024b'];
$active_tab = 'projects';

$flash_msg = '';
$view_detail_id = (int)($_GET['id'] ?? 0);
$is_detail_view = ($view_detail_id > 0);

// Add Project Form Handler
if ($_SERVER['REQUEST_METHOD'] === 'POST' && can_edit()) {
    $token = $_POST['csrf_token'] ?? '';
    if (verify_csrf_token($token)) {
        $sub_prog = trim($_POST['sub_programme'] ?? '');
        $project_code = trim($_POST['project_code'] ?? '');
        $project_type = trim($_POST['project_type'] ?? 'Project');
        $prog_title = trim($_POST['programme_title'] ?? '');
        $cat = $_POST['category'] ?? 'Directorate';
        $agency = trim($_POST['agency_name'] ?? '');
        $tier = $_POST['priority_tier'] ?? 'Tier 1 - High Priority';
        $total_budget = (float)($_POST['total_budget'] ?? 0);
        $status = $_POST['status'] ?? 'In Progress';
        $start_date = $_POST['start_date'] ?? date('Y-m-d');
        $end_date = $_POST['end_date'] ?? date('Y-m-d', strtotime('+1 year'));
        $desc = trim($_POST['description'] ?? '');

        if (!empty($sub_prog)) {
            if ($db_connected && $pdo) {
                try {
                    $stmt = $pdo->prepare("
                        INSERT INTO projects (programme_title, sub_programme, project_code, project_type, category, directorate_name, saga_name, delivery_unit, priority_tier, total_budget, status, start_date, end_date, description)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ");
                    $stmt->execute([
                        $prog_title,
                        $sub_prog,
                        $project_code !== '' ? $project_code : null,
                        $project_type,
                        $cat,
                        $cat === 'Directorate' ? $agency : null,
                        $cat === 'Saga' ? $agency : null,
                        $agency,
                        $tier,
                        $total_budget,
                        $status,
                        $start_date,
                        $end_date,
                        $desc
                    ]);
                    log_audit_trail('CREATE', 'Projects', $pdo->lastInsertId(), "Created project: $sub_prog");
                    $flash_msg = 'Project successfully added to portfolio.';
                } catch (Exception $e) {
                    $flash_msg = 'Database error: ' . $e->getMessage();
                }
            } else {
                $flash_msg = 'Database connection unavailable; project was not saved.';
            }
        }
    }
}

// Multi-Filter parameters
$get_filter = static function (string $key): string {
    $value = isset($_GET[$key]) && is_string($_GET[$key]) ? trim($_GET[$key]) : '';
    return $value !== '' ? $value : 'All';
};
$status_chosen = isset($_GET['status']) && is_string($_GET['status']) && trim($_GET['status']) !== '';
$filter_status = $get_filter('status');
$filter_saga = $get_filter('saga');
$filter_dir = $get_filter('dir');
$filter_category = $get_filter('category');
if (!in_array($filter_category, ['Directorate','Saga'], true)) $filter_category = 'All';
$filter_div = $get_filter('div');
$filter_du = $get_filter('du');
$filter_tier = $get_filter('tier');
$search_q = trim($_GET['q'] ?? '');
$gantt_year = (int)($_GET['year'] ?? 0);
$gantt_month = trim((string)($_GET['month'] ?? ''));
if ($gantt_month !== 'all' && (!ctype_digit($gantt_month) || (int)$gantt_month < 1 || (int)$gantt_month > 12)) $gantt_month = '0';
$gantt_year_options = range(2022, 2027);
if (!in_array($gantt_year, $gantt_year_options, true)) $gantt_year = 0;

$year_chosen = $gantt_year > 0;
$month_chosen = $gantt_month !== '0';
$gantt_directorate = $get_filter('gantt_directorate');
$gantt_saga = $get_filter('gantt_saga');

// Graph and Table Specific Filters
$graph_filter_kpi = isset($_GET['graph_kpi']) && is_string($_GET['graph_kpi']) ? trim($_GET['graph_kpi']) : 'All';
$graph_filter_month = isset($_GET['graph_month']) && is_string($_GET['graph_month']) ? trim($_GET['graph_month']) : 'All';
$graph_filter_year = isset($_GET['graph_year']) && is_string($_GET['graph_year']) ? trim($_GET['graph_year']) : 'All';

$table_filter_kpi = isset($_GET['table_kpi']) && is_string($_GET['table_kpi']) ? trim($_GET['table_kpi']) : '';
$table_filter_month = isset($_GET['table_month']) && is_string($_GET['table_month']) ? trim($_GET['table_month']) : '';
$table_filter_year = isset($_GET['table_year']) && is_string($_GET['table_year']) ? trim($_GET['table_year']) : '';

$monthly_gantt = [];
$available_months = [];
$gantt_directorates = [];
$gantt_divisions = [];
$gantt_sagas = [];
$filter_directorates = [];
$filter_divisions = [];
$filter_sagas = [];
$saga_filter_aliases = [];
$dir_filter_aliases = [];
$registered_dir_rows = [];
$nav_divisions_by_dir = [];
$filter_delivery_units = [];
$filter_tiers = [];
$annual_key_output_records = [];
$annual_key_output_groups = [];
$detail_annual_key_outputs = [];
$portfolio_progress_records = [];
$project_key_output_records = [];
$project_total_count = null;
$project_load_error = false;
$registered_directorates = [];
$registered_sagas = [];

if ($db_connected && $pdo) {
    try {
        $registered_directorates = $pdo->query("SELECT name, code FROM directorates ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
        foreach ($registered_directorates as $registered_dir) {
            $name = (string)$registered_dir['name'];
            // Projects store short names (e.g. "Family Health") while the registry holds the full title.
            $short = trim(preg_replace('/\s+Directorate$/iu', '', preg_replace('/^Directorate\s+(for|of)\s+/iu', '', $name)));
            $dir_filter_aliases[$name] = array_values(array_unique(array_filter([$name, $short, (string)$registered_dir['code']], static fn($v) => $v !== '')));
        }
        $registered_dir_rows = $pdo->query("SELECT id, name FROM directorates ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
        $registered_directorates = array_column($registered_directorates, 'name');
    } catch (Exception $e) { $registered_directorates = []; }
    try {
        $registered_sagas = $pdo->query("SELECT name, code FROM sagas ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
        foreach ($registered_sagas as $registered_saga) {
            $name = (string)$registered_saga['name'];
            $aliases = [$name, (string)$registered_saga['code']];
            if (preg_match('/^(.*?)\s*\(([^()]*)\)\s*$/u', $name, $match)) {
                $aliases[] = trim($match[1]);
                $aliases[] = trim($match[2]);
            }
            $saga_filter_aliases[$name] = array_values(array_unique(array_filter($aliases, static fn($v) => $v !== '')));
        }
    } catch (Exception $e) { $registered_sagas = []; }
}

$projects = [];
if ($db_connected && $pdo) {
    try {
        $project_total_count = (int)$pdo->query("SELECT COUNT(*) FROM projects")->fetchColumn();
        $sql = "SELECT * FROM projects WHERE 1=1";
        $params = [];
        if ($filter_status !== 'All') {
            $sql .= " AND (status = ? OR LOWER(status) = LOWER(?))";
            $params[] = $filter_status;
            $params[] = $filter_status;
        }
        if ($filter_saga !== 'All') {
            $aliases = $saga_filter_aliases[$filter_saga] ?? [$filter_saga];
            $placeholders = implode(',', array_fill(0, count($aliases), '?'));
            $sql .= " AND (saga_name IN ($placeholders) OR delivery_unit IN ($placeholders))";
            array_push($params, ...$aliases, ...$aliases);
        }
        if ($filter_dir !== 'All') {
            $aliases = $dir_filter_aliases[$filter_dir] ?? [$filter_dir];
            $placeholders = implode(',', array_fill(0, count($aliases), '?'));
            $sql .= " AND directorate_name IN ($placeholders)";
            array_push($params, ...$aliases);
        }
        if ($filter_category !== 'All') {
            if ($filter_category === 'Directorate') $sql .= " AND (category = 'Directorate' OR (directorate_name IS NOT NULL AND TRIM(directorate_name) <> ''))";
            else $sql .= " AND (category = 'Saga' OR (saga_name IS NOT NULL AND TRIM(saga_name) <> ''))";
        }
        if ($filter_div !== 'All') {
            $sql .= " AND division_name = ?";
            $params[] = $filter_div;
        }
        if ($filter_du !== 'All') {
            $sql .= " AND delivery_unit = ?";
            $params[] = $filter_du;
        }
        if ($filter_tier !== 'All') {
            $sql .= " AND priority_tier = ?";
            $params[] = $filter_tier;
        }
        if ($search_q !== '') {
            $sql .= " AND (sub_programme LIKE ? OR programme_title LIKE ? OR description LIKE ? OR project_code LIKE ? OR saga_name LIKE ? OR delivery_unit LIKE ? OR directorate_name LIKE ? OR division_name LIKE ?)";
            for ($i = 0; $i < 8; $i++) $params[] = "%$search_q%";
        }
        $sql .= " ORDER BY id ASC";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $projects = $stmt->fetchAll();
    } catch (Exception $e) { $project_load_error = true; }
}

// Single Project Detail Selection
$current_project = null;
if ($is_detail_view && $db_connected && $pdo) {
    try {
        $stmt = $pdo->prepare('SELECT * FROM projects WHERE id = ?');
        $stmt->execute([$view_detail_id]);
        $current_project = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    } catch (Exception $e) {
        $current_project = null;
    }
}

if ($db_connected && $pdo) {
    try {
        $project_directorates = $pdo->query("SELECT DISTINCT directorate_name FROM projects WHERE directorate_name IS NOT NULL AND TRIM(directorate_name) <> '' ORDER BY directorate_name")->fetchAll(PDO::FETCH_COLUMN);
        $known_dir_aliases = [];
        foreach ($dir_filter_aliases as $aliases) foreach ($aliases as $alias) $known_dir_aliases[strtolower($alias)] = true;
        $extra_directorates = array_filter($project_directorates, static fn($d) => !isset($known_dir_aliases[strtolower(trim((string)$d))]));
        $gantt_directorates = array_values(array_unique(array_merge($registered_directorates, $extra_directorates)));
        natcasesort($gantt_directorates); $gantt_directorates = array_values($gantt_directorates);
    } catch (Exception $e) { $gantt_directorates = []; }
    try {
        // Navigation dropdown: divisions come straight from the divisions table, keyed by directorate_id.
        foreach ($pdo->query("SELECT directorate_id, name FROM divisions ORDER BY name")->fetchAll(PDO::FETCH_ASSOC) as $nav_div) {
            $nav_divisions_by_dir[(int)$nav_div['directorate_id']][] = $nav_div['name'];
        }
    } catch (Exception $e) { $nav_divisions_by_dir = []; }
    try {
        $gantt_divisions = $pdo->query("SELECT dir.name AS directorate_name, div.name AS division_name
            FROM divisions div INNER JOIN directorates dir ON dir.id = div.directorate_id
            ORDER BY dir.name, div.name")->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) { $gantt_divisions = []; }
    try {
        $project_divisions = $pdo->query("SELECT DISTINCT directorate_name, division_name FROM projects
            WHERE directorate_name IS NOT NULL AND TRIM(directorate_name) <> ''
              AND division_name IS NOT NULL AND TRIM(division_name) <> ''
            ORDER BY directorate_name, division_name")->fetchAll(PDO::FETCH_ASSOC);
        $division_pairs = [];
        foreach (array_merge($gantt_divisions, $project_divisions) as $division) {
            $pair_key = strtolower(trim((string)$division['directorate_name']) . "\0" . trim((string)$division['division_name']));
            if (!isset($division_pairs[$pair_key])) $division_pairs[$pair_key] = $division;
        }
        $gantt_divisions = array_values($division_pairs);
        usort($gantt_divisions, static function($a, $b) {
            return strnatcasecmp($a['directorate_name'], $b['directorate_name']) ?: strnatcasecmp($a['division_name'], $b['division_name']);
        });
    } catch (Exception $e) { }
    try {
        $project_sagas = $pdo->query("SELECT DISTINCT saga_name FROM projects WHERE saga_name IS NOT NULL AND TRIM(saga_name) <> '' ORDER BY saga_name")->fetchAll(PDO::FETCH_COLUMN);
        $gantt_sagas = array_column($registered_sagas, 'name');
        $known_saga_bases = array_map(static function($name) { return strtolower(trim(preg_replace('/\s*\([^()]*\)\s*$/u', '', (string)$name))); }, $gantt_sagas);
        foreach ($project_sagas as $project_saga) {
            $base = strtolower(trim(preg_replace('/\s*\([^()]*\)\s*$/u', '', (string)$project_saga)));
            if (!in_array($base, $known_saga_bases, true)) $gantt_sagas[] = $project_saga;
        }
        natcasesort($gantt_sagas); $gantt_sagas = array_values(array_unique($gantt_sagas));
    } catch (Exception $e) { $gantt_sagas = []; }
    $filter_directorates = $gantt_directorates;
    $filter_divisions = array_values(array_unique(array_column($gantt_divisions, 'division_name')));
    $filter_sagas = $gantt_sagas;
    try { $filter_delivery_units = $pdo->query("SELECT DISTINCT delivery_unit FROM projects WHERE delivery_unit IS NOT NULL AND TRIM(delivery_unit) <> '' ORDER BY delivery_unit")->fetchAll(PDO::FETCH_COLUMN); } catch (Exception $e) { $filter_delivery_units = []; }
    try { $filter_tiers = $pdo->query("SELECT DISTINCT priority_tier FROM projects WHERE priority_tier IS NOT NULL AND TRIM(priority_tier) <> '' ORDER BY priority_tier")->fetchAll(PDO::FETCH_COLUMN); } catch (Exception $e) { $filter_tiers = []; }
}

// Key Output Progress graph: data comes from monthly_progress (one row per project / month / KPI).
// NB: `year_month` is a reserved word in MySQL, so it must always be back-quoted.
$available_kpi_names = [];
$available_table_years = [];
$available_graph_months = [];
$graph_db_rows = [];
$graph_has_any_data = false;
$graph_month_names = [1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'];

if ($db_connected && $pdo && $is_detail_view) {
    try {
        $scope = ' WHERE project_id = ?';
        $scope_params = [$view_detail_id];
        $stmt = $pdo->prepare("SELECT DISTINCT kpi_name FROM monthly_progress $scope AND kpi_name <> '' ORDER BY kpi_name");
        $stmt->execute($scope_params);
        $available_kpi_names = $stmt->fetchAll(PDO::FETCH_COLUMN);

        $stmt = $pdo->prepare("SELECT DISTINCT `year_month` FROM monthly_progress $scope ORDER BY `year_month`");
        $stmt->execute($scope_params);
        foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) as $ym) {
            if (!preg_match('/^(\d{4})-(\d{2})$/', (string)$ym, $mm)) continue;
            $available_table_years[$mm[1]] = $mm[1];
            $available_graph_months[(int)$mm[2]] = $graph_month_names[(int)$mm[2]] ?? $mm[2];
        }
        rsort($available_table_years);
        ksort($available_graph_months);
        $graph_has_any_data = (bool)$available_kpi_names;

        $g_sql = "SELECT kpi_name, cumulative_pct, `year_month` FROM monthly_progress WHERE project_id = ?";
        $g_params = [$view_detail_id];
        if ($graph_filter_kpi !== 'All') { $g_sql .= " AND kpi_name = ?"; $g_params[] = $graph_filter_kpi; }
        if ($graph_filter_year !== 'All' && preg_match('/^\d{4}$/', $graph_filter_year)) { $g_sql .= " AND `year_month` LIKE ?"; $g_params[] = $graph_filter_year . '-%'; }
        if ($graph_filter_month !== 'All') {
            $mNum = array_search($graph_filter_month, $graph_month_names, true);
            if ($mNum !== false) { $g_sql .= " AND `year_month` LIKE ?"; $g_params[] = '%-' . str_pad((string)$mNum, 2, '0', STR_PAD_LEFT); }
        }
        $g_sql .= " ORDER BY `year_month` ASC, kpi_name ASC";
        $g_stmt = $pdo->prepare($g_sql);
        $g_stmt->execute($g_params);
        $graph_db_rows = $g_stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        error_log('Key output graph query failed: ' . $e->getMessage());
        $graph_db_rows = [];
    }
}

// Demo data is shown only when the project has no monthly progress recorded at all.
$default_graph_months = ['March', 'April', 'May', 'June', 'July', 'August', 'Sept', 'October'];
$default_graph_kpis = [
    'Electrical Works' => [12, 30, 50, 65, 80, 90, 95, 100],
    'Foundation structure' => [20, 45, 65, 80, 90, 95, 98, 100],
    'Mechanical Works' => [10, 25, 45, 60, 75, 85, 95, 100],
    'Plumbing Works' => [8, 23, 43, 58, 73, 85, 95, 100],
    'Structural Works' => [15, 35, 55, 70, 80, 90, 95, 100]
];

if ($graph_has_any_data) {
    $graph_months = [];
    $graph_kpis = [];
    $cells = [];
    $years_in_view = [];
    foreach ($graph_db_rows as $row) {
        $years_in_view[substr((string)$row['year_month'], 0, 4)] = true;
    }
    foreach ($graph_db_rows as $row) {
        $ym = (string)$row['year_month'];
        $label = $graph_month_names[(int)substr($ym, 5, 2)] ?? $ym;
        if (count($years_in_view) > 1) $label .= ' ' . substr($ym, 0, 4);
        if (!in_array($label, $graph_months, true)) $graph_months[] = $label;
        $cells[$row['kpi_name']][$label] = (float)($row['cumulative_pct'] ?? 0);
    }
    foreach ($cells as $kName => $byMonth) {
        $graph_kpis[$kName] = array_map(static fn($m) => $byMonth[$m] ?? 0, $graph_months);
    }
} else {
    $graph_months = $default_graph_months;
    $graph_kpis = $default_graph_kpis;
    $available_kpi_names = array_keys($default_graph_kpis);
    $available_graph_months = array_combine(range(1, 8), ['March', 'April', 'May', 'June', 'July', 'August', 'September', 'October']);
    $available_table_years = ['2026'];
}

$overall_progress_pct = 100.0;
$overall_month_label = 'October';

require_once __DIR__ . '/../includes/header.php';
?>

<div style="display: flex; flex-direction: column; gap: 24px;">

<?php if ($is_detail_view && $current_project): ?>
    <!-- ================= SINGLE PROJECT DETAIL VIEW ================= -->
    <div style="display: flex; flex-direction: column; gap: 20px;">
        <!-- Back Navigation & Action Bar -->
        <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px;">
            <a href="/modules/projects.php" style="background: white; border: 1px solid #cbd5e1; color: #1e293b; padding: 7px 14px; border-radius: 6px; text-decoration: none; font-size: 0.8rem; font-weight: 700; display: inline-flex; align-items: center; gap: 6px;">
                &larr; Back to Projects Portfolio
            </a>

            <a href="/modules/monthly_progress.php" style="background:#087f5b;color:#fff;text-decoration:none;padding:7px 14px;border-radius:6px;font-size:.8rem;font-weight:700;">Manage Project Key Output Progress</a>
        </div>

        <!-- Project Header and Status Badge -->
        <div style="background: white; border: 1px solid #e2e8f0; border-radius: 12px; padding: 24px; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
            <h1 style="font-size: 1.4rem; font-weight: 800; color: #0f172a; margin: 0 0 10px;">
                <?= htmlspecialchars($current_project['sub_programme']) ?>
            </h1>

            <div style="display: flex; gap: 10px; align-items: center; margin-bottom: 16px;">
                <span style="background: #16a34a; color: white; padding: 4px 12px; border-radius: 6px; font-size: 0.75rem; font-weight: 800;">
                    <?= htmlspecialchars($current_project['status']) ?>
                </span>
                <span style="background: #dbeafe; color: #1d4ed8; padding: 4px 12px; border-radius: 6px; font-size: 0.75rem; font-weight: 800;">
                    <?= htmlspecialchars($current_project['priority_tier'] ?? 'Tier 1 - High Priority') ?>
                </span>
            </div>
        </div>

        <!-- Main Detail Grid -->
        <div style="display: grid; grid-template-columns: 1fr 1.4fr; gap: 20px;">
            <!-- Left Column: Action & Remarks -->
            <div style="display: flex; flex-direction: column; gap: 16px;">
            <!-- Project Metadata Grid (always visible) -->
            <div id="projectDetailsGrid" style="margin-top: 0; padding: 18px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px;">
               <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; font-size: 0.8rem;">  <h3 style="font-size:.9rem;font-weight:800;color:#0f172a;margin:0;">PROJECT DETAILS</h3>  </div>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; font-size: 0.8rem; margin-top: 12px;">
                    <div>
                        <div style="font-size: 0.7rem; font-weight: 700; color: #64748b; text-transform: uppercase;">PROGRAMME TITLE</div>
                        <div style="font-weight: 800; color: #1d4ed8; margin-top: 4px;"><?= htmlspecialchars($current_project['programme_title']) ?></div>
                    </div>
                    <div>
                        <div style="font-size: 0.7rem; font-weight: 700; color: #64748b; text-transform: uppercase;">CATEGORY</div>
                        <div style="font-weight: 800; color: #1d4ed8; margin-top: 4px;"><?= htmlspecialchars($current_project['category']) ?></div>
                    </div>
                    <div>
                        <div style="font-size: 0.7rem; font-weight: 700; color: #64748b; text-transform: uppercase;">DELIVERY UNIT</div>
                        <div style="font-weight: 800; color: #1d4ed8; margin-top: 4px;"><?= htmlspecialchars($current_project['delivery_unit'] ?? 'Ministry of Health') ?></div>
                    </div>
                    <div>
                        <div style="font-size: 0.7rem; font-weight: 700; color: #64748b; text-transform: uppercase;">TOTAL BUDGET</div>
                        <div style="font-weight: 800; color: #1d4ed8; font-family: 'JetBrains Mono', monospace; margin-top: 4px;"><?= format_kes($current_project['total_budget']) ?></div>
                    </div>
                    <div>
                        <div style="font-size: 0.7rem; font-weight: 700; color: #64748b; text-transform: uppercase;">START DATE</div>
                        <div style="font-weight: 800; color: #1d4ed8; margin-top: 4px;"><?= !empty($current_project['start_date']) && strtotime((string)$current_project['start_date']) ? htmlspecialchars(date('d M Y', strtotime((string)$current_project['start_date']))) : '—' ?></div>
                    </div>
                    <div>
                        <div style="font-size: 0.7rem; font-weight: 700; color: #64748b; text-transform: uppercase;">END DATE</div>
                        <div style="font-weight: 800; color: #1d4ed8; margin-top: 4px;"><?= !empty($current_project['end_date']) && strtotime((string)$current_project['end_date']) ? htmlspecialchars(date('d M Y', strtotime((string)$current_project['end_date']))) : '—' ?></div>
                    </div>
                </div>
            </div>

                <div style="background: white; border: 1px solid #e2e8f0; border-radius: 8px; padding: 18px;">
                    <h3 style="font-size: 0.85rem; font-weight: 800; color: #0f172a; margin: 0 0 10px;">Action:</h3>
                    <div style="background: #f8fafc; border: 1px solid #e2e8f0; padding: 12px; border-radius: 6px; font-size: 0.8rem; color: #334155; line-height: 1.6; min-height: 120px;">
                        <?= nl2br(htmlspecialchars($current_project['description'])) ?>
                    </div>
                    <div style="margin-top: 14px;">
                        <div style="display: flex; justify-content: space-between; font-size: 0.8rem; font-weight: 800;">
                            <span>Overall Project Progress: <?= number_format($overall_progress_pct, 1).'%' ?></span>
                        </div>
                        <div style="background: #e2e8f0; height: 10px; border-radius: 5px; overflow: hidden; margin-top: 6px;">
                            <div style="background: #334155; height: 100%; width: <?= min(100, $overall_progress_pct) ?>%;"></div>
                        </div>
                    </div>
                </div>

                <div style="background: white; border: 1px solid #e2e8f0; border-radius: 8px; padding: 18px;">
                    <h3 style="font-size: 0.85rem; font-weight: 800; color: #0f172a; margin: 0 0 10px;">Remarks:</h3>
                    <div style="background: #f8fafc; border: 1px solid #e2e8f0; padding: 12px; border-radius: 6px; font-size: 0.8rem; color: #334155; line-height: 1.6;">
                        Structural fitouts and medical gas telemetry testing proceeding according to revised quarterly milestone timelines.
                    </div>
                </div>
            </div>

            <!-- Right Column: Financial Bar Graph & Grouped Bar Chart with Target Line & Graph Filters -->
            <div style="display: flex; flex-direction: column; gap: 16px;">
                <?php
                $finance_total = isset($current_project['total_budget']) ? (float)$current_project['total_budget'] : null;
                $finance_utilized = isset($current_project['funds_utilized']) ? (float)$current_project['funds_utilized'] : null;
                $finance_gok = isset($current_project['gok_financing']) ? (float)$current_project['gok_financing'] : null;
                $finance_foreign = isset($current_project['foreign_financing']) ? (float)$current_project['foreign_financing'] : null;
                $finance_outstanding = isset($current_project['funds_outstanding']) && $current_project['funds_outstanding'] !== null
                    ? (float)$current_project['funds_outstanding']
                    : (($finance_total !== null && $finance_utilized !== null) ? max(0, $finance_total - $finance_utilized) : null);
                $finance_chart_data = [
                    'Total Budget' => $finance_total,
                    'GOK Financing' => $finance_gok,
                    'Foreign Financing' => $finance_foreign,
                    'Funds Utilized' => $finance_utilized,
                    'Funds Outstanding' => $finance_outstanding,
                ];
                $finance_has_data = count(array_filter($finance_chart_data, static fn($value) => $value !== null)) > 0;
                ?>
                <!-- Project Finance Graph -->
                <div style="background: white; border: 1px solid #e2e8f0; border-radius: 8px; padding: 18px;">
                    <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:12px;margin-bottom:8px;">
                        <div>
                            <h3 style="font-size:.9rem;font-weight:800;color:#0f172a;margin:0;">Financial Data (Amount in Millions)</h3>
                            <span style="font-size:.7rem;color:#64748b;">Project financial values from the database.</span>
                        </div>
                        <span style="font-size:.68rem;font-weight:700;color:#475569;background:#f1f5f9;border-radius:5px;padding:4px 7px;white-space:nowrap;">KES millions</span>
                    </div>
                    <?php if ($finance_has_data): ?><div style="height:280px;position:relative;"><canvas id="projectFinanceChart" aria-label="Project financial data in KES millions"></canvas></div><?php else: ?><div style="padding:24px;text-align:center;color:#64748b;background:#f8fafc;border-radius:6px;">No financial records are available for this project.</div><?php endif; ?>
                    <script src="/assets/js/chart.min.js"></script>
                    <script>
                    (() => {
                        const canvas = document.getElementById('projectFinanceChart');
                        if (!canvas || typeof Chart === 'undefined') return;
                        const labels = <?= json_encode(array_keys($finance_chart_data), JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_AMP|JSON_HEX_QUOT) ?>;
                        const values = <?= json_encode(array_values($finance_chart_data), JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_AMP|JSON_HEX_QUOT) ?>.map(v => v === null ? null : Number(v) / 1000000);
                        const colors = ['#245789','#4f8fc2','#72b6d8','#70ad5a','#ed8b24'];
                        const valueLabels = {
                            id: 'projectFinanceValueLabels',
                            afterDatasetsDraw(chart) {
                                const {ctx} = chart;
                                ctx.save();
                                ctx.font = '700 12px Arial';
                                ctx.fillStyle = '#111827';
                                ctx.textAlign = 'center';
                                chart.getDatasetMeta(0).data.forEach((bar, index) => {
                                    if (values[index] === null) return;
                                    ctx.fillText(`${values[index].toLocaleString(undefined,{maximumFractionDigits:1})}M`, bar.x, bar.y - 7);
                                });
                                ctx.restore();
                            }
                        };
                        new Chart(canvas, {
                            type: 'bar',
                            data: {labels, datasets: [{label: 'KES millions', data: values, backgroundColor: colors, borderColor: colors, borderWidth: 1, borderRadius: 2, maxBarThickness: 58}]},
                            plugins: [valueLabels],
                            options: {
                                responsive: true, maintainAspectRatio: false,
                                plugins: {legend: {display: false}, tooltip: {callbacks: {label: c => `KES ${Number(c.raw).toLocaleString(undefined,{maximumFractionDigits:2})}M`}}},
                                scales: {
                                    y: {beginAtZero: true, suggestedMax: Math.max(1, Math.ceil(Math.max(...values.filter(v => v !== null)) / 50) * 50), title: {display: true, text: 'Amount in KES millions'}, ticks: {callback: v => `${v}M`}, grid: {color: '#d1d5db'}},
                                    x: {grid: {display: false}, ticks: {maxRotation: 0, minRotation: 0}}
                                }
                            }
                        });
                    })();
                    </script>
                </div>

                <!-- Project Key Output Progress Section: Grouped Bar Chart with Target Line & Graph Filters -->
                <div style="background: white; border: 1px solid #e2e8f0; border-radius: 8px; padding: 18px;">
                    <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 12px; flex-wrap: wrap; margin-bottom: 12px;">
                        <div>
                            <h3 style="font-size: 0.85rem; font-weight: 800; color: #0f172a; margin: 0;">
                                Project Key Output Progress
                            </h3>
                            <span style="font-size: 0.72rem; color: #64748b;">Cumulative Progress (%) per KPI vs. Target Line (100%)</span>
                        </div>
                    </div>

                    <!-- Graph Filter Controls Form -->
                    <form method="GET" action="/modules/projects.php" style="display: flex; gap: 10px; align-items: flex-end; margin-bottom: 14px; flex-wrap: wrap; font-size: 0.75rem;">
                        <?php if ($is_detail_view): ?><input type="hidden" name="id" value="<?= $view_detail_id ?>"><?php endif; ?>
                        <div>
                            <label style="display:block; font-weight:700; color:#64748b; margin-bottom:2px;">Filter KPI</label>
                            <select name="graph_kpi" style="padding: 5px 8px; border: 1px solid #cbd5e1; border-radius: 4px; font-size: 0.75rem;">
                                <option value="All">All KPIs</option>
                                <?php foreach ($available_kpi_names as $kname): ?>
                                    <option value="<?= htmlspecialchars($kname) ?>" <?= $graph_filter_kpi === $kname ? 'selected' : '' ?>><?= htmlspecialchars($kname) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div>
                            <label style="display:block; font-weight:700; color:#64748b; margin-bottom:2px;">Filter Month</label>
                            <select name="graph_month" style="padding: 5px 8px; border: 1px solid #cbd5e1; border-radius: 4px; font-size: 0.75rem;">
                                <option value="All">All Months</option>
                                <?php foreach ($available_graph_months as $m): ?>
                                    <option value="<?= htmlspecialchars($m) ?>" <?= $graph_filter_month === $m ? 'selected' : '' ?>><?= htmlspecialchars($m) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div>
                            <label style="display:block; font-weight:700; color:#64748b; margin-bottom:2px;">Filter Year</label>
                            <select name="graph_year" style="padding: 5px 8px; border: 1px solid #cbd5e1; border-radius: 4px; font-size: 0.75rem;">
                                <option value="All">All Years</option>
                                <?php foreach ($available_table_years as $ty): ?>
                                    <option value="<?= htmlspecialchars($ty) ?>" <?= $graph_filter_year === $ty ? 'selected' : '' ?>><?= htmlspecialchars($ty) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div>
                            <button type="submit" style="background: #0d47a1; color: white; border: none; padding: 6px 12px; border-radius: 4px; font-weight: 700; cursor: pointer;">Filter Graph</button>
                        </div>
                    </form>

                    <div style="height:340px; position:relative;">
                        <canvas id="projectKeyOutputProgressChart" aria-label="Cumulative Progress (%) per KPI with Target Line"></canvas>
                    </div>

                    <script src="/assets/js/chart.min.js"></script>
                    <script>
                    (() => {
                        const canvas = document.getElementById('projectKeyOutputProgressChart');
                        if (!canvas || typeof Chart === 'undefined') return;

                        const months = <?= json_encode(array_values($graph_months)) ?>;
                        const kpiData = <?= json_encode($graph_kpis) ?>;

                        const colorPalette = {
                            'Electrical Works': '#4f8fc2',
                            'Foundation structure': '#ed8b24',
                            'Mechanical Works': '#a5a5a5',
                            'Plumbing Works': '#ffc000',
                            'Structural Works': '#245789'
                        };

                        const barDatasets = Object.keys(kpiData).map(kpi => ({
                            type: 'bar',
                            label: kpi,
                            data: kpiData[kpi],
                            backgroundColor: colorPalette[kpi] || '#64748b',
                            borderColor: colorPalette[kpi] || '#64748b',
                            borderWidth: 1,
                            borderRadius: 3,
                            order: 2
                        }));

                        const targetLineDataset = {
                            type: 'line',
                            label: 'Target (100%)',
                            data: months.map(() => 100),
                            borderColor: '#dc2626',
                            backgroundColor: '#dc2626',
                            borderWidth: 2,
                            borderDash: [6, 4],
                            pointRadius: 0,
                            pointHoverRadius: 0,
                            fill: false,
                            order: 1
                        };

                        new Chart(canvas, {
                            data: {
                                labels: months,
                                datasets: [...barDatasets, targetLineDataset]
                            },
                            options: {
                                responsive: true,
                                maintainAspectRatio: false,
                                interaction: {
                                    mode: 'index',
                                    intersect: false
                                },
                                plugins: {
                                    legend: {
                                        position: 'bottom',
                                        labels: { font: { size: 11, weight: '600' }, usePointStyle: true, boxWidth: 10 }
                                    },
                                    tooltip: {
                                        callbacks: {
                                            label: c => `${c.dataset.label}: ${c.raw}%`
                                        }
                                    }
                                },
                                scales: {
                                    y: {
                                        beginAtZero: true,
                                        max: 110,
                                        title: { display: true, text: 'Cumulative Progress (%)' },
                                        ticks: { callback: v => v + '%' },
                                        grid: { color: '#e2e8f0' }
                                    },
                                    x: {
                                        grid: { display: false },
                                        ticks: { font: { weight: '600' } }
                                    }
                                }
                            }
                        });
                    })();
                    </script>
                </div>
                
            </div>
           
        </div>

    </div>

<?php else: ?>
    <!-- ================= MAIN PROJECTS PORTFOLIO VIEW ================= -->

    <?php
    $nav_keep = array_filter([
        'status' => $status_chosen ? $filter_status : '',
        'tier' => $filter_tier !== 'All' ? $filter_tier : '',
        'q' => $search_q,
        'year' => $year_chosen ? $gantt_year : '',
        'month' => $month_chosen ? $gantt_month : '',
    ], static fn($v) => $v !== '' && $v !== null);
    $nav_url = static fn(array $extra) => '/modules/projects.php?' . htmlspecialchars(http_build_query($extra + $nav_keep));
    $nav_directorates = [];
    foreach ($registered_dir_rows as $r) $nav_directorates[] = ['name' => $r['name'], 'divisions' => $nav_divisions_by_dir[(int)$r['id']] ?? []];
    foreach ($gantt_directorates as $d) if (!in_array($d, array_column($nav_directorates, 'name'), true)) $nav_directorates[] = ['name' => $d, 'divisions' => []];
    $dir_tab_active = $filter_category === 'Directorate' || ($filter_dir !== 'All' && $filter_saga === 'All');
    $saga_tab_active = $filter_category === 'Saga' || $filter_saga !== 'All';
    ?>
    <nav class="project-nav-tabs" id="projectNavTabs" aria-label="Browse projects by directorate or SAGA">
        <div class="project-nav-item<?= $dir_tab_active ? ' is-active' : '' ?>">
            <a class="project-nav-tab project-nav-blue" href="<?= $nav_url(['category' => 'Directorate']) ?>" aria-haspopup="true" aria-expanded="false">
                <span class="project-nav-icon" aria-hidden="true">▣</span><span>Directorates</span><small><?= count($nav_directorates) ?></small><b aria-hidden="true">⌄</b>
            </a>
            <div class="project-nav-menu">
                <?php if (!$nav_directorates): ?><span class="project-browse-empty">No directorates are registered.</span><?php endif; ?>
                <?php foreach ($nav_directorates as $nav_dir): ?>
                    <?php $directorate = $nav_dir['name']; $directorate_divisions = $nav_dir['divisions']; ?>
                    <div class="project-nav-row<?= $directorate_divisions ? ' has-sub' : '' ?>">
                        <a class="project-nav-link<?= $filter_dir === $directorate && $filter_div === 'All' ? ' is-current' : '' ?>" href="<?= $nav_url(['dir' => $directorate]) ?>"><span><?= htmlspecialchars($directorate) ?></span><?php if ($directorate_divisions): ?><i aria-hidden="true">›</i><?php endif; ?></a>
                        <?php if ($directorate_divisions): ?>
                        <div class="project-nav-submenu">
                            <a class="project-nav-link project-nav-all" href="<?= $nav_url(['dir' => $directorate]) ?>">All divisions</a>
                            <?php foreach ($directorate_divisions as $division_name): ?>
                                <a class="project-nav-link<?= $filter_dir === $directorate && $filter_div === $division_name ? ' is-current' : '' ?>" href="<?= $nav_url(['dir' => $directorate, 'div' => $division_name]) ?>"><?= htmlspecialchars($division_name) ?></a>
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <div class="project-nav-item<?= $saga_tab_active ? ' is-active' : '' ?>">
            <a class="project-nav-tab project-nav-green" href="<?= $nav_url(['category' => 'Saga']) ?>" aria-haspopup="true" aria-expanded="false">
                <span class="project-nav-icon" aria-hidden="true">⬡</span><span>SAGAs</span><small><?= count($gantt_sagas) ?></small><b aria-hidden="true">⌄</b>
            </a>
            <div class="project-nav-menu">
                <?php if (!$gantt_sagas): ?><span class="project-browse-empty">No SAGAs are registered.</span><?php endif; ?>
                <?php foreach ($gantt_sagas as $saga): ?>
                    <div class="project-nav-row"><a class="project-nav-link<?= $filter_saga === $saga ? ' is-current' : '' ?>" href="<?= $nav_url(['saga' => $saga]) ?>"><span><?= htmlspecialchars($saga) ?></span></a></div>
                <?php endforeach; ?>
            </div>
        </div>
    </nav>
    <script>
    (() => {
        const nav = document.getElementById('projectNavTabs');
        if (!nav) return;
        nav.classList.add("js-ready");
        const items = [...nav.querySelectorAll('.project-nav-item')];
        const setOpen = (item) => items.forEach(i => {
            const on = i === item;
            i.classList.toggle('is-open', on);
            i.querySelector('.project-nav-tab').setAttribute('aria-expanded', on ? 'true' : 'false');
        });
        items.forEach(item => {
            item.addEventListener('mouseenter', () => setOpen(item));
            item.addEventListener('focusin', () => setOpen(item));
            // Touch devices: first tap opens the menu, second tap follows the tab link.
            item.querySelector('.project-nav-tab').addEventListener('click', e => {
                if (window.matchMedia('(hover: none)').matches && !item.classList.contains('is-open')) { e.preventDefault(); setOpen(item); }
            });
        });
        nav.addEventListener('mouseleave', () => setOpen(null));
        document.addEventListener('click', e => { if (!nav.contains(e.target)) setOpen(null); });
        document.addEventListener('keydown', e => { if (e.key === 'Escape') setOpen(null); });
    })();
    </script>

    <!-- Top Status Filter Pills -->
    <div style="background: white; padding: 14px 20px; border-radius: 12px; border: 1px solid #e2e8f0; display: flex; flex-wrap: wrap; justify-content: space-between; align-items: center; gap: 10px; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
        <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
            <span style="font-size: 0.75rem; font-weight: 800; color: #475569; margin-right: 4px;">Status Filter:</span>
            <?php
            $statuses = ['All', 'In Progress', 'On Hold', 'Completed', 'Planning', 'Delayed', 'Overdue', 'Cancelled'];
            foreach ($statuses as $st):
                $isActive = $status_chosen && (strtolower($filter_status) === strtolower($st));
                $status_colors = ['All'=>['#0d47a1','#ffffff'],'In Progress'=>['#d1fae5','#047857'],'On Hold'=>['#fef3c7','#92400e'],'Completed'=>['#dbeafe','#1d4ed8'],'Planning'=>['#ede9fe','#6d28d9'],'Delayed'=>['#ffedd5','#c2410c'],'Overdue'=>['#fee2e2','#b91c1c'],'Cancelled'=>['#e2e8f0','#475569']];
                $status_color = $status_colors[$st] ?? ['#f1f5f9','#334155'];
            ?>
                <a href="/modules/projects.php?status=<?= urlencode($st) ?>&saga=<?= urlencode($filter_saga) ?>&dir=<?= urlencode($filter_dir) ?>&div=<?= urlencode($filter_div) ?>&du=<?= urlencode($filter_du) ?>&tier=<?= urlencode($filter_tier) ?>&q=<?= urlencode($search_q) ?>&year=<?= $year_chosen ? $gantt_year : '' ?>&month=<?= $month_chosen ? $gantt_month : '' ?>&gantt_directorate=<?= urlencode($gantt_directorate) ?>&gantt_saga=<?= urlencode($gantt_saga) ?>" 
                   aria-label="Filter projects by <?= htmlspecialchars($st) ?>" <?= $isActive ? 'aria-current="true"' : '' ?>
                   style="padding: 5px 12px; border-radius: 20px; font-size: 0.75rem; font-weight: 700; text-decoration: none; transition: all 0.2s; background: <?= $status_color[0] ?>; color: <?= $status_color[1] ?>; border:<?= $isActive ? '2px' : '1px' ?> solid <?= $status_color[1] ?>; box-shadow:<?= $isActive ? '0 0 0 2px '.$status_color[0] : 'none' ?>;">
                    <?= $st ?>
                </a>
            <?php endforeach; ?>
        </div>

        <div>
            <a href="/modules/projects.php" style="background: #e2e8f0; color: #1e293b; padding: 6px 14px; border-radius: 20px; font-size: 0.75rem; font-weight: 800; text-decoration: none;">
                &#x21bb; Reset Filters
            </a>
        </div>
    </div>

    <!-- Search and Filters -->
    <div style="background: white; padding: 20px; border-radius: 12px; border: 1px solid #e2e8f0; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
        <form method="GET" action="/modules/projects.php" id="projectFilterForm" autocomplete="off" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(170px, 1fr)); gap: 14px; align-items: flex-end;">
            <input type="hidden" name="status" value="<?= $status_chosen ? htmlspecialchars($filter_status) : '' ?>">
            <input type="hidden" name="gantt_directorate" value="<?= $gantt_directorate === 'All' ? '' : htmlspecialchars($gantt_directorate) ?>">
            <input type="hidden" name="gantt_saga" value="<?= $gantt_saga === 'All' ? '' : htmlspecialchars($gantt_saga) ?>">

            <div><label style="display:block;font-size:.72rem;font-weight:700;color:#64748b;text-transform:uppercase;margin-bottom:4px;">Year</label><select name="year" style="width:100%;padding:7px 10px;border:1px solid #cbd5e1;border-radius:6px;font-size:.78rem;"><option value="" <?= !$year_chosen ? 'selected' : '' ?>>Select year</option><?php foreach ($gantt_year_options as $fy): ?><option value="<?= $fy ?>" <?= $year_chosen && $fy === $gantt_year ? 'selected' : '' ?>><?= $fy ?></option><?php endforeach; ?></select></div>
            <div><label style="display:block;font-size:.72rem;font-weight:700;color:#64748b;text-transform:uppercase;margin-bottom:4px;">Month</label><select name="month" style="width:100%;padding:7px 10px;border:1px solid #cbd5e1;border-radius:6px;font-size:.78rem;"><option value="" <?= !$month_chosen ? 'selected' : '' ?>>Select month</option><option value="all" <?= $gantt_month === 'all' ? 'selected' : '' ?>>All Months</option><?php foreach (range(1, 12) as $fm): ?><option value="<?= $fm ?>" <?= $month_chosen && (string)$fm === $gantt_month ? 'selected' : '' ?>><?= date('F', mktime(0, 0, 0, $fm, 1)) ?></option><?php endforeach; ?></select></div>

            <!-- SAGA Filter -->
            <div>
                <label style="display: block; font-size: 0.72rem; font-weight: 700; color: #64748b; text-transform: uppercase; margin-bottom: 4px;">Filter by SAGA</label>
                <select name="saga" style="width: 100%; padding: 7px 10px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.78rem;">
                    <option value="" <?= $filter_saga === 'All' ? 'selected' : '' ?>>Select SAGA</option>
                    <?php foreach ($filter_sagas as $saga): ?><option value="<?= htmlspecialchars($saga) ?>" <?= $filter_saga === $saga ? 'selected' : '' ?>><?= htmlspecialchars($saga) ?></option><?php endforeach; ?>
                </select>
            </div>

            <!-- Directorate Filter -->
            <div>
                <label style="display: block; font-size: 0.72rem; font-weight: 700; color: #64748b; text-transform: uppercase; margin-bottom: 4px;">Filter by Directorate</label>
                <select name="dir" id="filterDirectorateSelect" style="width: 100%; padding: 7px 10px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.78rem;">
                    <option value="" <?= $filter_dir === 'All' ? 'selected' : '' ?>>Select directorate</option>
                    <?php foreach ($filter_directorates as $directorate): ?><option value="<?= htmlspecialchars($directorate) ?>" <?= $filter_dir === $directorate ? 'selected' : '' ?>><?= htmlspecialchars($directorate) ?></option><?php endforeach; ?>
                </select>
            </div>

            <!-- Division Filter -->
            <div>
                <label style="display: block; font-size: 0.72rem; font-weight: 700; color: #64748b; text-transform: uppercase; margin-bottom: 4px;">Filter by Division</label>
                <select name="div" id="filterDivisionSelect" style="width: 100%; padding: 7px 10px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.78rem;">
                    <option value="" <?= $filter_div === 'All' ? 'selected' : '' ?>>Select division</option>
                    <?php $seen_division_options = []; foreach ($gantt_divisions as $division_row):
                        $division_label = (string)$division_row['division_name'];
                        $division_key = strtolower((string)$division_row['directorate_name'] . "\0" . $division_label);
                        if (isset($seen_division_options[$division_key])) continue; $seen_division_options[$division_key] = true; ?>
                        <option value="<?= htmlspecialchars($division_label) ?>" data-directorate="<?= htmlspecialchars((string)$division_row['directorate_name']) ?>" <?= $filter_div === $division_label ? 'selected' : '' ?>><?= htmlspecialchars($division_label) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Delivery Unit Filter -->
            <div>
                <label style="display: block; font-size: 0.72rem; font-weight: 700; color: #64748b; text-transform: uppercase; margin-bottom: 4px;">Filter by Delivery Unit</label>
                <select name="du" style="width: 100%; padding: 7px 10px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.78rem;">
                    <option value="" <?= $filter_du === 'All' ? 'selected' : '' ?>>Select delivery unit</option>
                    <?php foreach ($filter_delivery_units as $delivery_unit): ?><option value="<?= htmlspecialchars($delivery_unit) ?>" <?= $filter_du === $delivery_unit ? 'selected' : '' ?>><?= htmlspecialchars($delivery_unit) ?></option><?php endforeach; ?>
                </select>
            </div>

            <!-- Priority Tier Filter -->
            <div>
                <label style="display: block; font-size: 0.72rem; font-weight: 700; color: #64748b; text-transform: uppercase; margin-bottom: 4px;">Priority Tier</label>
                <select name="tier" style="width: 100%; padding: 7px 10px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.78rem;">
                    <option value="" <?= $filter_tier === 'All' ? 'selected' : '' ?>>Select priority tier</option>
                    <?php foreach ($filter_tiers as $tier): ?><option value="<?= htmlspecialchars($tier) ?>" <?= $filter_tier === $tier ? 'selected' : '' ?>><?= htmlspecialchars($tier) ?></option><?php endforeach; ?>
                </select>
            </div>

            <!-- Search Projects -->
            <div>
                <label style="display: block; font-size: 0.72rem; font-weight: 700; color: #64748b; text-transform: uppercase; margin-bottom: 4px;">Search Projects</label>
                <input type="text" name="q" autocomplete="off" value="<?= htmlspecialchars($search_q) ?>" placeholder="Search title, keyword..." style="width: 100%; padding: 7px 10px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.78rem;">
            </div>

            <!-- Filter Buttons -->
            <div style="display: flex; gap: 8px;">
                <button type="submit" style="background: #0d47a1; color: white; border: none; padding: 8px 16px; border-radius: 6px; font-weight: 700; font-size: 0.78rem; cursor: pointer;">
                    Apply Filters
                </button>
                <a href="/modules/projects.php" style="background: #f1f5f9; color: #334155; border: 1px solid #cbd5e1; padding: 7px 12px; border-radius: 6px; font-weight: 700; font-size: 0.78rem; text-decoration: none; text-align: center;">
                    Reset
                </a>
            </div>
        </form>
    </div>

    <script>
    (() => {
        const form = document.getElementById('projectFilterForm');
        const dir = document.getElementById('filterDirectorateSelect');
        const div = document.getElementById('filterDivisionSelect');
        if (!form || !dir || !div) return;
        const syncDivisions = (resetInvalid) => {
            [...div.options].forEach(option => {
                const belongs = !option.dataset.directorate || !dir.value || dir.value === 'All' || option.dataset.directorate === dir.value;
                option.hidden = !belongs; option.disabled = !belongs;
            });
            if (resetInvalid && div.selectedOptions[0]?.disabled) div.value = '';
        };
        syncDivisions(false);
        dir.addEventListener('change', () => { syncDivisions(true); form.requestSubmit(); });
        form.querySelectorAll('select').forEach(select => { if (select !== dir) select.addEventListener('change', () => form.requestSubmit()); });
    })();
    </script>

    <?php
    $ft_progress_map = $monthly_progress_by_project ?? [];
    $ft_progress = static function(array $p) use ($ft_progress_map) {
        if (isset($ft_progress_map[(int)$p['id']])) return (float)$ft_progress_map[(int)$p['id']];
        if (isset($p['overall_progress_pct']) && $p['overall_progress_pct'] !== null) return (float)$p['overall_progress_pct'];
        if (preg_match('/^\s*(\d+(?:\.\d+)?)\s*%?\s*$/', (string)($p['progress_status'] ?? ''), $m)) return (float)$m[1];
        return 0.0;
    };
    $ft_types = array_values(array_unique(array_filter(array_map(static fn($p) => (string)($p['project_type'] ?? ''), $projects))));
    $ft_cats = array_values(array_unique(array_filter(array_map(static fn($p) => (string)($p['category'] ?? ''), $projects))));
    $ft_statuses = array_values(array_unique(array_filter(array_map(static fn($p) => (string)($p['status'] ?? ''), $projects))));
    sort($ft_types); sort($ft_cats); sort($ft_statuses);
    ?>
    <?php
    $ft_agency = static fn($p) => (string)(($p['directorate_name'] ?? '') !== '' && $p['directorate_name'] !== null ? $p['directorate_name'] : ($p['saga_name'] ?? ''));
    $ft_uniq = static function(callable $fn) use ($projects) { $v = array_values(array_unique(array_filter(array_map($fn, $projects), static fn($x) => trim((string)$x) !== ''))); natcasesort($v); return array_values($v); };
    $ft_agencies = $ft_uniq($ft_agency);
    $ft_divs = $ft_uniq(static fn($p) => (string)($p['division_name'] ?? ''));
    $ft_dus = $ft_uniq(static fn($p) => (string)($p['delivery_unit'] ?? ''));
    $ft_row_tint = ['in progress'=>'#f0fdf4','completed'=>'#f0fdf4','overdue'=>'#fef2f2','delayed'=>'#fff7ed','on hold'=>'#fffbeb','planning'=>'#f5f3ff','cancelled'=>'#f1f5f9'];
    ?>
    <div class="ft-toggle-wrap">
        <button type="button" class="ft-toggle" id="ftToggle" aria-expanded="false" aria-controls="projectFilterTable">
            <span>All Projects &amp; Programmes</span><small><?= count($projects) ?></small><b aria-hidden="true">⌄</b>
        </button>
    </div>
    <section class="ft-card" id="projectFilterTable" aria-label="Filterable list of all projects" hidden>
        <div class="ft-toolbar">
            <strong>All Projects &amp; Programmes</strong>
            <span class="ft-count" id="ftCount" aria-live="polite"></span>
            <button type="button" id="ftClear">Clear filters</button>
        </div>
        <div class="ft-filterbar">
            <label class="ft-wide">Search<input type="search" id="ftSearch" placeholder="Title, code, unit…"></label>
            <label>Type<select data-filter="type"><option value="">All</option><?php foreach ($ft_types as $v): ?><option><?= htmlspecialchars($v) ?></option><?php endforeach; ?></select></label>
            <label>Category<select data-filter="category"><option value="">All</option><?php foreach ($ft_cats as $v): ?><option><?= htmlspecialchars($v) ?></option><?php endforeach; ?></select></label>
            <label>Directorate / SAGA<select data-filter="agency"><option value="">All</option><?php foreach ($ft_agencies as $v): ?><option><?= htmlspecialchars($v) ?></option><?php endforeach; ?></select></label>
            <label>Division<select data-filter="division"><option value="">All</option><?php foreach ($ft_divs as $v): ?><option><?= htmlspecialchars($v) ?></option><?php endforeach; ?></select></label>
            <label>Delivery unit<select data-filter="unit"><option value="">All</option><?php foreach ($ft_dus as $v): ?><option><?= htmlspecialchars($v) ?></option><?php endforeach; ?></select></label>
            <label>Status<select data-filter="status"><option value="">All</option><?php foreach ($ft_statuses as $v): ?><option><?= htmlspecialchars($v) ?></option><?php endforeach; ?></select></label>
            <label>Budget<input type="text" data-filter="budget" placeholder="e.g. &gt;1000000"></label>
            <label>Progress %<input type="text" data-filter="progress" placeholder="e.g. &gt;50"></label>
        </div>
        <div class="ft-scroll">
        <table class="ft-table">
            <thead>
                <tr class="ft-heads">
                    <th data-sort="title">Project / Programme</th><th data-sort="type">Type</th><th data-sort="category">Category</th>
                    <th data-sort="status">Status</th><th data-sort="budget" class="ft-num">Budget (KES)</th><th data-sort="progress">Progress</th><th class="ft-act">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($projects as $p): $pv = $ft_progress($p); $sk = strtolower(trim((string)($p['status'] ?? ''))); $place = trim((string)(($p['delivery_unit'] ?? '') ?: $ft_agency($p))); ?>
                <tr style="background:<?= $ft_row_tint[$sk] ?? '#fff' ?>"
                    data-title="<?= htmlspecialchars(strtolower($p['sub_programme'] . ' ' . ($p['project_code'] ?? '') . ' ' . $place)) ?>"
                    data-type="<?= htmlspecialchars((string)($p['project_type'] ?? '')) ?>" data-category="<?= htmlspecialchars((string)($p['category'] ?? '')) ?>"
                    data-agency="<?= htmlspecialchars($ft_agency($p)) ?>" data-division="<?= htmlspecialchars((string)($p['division_name'] ?? '')) ?>"
                    data-unit="<?= htmlspecialchars((string)($p['delivery_unit'] ?? '')) ?>" data-status="<?= htmlspecialchars((string)($p['status'] ?? '')) ?>"
                    data-budget="<?= (float)($p['total_budget'] ?? 0) ?>" data-progress="<?= round($pv, 2) ?>">
                    <td class="ft-title"><strong><?= htmlspecialchars($p['sub_programme']) ?></strong>
                        <span class="ft-place"><svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 0 1 16 0z"/><circle cx="12" cy="10" r="3"/></svg><?= htmlspecialchars($place !== '' ? $place : 'Ministry of Health') ?><?php if (!empty($p['project_code'])): ?> · <?= htmlspecialchars($p['project_code']) ?><?php endif; ?></span></td>
                    <td><span class="ft-type"><?= htmlspecialchars($p['project_type'] ?? 'Project') ?></span></td>
                    <td><?= htmlspecialchars($p['category'] ?? '') ?></td>
                    <td><span class="ft-status <?= $sk === 'overdue' ? 'is-overdue' : '' ?>"><?= htmlspecialchars($p['status'] ?? '') ?></span></td>
                    <td class="ft-num ft-mono"><?= number_format((float)($p['total_budget'] ?? 0), 2) ?></td>
                    <td class="ft-prog"><span class="ft-bar"><i style="width:<?= min(100, $pv) ?>%"></i></span><b><?= round($pv) ?>%</b></td>
                    <td class="ft-act">
                        <a class="ft-icon" href="/modules/projects.php?id=<?= (int)$p['id'] ?>" title="View details" aria-label="View details"><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/></svg></a>
                        <?php if (can_edit()): ?><a class="ft-icon" href="/modules/projects.php?id=<?= (int)$p['id'] ?>" title="Open to edit" aria-label="Open to edit"><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 20h9M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/></svg></a><?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
                <tr class="ft-empty" hidden><td colspan="7">No projects match the filters.</td></tr>
            </tbody>
        </table>
        </div>
        <div class="ft-pager"><span id="ftShown"></span><button type="button" id="ftMore">View 10 next rows &darr;</button></div>
    </section>
    <script>
    (() => {
        const root = document.getElementById('projectFilterTable'); if (!root) return;
        const rows = [...root.querySelectorAll('tbody tr[data-budget]')], empty = root.querySelector('.ft-empty');
        const filters = [...root.querySelectorAll('[data-filter]')], search = root.querySelector('#ftSearch');
        const count = root.querySelector('#ftCount'), shownLbl = root.querySelector('#ftShown'), more = root.querySelector('#ftMore');
        const STEP = 10; let limit = STEP, sortKey = null, sortDir = 1;
        const toggle = document.getElementById('ftToggle');
        toggle.addEventListener('click', () => {
            const open = root.hidden;
            root.hidden = !open; toggle.setAttribute('aria-expanded', open ? 'true' : 'false'); toggle.classList.toggle('is-open', open);
            if (open) { root.classList.add('ft-reveal'); root.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); }
        });
        const numTest = (expr, val) => {
            const m = expr.trim().match(/^(>=|<=|>|<|=)?\s*([\d.,]+)$/); if (!m) return true;
            const n = parseFloat(m[2].replace(/,/g, '')); switch (m[1]) { case '>': return val > n; case '>=': return val >= n; case '<': return val < n; case '<=': return val <= n; default: return val === n; }
        };
        const apply = () => {
            const q = search.value.trim().toLowerCase();
            const match = rows.filter(r => {
                if (q && !r.dataset.title.includes(q)) return false;
                return filters.every(f => {
                    const v = f.value.trim(), k = f.dataset.filter; if (!v) return true;
                    if (k === 'budget' || k === 'progress') return numTest(v, +r.dataset[k]);
                    return r.dataset[k] === v;
                });
            });
            if (sortKey) match.sort((a, b) => {
                const num = sortKey === 'budget' || sortKey === 'progress';
                const x = num ? +a.dataset[sortKey] : (a.dataset[sortKey] || '').toLowerCase(), y = num ? +b.dataset[sortKey] : (b.dataset[sortKey] || '').toLowerCase();
                return (x > y ? 1 : x < y ? -1 : 0) * sortDir;
            });
            const shown = new Set(match.slice(0, limit));
            if (rows.length) match.forEach(r => empty.parentNode.insertBefore(r, empty));
            rows.forEach(r => { r.hidden = !shown.has(r); });
            empty.hidden = match.length > 0;
            count.textContent = match.length + ' of ' + rows.length + ' projects match';
            const left = match.length - shown.size;
            shownLbl.textContent = 'Showing ' + shown.size + ' of ' + match.length;
            more.hidden = left <= 0; more.textContent = 'View ' + Math.min(STEP, left) + ' next row' + (Math.min(STEP, left) === 1 ? '' : 's') + ' \u2193';
        };
        [search, ...filters].forEach(el => el.addEventListener(el.tagName === 'SELECT' ? 'change' : 'input', () => { limit = STEP; apply(); }));
        more.addEventListener('click', () => { limit += STEP; apply(); });
        root.querySelector('#ftClear').addEventListener('click', () => { search.value = ''; filters.forEach(f => f.value = ''); limit = STEP; apply(); });
        root.querySelectorAll('th[data-sort]').forEach(th => th.addEventListener('click', () => { const k = th.dataset.sort; sortDir = sortKey === k ? -sortDir : 1; sortKey = k; limit = STEP; apply(); }));
        apply();
    })();
    </script>

    <!-- Projects Table -->
    <div id="allProjectsPanel" role="tabpanel" aria-labelledby="allProjectsTab" style="background: #ffffff; border-radius: 12px; border: 1px solid #e2e8f0; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.05); margin-top: 20px;">
        <div style="background: #0d47a1; color: white; padding: 14px 20px; font-size: 0.85rem; font-weight: 800; display: flex; justify-content: space-between; align-items: center;">
            <span>Priority Projects &amp; Programmes (<?= count($projects) ?> Projects)</span>
            <button onclick="document.getElementById('addProjectModal').style.display='flex';" style="background: #10b981; color: white; border: none; padding: 6px 14px; border-radius: 6px; font-size: 0.75rem; font-weight: 700; cursor: pointer;">
                + Add Project
            </button>
        </div>
        <div style="overflow-x: auto;">
            <table class="priority-table" style="width: 100%; border-collapse: collapse; font-size: 0.8rem; text-align: left;">
                <thead>
                    <tr style="background: #f8fafc; color: #475569; font-weight: 700; border-bottom: 2px solid #e2e8f0; text-transform: uppercase; font-size: 0.7rem;">
                        <th style="padding: 12px 16px;">Title &amp; Delivery Unit</th>
                        <th style="padding: 12px 16px;">Type</th>
                        <th style="padding: 12px 16px;">Category</th>
                        <th style="padding: 12px 16px;">Status</th>
                        <th style="padding: 12px 16px;">Duration</th>
                        <th style="padding: 12px 16px; text-align: right;">Total Budget (KES)</th>
                        <th style="padding: 12px 16px; width: 140px;">Progress</th>
                        <th style="padding: 12px 16px; text-align: center;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($projects)): ?>
                        <tr>
                            <td colspan="8" style="padding: 30px; text-align: center; color: #64748b;">
                                <?php if (!$db_connected): ?>The projects database connection is unavailable.
                                <?php elseif ($project_load_error): ?>Project records could not be loaded. Check the live database schema and application connection.
                                <?php elseif ($project_total_count === 0): ?>No project rows are present in the database. Import <code>seed_knh_ten_sample_projects.sql</code> to add the KNH sample projects.
                                <?php else: ?>No projects match the selected filters. Use Reset Filters to show all database records.
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($projects as $p):
                            $statusKey = strtolower(trim((string)($p['status'] ?? '')));
                            $rowStatusClass = ['in progress'=>'status-in-progress','on hold'=>'status-on-hold','completed'=>'status-completed','planning'=>'status-planning','delayed'=>'status-delayed','overdue'=>'status-overdue','cancelled'=>'status-cancelled'][$statusKey] ?? 'status-default';
                            $progressValue = null;
                            if (isset($monthly_progress_by_project[(int)$p['id']])) $progressValue = (float)$monthly_progress_by_project[(int)$p['id']];
                            elseif (isset($p['overall_progress_pct']) && $p['overall_progress_pct'] !== null) $progressValue = (float)$p['overall_progress_pct'];
                            elseif (preg_match('/^\s*(\d+(?:\.\d+)?)\s*%?\s*$/', (string)($p['progress_status'] ?? ''), $progressMatch)) $progressValue = (float)$progressMatch[1];
                            else $progressValue = 0.0;
                            $progressValue = max(0, $progressValue);
                            $durationLabel = '—';
                            $durationStart = !empty($p['start_date']) ? DateTimeImmutable::createFromFormat('!Y-m-d', (string)$p['start_date']) : false;
                            $durationEnd = !empty($p['end_date']) ? DateTimeImmutable::createFromFormat('!Y-m-d', (string)$p['end_date']) : false;
                            if ($durationStart && $durationEnd && $durationEnd >= $durationStart) {
                                $duration = $durationStart->diff($durationEnd);
                                $durationParts = [];
                                if ($duration->y) $durationParts[] = $duration->y . ' ' . ($duration->y === 1 ? 'year' : 'years');
                                if ($duration->m) $durationParts[] = $duration->m . ' ' . ($duration->m === 1 ? 'month' : 'months');
                                if (!$durationParts && $duration->d) $durationParts[] = $duration->d . ' ' . ($duration->d === 1 ? 'day' : 'days');
                                $durationLabel = $durationParts ? implode(' ', $durationParts) : 'Under 1 month';
                            }
                            $statusStyle = ['in progress'=>['#047857','#ffffff'],'on hold'=>['#92400e','#ffffff'],'completed'=>['#1d4ed8','#ffffff'],'planning'=>['#6d28d9','#ffffff'],'delayed'=>['#c2410c','#ffffff'],'overdue'=>['#b91c1c','#ffffff'],'cancelled'=>['#475569','#ffffff']][$statusKey] ?? ['#64748b','#ffffff'];
                        ?>
                            <tr class="project-status-row <?= $rowStatusClass ?>">
                                <td style="padding: 12px 16px;">
                                    <strong style="color: #0f172a; font-size: 0.82rem;"><?= htmlspecialchars($p['sub_programme']) ?></strong>
                                    <?php if (!empty($p['project_code'])): ?><div style="font-size:.68rem;color:#64748b;margin-top:2px;">Code: <?= htmlspecialchars($p['project_code']) ?></div><?php endif; ?>
                                    <div style="font-size: 0.72rem; color: #64748b; margin-top: 2px;">
                                        <?= htmlspecialchars($p['delivery_unit'] ?? $p['saga_name'] ?? $p['directorate_name'] ?? 'Ministry of Health') ?>
                                    </div>
                                </td>
                                <td style="padding:12px 16px;"><span style="background:#f1f5f9;color:#475569;border:1px solid #cbd5e1;padding:3px 7px;border-radius:4px;font-size:.7rem;font-weight:700;"><?= htmlspecialchars($p['project_type'] ?? 'Project') ?></span></td>
                                <td style="padding: 12px 16px;">
                                    <span style="background: #dbeafe; color: #1e40af; font-weight: 800; font-size: 0.68rem; padding: 2px 6px; border-radius: 4px;"><?= htmlspecialchars($p['category']) ?></span>
                                </td>
                                <td style="padding: 12px 16px;">
                                    <span style="background: <?= $statusStyle[0] ?>; color: <?= $statusStyle[1] ?>; padding: 4px 10px; border-radius: 6px; font-size: 0.7rem; font-weight: 800;">
                                        <?= htmlspecialchars($p['status']) ?>
                                    </span>
                                </td>
                                <td style="padding: 12px 16px; white-space: nowrap; font-weight: 700; color: #334155;">
                                    <?= htmlspecialchars($durationLabel) ?>
                                </td>
                                <td style="padding: 12px 16px; text-align: right; font-family: 'JetBrains Mono', monospace; font-weight: 700; color: #0d47a1;">
                                    <?=$p['total_budget'] ?>
                                </td>
                                <td style="padding: 12px 16px;">
                                    <div style="font-size: 0.75rem; font-weight: 800; color: #334155; margin-bottom: 4px;"><?= number_format($progressValue, 1) ?>%</div>
                                    <div style="background: #e2e8f0; height: 8px; border-radius: 4px; overflow: hidden;">
                                        <div style="background: <?= htmlspecialchars($p['color'] ?? '#0d47a1') ?>; height: 100%; width: <?= min(100, $progressValue) ?>%;"></div>
                                    </div>
                                </td>
                                <td style="padding: 12px 16px; text-align: center;">
                                    <a href="/modules/projects.php?id=<?= $p['id'] ?>" style="background: #1d4ed8; color: #ffffff; text-decoration: none; padding: 5px 12px; border-radius: 6px; font-size: 0.72rem; font-weight: 800; display: inline-block; white-space: nowrap;">
                                        View Detail &rarr;
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

<?php endif; ?>

</div>

<!-- Modal: Add Project -->
<div id="addProjectModal" style="display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 9999; align-items: center; justify-content: center; padding: 20px;">
    <div style="background: white; border-radius: 12px; max-width: 600px; width: 100%; padding: 24px; box-shadow: 0 20px 40px rgba(0,0,0,0.3);">
        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #e2e8f0; padding-bottom: 12px; margin-bottom: 16px;">
            <h3 style="margin: 0; font-size: 1.05rem; font-weight: 800; color: #0f172a;">Register Project to Portfolio</h3>
            <button onclick="document.getElementById('addProjectModal').style.display='none';" style="background: none; border: none; font-size: 1.3rem; cursor: pointer; color: #64748b;">&times;</button>
        </div>

        <form method="POST" action="/modules/projects.php">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(get_csrf_token()) ?>">
            <input type="hidden" name="action_type" value="add_project">

            <div style="margin-bottom: 12px;">
                <label style="display: block; font-size: 0.75rem; font-weight: 700; margin-bottom: 4px;">Sub-Programme / Project Name</label>
                <input type="text" name="sub_programme" required style="width: 100%; padding: 8px 12px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.82rem;" placeholder="e.g. Modern Burns ICU Center">
            </div>

            <div style="margin-bottom: 12px;">
                <label style="display: block; font-size: 0.75rem; font-weight: 700; margin-bottom: 4px;">Strategic Programme Title</label>
                <input type="text" name="programme_title" required style="width: 100%; padding: 8px 12px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.82rem;" placeholder="e.g. Specialized Hospital Infrastructure">
            </div>

            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px;">
                <div><label style="display:block;font-size:.75rem;font-weight:700;margin-bottom:4px;">Project Code</label><input type="text" name="project_code" maxlength="50" style="width:100%;padding:8px 12px;border:1px solid #cbd5e1;border-radius:6px;font-size:.82rem;"></div>
                <div><label style="display:block;font-size:.75rem;font-weight:700;margin-bottom:4px;">Type</label><select name="project_type" style="width:100%;padding:8px 12px;border:1px solid #cbd5e1;border-radius:6px;font-size:.82rem;"><option>Project</option><option>Programme</option></select></div>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 2fr; gap: 12px; margin-bottom: 12px;">
                <div>
                    <label style="display: block; font-size: 0.75rem; font-weight: 700; margin-bottom: 4px;">Category</label>
                    <select name="category" style="width: 100%; padding: 8px 12px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.82rem;">
                        <option value="Saga">SAGA (Referral Hospital)</option>
                        <option value="Directorate">Directorate</option>
                        <option value="Division">Division</option>
                    </select>
                </div>
                <div>
                    <label style="display: block; font-size: 0.75rem; font-weight: 700; margin-bottom: 4px;">Agency / Directorate / SAGA Name</label>
                    <input type="text" name="agency_name" list="projectAgencyOptions" required style="width: 100%; padding: 8px 12px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.82rem;" placeholder="Select or enter an agency, directorate, or division">
                    <datalist id="projectAgencyOptions">
                        <?php foreach ($gantt_sagas as $agencyOption): ?><option value="<?= htmlspecialchars($agencyOption) ?>"></option><?php endforeach; ?>
                        <?php foreach ($gantt_directorates as $agencyOption): ?><option value="<?= htmlspecialchars($agencyOption) ?>"></option><?php endforeach; ?>
                        <?php foreach ($filter_divisions as $agencyOption): ?><option value="<?= htmlspecialchars($agencyOption) ?>"></option><?php endforeach; ?>
                    </datalist>
                </div>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 12px;">
                <div>
                    <label style="display: block; font-size: 0.75rem; font-weight: 700; margin-bottom: 4px;">Priority Tier</label>
                    <select name="priority_tier" style="width: 100%; padding: 8px 12px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.82rem;">
                        <option value="Tier 1 - High Priority">Tier 1 - Critical Priority</option>
                        <option value="Tier 2 - Medium Priority">Tier 2 - High Priority</option>
                        <option value="Tier 3 - Standard Priority">Tier 3 - Medium Priority</option>
                        <option value="Tier 4 - Low Priority">Tier 4 - Low Priority</option>
                    </select>
                </div>
                <div>
                    <label style="display: block; font-size: 0.75rem; font-weight: 700; margin-bottom: 4px;">Total Budget (KES)</label>
                    <input type="number" step="100000" name="total_budget" value="1500000000" required style="width: 100%; padding: 8px 12px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.82rem;">
                </div>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 12px;">
                <div>
                    <label style="display: block; font-size: 0.75rem; font-weight: 700; margin-bottom: 4px;">Status</label>
                    <select name="status" style="width: 100%; padding: 8px 12px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.82rem;">
                        <option value="In Progress">In Progress</option>
                        <option value="Completed">Completed</option>
                        <option value="On Hold">On Hold</option>
                        <option value="Delayed">Delayed</option>
                    </select>
                </div>
                <div>
                    <label style="display: block; font-size: 0.75rem; font-weight: 700; margin-bottom: 4px;">Start Date</label>
                    <input type="date" name="start_date" required style="width: 100%; padding: 8px 12px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.82rem;">
                </div>
            </div>

            <div style="display: flex; justify-content: flex-end; gap: 10px; margin-top: 16px;">
                <button type="button" onclick="document.getElementById('addProjectModal').style.display='none';" style="padding: 8px 16px; border: 1px solid #cbd5e1; background: white; border-radius: 6px; font-weight: 600; font-size: 0.8rem; cursor: pointer;">Cancel</button>
                <button type="submit" style="padding: 8px 18px; background: #0d47a1; color: white; border: none; border-radius: 6px; font-weight: 700; font-size: 0.8rem; cursor: pointer;">Save Project</button>
            </div>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
