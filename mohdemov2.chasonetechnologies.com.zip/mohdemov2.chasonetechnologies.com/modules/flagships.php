<?php
/**
 * Priority Flagships Module (with CRUD)
 * Ministry of Health — State Department for Medical Services (PP-SDOMS)
 * Native PHP 8.1+ & MySQL (No Node.js)
 *
 * Projects are linked to a flagship through projects.flagship_id.
 * Flagships are never hard-deleted: "Archive" sets flagships.is_archived = 1 (linked projects stay
 * linked) and an archived flagship can be restored from the Archived view.
 */
require_once __DIR__ . '/../config/db.php';
require_auth();

$page_title = 'Priority Flagships — State Department for Medical Services';
$active_tab = 'flagships';

const FLAGSHIP_TIERS    = ['Critical', 'High', 'Medium', 'Low'];

/** Best-effort name of the logged-in user for the archive record. */
function flagship_current_user(): string
{
    foreach (['full_name', 'user_name', 'name', 'email'] as $k) {
        if (!empty($_SESSION[$k]) && is_string($_SESSION[$k])) return $_SESSION[$k];
        if (!empty($_SESSION['user'][$k]) && is_string($_SESSION['user'][$k])) return $_SESSION['user'][$k];
    }
    return 'Unknown';
}

/** Adds the soft-archive columns to `flagships` when missing (cheap check, safe on every request). */
function flagship_ensure_archive_columns(PDO $pdo): bool
{
    try {
        if ($pdo->query("SHOW COLUMNS FROM `flagships` LIKE 'is_archived'")->fetch()) return true;
        $pdo->exec("ALTER TABLE `flagships`
            ADD COLUMN `is_archived` tinyint(1) NOT NULL DEFAULT 0,
            ADD COLUMN `archived_at` timestamp NULL DEFAULT NULL,
            ADD KEY `idx_flagships_is_archived` (`is_archived`)");
        return true;
    } catch (Throwable $e) {
        error_log('Flagship archive columns unavailable: ' . $e->getMessage());
        return false;
    }
}

/** Reads and validates the add/edit form fields. */
function flagship_read_input(): array
{
    $tier = $_POST['priority_tier'] ?? 'Medium';
    if (!in_array($tier, FLAGSHIP_TIERS, true)) $tier = 'Medium';
    $date = static function ($v) {
        $v = trim((string)$v);
        $d = DateTime::createFromFormat('Y-m-d', $v);
        return ($d && $d->format('Y-m-d') === $v) ? $v : null;
    };
    $ids = [];
    foreach ((array)($_POST['project_ids'] ?? []) as $pid) {
        $pid = (int)$pid;
        if ($pid > 0) $ids[$pid] = $pid;
    }
    return [
        'title'        => trim((string)($_POST['title'] ?? '')),
        'progress'     => max(0, min(100, (float)($_POST['progress_pct'] ?? 0))),
        'budget'       => max(0, (float)($_POST['allocated_budget'] ?? 0)),
        'tier'         => $tier,
        'desc'         => trim((string)($_POST['description'] ?? '')),
        'start_date'   => $date($_POST['start_date'] ?? ''),
        'target_date'  => $date($_POST['target_date'] ?? ''),
        'project_ids'  => array_values($ids),
    ];
}

/** Makes projects.flagship_id match the chosen list for one flagship. */
function flagship_sync_projects(PDO $pdo, int $flagship_id, array $project_ids): void
{
    if ($project_ids) {
        $in = implode(',', array_fill(0, count($project_ids), '?'));
        $pdo->prepare("UPDATE projects SET flagship_id = NULL WHERE flagship_id = ? AND id NOT IN ($in)")
            ->execute(array_merge([$flagship_id], $project_ids));
        $pdo->prepare("UPDATE projects SET flagship_id = ? WHERE id IN ($in)")
            ->execute(array_merge([$flagship_id], $project_ids));
    } else {
        $pdo->prepare("UPDATE projects SET flagship_id = NULL WHERE flagship_id = ?")->execute([$flagship_id]);
    }
}

$flash_msg   = '';
$flash_error = false;
$flash_codes = [
    'created' => 'Flagship successfully recorded.',
    'updated' => 'Flagship successfully updated.',
    'archived' => 'Flagship archived. You can restore it from the Archived view.',
    'restored' => 'Flagship restored.',
];
if (isset($_GET['msg'], $flash_codes[$_GET['msg']])) $flash_msg = $flash_codes[$_GET['msg']];

$archive_ready = ($db_connected && $pdo) ? flagship_ensure_archive_columns($pdo) : false;
$show_archived = $archive_ready && isset($_GET['archived']);

// ---------------------------------------------------------------- POST: add / edit / archive / restore
if ($_SERVER['REQUEST_METHOD'] === 'POST' && can_edit()) {
    $action = $_POST['action'] ?? 'add';
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $flash_msg = 'Security token expired. Please reload the page and try again.';
        $flash_error = true;
    } elseif (!$db_connected || !$pdo) {
        $flash_msg = 'Database connection unavailable; no changes were saved.';
        $flash_error = true;
    } else {
        try {
            if ($action === 'add') {
                $in = flagship_read_input();
                if ($in['title'] === '') throw new RuntimeException('A flagship title is required.');
                $pdo->beginTransaction();
                $pdo->prepare("INSERT INTO flagships (title, description, progress_pct, priority_tier, allocated_budget, start_date, target_date)
                               VALUES (?, ?, ?, ?, ?, ?, ?)")
                    ->execute([$in['title'], $in['desc'], $in['progress'], $in['tier'], $in['budget'], $in['start_date'], $in['target_date']]);
                $new_id = (int)$pdo->lastInsertId();
                flagship_sync_projects($pdo, $new_id, $in['project_ids']);
                $pdo->commit();
                log_audit_trail('CREATE', 'Flagships', $new_id, "Created priority flagship: {$in['title']}" . ($in['project_ids'] ? ' (linked projects: ' . implode(', ', $in['project_ids']) . ')' : ''));
                header('Location: /modules/flagships.php?msg=created'); exit;

            } elseif ($action === 'edit') {
                $id = (int)($_POST['id'] ?? 0);
                $in = flagship_read_input();
                if ($id <= 0) throw new RuntimeException('Invalid flagship.');
                if ($in['title'] === '') throw new RuntimeException('A flagship title is required.');
                $pdo->beginTransaction();
                $oldStmt=$pdo->prepare('SELECT * FROM flagships WHERE id=? FOR UPDATE');$oldStmt->execute([$id]);$oldFlagship=$oldStmt->fetch(PDO::FETCH_ASSOC);
                if(!$oldFlagship)throw new RuntimeException('Flagship not found.');
                $reason=trim((string)($_POST['change_reason']??''));
                $criticalChanged=(float)$oldFlagship['progress_pct']!==(float)$in['progress']||strcasecmp((string)$oldFlagship['priority_tier'],(string)$in['tier'])!==0||(float)$oldFlagship['allocated_budget']!==(float)$in['budget'];
                if($criticalChanged&&$reason==='')throw new RuntimeException('Provide a reason when changing flagship progress, priority, or budget.');
                $pdo->prepare("UPDATE flagships SET title = ?, description = ?, progress_pct = ?, priority_tier = ?, allocated_budget = ?, start_date = ?, target_date = ? WHERE id = ?")
                    ->execute([$in['title'], $in['desc'], $in['progress'], $in['tier'], $in['budget'], $in['start_date'], $in['target_date'], $id]);
                flagship_sync_projects($pdo, $id, $in['project_ids']);
                $pdo->commit();
                $newStmt=$pdo->prepare('SELECT * FROM flagships WHERE id=?');$newStmt->execute([$id]);$newFlagship=$newStmt->fetch(PDO::FETCH_ASSOC)?:[];
                audit_log_change('Flagships',$id,$oldFlagship,$newFlagship,"Updated flagship: {$in['title']}",['reason'=>$reason,'metadata'=>['linked_project_ids'=>$in['project_ids']]]);
                $back = (($_POST['return_to'] ?? '') === 'view')
                    ? '/modules/flagship_view.php?id=' . $id . '&msg=updated'
                    : '/modules/flagships.php?msg=updated';
                header('Location: ' . $back); exit;

            } elseif ($action === 'archive' || $action === 'restore') {
                $id = (int)($_POST['id'] ?? 0);
                if ($id <= 0) throw new RuntimeException('Invalid flagship.');
                if (!$archive_ready) throw new RuntimeException('Archiving is unavailable: the archive columns could not be added to the flagships table. Run flagships_migration.sql.');
                $stmt = $pdo->prepare('SELECT title FROM flagships WHERE id = ?');
                $stmt->execute([$id]);
                $title = $stmt->fetchColumn();
                if ($title === false) throw new RuntimeException('Flagship not found.');
                if ($action === 'archive') {
                    $pdo->prepare('UPDATE flagships SET is_archived = 1, archived_at = NOW() WHERE id = ?')->execute([$id]);
                    log_audit_trail('ARCHIVE', 'Flagships', $id, "Archived flagship: {$title}");
                    header('Location: /modules/flagships.php?msg=archived'); exit;
                }
                $pdo->prepare('UPDATE flagships SET is_archived = 0, archived_at = NULL WHERE id = ?')->execute([$id]);
                log_audit_trail('RESTORE', 'Flagships', $id, "Restored flagship: {$title}");
                header('Location: /modules/flagship_view.php?id=' . $id . '&msg=restored'); exit;
            }
        } catch (Throwable $e) {
            if ($pdo && $pdo->inTransaction()) $pdo->rollBack();
            error_log('Flagship action failed: ' . $e->getMessage());
            $flash_msg = ($e instanceof RuntimeException) ? $e->getMessage() : 'Error saving to database: ' . $e->getMessage();
            $flash_error = true;
        }
    }
}

// ---------------------------------------------------------------- Fetch data
$flagships = [];
$archive_where = $archive_ready ? ('WHERE f.is_archived = ' . ($show_archived ? 1 : 0)) : '';
$project_options = [];
$linked_ids_by_flagship = [];
if ($db_connected && $pdo) {
    try {
        $flagships = $pdo->query("
            SELECT f.*,
                   COUNT(p.id)                                   AS linked_count,
                   COALESCE(SUM(p.total_budget), 0)              AS linked_budget,
                   AVG(COALESCE(p.overall_progress_pct, 0))      AS linked_progress
            FROM flagships f
            LEFT JOIN projects p ON p.flagship_id = f.id
            $archive_where
            GROUP BY f.id
            ORDER BY f.id ASC
        ")->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        error_log('Flagship rollup unavailable: ' . $e->getMessage());
        try {
            $flagships = $pdo->query("SELECT f.* FROM flagships f $archive_where ORDER BY f.id ASC")->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e2) {
            error_log('Flagships query failed: ' . $e2->getMessage());
        }
    }

    foreach ($flagships as &$row) {
        $count = (int)($row['linked_count'] ?? 0);
        $row['linked_count']     = $count;
        $row['display_progress'] = $count > 0 ? (float)$row['linked_progress'] : 0.0;
        $row['display_budget']   = $count > 0 ? (float)$row['linked_budget']   : 0.0;
    }
    unset($row);

    if (can_edit()) {
        try {
            $project_options = $pdo->query("SELECT id, project_code, sub_programme, flagship_id FROM projects ORDER BY sub_programme ASC")->fetchAll(PDO::FETCH_ASSOC);
            foreach ($project_options as $po) {
                if (!empty($po['flagship_id'])) $linked_ids_by_flagship[(int)$po['flagship_id']][] = (int)$po['id'];
            }
        } catch (Exception $e) {
            error_log('Project options unavailable: ' . $e->getMessage());
        }
    }
}
$flagship_titles = array_column($flagships, 'title', 'id');
$edit_payloads = []; // id => form data, used to open the edit modal (also via ?edit=ID from the detail page)

function flagship_tier_colour(string $tier): string
{
    return match ($tier) {
        'Critical' => '#dc2626',
        'High'     => '#f59e0b',
        'Medium'   => '#16a34a',
        'Low'      => '#2563eb',
        default    => '#64748b',
    };
}

require_once __DIR__ . '/../includes/header.php';
?>
<style>
.fl-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:20px}
.fl-card{position:relative;display:flex;flex-direction:column;background:#fff;border:1px solid #e6ebf2;border-radius:10px;padding:20px;color:inherit;text-decoration:none;transition:box-shadow .15s,border-color .15s}
.fl-card:hover{border-color:#c5d3e8;box-shadow:0 4px 14px rgba(15,23,42,.08)}
.fl-btn{display:inline-block;align-self:flex-start;margin-top:14px;padding:8px 16px;background:#2563eb;color:#fff;font-size:.8rem;font-weight:700;text-align:center;text-decoration:none;border-radius:8px;transition:background .15s}
.fl-btn:hover{background:#1d4ed8}
.fl-btn:focus-visible{outline:2px solid #1e3a8a;outline-offset:2px}
.fl-top{display:flex;justify-content:space-between;align-items:center;gap:10px}
.fl-tier{align-self:flex-start;color:#fff;font-size:.72rem;font-weight:700;line-height:1;padding:6px 12px;border-radius:999px}
.fl-title{margin:14px 0 6px;font-size:1.05rem;font-weight:800;line-height:1.3;color:#0f172a}
.fl-desc{margin:0 0 18px;font-size:.82rem;line-height:1.45;color:#64748b;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.fl-row{display:flex;justify-content:space-between;align-items:baseline;gap:12px;font-size:.82rem}
.fl-row .fl-label{color:#334155}
.fl-row strong{color:#0f172a;font-weight:800}
.fl-bar{height:6px;margin:8px 0 18px;background:#e2e8f0;border-radius:999px;overflow:hidden}
.fl-bar span{display:block;height:100%;background:#2563eb;border-radius:inherit}
.fl-sub{margin-top:2px;font-size:.72rem;color:#2563eb}
.fl-foot{display:flex;justify-content:space-between;align-items:center;gap:12px;margin-top:auto;padding-top:14px;border-top:1px solid #eef2f7}
.fl-due{display:inline-flex;align-items:center;gap:6px;font-size:.75rem;color:#475569}
.fl-due svg{flex:none}
.fl-status{background:#1e293b;color:#fff;font-size:.72rem;font-weight:700;padding:6px 10px;border-radius:6px;white-space:nowrap}
.fl-body{margin-top:auto}
/* Modals */
.fl-modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:9999;align-items:center;justify-content:center;padding:20px}
.fl-modal.is-open{display:flex}
.fl-modal-box{background:#fff;border-radius:8px;max-width:640px;width:100%;max-height:92vh;overflow-y:auto;padding:24px;box-shadow:0 20px 40px rgba(0,0,0,.3)}
.fl-field label{display:block;font-size:.75rem;font-weight:700;margin-bottom:4px}
.fl-field input,.fl-field select,.fl-field textarea{width:100%;padding:8px 12px;border:1px solid #cbd5e1;border-radius:4px;font-size:.85rem;box-sizing:border-box}
.fl-2col{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px}
.fl-picker{border:1px solid #cbd5e1;border-radius:6px;overflow:hidden}
.fl-picker input[type=search]{border:0;border-bottom:1px solid #e2e8f0;border-radius:0}
.fl-picker-list{max-height:170px;overflow-y:auto;padding:4px 0}
.fl-picker-item{display:flex;gap:8px;align-items:flex-start;padding:6px 12px;font-size:.8rem;cursor:pointer;margin:0!important;font-weight:500!important}
.fl-picker-item:hover{background:#f8fafc}
.fl-picker-item input{width:auto;margin-top:3px}
.fl-picker-item small{display:block;color:#64748b;font-size:.68rem}
.fl-picker-count{font-size:.7rem;color:#64748b;margin-top:4px}
.fl-card-link{cursor:pointer;transition:border-color .16s,box-shadow .16s,transform .16s}.fl-card-link:hover,.fl-card-link:focus-visible{border-color:#60a5fa;box-shadow:0 0 0 2px rgba(96,165,250,.22);outline:none;transform:translateY(-2px)}
.fl-card-actions{position:absolute;top:14px;right:14px;z-index:4}
.fl-card-actions summary{list-style:none;cursor:pointer;background:#10b981;color:#fff;border-radius:6px;padding:7px 11px;font-size:.72rem;font-weight:800}
.fl-card-actions summary::-webkit-details-marker{display:none}
.fl-card-actions[open] summary,.fl-card-actions summary:hover{background:#059669}
.fl-card-actions-menu{position:absolute;top:calc(100% + 5px);right:0;min-width:150px;padding:5px;background:#fff;border:1px solid #dbe3ed;border-radius:7px;box-shadow:0 10px 24px rgba(15,35,65,.16)}
.fl-card-actions-menu a,.fl-card-actions-menu button{display:block;box-sizing:border-box;width:100%;padding:8px 10px;border:0;border-radius:4px;background:transparent;color:#334155;text-align:left;text-decoration:none;font:inherit;font-size:.75rem;font-weight:700;cursor:pointer}
.fl-card-actions-menu a:hover,.fl-card-actions-menu button:hover{background:#f1f5f9;color:#0f172a}
.fl-card-actions-menu form{margin:0}
</style>

<div style="display: flex; flex-direction: column; gap: 20px;">

    <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px;">
        <div>
            <h2 style="font-size: 1.25rem; font-weight: 800; color: #0f172a; margin: 0; display: flex; align-items: center; gap: 8px;">
                🎯 Strategic Priority Flagships
            </h2>
            <span style="font-size: 0.8rem; color: #64748b;"><?= $show_archived ? 'Archived flagships (open one to restore it)' : 'Monitoring presidential health directives &amp; UHC transformative programs' ?></span>
            <?php if ($archive_ready): ?>
                <div style="margin-top:6px;font-size:.78rem;font-weight:700;"><a href="/modules/flagships.php<?= $show_archived ? '' : '?archived=1' ?>" style="color:#1d4ed8;text-decoration:none;"><?= $show_archived ? '&larr; Back to active flagships' : 'View archived flagships' ?></a></div>
            <?php endif; ?>
        </div>

        <?php if (can_edit()): ?>
            <button type="button" id="addFlagshipBtn" style="background: #10b981; color: white; border: none; padding: 8px 16px; border-radius: 6px; font-weight: 700; font-size: 0.8rem; cursor: pointer; display: flex; align-items: center; gap: 6px;">
                + Add Priority Flagship
            </button>
        <?php endif; ?>
    </div>

    <?php if ($flash_msg): ?>
        <div role="status" style="background: <?= $flash_error ? '#fef2f2' : '#ecfdf5' ?>; border: 1px solid <?= $flash_error ? '#dc2626' : '#10b981' ?>; color: <?= $flash_error ? '#991b1b' : '#065f46' ?>; padding: 12px; border-radius: 6px; font-size: 0.85rem;">
            <?= htmlspecialchars($flash_msg) ?>
        </div>
    <?php endif; ?>

    <!-- Flagship cards -->
    <div class="fl-grid">
        <?php foreach ($flagships as $f):
            $tier     = (string)($f['priority_tier'] ?? 'Medium');
            $progress = max(0, min(100, (float)$f['display_progress']));
            $count    = (int)$f['linked_count'];
            $due      = !empty($f['target_date']) ? date('d M Y', strtotime($f['target_date'])) : '—';
            $edit_data = [
                'id' => (int)$f['id'], 'title' => $f['title'], 'description' => $f['description'] ?? '',
                'priority_tier' => $tier,
                'progress_pct' => (float)($f['progress_pct'] ?? 0), 'allocated_budget' => (float)($f['allocated_budget'] ?? 0),
                'start_date' => $f['start_date'] ?? '', 'target_date' => $f['target_date'] ?? '',
                'project_ids' => $linked_ids_by_flagship[(int)$f['id']] ?? [],
            ];
            $edit_payloads[(int)$f['id']] = $edit_data;
        ?>
            <div class="fl-card fl-card-link" tabindex="0" role="link" aria-label="View flagship <?= htmlspecialchars((string)$f['title'], ENT_QUOTES) ?>" onclick="if(!event.target.closest('button, form, a, details')) location.href='/modules/flagship_view.php?id=<?= (int)$f['id'] ?>'" onkeydown="if((event.key==='Enter'||event.key===' ')&&!event.target.closest('button, form, a, details')){event.preventDefault();location.href='/modules/flagship_view.php?id=<?= (int)$f['id'] ?>'}">
                <details class="fl-card-actions">
                    <summary>Actions ▾</summary>
                    <div class="fl-card-actions-menu">
                        <a href="/modules/flagship_view.php?id=<?= (int)$f['id'] ?>">View details</a>
                        <?php if (can_edit()): ?><a href="/modules/flagships.php?edit=<?= (int)$f['id'] ?>">Edit flagship</a>
                        <form method="post" action="/modules/flagships.php" onsubmit="return confirm('<?= $show_archived ? 'Restore' : 'Archive' ?> this flagship?')"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars(get_csrf_token()) ?>"><input type="hidden" name="action" value="<?= $show_archived ? 'restore' : 'archive' ?>"><input type="hidden" name="id" value="<?= (int)$f['id'] ?>"><button type="submit"><?= $show_archived ? 'Restore flagship' : 'Archive flagship' ?></button></form><?php endif; ?>
                    </div>
                </details>
                <div class="fl-top">
                    <span class="fl-tier" style="background: <?= flagship_tier_colour($tier) ?>;">Tier: <?= htmlspecialchars($tier) ?></span>
                    <?php if ($show_archived): ?><span class="fl-status" style="background:#64748b;">Archived</span><?php endif; ?>
                </div>

                <h3 class="fl-title"><?= htmlspecialchars($f['title']) ?></h3>
                <p class="fl-desc"><?= htmlspecialchars((string)($f['description'] ?? '')) ?></p>

                <div class="fl-body">
                    <div class="fl-row">
                        <span class="fl-label">Progress</span>
                        <strong><?= number_format($progress, 0) ?>%</strong>
                    </div>
                    <div class="fl-bar" role="progressbar" aria-valuenow="<?= round($progress) ?>" aria-valuemin="0" aria-valuemax="100">
                        <span style="width: <?= $progress ?>%;"></span>
                    </div>

                    <div class="fl-row">
                        <span class="fl-label">Total Budget</span>
                        <strong><?= format_kes($f['display_budget']) ?></strong>
                    </div>
                    <div class="fl-sub"><?= $count ?> linked project<?= $count === 1 ? '' : 's' ?></div>
                </div>

            </div>
        <?php endforeach; ?>
    </div>

</div>

<?php if (can_edit()): ?>
<!-- Add / Edit Flagship Modal -->
<div id="flagshipModal" class="fl-modal" role="dialog" aria-modal="true" aria-labelledby="flagshipModalTitle">
    <div class="fl-modal-box">
        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #e2e8f0; padding-bottom: 12px; margin-bottom: 16px;">
            <h3 id="flagshipModalTitle" style="margin: 0; font-size: 1rem; font-weight: 800;">Add Strategic Priority Flagship</h3>
            <button type="button" data-close="flagshipModal" style="background: none; border: none; font-size: 1.2rem; cursor: pointer;" aria-label="Close">&times;</button>
        </div>

        <form method="POST" action="/modules/flagships.php" id="flagshipForm">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(get_csrf_token()) ?>">
            <input type="hidden" name="action" id="flagshipAction" value="add">
            <input type="hidden" name="id" id="flagshipId" value="">
            <input type="hidden" name="return_to" id="flagshipReturn" value="">

            <div class="fl-field" style="margin-bottom: 12px;">
                <label for="ffTitle">Flagship Initiative Title</label>
                <input type="text" name="title" id="ffTitle" required placeholder="e.g. Afya Care Infrastructure Digitization">
            </div>

            <div class="fl-2col">
                <div class="fl-field">
                    <label for="ffTier">Priority Tier</label>
                    <select name="priority_tier" id="ffTier">
                        <?php foreach (FLAGSHIP_TIERS as $t): ?><option value="<?= $t ?>"><?= $t ?></option><?php endforeach; ?>
                    </select>
                </div>
                <div class="fl-field"><label for="ffProgress">Progress (%)</label><input type="number" step="0.1" min="0" max="100" name="progress_pct" id="ffProgress"></div>
            </div>

            <div class="fl-2col">
                <div class="fl-field"><label for="ffStart">Start Date</label><input type="date" name="start_date" id="ffStart"></div>
                <div class="fl-field"><label for="ffTarget">Target Date</label><input type="date" name="target_date" id="ffTarget"></div>
            </div>

            <div class="fl-field" style="margin-bottom: 12px;">
                <label for="ffBudget">Allocated Budget (KES)</label>
                <input type="number" step="any" min="0" name="allocated_budget" id="ffBudget" required>
            </div>

            <div class="fl-field" style="margin-bottom: 12px;">
                <label for="ffDesc">Scope Description</label>
                <textarea name="description" id="ffDesc" rows="3" placeholder="Strategic scope and UHC impact..."></textarea>
            </div>

            <div class="fl-field" style="margin-bottom: 12px;">
                <label for="ffChangeReason">Reason for changes (required when changing progress, priority, or budget)</label>
                <textarea name="change_reason" id="ffChangeReason" rows="2" maxlength="2000"></textarea>
            </div>

            <div class="fl-field" style="margin-bottom: 16px;">
                <label>Attach Projects</label>
                <div class="fl-picker">
                    <input type="search" id="ffProjectSearch" placeholder="Search projects by name, code or ID..." aria-label="Search projects">
                    <div class="fl-picker-list" id="ffProjectList">
                        <?php if (!$project_options): ?>
                            <div style="padding:10px 12px;font-size:.8rem;color:#64748b;">No projects available.</div>
                        <?php endif; ?>
                        <?php foreach ($project_options as $po):
                            $owner = !empty($po['flagship_id']) ? ($flagship_titles[(int)$po['flagship_id']] ?? ('Flagship #' . (int)$po['flagship_id'])) : '';
                            $search = strtolower($po['id'] . ' ' . ($po['project_code'] ?? '') . ' ' . $po['sub_programme']);
                        ?>
                            <label class="fl-picker-item" data-search="<?= htmlspecialchars($search, ENT_QUOTES) ?>" data-owner="<?= (int)($po['flagship_id'] ?? 0) ?>">
                                <input type="checkbox" name="project_ids[]" value="<?= (int)$po['id'] ?>">
                                <span><?= htmlspecialchars((string)$po['sub_programme']) ?>
                                    <small>ID <?= (int)$po['id'] ?><?= !empty($po['project_code']) ? ' · Code ' . htmlspecialchars((string)$po['project_code']) : '' ?><?= $owner !== '' ? ' · Currently under: ' . htmlspecialchars($owner) : '' ?></small>
                                </span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div class="fl-picker-count" id="ffProjectCount">0 selected. A project belongs to one flagship, so selecting one already under another flagship moves it here.</div>
            </div>

            <div style="display: flex; justify-content: flex-end; gap: 10px;">
                <button type="button" data-close="flagshipModal" style="padding: 8px 16px; border: 1px solid #cbd5e1; background: white; border-radius: 4px; font-weight: 600; font-size: 0.8rem; cursor: pointer;">Cancel</button>
                <button type="submit" id="flagshipSubmit" style="padding: 8px 16px; background: #0d47a1; color: white; border: none; border-radius: 4px; font-weight: 700; font-size: 0.8rem; cursor: pointer;">Save Flagship</button>
            </div>
        </form>
    </div>
</div>

<script>
(() => {
    const $ = id => document.getElementById(id);
    const modal = $('flagshipModal'), form = $('flagshipForm');
    const editPayloads = <?= json_encode($edit_payloads, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
    const boxes = () => [...document.querySelectorAll('#ffProjectList input[type=checkbox]')];
    const updateCount = () => { const n = boxes().filter(b => b.checked).length; $('ffProjectCount').textContent = n + ' selected. A project belongs to one flagship, so selecting one already under another flagship moves it here.'; };
    const filterProjects = () => { const q = $('ffProjectSearch').value.trim().toLowerCase(); document.querySelectorAll('#ffProjectList .fl-picker-item').forEach(i => { i.style.display = !q || i.dataset.search.includes(q) ? '' : 'none'; }); };

    function openForm(data, returnToView) {
        const edit = !!data;
        form.reset();
        $('flagshipModalTitle').textContent = edit ? 'Edit Strategic Priority Flagship' : 'Add Strategic Priority Flagship';
        $('flagshipSubmit').textContent = edit ? 'Update Flagship' : 'Save Flagship';
        $('flagshipAction').value = edit ? 'edit' : 'add';
        $('flagshipId').value = edit ? data.id : '';
        $('flagshipReturn').value = (edit && returnToView) ? 'view' : '';
        const ids = new Set((edit ? data.project_ids : []).map(Number));
        boxes().forEach(b => { b.checked = ids.has(Number(b.value)); });
        if (edit) {
            $('ffTitle').value = data.title;
            $('ffTier').value = data.priority_tier;
            $('ffStart').value = data.start_date || '';
            $('ffTarget').value = data.target_date || '';
            $('ffBudget').value = data.allocated_budget;
            $('ffProgress').value = data.progress_pct;
            $('ffDesc').value = data.description;
        } else { $('ffTier').value = 'Medium'; }
        $('ffProjectSearch').value = ''; filterProjects(); updateCount();
        modal.classList.add('is-open'); $('ffTitle').focus();
    }

    // Closing the edit form that was opened from the detail page goes back to that page.
    function closeModal(m) {
        m.classList.remove('is-open');
        if (m === modal && $('flagshipReturn').value === 'view' && $('flagshipId').value) {
            location.href = '/modules/flagship_view.php?id=' + encodeURIComponent($('flagshipId').value);
        }
    }

    $('addFlagshipBtn')?.addEventListener('click', () => openForm(null));
    document.querySelectorAll('[data-close]').forEach(b => b.addEventListener('click', () => closeModal($(b.dataset.close))));
    document.querySelectorAll('.fl-modal').forEach(m => m.addEventListener('click', e => { if (e.target === m) closeModal(m); }));
    document.addEventListener('keydown', e => { if (e.key === 'Escape') document.querySelectorAll('.fl-modal.is-open').forEach(closeModal); });
    $('ffProjectSearch').addEventListener('input', filterProjects);
    $('ffProjectList').addEventListener('change', updateCount);

    // Opened from the flagship detail page: flagships.php?edit=ID
    const editId = parseInt(new URLSearchParams(location.search).get('edit'), 10);
    if (editId && editPayloads[editId]) openForm(editPayloads[editId], true);
})();
</script>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
