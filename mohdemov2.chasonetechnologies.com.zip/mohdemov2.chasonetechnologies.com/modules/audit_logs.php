<?php
/**
 * Admin-only audit history.
 */
require_once __DIR__ . '/../config/db.php';
if (!function_exists('e')) { function e($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); } }
if (!function_exists('url')) { function url(string $path = ''): string { return '/modules/' . ltrim($path, '/'); } }
if (!function_exists('getDBConnection')) { function getDBConnection(): PDO { global $pdo; if (!$pdo) throw new RuntimeException('Database connection is unavailable.'); return $pdo; } }
if (!function_exists('getCurrentUser')) { function getCurrentUser(): array { return get_current_user_data(); } }
if (!function_exists('requireAuth')) { function requireAuth(): void { require_auth(); } }
if (!function_exists('getCSRFToken')) { function getCSRFToken(): string { return get_csrf_token(); } }
if (!function_exists('verifyCSRFToken')) { function verifyCSRFToken(?string $token): bool { return verify_csrf_token($token); } }

requireAuth();
$currentUser = getCurrentUser();
if (!is_admin()) {
    http_response_code(403);
    exit('Administrator access is required to view audit logs.');
}

$db = getDBConnection();
ensure_audit_log_schema($db);
$archiveCheck=$db->prepare("SELECT 1 FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name='audit_logs_archive'");
$archiveCheck->execute();$hasAuditArchive=(bool)$archiveCheck->fetchColumn();
$auditSource=$hasAuditArchive?'(SELECT * FROM audit_logs UNION ALL SELECT * FROM audit_logs_archive) AS audit_all':'audit_logs';
$page_title = 'Audit Logs';
$active_tab = 'administration';
$adminCurrentTab = 'audit';
$perPage = 50;
$page = max(1, (int)($_GET['page'] ?? 1));
$search = trim((string)($_GET['q'] ?? ''));
$moduleFilter = trim((string)($_GET['module'] ?? ''));
$actionFilter = trim((string)($_GET['action'] ?? ''));
$userFilter = trim((string)($_GET['user'] ?? ''));
$severityFilter = strtoupper(trim((string)($_GET['severity'] ?? '')));
$projectFilter = max(0, (int)($_GET['project_id'] ?? 0));
$fromDate = trim((string)($_GET['from'] ?? ''));
$toDate = trim((string)($_GET['to'] ?? ''));

$validDate = static function (string $value): bool {
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) return false;
    $parsed = DateTimeImmutable::createFromFormat('!Y-m-d', $value);
    return $parsed !== false && $parsed->format('Y-m-d') === $value;
};
if (!$validDate($fromDate)) $fromDate = '';
if (!$validDate($toDate)) $toDate = '';

$where = [];
$params = [];
if ($search !== '') {
    $where[] = '(user_name LIKE :search_user OR module LIKE :search_module OR action LIKE :search_action OR details LIKE :search_description OR ip_address LIKE :search_ip OR user_agent LIKE :search_agent OR metadata LIKE :search_metadata OR user_role LIKE :search_role)';
    $searchTerm = '%' . $search . '%';
    $params[':search_user'] = $searchTerm;
    $params[':search_module'] = $searchTerm;
    $params[':search_action'] = $searchTerm;
    $params[':search_description'] = $searchTerm;
    $params[':search_ip'] = $searchTerm;
    $params[':search_agent'] = $searchTerm;
    $params[':search_metadata'] = $searchTerm;
    $params[':search_role'] = $searchTerm;
}
if ($moduleFilter !== '') {
    $where[] = 'module = :module';
    $params[':module'] = $moduleFilter;
}
if ($actionFilter !== '') {
    $where[] = 'action = :action';
    $params[':action'] = $actionFilter;
}
if ($userFilter !== '') {
    $where[] = 'user_name LIKE :user';
    $params[':user'] = '%' . $userFilter . '%';
}
if (in_array($severityFilter,['INFO','WARNING','CRITICAL'],true)) {
    $where[] = 'severity = :severity';
    $params[':severity'] = $severityFilter;
}
if ($projectFilter > 0) {
    $where[] = 'project_id = :project_id';
    $params[':project_id'] = $projectFilter;
}
if ($fromDate !== '') {
    $where[] = 'created_at >= :from_date';
    $params[':from_date'] = $fromDate . ' 00:00:00';
}
if ($toDate !== '') {
    $exclusiveEnd = (new DateTimeImmutable($toDate))->modify('+1 day')->format('Y-m-d');
    $where[] = 'created_at < :to_date';
    $params[':to_date'] = $exclusiveEnd . ' 00:00:00';
}
$whereSql = $where ? ' WHERE ' . implode(' AND ', $where) : '';

if (in_array(($_GET['export'] ?? ''), ['csv','print'], true)) {
    $export = $db->prepare('SELECT created_at,user_name,user_id,user_role,module,action,severity,record_id,project_id,details,reason,ip_address,user_agent,metadata FROM '.$auditSource.$whereSql.' ORDER BY created_at DESC,id DESC LIMIT 100000');
    $export->execute($params);
    if (($_GET['export'] ?? '') === 'csv') {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="audit-logs-' . date('Y-m-d') . '.csv"');
        $out = fopen('php://output','w');
        fputcsv($out,['Timestamp','User','User ID','Role','Module','Action','Severity','Record ID','Project ID','Details','Reason','IP Address','User Agent','Metadata']);
        while($record=$export->fetch(PDO::FETCH_ASSOC)) fputcsv($out,$record);
        fclose($out); exit;
    }
    header('Content-Type: text/html; charset=utf-8');
    $printRows=$export->fetchAll(PDO::FETCH_ASSOC);
    $printEsc=static fn($v)=>htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');
    echo '<!doctype html><html><head><meta charset="utf-8"><title>Audit log report</title><style>body{font:12px Arial,sans-serif;margin:22px;color:#111}h1{font-size:20px}.tools{margin:12px 0}@media print{.tools{display:none}body{margin:8mm}table{font-size:9px}}table{width:100%;border-collapse:collapse}th,td{border:1px solid #bbb;padding:5px;text-align:left;vertical-align:top}th{background:#eee}</style></head><body><h1>PP-SDOMS Audit Log Report</h1><p>Generated '.date('d M Y H:i').' · '.count($printRows).' records matching active filters</p><div class="tools"><button onclick="window.print()">Print / Save as PDF</button></div><table><thead><tr><th>Timestamp</th><th>User</th><th>Role</th><th>Module / Action</th><th>Severity</th><th>Record / Project</th><th>Details / Reason / Changes</th><th>IP</th></tr></thead><tbody>';
    foreach($printRows as $record) echo '<tr><td>'.$printEsc($record['created_at']).'</td><td>'.$printEsc($record['user_name']).'</td><td>'.$printEsc($record['user_role']).'</td><td>'.$printEsc($record['module'].' / '.$record['action']).'</td><td>'.$printEsc($record['severity']).'</td><td>'.$printEsc($record['record_id'].' / '.$record['project_id']).'</td><td>'.$printEsc($record['details'].' '.$record['reason'].' '.$record['metadata']).'</td><td>'.$printEsc($record['ip_address']).'</td></tr>';
    echo '</tbody></table></body></html>'; exit;
}

$countStmt = $db->prepare('SELECT COUNT(*) FROM '.$auditSource . $whereSql);
$countStmt->execute($params);
$totalRows = (int)$countStmt->fetchColumn();
$totalPages = max(1, (int)ceil($totalRows / $perPage));
$page = min($page, $totalPages);
$offset = ($page - 1) * $perPage;

$logStmt = $db->prepare("
    SELECT id,user_id,user_role,severity,project_id,metadata,reason,user_name AS username,action,module,record_id AS entity_id,details AS description,ip_address,user_agent,created_at
    FROM {$auditSource}
    {$whereSql}
    ORDER BY created_at DESC, id DESC
    LIMIT :limit OFFSET :offset
");
foreach ($params as $key => $value) $logStmt->bindValue($key, $value, PDO::PARAM_STR);
$logStmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
$logStmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$logStmt->execute();
$auditRows = $logStmt->fetchAll();

$modules = $db->query("SELECT DISTINCT module FROM {$auditSource} WHERE module <> '' ORDER BY module")->fetchAll(PDO::FETCH_COLUMN);
$actions = $db->query("SELECT DISTINCT action FROM {$auditSource} WHERE action <> '' ORDER BY action")->fetchAll(PDO::FETCH_COLUMN);
$projects = $db->query("SELECT id, sub_programme FROM projects ORDER BY sub_programme")->fetchAll(PDO::FETCH_ASSOC);

$pageUrl = static function (int $targetPage): string {
    $query = [
        'q' => trim((string)($_GET['q'] ?? '')),
        'module' => trim((string)($_GET['module'] ?? '')),
        'action' => trim((string)($_GET['action'] ?? '')),
        'user' => trim((string)($_GET['user'] ?? '')),
        'from' => trim((string)($_GET['from'] ?? '')),
        'to' => trim((string)($_GET['to'] ?? '')),
        'severity' => trim((string)($_GET['severity'] ?? '')),
        'project_id' => (int)($_GET['project_id'] ?? 0),
        'page' => $targetPage,
    ];
    return url('audit_logs.php?' . http_build_query(array_filter($query, static fn($value) => $value !== '')));
};
$exportQuery = array_filter([
    'q'=>$search,'module'=>$moduleFilter,'action'=>$actionFilter,'user'=>$userFilter,
    'from'=>$fromDate,'to'=>$toDate,'severity'=>$severityFilter,'project_id'=>$projectFilter,
],static fn($value)=>$value!==''&&$value!==0);
$exportCsvUrl = url('audit_logs.php?'.http_build_query($exportQuery+['export'=>'csv']));
$exportPrintUrl = url('audit_logs.php?'.http_build_query($exportQuery+['export'=>'print']));

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/admin_tabs.php';
?>

<main class="module-page">
  <div class="module-page-head">
    <div>
      <h2 class="module-page-title">Audit Logs</h2>
      <p class="module-page-description">Administrator-only history of module visits and recorded changes.</p>
    </div>
  </div>

  <section class="module-summary-grid" aria-label="Audit log summary">
    <a class="module-summary-card" href="#auditResults" title="View the matching records">
      <div class="module-summary-label">Matching records</div>
      <div class="module-summary-value"><?php echo number_format($totalRows); ?></div>
      <div class="module-summary-hint">View matching records &rarr;</div>
    </a>
    <div class="module-summary-card">
      <div class="module-summary-label">Showing page</div>
      <div class="module-summary-value"><?php echo $page; ?> / <?php echo $totalPages; ?></div>
    </div>
    <div class="module-summary-card">
      <div class="module-summary-label">Rows per page</div>
      <div class="module-summary-value"><?php echo $perPage; ?></div>
    </div>
  </section>

  <section class="module-panel" aria-label="Filter and review audit records">
    <form class="audit-filter-form" method="get" action="<?php echo e(url('audit_logs.php')); ?>">
      <div class="module-form-field audit-search-field">
        <label for="auditSearch">Search logs</label>
        <input class="module-search" id="auditSearch" name="q" value="<?php echo e($search); ?>" placeholder="User, action, module, IP or description">
      </div>
      <div class="module-form-field">
        <label for="auditModule">Module</label>
        <select class="module-select" id="auditModule" name="module">
          <option value="">All modules</option>
          <?php foreach ($modules as $module): ?><option value="<?php echo e((string)$module); ?>" <?php echo $moduleFilter === (string)$module ? 'selected' : ''; ?>><?php echo e((string)$module); ?></option><?php endforeach; ?>
        </select>
      </div>
      <div class="module-form-field">
        <label for="auditAction">Action</label>
        <select class="module-select" id="auditAction" name="action">
          <option value="">All actions</option>
          <?php foreach ($actions as $action): ?><option value="<?php echo e((string)$action); ?>" <?php echo $actionFilter === (string)$action ? 'selected' : ''; ?>><?php echo e((string)$action); ?></option><?php endforeach; ?>
        </select>
      </div>
      <div class="module-form-field">
        <label for="auditUser">User</label>
        <input class="module-input" id="auditUser" name="user" value="<?php echo e($userFilter); ?>" placeholder="Name contains…">
      </div>
      <div class="module-form-field">
        <label for="auditSeverity">Severity</label>
        <select class="module-select" id="auditSeverity" name="severity">
          <option value="">All severities</option>
          <?php foreach (['INFO','WARNING','CRITICAL'] as $severity): ?><option value="<?php echo e($severity); ?>" <?php echo $severityFilter===$severity?'selected':''; ?>><?php echo e($severity); ?></option><?php endforeach; ?>
        </select>
      </div>
      <div class="module-form-field">
        <label for="auditProject">Project</label>
        <select class="module-select" id="auditProject" name="project_id">
          <option value="">All projects</option>
          <?php foreach ($projects as $project): ?><option value="<?php echo (int)$project['id']; ?>" <?php echo $projectFilter===(int)$project['id']?'selected':''; ?>><?php echo e((string)$project['sub_programme']); ?></option><?php endforeach; ?>
        </select>
      </div>
      <div class="module-form-field">
        <label for="auditFrom">From date</label>
        <input class="module-input" id="auditFrom" name="from" type="date" value="<?php echo e($fromDate); ?>">
      </div>
      <div class="module-form-field">
        <label for="auditTo">To date</label>
        <input class="module-input" id="auditTo" name="to" type="date" value="<?php echo e($toDate); ?>">
      </div>
      <div class="audit-filter-actions">
        <button class="module-btn module-btn-primary" type="submit">Apply filters</button>
        <a class="module-btn" href="<?php echo e(url('audit_logs.php')); ?>">Clear</a>
        <a class="module-btn" href="<?php echo e($exportCsvUrl); ?>">Export CSV / Excel</a>
        <a class="module-btn" href="<?php echo e($exportPrintUrl); ?>" target="_blank" rel="noopener">Print / Save PDF</a>
      </div>
    </form>

    <div class="module-table-wrap audit-table-wrap" id="auditResults">
      <table class="module-table audit-table">
        <thead>
          <tr>
            <th>Date</th>
            <th>Time</th>
            <th>User</th>
            <th>Module</th>
            <th>Action</th>
            <th>Severity</th>
            <th>Record</th>
            <th>Project</th>
            <th>What happened</th>
            <th>IP address</th>
            <th>User agent</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($auditRows as $row): ?>
            <?php
              $timestamp = (string)($row['created_at'] ?? '');
              $dateTs = strtotime($timestamp);
              $datePart = $dateTs ? date('d M Y', $dateTs) : $timestamp;
              $timePart = strlen($timestamp) >= 19 ? substr($timestamp, 11, 8) : '';
            ?>
            <tr>
              <td><?php echo e($datePart); ?></td>
              <td class="audit-time"><?php echo e($timePart); ?></td>
              <td>
                <strong><?php echo e((string)$row['username']); ?></strong>
                <?php if (!empty($row['user_id'])): ?><small class="audit-user-id">User #<?php echo (int)$row['user_id']; ?></small><?php endif; ?>
                <?php if (!empty($row['user_role'])): ?><small class="audit-user-id"><?php echo e((string)$row['user_role']); ?></small><?php endif; ?>
              </td>
              <td><span class="module-status"><?php echo e((string)$row['module']); ?></span></td>
              <td><?php echo e(str_replace('_', ' ', (string)$row['action'])); ?></td>
              <td><?php echo e((string)($row['severity'] ?? 'INFO')); ?></td>
              <td><?php echo $row['entity_id'] !== null ? '#' . (int)$row['entity_id'] : '—'; ?></td>
              <td><?php echo $row['project_id'] ? '#'.(int)$row['project_id'] : '—'; ?></td>
              <td class="audit-description"><?php echo e((string)$row['description']); ?><?php if(!empty($row['reason'])): ?><br><strong>Reason:</strong> <?php echo e((string)$row['reason']); ?><?php endif; ?><?php if(!empty($row['metadata'])): ?><details><summary>View change details</summary><pre style="white-space:pre-wrap;max-width:420px;max-height:260px;overflow:auto"><?php echo e((string)$row['metadata']); ?></pre></details><?php endif; ?></td>
              <td class="audit-ip"><?php echo e((string)($row['ip_address'] ?? '—')); ?></td>
              <td><?php echo e((string)($row['user_agent'] ?? '—')); ?></td>
            </tr>
          <?php endforeach; ?>
          <?php if (!$auditRows): ?><tr><td colspan="11" class="module-empty">No audit records match these filters.</td></tr><?php endif; ?>
        </tbody>
      </table>
    </div>

    <div class="audit-pagination" aria-label="Audit log pages">
      <span>Showing <?php echo $totalRows ? ($offset + 1) : 0; ?>–<?php echo min($offset + count($auditRows), $totalRows); ?> of <?php echo number_format($totalRows); ?></span>
      <div>
        <?php if ($page > 1): ?><a class="module-btn module-btn-small" href="<?php echo e($pageUrl($page - 1)); ?>">Previous</a><?php endif; ?>
        <?php if ($page < $totalPages): ?><a class="module-btn module-btn-small" href="<?php echo e($pageUrl($page + 1)); ?>">Next</a><?php endif; ?>
      </div>
    </div>
    <p class="audit-privacy-note">Audit entries include the actor, module, action, record ID, changed field names, and request IP. Submitted field values and passwords are not copied into new audit entries.</p>
  </section>
</main>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
