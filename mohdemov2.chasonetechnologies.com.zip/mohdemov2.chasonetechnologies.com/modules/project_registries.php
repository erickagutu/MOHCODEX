<?php
require_once __DIR__ . '/../config/db.php';
require_auth();
$page_title='Project Registries — State Department for Medical Services'; $active_tab='projects';
if(!can_edit()){http_response_code(403);exit('You do not have permission to manage project registries.');}
if(!$db_connected||!$pdo){http_response_code(503);exit('The database connection is unavailable.');}
$error=''; $notice=isset($_GET['saved']) ? ('Registry record '.(string)$_GET['saved'].'.') : ''; $deliveryReady=false;
try{$deliveryReady=(bool)$pdo->query("SHOW COLUMNS FROM delivery_units LIKE 'delivery_init__id'")->fetch(PDO::FETCH_ASSOC);}catch(Throwable $e){error_log($e->getMessage());}
if($_SERVER['REQUEST_METHOD']==='POST'){
 if(!verify_csrf_token($_POST['csrf_token']??'')){http_response_code(403);exit('Invalid security token.');}
 $entity=(string)($_POST['entity']??'');$op=(string)($_POST['operation']??'');$id=trim((string)($_POST['id']??''));$name=trim((string)($_POST['name']??''));$code=strtoupper(trim((string)($_POST['code']??'')));$description=trim((string)($_POST['description']??''));$head=trim((string)($_POST['head']??''));$directorateId=(int)($_POST['directorate_id']??0);
 try{
  if(!in_array($entity,['sagas','directorates','divisions','delivery_units'],true)||!in_array($op,['create','update','delete'],true))throw new InvalidArgumentException('Invalid registry action.');
  if($entity==='delivery_units'&&!$deliveryReady)throw new RuntimeException('Apply the delivery units database migration first.');
  if($op!=='delete'&&($name===''||mb_strlen($name)>($entity==='divisions'?200:150)))throw new InvalidArgumentException('Enter a valid name.');
  if($op!=='delete'&&$entity!=='divisions'&&($code===''||mb_strlen($code)>20))throw new InvalidArgumentException('Enter a code up to 20 characters.');
  if($op==='create'){
   if($entity==='sagas'){$q=$pdo->prepare('INSERT INTO sagas(name,code,description) VALUES(?,?,?)');$q->execute([$name,$code,$description?:null]);$id=(string)$pdo->lastInsertId();}
   elseif($entity==='directorates'){$q=$pdo->prepare('INSERT INTO directorates(name,code,head,description) VALUES(?,?,?,?)');$q->execute([$name,$code,$head?:null,$description?:null]);$id=(string)$pdo->lastInsertId();}
   elseif($entity==='divisions'){$q=$pdo->prepare('SELECT 1 FROM directorates WHERE id=?');$q->execute([$directorateId]);if(!$q->fetchColumn())throw new InvalidArgumentException('Choose a valid directorate.');$q=$pdo->prepare('INSERT INTO divisions(directorate_id,name) VALUES(?,?)');$q->execute([$directorateId,$name]);$id=(string)$pdo->lastInsertId();}
   else{$id=(string)$pdo->query('SELECT COALESCE(MAX(CAST(delivery_init__id AS UNSIGNED)),0)+1 FROM delivery_units')->fetchColumn();$q=$pdo->prepare('INSERT INTO delivery_units(delivery_init__id,name,code,description) VALUES(?,?,?,?)');$q->execute([$id,$name,$code,$description?:null]);}
  }elseif($op==='update'){
   if($id==='')throw new InvalidArgumentException('Select a record to update.');
   if($entity==='sagas'){$q=$pdo->prepare('SELECT name FROM sagas WHERE id=?');$q->execute([$id]);$old=$q->fetchColumn();if($old===false)throw new RuntimeException('SAGA not found.');$pdo->beginTransaction();$pdo->prepare('UPDATE sagas SET name=?,code=?,description=? WHERE id=?')->execute([$name,$code,$description?:null,$id]);if($old!==$name)$pdo->prepare('UPDATE projects SET saga_name=? WHERE saga_name=?')->execute([$name,$old]);$pdo->commit();}
   elseif($entity==='directorates'){$q=$pdo->prepare('SELECT name FROM directorates WHERE id=?');$q->execute([$id]);$old=$q->fetchColumn();if($old===false)throw new RuntimeException('Directorate not found.');$pdo->beginTransaction();$pdo->prepare('UPDATE directorates SET name=?,code=?,head=?,description=? WHERE id=?')->execute([$name,$code,$head?:null,$description?:null,$id]);if($old!==$name)$pdo->prepare('UPDATE projects SET directorate_name=? WHERE directorate_name=?')->execute([$name,$old]);$pdo->commit();}
   elseif($entity==='divisions'){$q=$pdo->prepare('SELECT name FROM directorates WHERE id=?');$q->execute([$directorateId]);$newDir=$q->fetchColumn();if($newDir===false)throw new InvalidArgumentException('Choose a valid directorate.');$q=$pdo->prepare('SELECT d.name,dir.name AS old_dir FROM divisions d JOIN directorates dir ON dir.id=d.directorate_id WHERE d.id=?');$q->execute([$id]);$old=$q->fetch(PDO::FETCH_ASSOC);if(!$old)throw new RuntimeException('Division not found.');$pdo->beginTransaction();$pdo->prepare('UPDATE divisions SET directorate_id=?,name=? WHERE id=?')->execute([$directorateId,$name,$id]);$pdo->prepare('UPDATE projects SET division_name=?,directorate_name=? WHERE division_name=? AND directorate_name=?')->execute([$name,$newDir,$old['name'],$old['old_dir']]);$pdo->commit();}
   else{$q=$pdo->prepare('SELECT name FROM delivery_units WHERE delivery_init__id=?');$q->execute([$id]);$old=$q->fetchColumn();if($old===false)throw new RuntimeException('Delivery unit not found.');$pdo->beginTransaction();$pdo->prepare('UPDATE delivery_units SET name=?,code=?,description=? WHERE delivery_init__id=?')->execute([$name,$code,$description?:null,$id]);if($old!==$name)$pdo->prepare('UPDATE projects SET delivery_unit=? WHERE delivery_unit=?')->execute([$name,$old]);$pdo->commit();}
  }else{
   if($entity==='sagas'){$q=$pdo->prepare('SELECT name FROM sagas WHERE id=?');$q->execute([$id]);$old=$q->fetchColumn();if($old===false)throw new RuntimeException('SAGA not found.');$q=$pdo->prepare('SELECT COUNT(*) FROM projects WHERE saga_name=?');$q->execute([$old]);if((int)$q->fetchColumn())throw new RuntimeException('Reassign projects using this SAGA before deleting it.');$pdo->prepare('DELETE FROM sagas WHERE id=?')->execute([$id]);}
   elseif($entity==='directorates'){$q=$pdo->prepare('SELECT name FROM directorates WHERE id=?');$q->execute([$id]);$old=$q->fetchColumn();if($old===false)throw new RuntimeException('Directorate not found.');$q=$pdo->prepare('SELECT (SELECT COUNT(*) FROM divisions WHERE directorate_id=?) + (SELECT COUNT(*) FROM projects WHERE directorate_name=?)');$q->execute([$id,$old]);if((int)$q->fetchColumn())throw new RuntimeException('Remove or reassign its divisions and projects before deleting it.');$pdo->prepare('DELETE FROM directorates WHERE id=?')->execute([$id]);}
   elseif($entity==='divisions'){$q=$pdo->prepare('SELECT d.name,dir.name AS dir_name FROM divisions d JOIN directorates dir ON dir.id=d.directorate_id WHERE d.id=?');$q->execute([$id]);$old=$q->fetch(PDO::FETCH_ASSOC);if(!$old)throw new RuntimeException('Division not found.');$q=$pdo->prepare('SELECT COUNT(*) FROM projects WHERE division_name=? AND directorate_name=?');$q->execute([$old['name'],$old['dir_name']]);if((int)$q->fetchColumn())throw new RuntimeException('Reassign projects using this division before deleting it.');$pdo->prepare('DELETE FROM divisions WHERE id=?')->execute([$id]);}
   else{$q=$pdo->prepare('SELECT name FROM delivery_units WHERE delivery_init__id=?');$q->execute([$id]);$old=$q->fetchColumn();if($old===false)throw new RuntimeException('Delivery unit not found.');$q=$pdo->prepare('SELECT COUNT(*) FROM projects WHERE delivery_unit=?');$q->execute([$old]);if((int)$q->fetchColumn())throw new RuntimeException('Reassign projects using this delivery unit before deleting it.');$pdo->prepare('DELETE FROM delivery_units WHERE delivery_init__id=?')->execute([$id]);}
  }
  log_audit_trail(strtoupper($op),'Project Registries',$entity.':'.$id,$op.' registry record');
  header('Location: project_registries.php?saved='.urlencode($op==='delete'?'deleted':($op==='create'?'added':'updated')).'&tab='.urlencode($entity)); exit;
 }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();error_log('Project registry CRUD failed: '.$e->getMessage());$error=$e instanceof InvalidArgumentException||$e instanceof RuntimeException?$e->getMessage():'Could not save this record. Check for duplicate names or codes.';}
}
$sagas=$directorates=$divisions=$deliveryUnits=[];
try{$sagas=$pdo->query('SELECT id,name,code,description FROM sagas ORDER BY name')->fetchAll(PDO::FETCH_ASSOC);$directorates=$pdo->query('SELECT id,name,code,head,description FROM directorates ORDER BY name')->fetchAll(PDO::FETCH_ASSOC);$divisions=$pdo->query('SELECT d.id,d.directorate_id,d.name,dir.name AS directorate_name FROM divisions d JOIN directorates dir ON dir.id=d.directorate_id ORDER BY dir.name,d.name')->fetchAll(PDO::FETCH_ASSOC);if($deliveryReady)$deliveryUnits=$pdo->query('SELECT delivery_init__id,name,code,description FROM delivery_units ORDER BY name')->fetchAll(PDO::FETCH_ASSOC);}catch(Throwable $e){error_log('Registry list load failed: '.$e->getMessage());if($error==='')$error='Could not load all registry records.';}
$esc=static fn($v):string=>htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');
?>
<?php require_once __DIR__ . '/../includes/header.php'; ?>
<style>.rg-tabs{display:flex;gap:7px;flex-wrap:wrap;border-bottom:1px solid #dbe3ed;margin:14px 0}.rg-tabs a{display:inline-flex;align-items:center;gap:5px;border:1px solid #cbd5e1;border-bottom:0;background:#f1f5f9;color:#475569;text-decoration:none;padding:9px 14px;border-radius:7px 7px 0 0;font-weight:800;font-size:.78rem}.rg-tabs a[aria-selected=true]{background:#1d4ed8;color:#fff;border-color:#1d4ed8}.rg-tabs a:focus-visible{outline:2px solid #60a5fa;outline-offset:2px}.rg-panel[hidden]{display:none}.rg{display:grid;grid-template-columns:minmax(0,1fr);gap:14px}.rg section{background:#fff;border:1px solid #dce4ef;border-radius:9px;padding:14px;min-width:0}.rg h2{font-size:1rem;color:#102c53;margin:0 0 10px}.rg form{display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:7px;margin:0 0 10px}.rg label{font-size:.68rem;font-weight:700;color:#475569}.rg input,.rg select,.rg textarea{box-sizing:border-box;width:100%;padding:7px;border:1px solid #cbd5e1;border-radius:5px;font:inherit;margin-top:3px}.rg button{border:0;border-radius:5px;padding:6px 9px;font-size:.7rem;font-weight:800;cursor:pointer}.rg .save{background:#1d4ed8;color:white}.rg .del{background:#fee2e2;color:#991b1b}.rg-table-tools{display:flex;align-items:end;gap:10px;flex-wrap:wrap;margin:12px 0}.rg-table-tools label{flex:1;min-width:220px}.rg-table-tools button{background:#eff6ff;color:#1d4ed8;border:1px solid #bfdbfe}.rg-table-tools .row-count{font-size:.72rem;color:#64748b}.rg table{border-collapse:collapse;width:100%;min-width:390px;font-size:.73rem}.rg th,.rg td{text-align:left;padding:7px;border-bottom:1px solid #e2e8f0;vertical-align:top}.rg th{background:#f1f5f9}.rg summary{cursor:pointer;color:#1d4ed8;font-weight:800}.rg .scroll{overflow:auto}</style>
<h1 style="margin:0;color:#0f2f59;font-size:1.4rem">Project Registries</h1><p style="margin:5px 0 16px;color:#64748b;font-size:.84rem">Manage SAGAs, directorates, divisions and delivery units used in the project portfolio. <a href="projects.php">Back to projects</a></p>
<?php if($notice):?><div role="status" style="padding:9px;margin-bottom:10px;background:#dcfce7;color:#166534"><?=$esc($notice)?></div><?php endif;?>
<?php if($error):?><div role="alert" style="padding:9px;margin-bottom:10px;background:#fee2e2;color:#991b1b"><?=$esc($error)?></div><?php endif;?>
<?php if(!$deliveryReady):?><p style="padding:9px;background:#fef3c7;color:#92400e">Apply database/migrations/20261104_delivery_units_from_sagas.sql before managing delivery units.</p><?php endif;?>
<?php
$registryDefs=[
 ['entity'=>'sagas','title'=>'SAGAs','rows'=>$sagas,'has_code'=>true,'has_head'=>false,'has_description'=>true],
 ['entity'=>'directorates','title'=>'Directorates','rows'=>$directorates,'has_code'=>true,'has_head'=>true,'has_description'=>true],
 ['entity'=>'divisions','title'=>'Divisions','rows'=>$divisions,'has_code'=>false,'has_head'=>false,'has_description'=>false],
 ['entity'=>'delivery_units','title'=>'Delivery Units','rows'=>$deliveryUnits,'has_code'=>true,'has_head'=>false,'has_description'=>true],
];
$tabIds=array_column($registryDefs,'entity');$activeRegistryTab=(string)($_GET['tab']??'directorates');if(!in_array($activeRegistryTab,$tabIds,true)||($activeRegistryTab==='delivery_units'&&!$deliveryReady))$activeRegistryTab='directorates';
?>
<div class="rg-tabs" role="tablist" aria-label="Project registries">
<?php foreach($registryDefs as $def): if($def['entity']==='delivery_units'&&!$deliveryReady)continue; $selected=$activeRegistryTab===$def['entity']; ?>
<a role="tab" id="tab-<?=$esc($def['entity'])?>" href="project_registries.php?tab=<?=$esc($def['entity'])?>" aria-controls="panel-<?=$esc($def['entity'])?>" aria-selected="<?=$selected?'true':'false'?>" aria-current="<?=$selected?'page':'false'?>"><?=$esc($def['title'])?> <span>(<?=count($def['rows'])?>)</span></a>
<?php endforeach; ?>
</div>
<?php foreach($registryDefs as $def): if($def['entity']==='delivery_units'&&!$deliveryReady)continue; $selected=$activeRegistryTab===$def['entity']; ?>
<div class="rg-panel" role="tabpanel" id="panel-<?=$esc($def['entity'])?>" aria-labelledby="tab-<?=$esc($def['entity'])?>" <?=$selected?'':'hidden'?>>
<div class="rg"><section><h2><?=$esc($def['title'])?> (<?=count($def['rows'])?>)</h2>
<form method="post"><input type="hidden" name="csrf_token" value="<?=$esc(get_csrf_token())?>"><input type="hidden" name="entity" value="<?=$esc($def['entity'])?>"><input type="hidden" name="operation" value="create">
<?php if($def['entity']==='divisions'):?><label>Directorate<select name="directorate_id" required><option value="">Select</option><?php foreach($directorates as $d):?><option value="<?=(int)$d['id']?>"><?=$esc($d['name'])?></option><?php endforeach;?></select></label><?php endif;?>
<label>Name<input name="name" maxlength="<?=$def['entity']==='divisions'?200:150?>" required></label>
<?php if($def['has_code']):?><label>Code<input name="code" maxlength="20" required></label><?php endif;?>
<?php if($def['has_head']):?><label>Head<input name="head" maxlength="100"></label><?php endif;?>
<?php if($def['has_description']):?><label style="grid-column:1/-1">Description<textarea name="description" rows="2"></textarea></label><?php endif;?>
<button class="save">Add</button></form>
<div class="rg-table-tools"><label>Search this tab<input type="search" data-registry-search placeholder="Search name, code, directorate..."></label><span class="row-count" data-registry-count aria-live="polite"></span><button type="button" data-registry-more>Load more</button></div>
<div class="scroll"><table><thead><tr><th>Name / code</th><th>Actions</th></tr></thead><tbody>
<?php foreach($def['rows'] as $r): $rowId=$def['entity']==='delivery_units'?$r['delivery_init__id']:$r['id']; ?>
<tr data-registry-row><td><strong><?=$esc($r['name'])?></strong><?php if($def['has_code']):?><br><small><?=$esc($r['code'])?></small><?php endif;?><?php if($def['entity']==='divisions'):?><br><small><?=$esc($r['directorate_name'])?></small><?php endif;?></td><td>
<details><summary>Edit</summary><form method="post"><input type="hidden" name="csrf_token" value="<?=$esc(get_csrf_token())?>"><input type="hidden" name="entity" value="<?=$esc($def['entity'])?>"><input type="hidden" name="operation" value="update"><input type="hidden" name="id" value="<?=$esc($rowId)?>">
<?php if($def['entity']==='divisions'):?><label>Directorate<select name="directorate_id" required><?php foreach($directorates as $d):?><option value="<?=(int)$d['id']?>" <?=(int)$d['id']===(int)$r['directorate_id']?'selected':''?>><?=$esc($d['name'])?></option><?php endforeach;?></select></label><?php endif;?>
<label>Name<input name="name" maxlength="<?=$def['entity']==='divisions'?200:150?>" required value="<?=$esc($r['name'])?>"></label>
<?php if($def['has_code']):?><label>Code<input name="code" maxlength="20" required value="<?=$esc($r['code'])?>"></label><?php endif;?>
<?php if($def['has_head']):?><label>Head<input name="head" maxlength="100" value="<?=$esc($r['head'])?>"></label><?php endif;?>
<?php if($def['has_description']):?><label style="grid-column:1/-1">Description<textarea name="description" rows="2"><?=$esc($r['description'])?></textarea></label><?php endif;?>
<button class="save">Save</button></form></details>
<form method="post" onsubmit="return confirm('Delete this registry record?')"><input type="hidden" name="csrf_token" value="<?=$esc(get_csrf_token())?>"><input type="hidden" name="entity" value="<?=$esc($def['entity'])?>"><input type="hidden" name="operation" value="delete"><input type="hidden" name="id" value="<?=$esc($rowId)?>"><button class="del">Delete</button></form>
</td></tr><?php endforeach;?>
</tbody></table></div></section></div></div>
<?php endforeach;?>
<script>(()=>{const batch=25;document.querySelectorAll('.rg-panel').forEach(panel=>{const rows=[...panel.querySelectorAll('[data-registry-row]')],search=panel.querySelector('[data-registry-search]'),more=panel.querySelector('[data-registry-more]'),count=panel.querySelector('[data-registry-count]');let limit=batch,visible=rows;const render=()=>{rows.forEach(r=>r.hidden=true);visible.slice(0,limit).forEach(r=>r.hidden=false);count.textContent=visible.length?'Showing '+Math.min(limit,visible.length)+' of '+visible.length+' records':'No matching records';more.hidden=visible.length<=limit;};search.addEventListener('input',()=>{const q=search.value.trim().toLocaleLowerCase();visible=rows.filter(r=>!q||r.textContent.toLocaleLowerCase().includes(q));limit=batch;render();});more.addEventListener('click',()=>{limit+=batch;render();});render();});})();</script>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
