<?php
require_once __DIR__ . '/../config/db.php';
require_auth();
if (!is_admin()) { http_response_code(403); exit('Administrator access is required to view system security.'); }
$page_title = 'System Security — State Department for Medical Services';
$active_tab = 'administration';
$adminCurrentTab = 'security';
$securityStats = ['users'=>0,'permissions'=>0,'two_factor'=>0,'audit_events'=>0];
$securityEvents = [];
$loadWarnings = [];
try {
    if (!$pdo) throw new RuntimeException('Database connection unavailable.');
    $securityStats['users'] = (int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
    try { $securityStats['permissions'] = (int)$pdo->query('SELECT COUNT(*) FROM user_module_permissions')->fetchColumn(); }
    catch (Throwable $e) { $loadWarnings[] = 'Module permission records are not available.'; }
    try { $securityStats['two_factor'] = (int)$pdo->query('SELECT COUNT(*) FROM user_security_settings WHERE email_2fa_enabled = 1')->fetchColumn(); }
    catch (Throwable $e) { $loadWarnings[] = 'Email verification settings have not been initialized.'; }
    try {
        $securityStats['audit_events'] = (int)$pdo->query('SELECT COUNT(*) FROM audit_logs')->fetchColumn();
        $securityEvents = $pdo->query("SELECT user_name, action, module, details, created_at FROM audit_logs WHERE UPPER(action) LIKE '%LOGIN%' OR UPPER(action) LIKE '%SECURITY%' OR UPPER(action) LIKE '%PERMISSION%' OR UPPER(action) LIKE '%ACCESS%' ORDER BY created_at DESC LIMIT 20")->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) { $loadWarnings[] = 'Audit history is unavailable.'; }
} catch (Throwable $e) { $loadWarnings[] = 'Unable to load system security status.'; }
$esc = static fn($value): string => htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/admin_tabs.php';
?>
<div style="display:flex;flex-direction:column;gap:16px;">
    <div><h2 style="margin:0;color:#0f172a;font-size:1.3rem;">System Security</h2><p style="margin:5px 0;color:#64748b;font-size:.84rem;">Review the application security controls currently available.</p></div>
    <?php foreach ($loadWarnings as $warning): ?><div role="status" style="padding:10px;background:#fffbeb;color:#92400e;border-radius:7px;font-size:.8rem;"><?=$esc($warning)?></div><?php endforeach; ?>
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:12px;">
        <section style="padding:15px;background:#fff;border:1px solid #e2e8f0;border-radius:8px;"><small style="color:#64748b;">User accounts</small><div style="font-size:1.4rem;font-weight:800;color:#0f172a;"><?=$securityStats['users']?></div><a href="users.php?tab=accounts">Manage accounts</a></section>
        <section style="padding:15px;background:#fff;border:1px solid #e2e8f0;border-radius:8px;"><small style="color:#64748b;">Module access grants</small><div style="font-size:1.4rem;font-weight:800;color:#0f172a;"><?=$securityStats['permissions']?></div><a href="users.php?tab=permissions">Review access controls</a></section>
        <section style="padding:15px;background:#fff;border:1px solid #e2e8f0;border-radius:8px;"><small style="color:#64748b;">Accounts with email verification</small><div style="font-size:1.4rem;font-weight:800;color:#0f172a;"><?=$securityStats['two_factor']?></div><a href="users.php?tab=security">Account security settings</a></section>
        <section style="padding:15px;background:#fff;border:1px solid #e2e8f0;border-radius:8px;"><small style="color:#64748b;">Recorded audit events</small><div style="font-size:1.4rem;font-weight:800;color:#0f172a;"><?=$securityStats['audit_events']?></div><a href="audit_logs.php">Open audit logs</a></section>
    </div>
    <section style="padding:16px;background:#fff;border:1px solid #e2e8f0;border-radius:8px;">
        <h3 style="margin:0 0 8px;color:#0f172a;">Security coverage</h3>
        <p style="font-size:.82rem;color:#475569;line-height:1.55;margin:0;">The application provides role-based module access, administrator-only account and permission management, CSRF-protected forms, email sign-in verification, and audit history. Vulnerability monitoring, malware scanning, and automated security alerting are not configured in this codebase.</p>
    </section>
    <section style="overflow:auto;background:#fff;border:1px solid #e2e8f0;border-radius:8px;padding:14px;">
        <h3 style="margin:0 0 10px;color:#0f172a;">Recent security and access events</h3>
        <table style="width:100%;border-collapse:collapse;font-size:.8rem;"><thead><tr style="text-align:left;background:#f8fafc;"><th style="padding:9px;">Date</th><th style="padding:9px;">User</th><th style="padding:9px;">Action</th><th style="padding:9px;">Module</th><th style="padding:9px;">Details</th></tr></thead><tbody>
        <?php if (!$securityEvents): ?><tr><td colspan="5" style="padding:12px;color:#64748b;">No matching security or access events were recorded.</td></tr><?php else: foreach ($securityEvents as $event): ?><tr style="border-top:1px solid #e2e8f0;"><td style="padding:9px;white-space:nowrap;"><?=$esc($event['created_at'])?></td><td style="padding:9px;"><?=$esc($event['user_name'])?></td><td style="padding:9px;"><?=$esc($event['action'])?></td><td style="padding:9px;"><?=$esc($event['module'])?></td><td style="padding:9px;"><?=$esc($event['details'])?></td></tr><?php endforeach; endif; ?>
        </tbody></table>
    </section>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
