<?php
/** User management, RBAC categories, and module access administration. */
require_once __DIR__ . '/../config/db.php';
require_auth();

$page_title = 'Users & RBAC — State Department for Medical Services';
$active_tab = 'administration';
$adminCurrentTab = 'users';
$currentUser = get_current_user_data();
$currentUserId = (int)($currentUser['id'] ?? $_SESSION['user_id'] ?? 0);
$isAdmin = !empty($currentUser['is_admin']) || strcasecmp((string)($currentUser['role'] ?? ''), 'Administrator') === 0;
$tab = $_GET['tab'] ?? 'accounts';
$allowedTabs = ['accounts', 'security', 'permissions'];
if (!in_array($tab, $allowedTabs, true)) $tab = 'accounts';
$notice = '';
$error = '';
$modules = [
    'dashboard' => 'Dashboard', 'flagships' => 'Priority Flagships', 'events' => 'Activities & Events',
    'actions' => 'Action Points Tracker', 'meetings' => 'Meeting Minutes', 'projects' => 'Projects & Programmes',
    'reports' => 'Reports', 'diary' => 'Diary', 'pc' => 'Performance Contract',
    'administration' => 'Administration & Security',
];
$categories = ['System Administrator', 'Executive Oversight', 'Module Manager', 'Officer', 'Read Only'];

if ($db_connected && $pdo) {
    try {
        $exists = $pdo->prepare('SELECT 1 FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ?');
        $exists->execute(['user_module_permissions']);
        $permissionsTableExisted = (bool)$exists->fetchColumn();
        $pdo->exec("CREATE TABLE IF NOT EXISTS user_module_permissions (
            user_id INT NOT NULL, module_key VARCHAR(60) NOT NULL, granted_by INT NULL,
            granted_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (user_id, module_key), INDEX idx_user_module_permissions_module (module_key)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $pdo->exec("CREATE TABLE IF NOT EXISTS user_security_settings (
            user_id INT NOT NULL PRIMARY KEY, email_2fa_enabled TINYINT(1) NOT NULL DEFAULT 0,
            updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $securityColumns = $pdo->query('SHOW COLUMNS FROM user_security_settings')->fetchAll(PDO::FETCH_COLUMN);
        if (!in_array('email_2fa_enabled', $securityColumns, true)) $pdo->exec('ALTER TABLE user_security_settings ADD COLUMN email_2fa_enabled TINYINT(1) NOT NULL DEFAULT 0');
        // Discard obsolete authenticator secrets and flags from earlier versions.
        if (in_array('totp_secret', $securityColumns, true)) $pdo->exec('UPDATE user_security_settings SET totp_secret = NULL');
        if (in_array('totp_enabled', $securityColumns, true)) $pdo->exec('UPDATE user_security_settings SET totp_enabled = 0');
        if (in_array('totp_user_opt_in', $securityColumns, true)) $pdo->exec('UPDATE user_security_settings SET totp_user_opt_in = 0');
        $userColumns = $pdo->query('SHOW COLUMNS FROM users')->fetchAll(PDO::FETCH_COLUMN);
        if (!in_array('rbac_category', $userColumns, true)) {
            $pdo->exec("ALTER TABLE users ADD COLUMN rbac_category VARCHAR(60) NOT NULL DEFAULT 'Officer'");
            $pdo->exec("UPDATE users SET rbac_category = CASE WHEN is_admin = 1 OR role = 'Administrator' THEN 'System Administrator' WHEN role LIKE '%Principal Secretary%' OR role LIKE '%Director%' THEN 'Executive Oversight' WHEN role LIKE '%Manager%' OR role LIKE '%Head%' THEN 'Module Manager' WHEN role LIKE '%Viewer%' THEN 'Read Only' ELSE 'Officer' END");
        }
        // Preserve existing access once when the permission matrix is first installed.
        if (!$permissionsTableExisted) {
            $seed = $pdo->prepare('INSERT IGNORE INTO user_module_permissions (user_id, module_key) SELECT id, ? FROM users');
            foreach ($modules as $key => $_label) $seed->execute([$key]);
        }
        $pdo->exec("INSERT IGNORE INTO user_module_permissions (user_id, module_key) SELECT DISTINCT user_id, 'administration' FROM user_module_permissions WHERE module_key IN ('users','audit_logs')");
    } catch (Throwable $e) {
        $error = 'Unable to prepare user access controls. Check database permissions and reload.';
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $db_connected && $pdo) {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) $error = 'Your session token expired. Reload and try again.';
    elseif ($tab === 'security') {
        try {
            if ($isAdmin && isset($_POST['admin_disable_2fa'])) {
                $targetId = (int)($_POST['user_id'] ?? 0);
                $pdo->prepare('UPDATE user_security_settings SET email_2fa_enabled = 0 WHERE user_id = ?')->execute([$targetId]);
                log_audit_trail('ADMIN_DISABLE_EMAIL_2FA', 'Users', $targetId, 'Administrator disabled email verification for account');
                $notice = 'Email verification is off for that account.';
            } elseif (isset($_POST['begin_email_2fa'])) {
                $code = (string)random_int(100000, 999999);
                if (send_email_verification_code((string)$currentUser['email'], (string)$currentUser['full_name'], $code)) {
                    $_SESSION['email_2fa_enrollment'] = ['code_hash' => hash('sha256', $code), 'expires_at' => time() + 600, 'last_sent' => time(), 'attempts' => 0];
                    $notice = 'A verification code was sent to your account email. Enter it below to activate email verification.';
                } else $error = 'Could not send the verification email. Check server email configuration or contact the administrator.';
            } elseif (isset($_POST['confirm_email_2fa'])) {
                $pending = $_SESSION['email_2fa_enrollment'] ?? [];
                if (empty($pending) || time() > (int)$pending['expires_at']) { unset($_SESSION['email_2fa_enrollment']); $error = 'That code expired. Start email verification setup again.'; }
                elseif ((int)$pending['attempts'] >= 5) { unset($_SESSION['email_2fa_enrollment']); $error = 'Too many incorrect codes. Start email verification setup again.'; }
                else {
                    $_SESSION['email_2fa_enrollment']['attempts']++;
                    $code = trim((string)($_POST['email_code'] ?? ''));
                    if (preg_match('/^\d{6}$/', $code) && hash_equals($pending['code_hash'], hash('sha256', $code))) {
                        $pdo->prepare('INSERT INTO user_security_settings (user_id, email_2fa_enabled) VALUES (?, 1) ON DUPLICATE KEY UPDATE email_2fa_enabled = 1')->execute([$currentUserId]);
                        unset($_SESSION['email_2fa_enrollment']); log_audit_trail('ENABLE_EMAIL_2FA', 'Users', $currentUserId, 'User enabled email verification for sign-in');
                        $notice = 'Email verification is enabled for your account.';
                    } else $error = 'The email verification code is incorrect.';
                }
            } elseif (isset($_POST['disable_email_2fa'])) {
                $pdo->prepare('UPDATE user_security_settings SET email_2fa_enabled = 0 WHERE user_id = ?')->execute([$currentUserId]);
                unset($_SESSION['email_2fa_enrollment']); log_audit_trail('DISABLE_EMAIL_2FA', 'Users', $currentUserId, 'User disabled email verification for sign-in');
                $notice = 'Email verification is off for your account.';
            }
        } catch (Throwable $e) { $error = 'Unable to update two-factor authentication settings.'; }
    }
    elseif (!$isAdmin) {
        http_response_code(403); $error = 'Only an administrator can change user access settings.';
    } elseif ($tab === 'accounts' && isset($_POST['save_category'])) {
        $targetId = (int)($_POST['user_id'] ?? 0); $category = (string)($_POST['rbac_category'] ?? '');
        if ($targetId === $currentUserId && $category !== 'System Administrator') $error = 'You cannot remove your own administrator category.';
        elseif (!in_array($category, $categories, true)) $error = 'Select a valid RBAC category.';
        else { $oldStmt=$pdo->prepare('SELECT rbac_category FROM users WHERE id=?');$oldStmt->execute([$targetId]);$oldCategory=(string)$oldStmt->fetchColumn();$pdo->prepare('UPDATE users SET rbac_category = ? WHERE id = ?')->execute([$category, $targetId]);audit_log_change('Users',$targetId,['rbac_category'=>$oldCategory],['rbac_category'=>$category],'Updated user access category',['severity'=>'WARNING','metadata'=>['target_user_id'=>$targetId]]);$notice = 'RBAC category updated.'; }
    } elseif ($tab === 'permissions' && isset($_POST['save_permissions'])) {
        $targetId = (int)($_POST['user_id'] ?? 0); $selected = array_values(array_intersect(array_keys($modules), (array)($_POST['modules'] ?? [])));
        if ($targetId <= 0) $error = 'Select a valid user.';
        elseif ($targetId === $currentUserId && !in_array('administration', $selected, true)) $error = 'You cannot remove your own Administration access.';
        else {
            $pdo->beginTransaction();
            try { $oldModuleStmt=$pdo->prepare('SELECT module_key FROM user_module_permissions WHERE user_id=? ORDER BY module_key');$oldModuleStmt->execute([$targetId]);$oldModules=$oldModuleStmt->fetchAll(PDO::FETCH_COLUMN);$pdo->prepare('DELETE FROM user_module_permissions WHERE user_id = ?')->execute([$targetId]); $grant = $pdo->prepare('INSERT INTO user_module_permissions (user_id, module_key, granted_by) VALUES (?, ?, ?)'); foreach ($selected as $moduleKey) $grant->execute([$targetId, $moduleKey, $currentUserId]); $pdo->commit(); log_audit_trail('UPDATE_MODULE_ACCESS', 'Users', $targetId, 'Changed module access grants',['severity'=>'WARNING','metadata'=>['target_user_id'=>$targetId,'old_modules'=>$oldModules,'new_modules'=>$selected]]); $notice = 'Module access saved.'; }
            catch (Throwable $e) { if ($pdo->inTransaction()) $pdo->rollBack(); $error = 'Could not save module access.'; }
        }
    }
}

$users = []; $permissionMap = []; $security = []; $securityRows = [];
if ($db_connected && $pdo) {
    try { $users = $pdo->query('SELECT id, full_name, email, role, directorate, is_admin, rbac_category FROM users ORDER BY full_name')->fetchAll(); } catch (Throwable $e) {}
    try { foreach ($pdo->query('SELECT user_id, module_key FROM user_module_permissions')->fetchAll() as $row) $permissionMap[(int)$row['user_id']][] = $row['module_key']; } catch (Throwable $e) {}
    try { $currentSecurity = $pdo->prepare('SELECT * FROM user_security_settings WHERE user_id = ?'); $currentSecurity->execute([$currentUserId]); $security = $currentSecurity->fetch() ?: []; } catch (Throwable $e) {}
    if ($isAdmin) { try { $securityRows = $pdo->query('SELECT u.id, u.full_name, u.email, s.email_2fa_enabled FROM users u LEFT JOIN user_security_settings s ON s.user_id = u.id ORDER BY u.full_name')->fetchAll(); } catch (Throwable $e) {} }
}
$pendingEmailEnrollment = !empty($_SESSION['email_2fa_enrollment']);
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/admin_tabs.php';
?>
<div style="display:flex;flex-direction:column;gap:18px;">
    <div><h2 style="margin:0;color:#0f172a;font-size:1.3rem;">👥 Users &amp; Access Control</h2><p style="margin:5px 0 0;color:#64748b;font-size:.84rem;">Manage accounts, RBAC categories, and role-based module access.</p></div>
    <nav aria-label="User administration tabs" style="display:flex;gap:8px;flex-wrap:wrap;border-bottom:1px solid #cbd5e1;padding-bottom:10px;">
        <?php foreach (['accounts'=>'User Management','security'=>'My Security · Email Verification','permissions'=>'Module Permissions'] as $key=>$label): ?><a href="/modules/users.php?tab=<?= $key ?>" style="padding:9px 14px;border-radius:7px;text-decoration:none;font-size:.8rem;font-weight:800;<?= $tab===$key?'background:#1a61c1;color:white;':'background:#f1f5f9;color:#334155;' ?>"><?= htmlspecialchars($label) ?></a><?php endforeach; ?>
    </nav>
    <?php if ($notice): ?><div role="status" style="padding:10px 13px;background:#ecfdf5;color:#065f46;border-radius:7px;font-size:.82rem;"><?= htmlspecialchars($notice) ?></div><?php endif; ?>
    <?php if ($error): ?><div role="alert" style="padding:10px 13px;background:#fef2f2;color:#991b1b;border-radius:7px;font-size:.82rem;"><?= htmlspecialchars($error) ?></div><?php endif; ?>

    <?php if ($tab === 'security'): ?>
        <section style="max-width:800px;padding:20px;background:#fff;border:1px solid #e2e8f0;border-radius:9px;">
            <h3 style="margin:0 0 8px;color:#0f172a;">Email sign-in verification</h3>
            <p style="color:#475569;font-size:.84rem;line-height:1.55;">Email verification is off by default. Turn it on for your account to require a short-lived code sent to your account email after your password.</p>
            <p style="font-size:.82rem;"><strong>Account status:</strong> <?= !empty($security['email_2fa_enabled']) ? 'Email verification enabled' : 'Off' ?></p>
            <?php if ($pendingEmailEnrollment): ?>
                <form method="post" style="display:grid;gap:8px;max-width:360px;"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars(get_csrf_token()) ?>"><label>Enter the six-digit code sent to <?= htmlspecialchars($currentUser['email']) ?><input name="email_code" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" required></label><button name="confirm_email_2fa" value="1" style="padding:8px 11px;background:#1a61c1;color:white;border:0;border-radius:5px;">Confirm and enable email verification</button></form>
            <?php elseif (!empty($security['email_2fa_enabled'])): ?>
                <form method="post"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars(get_csrf_token()) ?>"><button name="disable_email_2fa" value="1" style="padding:8px 11px;background:#b91c1c;color:white;border:0;border-radius:5px;">Turn off email verification</button></form>
            <?php else: ?>
                <form method="post"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars(get_csrf_token()) ?>"><button name="begin_email_2fa" value="1" style="padding:9px 13px;background:#1a61c1;color:#fff;border:0;border-radius:6px;font-weight:700;">Enable email verification</button></form>
            <?php endif; ?>
            <?php if ($isAdmin): ?><div style="margin-top:20px;border-top:1px solid #e2e8f0;padding-top:14px;"><h4 style="margin:0 0 10px;">Account recovery</h4><p style="font-size:.78rem;color:#64748b;">Administrators can turn off email verification for a user who cannot access their email account.</p><div style="display:grid;gap:8px;"><?php foreach($securityRows as $securityUser): if ((int)$securityUser['id'] === $currentUserId) continue; ?><form method="post" style="display:flex;justify-content:space-between;gap:10px;align-items:center;flex-wrap:wrap;padding:9px;background:#f8fafc;border-radius:6px;"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars(get_csrf_token()) ?>"><input type="hidden" name="user_id" value="<?= (int)$securityUser['id'] ?>"><span><strong><?= htmlspecialchars($securityUser['full_name']) ?></strong> <small style="color:#64748b;">· <?= htmlspecialchars($securityUser['email']) ?></small> — <?= !empty($securityUser['email_2fa_enabled']) ? 'Email verification on' : 'Off' ?></span><?php if (!empty($securityUser['email_2fa_enabled'])): ?><button name="admin_disable_2fa" value="1" style="padding:7px 10px;background:#b91c1c;color:white;border:0;border-radius:5px;">Turn off</button><?php endif; ?></form><?php endforeach; ?></div></div><?php endif; ?>
        </section>
    <?php elseif (!$isAdmin): ?>
        <div style="padding:18px;background:#fff7ed;color:#9a3412;border:1px solid #fed7aa;border-radius:8px;">Administrator access is required to view or change account-wide RBAC settings.</div>
    <?php elseif ($tab === 'accounts'): ?>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:10px;"><?php foreach ($categories as $category): $count=count(array_filter($users,fn($u)=>($u['rbac_category']??'Officer')===$category)); ?><div style="background:#fff;border:1px solid #e2e8f0;border-radius:8px;padding:12px;"><div style="font-size:.7rem;text-transform:uppercase;color:#64748b;font-weight:800;">RBAC category</div><strong style="color:#0f172a;"> <?= htmlspecialchars($category) ?></strong><div style="font-size:1.2rem;font-weight:800;color:#1a61c1;"> <?= $count ?> <small style="font-size:.7rem;color:#64748b;">accounts</small></div></div><?php endforeach; ?></div>
        <section style="overflow:auto;background:#fff;border:1px solid #e2e8f0;border-radius:8px;"><table style="width:100%;border-collapse:collapse;font-size:.82rem;"><thead><tr style="background:#f8fafc;text-align:left;"><th style="padding:12px;">Account</th><th style="padding:12px;">Directorate</th><th style="padding:12px;">RBAC category</th><th style="padding:12px;">Status</th></tr></thead><tbody>
        <?php foreach ($users as $u): ?><tr style="border-top:1px solid #e2e8f0;"><td style="padding:12px;"><strong><?= htmlspecialchars($u['full_name']) ?></strong><br><small><?= htmlspecialchars($u['email']) ?></small></td><td style="padding:12px;"><?= htmlspecialchars($u['directorate']??'') ?></td><td style="padding:12px;"><form method="post" style="display:flex;gap:6px;align-items:center;"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars(get_csrf_token()) ?>"><input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>"><select name="rbac_category" aria-label="RBAC category for <?= htmlspecialchars($u['full_name']) ?>"><?php foreach($categories as $c): ?><option value="<?= htmlspecialchars($c) ?>" <?= ($u['rbac_category']??'Officer')===$c?'selected':'' ?>><?= htmlspecialchars($c) ?></option><?php endforeach; ?></select><button name="save_category" value="1">Save</button></form></td><td style="padding:12px;"><?= !empty($u['is_admin'])?'Administrator':'Active' ?></td></tr><?php endforeach; ?>
        </tbody></table></section>
    <?php else: ?>
        <section style="padding:15px;background:#eff6ff;border-radius:8px;color:#1e3a8a;font-size:.82rem;">Select which application modules each account can open. Administrators always retain access. Existing accounts were initialized with their current module availability.</section>
        <div style="display:grid;gap:12px;"><?php foreach($users as $u): ?><form method="post" style="padding:15px;background:#fff;border:1px solid #e2e8f0;border-radius:8px;"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars(get_csrf_token()) ?>"><input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>"><div style="display:flex;justify-content:space-between;gap:10px;align-items:center;flex-wrap:wrap;margin-bottom:12px;"><div><strong><?= htmlspecialchars($u['full_name']) ?></strong> <span style="color:#64748b;font-size:.78rem;">· <?= htmlspecialchars($u['email']) ?> · <?= htmlspecialchars($u['rbac_category']??'Officer') ?></span></div><button name="save_permissions" value="1" style="padding:7px 12px;background:#1a61c1;color:#fff;border:0;border-radius:5px;font-weight:700;">Save access</button></div><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:8px;"><?php foreach($modules as $key=>$label): $legacyAccess=$key==='administration'&&array_intersect(['users','audit_logs'],$permissionMap[(int)$u['id']]??[]); $hasAccess=in_array($key,$permissionMap[(int)$u['id']]??[],true)||$legacyAccess; ?><?php if ((int)$u['id']===$currentUserId && $key==='administration'): ?><input type="hidden" name="modules[]" value="administration"><?php endif; ?><label style="display:flex;gap:7px;align-items:center;padding:7px;background:#f8fafc;border-radius:5px;font-size:.78rem;"><input type="checkbox" name="modules[]" value="<?= htmlspecialchars($key) ?>" <?= $hasAccess?'checked':'' ?> <?= ((int)$u['id']===$currentUserId && $key==='administration')?'checked disabled':'' ?>><?= htmlspecialchars($label) ?></label><?php endforeach; ?></div></form><?php endforeach; ?></div>
    <?php endif; ?>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
