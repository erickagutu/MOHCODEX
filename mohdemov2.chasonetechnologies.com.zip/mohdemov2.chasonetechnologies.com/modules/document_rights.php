<?php
/**
 * Document Rights & Access Authorization Matrix Module
 * Ministry of Health — State Department for Medical Services (PP-SDOMS)
 * Native PHP 8.1+ & MySQL (PDO)
 * Brand Colors: Blue (#1a61c1), Green (#10b981)
 */
require_once __DIR__ . '/../config/db.php';
require_auth();

$page_title = 'Document Rights & Access Control — PP-SDOMS';
$active_tab = 'document_rights';

$current_user_name  = $_SESSION['full_name'] ?? 'Authorized User';
$current_user_role  = $_SESSION['role'] ?? 'Viewer';
$current_user_email = $_SESSION['email'] ?? '';
$is_admin_account   = !empty($_SESSION['is_admin']) || !empty(get_current_user_data()['is_admin']) || (strcasecmp(trim($current_user_role), 'Administrator') === 0);
$is_ps_account      = (strcasecmp(trim($current_user_role), 'Principal Secretary') === 0) || 
                      (stripos($current_user_role, 'PS') !== false) || 
                      (strtolower($current_user_email) === 'ps@medicalservices.go.ke');

// Only Admin or PS may access this document rights management page
if (!$is_admin_account && !$is_ps_account) {
    die("<div style='font-family: sans-serif; padding: 40px; text-align: center;'><h2>Access Denied</h2><p>Document rights configuration is strictly restricted to System Administrators and the Principal Secretary.</p><a href='reports.php'>Return to Reports</a></div>");
}

$notice_msg = '';
$error_msg  = '';

// Auto-provision document_permissions table if needed
if ($db_connected && $pdo) {
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS document_permissions (
            id INT AUTO_INCREMENT PRIMARY KEY,
            report_id INT NOT NULL,
            user_email VARCHAR(150) NOT NULL,
            user_name VARCHAR(150) NOT NULL,
            can_view TINYINT(1) NOT NULL DEFAULT 1,
            can_download TINYINT(1) NOT NULL DEFAULT 1,
            granted_by VARCHAR(150) DEFAULT NULL,
            granted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uq_doc_user (report_id, user_email)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
    } catch (Exception $e) {
        // Continue
    }
}

// Handle Permission Grant/Revoke
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_rights') {
    $report_id   = (int)($_POST['report_id'] ?? 0);
    $target_email= trim($_POST['user_email'] ?? '');
    $target_name = trim($_POST['user_name'] ?? '');
    $can_view    = isset($_POST['can_view']) ? 1 : 0;
    $can_download= isset($_POST['can_download']) ? 1 : 0;

    if ($report_id > 0 && !empty($target_email)) {
        try {
            $stmt = $pdo->prepare("INSERT INTO document_permissions (report_id, user_email, user_name, can_view, can_download, granted_by, granted_at)
                VALUES (?, ?, ?, ?, ?, ?, NOW())
                ON DUPLICATE KEY UPDATE can_view = VALUES(can_view), can_download = VALUES(can_download), granted_by = VALUES(granted_by), granted_at = NOW()");
            $stmt->execute([$report_id, $target_email, $target_name, $can_view, $can_download, $current_user_name]);
            $notice_msg = "Document access rights successfully updated for {$target_name} ({$target_email}).";
        } catch (Exception $e) {
            $error_msg = "Error updating rights: " . $e->getMessage();
        }
    }
}

// Fetch users, reports, and existing permissions
$users = [];
$reports = [];
$permissions_matrix = [];

if ($db_connected && $pdo) {
    try {
        $u_stmt = $pdo->query("SELECT id, full_name, email, role, directorate, is_admin FROM users ORDER BY full_name ASC");
        $users = $u_stmt->fetchAll(PDO::FETCH_ASSOC);

        $r_stmt = $pdo->query("SELECT id, code, title, visibility, uploaded_by FROM reports ORDER BY id DESC");
        $reports = $r_stmt->fetchAll(PDO::FETCH_ASSOC);

        $p_stmt = $pdo->query("SELECT * FROM document_permissions");
        while ($row = $p_stmt->fetch(PDO::FETCH_ASSOC)) {
            $permissions_matrix[$row['report_id']][$row['user_email']] = $row;
        }
    } catch (Exception $e) {
        // Fallback
    }
}

require_once __DIR__ . '/../includes/header.php';
?>

<div style="display: flex; flex-direction: column; gap: 24px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">

    <!-- Page Header -->
    <div style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 16px; border-bottom: 2px solid #e2e8f0; padding-bottom: 16px;">
        <div>
            <div style="display: flex; align-items: center; gap: 10px;">
                <span style="background: #1a61c1; color: white; padding: 6px 10px; border-radius: 6px; font-weight: 800; font-size: 0.8rem;">RBAC</span>
                <h1 style="font-size: 1.4rem; font-weight: 800; color: #0f172a; margin: 0;">
                    Document Rights &amp; Access Authorization Matrix
                </h1>
            </div>
            <p style="font-size: 0.82rem; color: #64748b; margin: 4px 0 0 0;">
                Enforce granular view and download privileges for non-admin officers and project coordinators.
            </p>
        </div>

        <div style="display: flex; gap: 10px;">
            <a href="reports.php" style="background: #1a61c1; color: white; text-decoration: none; padding: 8px 16px; border-radius: 6px; font-size: 0.78rem; font-weight: 700;">
                ⬅️ Back to Reports Repository
            </a>
        </div>
    </div>

    <!-- Alert Messages -->
    <?php if ($notice_msg): ?>
        <div style="background: #ecfdf5; border-left: 4px solid #10b981; color: #065f46; padding: 12px 16px; border-radius: 4px; font-size: 0.82rem; font-weight: 600;">
            <?= htmlspecialchars($notice_msg) ?>
        </div>
    <?php endif; ?>
    <?php if ($error_msg): ?>
        <div style="background: #fef2f2; border-left: 4px solid #ef4444; color: #991b1b; padding: 12px 16px; border-radius: 4px; font-size: 0.82rem; font-weight: 600;">
            <?= htmlspecialchars($error_msg) ?>
        </div>
    <?php endif; ?>

    <!-- Explanatory Policy Card -->
    <div style="background: #eff6ff; border: 1px solid #bfdbfe; border-radius: 8px; padding: 16px; display: flex; gap: 14px; align-items: flex-start;">
        <span style="font-size: 1.5rem;">🛡️</span>
        <div style="font-size: 0.8rem; color: #1e3a8a;">
            <div style="font-weight: 800; font-size: 0.85rem; margin-bottom: 2px;">Security &amp; Authorization Policy</div>
            By default, <strong>Administrator</strong> and <strong>Principal Secretary (PS)</strong> accounts possess universal view and download privileges across all statutory documents. Non-administrative officers can only view documents they personally uploaded unless granted explicit authorization via this matrix below.
        </div>
    </div>

    <!-- Document Rights Matrix Table -->
    <div style="background: #ffffff; border-radius: 8px; border: 1px solid #e2e8f0; overflow: hidden; box-shadow: 0 2px 4px rgba(0,0,0,0.02);">
        <div style="background: #f8fafc; border-bottom: 1px solid #e2e8f0; padding: 14px 20px; font-weight: 800; font-size: 0.85rem; color: #0f172a;">
            Document Permissions Matrix by Officer
        </div>
        <div style="overflow-x: auto;">
            <table style="width: 100%; border-collapse: collapse; font-size: 0.8rem; text-align: left;">
                <thead>
                    <tr style="background: #f1f5f9; color: #475569; font-weight: 700; border-bottom: 2px solid #e2e8f0; text-transform: uppercase; font-size: 0.72rem;">
                        <th style="padding: 12px 16px;">Document Code &amp; Title</th>
                        <th style="padding: 12px 16px;">Classification</th>
                        <th style="padding: 12px 16px;">Authorized Officers</th>
                        <th style="padding: 12px 16px; text-align: right;">Grant Access</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($reports)): ?>
                        <tr><td colspan="4" style="padding: 24px; text-align: center; color: #64748b;">No documents available to assign rights.</td></tr>
                    <?php endif; ?>

                    <?php foreach ($reports as $r): ?>
                        <tr style="border-bottom: 1px solid #f1f5f9;">
                            <td style="padding: 14px 16px;">
                                <div style="font-family: 'JetBrains Mono', monospace; font-weight: 800; color: #1a61c1; font-size: 0.75rem;">
                                    <?= htmlspecialchars($r['code']) ?>
                                </div>
                                <div style="font-weight: 700; color: #0f172a; margin-top: 2px;">
                                    <?= htmlspecialchars($r['title']) ?>
                                </div>
                                <div style="font-size: 0.7rem; color: #64748b;">Uploaded by: <?= htmlspecialchars($r['uploaded_by']) ?></div>
                            </td>
                            <td style="padding: 14px 16px;">
                                <span style="background: #f1f5f9; color: #334155; font-size: 0.7rem; font-weight: 700; padding: 2px 8px; border-radius: 4px; border: 1px solid #cbd5e1;">
                                    <?= htmlspecialchars($r['visibility']) ?>
                                </span>
                            </td>
                            <td style="padding: 14px 16px;">
                                <div style="display: flex; gap: 6px; flex-wrap: wrap;">
                                    <span style="background: #ecfdf5; color: #065f46; font-size: 0.68rem; font-weight: 700; padding: 2px 6px; border-radius: 4px; border: 1px solid #a7f3d0;">
                                        Admin &amp; PS (Universal)
                                    </span>
                                    <?php 
                                        $perms = $permissions_matrix[$r['id']] ?? [];
                                        foreach ($perms as $email => $p):
                                            if (!empty($p['can_view'])):
                                    ?>
                                        <span style="background: #eff6ff; color: #1e40af; font-size: 0.68rem; font-weight: 700; padding: 2px 6px; border-radius: 4px; border: 1px solid #bfdbfe;">
                                            <?= htmlspecialchars($p['user_name']) ?> (<?= !empty($p['can_download']) ? 'View+DL' : 'View' ?>)
                                        </span>
                                    <?php 
                                            endif;
                                        endforeach; 
                                    ?>
                                </div>
                            </td>
                            <td style="padding: 14px 16px; text-align: right;">
                                <button onclick="openGrantModal(<?= $r['id'] ?>, '<?= htmlspecialchars(addslashes($r['code'])) ?>', '<?= htmlspecialchars(addslashes($r['title'])) ?>');"
                                        style="background: #1a61c1; color: white; border: none; padding: 5px 12px; border-radius: 4px; font-size: 0.72rem; font-weight: 700; cursor: pointer;">
                                    Manage Rights
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<!-- Grant Rights Modal -->
<div id="grantModal" style="display: none; position: fixed; inset: 0; background: rgba(15, 23, 42, 0.6); z-index: 9999; justify-content: center; align-items: center; padding: 20px;">
    <div style="background: white; border-radius: 8px; width: 100%; max-width: 500px; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1); border: 1px solid #e2e8f0; overflow: hidden;">
        <div style="background: #1a61c1; color: white; padding: 14px 20px; display: flex; justify-content: space-between; align-items: center;">
            <h3 style="margin: 0; font-size: 0.95rem; font-weight: 800;">Grant Document Access Rights</h3>
            <button onclick="document.getElementById('grantModal').style.display='none';" style="background: transparent; border: none; color: white; font-size: 1.2rem; cursor: pointer;">&times;</button>
        </div>
        <form method="POST" style="padding: 20px; display: flex; flex-direction: column; gap: 14px;">
            <input type="hidden" name="action" value="update_rights">
            <input type="hidden" name="report_id" id="modal_report_id" value="">
            <input type="hidden" name="user_name" id="modal_user_name" value="">

            <div>
                <div style="font-size: 0.72rem; color: #64748b; font-weight: 700; text-transform: uppercase;">Selected Report</div>
                <div id="modal_doc_title" style="font-size: 0.85rem; font-weight: 700; color: #0f172a; margin-top: 2px;"></div>
            </div>

            <div>
                <label style="display: block; font-size: 0.75rem; font-weight: 700; color: #334155; margin-bottom: 4px;">Assign Rights to Officer *</label>
                <select name="user_email" id="modal_user_email" required onchange="updateUserName();"
                        style="width: 100%; padding: 8px 12px; font-size: 0.8rem; border: 1px solid #cbd5e1; border-radius: 4px;">
                    <option value="">-- Select Ministerial Officer --</option>
                    <?php foreach ($users as $u): ?>
                        <option value="<?= htmlspecialchars($u['email']) ?>" data-name="<?= htmlspecialchars($u['full_name']) ?>">
                            <?= htmlspecialchars($u['full_name']) ?> (<?= htmlspecialchars($u['role']) ?> - <?= htmlspecialchars($u['directorate']) ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 12px; display: flex; flex-direction: column; gap: 8px;">
                <label style="display: flex; align-items: center; gap: 8px; font-size: 0.8rem; color: #1e293b; font-weight: 600; cursor: pointer;">
                    <input type="checkbox" name="can_view" value="1" checked style="accent-color: #1a61c1;">
                    Can View &amp; Inspect Document
                </label>
                <label style="display: flex; align-items: center; gap: 8px; font-size: 0.8rem; color: #1e293b; font-weight: 600; cursor: pointer;">
                    <input type="checkbox" name="can_download" value="1" checked style="accent-color: #10b981;">
                    Can Download Document Attachment (PDF/Excel)
                </label>
            </div>

            <div style="display: flex; justify-content: flex-end; gap: 10px; margin-top: 10px;">
                <button type="button" onclick="document.getElementById('grantModal').style.display='none';" 
                        style="background: #f1f5f9; color: #334155; border: 1px solid #cbd5e1; padding: 8px 16px; border-radius: 4px; font-size: 0.8rem; font-weight: 700; cursor: pointer;">
                    Cancel
                </button>
                <button type="submit" 
                        style="background: #10b981; color: white; border: none; padding: 8px 18px; border-radius: 4px; font-size: 0.8rem; font-weight: 700; cursor: pointer;">
                    Save Permissions
                </button>
            </div>
        </form>
    </div>
</div>

<script>
function openGrantModal(id, code, title) {
    document.getElementById('modal_report_id').value = id;
    document.getElementById('modal_doc_title').innerText = code + " — " + title;
    document.getElementById('grantModal').style.display = 'flex';
}
function updateUserName() {
    var sel = document.getElementById('modal_user_email');
    var opt = sel.options[sel.selectedIndex];
    document.getElementById('modal_user_name').value = opt.getAttribute('data-name') || '';
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
