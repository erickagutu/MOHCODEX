<?php
/** Division register from the official organogram, with current project totals. */
require_once __DIR__ . '/../config/db.php';
require_auth();
$page_title = 'Divisions — State Department for Medical Services';
$active_tab = 'divisions';
$divisions = [];
if ($db_connected && $pdo) {
    try {
        $divisions = $pdo->query("SELECT d.name, dir.name AS directorate_name,
                COUNT(p.id) AS project_count, COALESCE(SUM(p.total_budget), 0) AS total_budget
            FROM divisions d
            INNER JOIN directorates dir ON dir.id = d.directorate_id
            LEFT JOIN projects p ON p.division_name = d.name AND p.directorate_name = dir.name
            GROUP BY d.id, d.name, dir.name
            ORDER BY dir.name, d.name")->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $error) {
        // Support older installations until the organogram import has been run.
        try {
            $divisions = $pdo->query("SELECT division_name AS name, directorate_name,
                    COUNT(*) AS project_count, COALESCE(SUM(total_budget),0) AS total_budget
                FROM projects WHERE division_name IS NOT NULL AND TRIM(division_name) <> ''
                GROUP BY division_name, directorate_name ORDER BY directorate_name, division_name")->fetchAll(PDO::FETCH_ASSOC);
        } catch (Throwable $fallbackError) {
            error_log('Division list query failed: ' . $fallbackError->getMessage());
        }
    }
}
$directorates = array_values(array_unique(array_filter(array_map(static fn($row) => trim((string)$row['directorate_name']), $divisions))));
?>
<?php require_once __DIR__ . '/../includes/header.php'; ?>
<style>
.division-page{display:flex;flex-direction:column;gap:18px}.division-heading h2{margin:0;color:#102c53;font-size:1.4rem;font-weight:800}.division-heading p{margin:5px 0 0;color:#64748b;font-size:.84rem}.division-filters{display:flex;gap:10px;flex-wrap:wrap;background:#fff;padding:14px;border:1px solid #dce4ef;border-radius:8px}.division-filters input,.division-filters select{min-height:40px;padding:8px 11px;border:1px solid #dce4ef;border-radius:6px;background:#f8fafc;color:#1e293b;font:inherit}.division-filters input{flex:1 1 250px}.division-table-wrap{overflow:auto;background:#fff;border:1px solid #dce4ef;border-radius:8px;box-shadow:0 2px 5px rgba(15,23,42,.04)}.division-table{border-collapse:collapse;width:100%;min-width:760px;font-size:.84rem}.division-table th{padding:13px 15px;background:#f8fafc;color:#52647c;text-align:left;font-size:.7rem;letter-spacing:.05em;text-transform:uppercase}.division-table td{padding:14px 15px;border-top:1px solid #edf1f6;color:#334155}.division-table tr:hover{background:#f8fbff}.division-name{color:#102c53;font-weight:750}.division-directorate{color:#64748b}.division-count{text-align:right;font-weight:750}.division-budget{text-align:right;white-space:nowrap;font-family:'JetBrains Mono',monospace;font-size:.78rem}.division-link{display:inline-flex;padding:6px 10px;border-radius:6px;background:#eff6ff;color:#0d47a1;text-decoration:none;font-size:.75rem;font-weight:750}.division-empty{text-align:center;color:#64748b!important;padding:24px!important}
</style>
<div class="division-page">
    <header class="division-heading"><h2>Divisions</h2><p>Divisions listed under their directorates in the approved organogram, with project allocations currently recorded in the system.</p></header>
    <section class="division-filters" aria-label="Filter divisions">
        <input id="divisionSearch" type="search" placeholder="Search division or directorate" aria-label="Search divisions">
        <select id="divisionDirectorate" aria-label="Filter by directorate"><option value="">All directorates</option><?php foreach ($directorates as $name): ?><option value="<?= htmlspecialchars($name, ENT_QUOTES) ?>"><?= htmlspecialchars($name) ?></option><?php endforeach; ?></select>
    </section>
    <div class="division-table-wrap"><table class="division-table"><thead><tr><th>Division</th><th>Directorate</th><th style="text-align:right">Projects</th><th style="text-align:right">Total Budget (KES)</th><th>Open portfolio</th></tr></thead><tbody id="divisionRows">
    <?php foreach ($divisions as $division): $dir=(string)($division['directorate_name'] ?? ''); $name=(string)$division['name']; ?>
        <tr data-search="<?= htmlspecialchars(strtolower($name.' '.$dir), ENT_QUOTES) ?>" data-directorate="<?= htmlspecialchars($dir, ENT_QUOTES) ?>"><td class="division-name"><?= htmlspecialchars($name) ?></td><td class="division-directorate"><?= htmlspecialchars($dir ?: '—') ?></td><td class="division-count"><?= (int)$division['project_count'] ?></td><td class="division-budget"><?= format_kes($division['total_budget']) ?></td><td><a class="division-link" href="/modules/projects.php?dir=<?= urlencode($dir) ?>&amp;div=<?= urlencode($name) ?>">View projects →</a></td></tr>
    <?php endforeach; ?>
    <tr id="divisionEmpty"<?= $divisions ? ' hidden' : '' ?>><td colspan="5" class="division-empty"><?= $divisions ? 'No divisions match the selected filters.' : 'No divisions are registered yet. Import database/migrations/import_organogram_divisions.sql to load the approved directorate and division structure.' ?></td></tr>
    </tbody></table></div>
</div>
<script>(()=>{const search=document.getElementById('divisionSearch'),dir=document.getElementById('divisionDirectorate'),rows=[...document.querySelectorAll('#divisionRows tr[data-search]')],empty=document.getElementById('divisionEmpty');function apply(){let n=0;rows.forEach(row=>{const show=(!dir.value||row.dataset.directorate===dir.value)&&(!search.value||row.dataset.search.includes(search.value.toLowerCase().trim()));row.hidden=!show;if(show)n++});empty.hidden=n>0}search.addEventListener('input',apply);dir.addEventListener('change',apply)})();</script>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
