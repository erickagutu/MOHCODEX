<?php
/** Project Planner Diary integrated with the PP-SDOMS diary_events/projects schema. */
require_once __DIR__ . '/../config/db.php';
require_auth();

$page_title = 'Project Planner Diary — PP-SDOMS';
$active_tab = 'diary';
$page_stylesheets = ['/assets/diary.css?v=20261028-1'];
$diary_projects = [];
if ($db_connected && $pdo) {
    try {
        $diary_projects = $pdo->query("SELECT id, programme_title, sub_programme FROM projects ORDER BY programme_title, sub_programme")->fetchAll();
    } catch (Throwable $e) { $diary_projects = []; }
}
require_once __DIR__ . '/../includes/header.php';
?>
<div class="app-container diary-module">
    <div class="section-header diary-section-header">
        <div class="section-title-wrap">
            <span class="section-title-icon" aria-hidden="true">♧</span>
            <div><h2 class="section-title">Diary</h2><div class="diary-page-subtitle">Plan meetings, tasks, deadlines and project activities.</div></div>
        </div>
        <div class="diary-header-actions"><a href="<?= htmlspecialchars('/modules/events.php') ?>" class="status-pill diary-events-link">Activities &amp; Events →</a><button type="button" id="addDiaryEntryBtn" class="btn-primary-green">＋ <span>New Diary Entry</span></button></div>
    </div>

    <section class="calendar-card" aria-label="Diary calendar">
        <div class="calendar-header diary-calendar-header">
            <div class="diary-month-navigation">
                <button type="button" id="prevMonthBtn" class="status-pill">← Prev</button>
                <h3 id="calendarMonthDisplay" aria-live="polite"></h3>
                <button type="button" id="nextMonthBtn" class="status-pill">Next →</button>
            </div>
        </div>
        <div id="calendarGrid" class="calendar-grid"></div>
    </section>

    <nav class="diary-category-filters" id="diaryCategoryFilters" aria-label="Filter diary entries by category">
        <button type="button" class="calendar-event-pill event-cat-meeting" data-filter-category="Meeting" aria-pressed="false">Meeting</button>
        <button type="button" class="calendar-event-pill event-cat-corporatebusiness" data-filter-category="Corporate Business" aria-pressed="false">Corporate Business</button>
        <button type="button" class="calendar-event-pill event-cat-task" data-filter-category="Task" aria-pressed="false">Task</button>
        <button type="button" class="calendar-event-pill event-cat-deadline" data-filter-category="Deadline" aria-pressed="false">Deadline</button>
        <button type="button" class="calendar-event-pill event-cat-event" data-filter-category="Event" aria-pressed="false">Event</button>
        <button type="button" class="calendar-event-pill event-cat-general" data-filter-category="General" aria-pressed="false">General</button>
        <button type="button" class="calendar-event-pill event-cat-fieldvisit" data-filter-category="Field Visit" aria-pressed="false">Field Visit</button>
        
        <button type="button" class="calendar-event-pill event-cat-executiveinspection" data-filter-category="Executive Inspection" aria-pressed="false">Executive Inspection</button>
        <button type="button" class="calendar-event-pill event-cat-training" data-filter-category="Training" aria-pressed="false">Training</button>
        
    </nav>

    <section id="linkedProjectDrawer" class="linked-project-drawer diary-details-panel" aria-live="polite">
        <div class="diary-details-heading">
            <h3><span aria-hidden="true">▣</span> Event Details &amp; Linked Project Specifications</h3>
            <button type="button" id="clearDiarySelection" class="modal-close-btn" aria-label="Clear selection">×</button>
        </div>
        <div id="drawerProjectContent" class="diary-details-content"><p class="diary-empty-note">Select a category on the calendar to view its entries.</p></div>
    </section>
</div>

<!-- Create / edit entry -->
<div id="newDiaryModal" class="modal-overlay" role="dialog" aria-modal="true" aria-labelledby="diaryModalTitle">
    <div class="modal-dialog diary-modal-dialog">
        <div class="modal-header diary-modal-header">
            <div><span class="diary-modal-kicker">PROJECT PLANNER DIARY</span><h3 class="modal-title" id="diaryModalTitle">Schedule New Diary Entry</h3><p id="diaryModalSubtitle">Capture the activity, schedule and project details.</p></div>
            <button type="button" class="modal-close-btn" onclick="closeNewDiaryModal()" aria-label="Close">×</button>
        </div>
        <form id="newDiaryForm" class="diary-entry-form">
            <input type="hidden" id="diaryEntryId" value="">
            <div class="form-group"><label for="diaryTitle">Entry Title <span>*</span></label><input type="text" id="diaryTitle" class="form-input" maxlength="255" required placeholder="e.g. KNH project review meeting"></div>
            <div class="diary-form-grid">
                <div class="form-group"><label for="diaryDate">Event Date <span>*</span></label><input type="date" id="diaryDate" class="form-input" min="<?= (new DateTimeImmutable('today', new DateTimeZone('Africa/Nairobi')))->format('Y-m-d') ?>" required></div>
                <div class="form-group"><label for="diaryTime">Event Time</label><input type="time" id="diaryTime" class="form-input" value="09:00"></div>
                <div class="form-group"><label for="diaryCategory">Category <span>*</span></label><select id="diaryCategory" class="form-select" required><option value="Meeting">Meeting</option><option value="Corporate Business">Corporate Business</option><option value="Task">Task</option><option value="Deadline">Deadline</option><option value="Event">Event</option><option value="General">General</option><optgroup label="Activities &amp; Events"><option value="Field Visit">Field Visit</option><option value="Executive Inspection">Executive Inspection</option><option value="Training">Training</option></optgroup></select></div>
                <div class="form-group"><label for="diaryPriority">Priority</label><select id="diaryPriority" class="form-select"><option value="Medium">Medium</option><option value="High">High</option><option value="Critical">Critical</option><option value="Low">Low</option></select></div>
                <div class="form-group"><label for="diaryStatus">Status</label><select id="diaryStatus" class="form-select"><option value="UPCOMING">Upcoming</option><option value="ONGOING">Ongoing</option><option value="COMPLETED">Completed</option><option value="CANCELLED">Cancelled</option></select></div>
            </div>

            <div class="form-group">
                <label for="diaryProjectSearch">Link to Projects / Programmes <small>(Optional — select one or more)</small></label>
                <div class="diary-project-picker" id="diaryProjectPicker">
                    <div class="diary-project-selected" id="diaryProjectSelected" aria-live="polite"></div>
                    <input type="search" id="diaryProjectSearch" class="form-input" placeholder="Search projects…" autocomplete="off">
                    <div class="diary-project-list" id="diaryProjectList" role="group" aria-label="Projects">
                        <?php foreach ($diary_projects as $project):
                            $label = trim(($project['programme_title'] ?? '') . ' — ' . ($project['sub_programme'] ?? ''), ' —'); ?>
                            <label class="diary-project-option" data-search="<?= htmlspecialchars(mb_strtolower($label)) ?>">
                                <input type="checkbox" value="<?= (int)$project['id'] ?>">
                                <span><?= htmlspecialchars($label) ?></span>
                            </label>
                        <?php endforeach; ?>
                        <p class="diary-project-nomatch" id="diaryProjectNoMatch" hidden>No projects match your search.</p>
                    </div>
                    <div class="diary-project-hint" id="diaryProjectHint">No project linked — this will be a standalone entry.</div>
                </div>
            </div>

            <div class="diary-form-grid">
                <div class="form-group"><label for="diaryLocation">Location</label><input type="text" id="diaryLocation" class="form-input" maxlength="255" placeholder="Venue or meeting link"></div>
                <div class="form-group"><label for="diaryHost">Host / Contact</label><input type="text" id="diaryHost" class="form-input" maxlength="150" placeholder="Responsible person"></div>
            </div>
            <div class="form-group"><label for="diaryAttendees">Attendees</label><input type="text" id="diaryAttendees" class="form-input" placeholder="Names or teams attending"></div>
            <div class="form-group"><label for="diaryContent">Agenda &amp; Operational Notes</label><textarea id="diaryContent" class="form-textarea" rows="4" placeholder="Agenda, expected deliverables or other useful details…"></textarea></div>
            <div id="diaryFormError" class="diary-form-error" hidden></div>
            <div class="diary-form-actions"><button type="button" class="status-pill" onclick="closeNewDiaryModal()">Cancel</button><button type="submit" id="diarySubmitBtn" class="btn-primary-green">Save Diary Entry</button></div>
        </form>
    </div>
</div>

<!-- Category entries popup (all entries of a category on a given day) -->
<div id="diaryDetailsModal" class="modal-overlay" role="dialog" aria-modal="true" aria-labelledby="diaryDetailsTitle">
    <div class="modal-dialog diary-details-dialog">
        <div class="modal-header diary-modal-header">
            <div>
                <span class="diary-modal-kicker">DIARY ENTRIES</span>
                <h3 class="modal-title" id="diaryDetailsTitle"></h3>
                <p id="diaryDetailsSubtitle"></p>
            </div>
            <button type="button" id="closeDiaryDetails" class="modal-close-btn" aria-label="Close">×</button>
        </div>
        <div id="diaryDetailsTabs" class="diary-details-tabs" role="tablist" aria-label="Entry categories"></div>
        <div id="diaryDetailsBody" class="diary-details-body"></div>
        <div id="diaryDetailsFooter" class="diary-details-footer"></div>
    </div>
</div>

<!-- Delete confirmation -->
<div id="deleteDiaryModal" class="modal-overlay" role="alertdialog" aria-modal="true" aria-labelledby="deleteDiaryTitle">
    <div class="modal-dialog diary-confirm-dialog">
        <h3 class="modal-title" id="deleteDiaryTitle">Delete this diary entry?</h3>
        <p id="deleteDiaryText" class="diary-confirm-text"></p>
        <div id="deleteDiaryError" class="diary-form-error" hidden></div>
        <div class="diary-confirm-actions">
            <button type="button" id="cancelDeleteBtn" class="status-pill">Cancel</button>
            <button type="button" id="confirmDeleteBtn" class="diary-danger-btn">Delete entry</button>
        </div>
    </div>
</div>
<script src="/assets/js/diary.js?v=20261028-1"></script>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
