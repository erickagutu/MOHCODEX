<?php
/**
 * Meeting minutes register — search, filter, add, edit, delete and multi-document upload.
 */
require_once __DIR__ . '/../config/db.php';
require_auth();

if (!function_exists('e')) { function e($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); } }
if (!function_exists('url')) { function url(string $path = ''): string { return '/modules/' . ltrim($path, '/'); } }

$page_title = 'Meeting Minutes — State Department for Medical Services';
$active_tab = 'meetings';

$can_manage     = can_edit();
$upload_dir     = __DIR__ . '/../uploads/meetings';
$allowed_ext    = ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'csv', 'txt', 'png', 'jpg', 'jpeg'];
$max_file_bytes = 10 * 1024 * 1024;
$max_files      = 10;
$filter_years   = range(2028, 2012);
$month_names    = [1 => 'January', 2 => 'February', 3 => 'March', 4 => 'April', 5 => 'May', 6 => 'June', 7 => 'July', 8 => 'August', 9 => 'September', 10 => 'October', 11 => 'November', 12 => 'December'];

if (!function_exists('meeting_excerpt')) {
    function meeting_excerpt($value, int $limit): string {
        $value = (string)$value;
        if (function_exists('mb_strimwidth')) return mb_strimwidth($value, 0, $limit, '…');
        return strlen($value) > $limit ? substr($value, 0, max(0, $limit - 3)) . '...' : $value;
    }
}
function meeting_strlen(string $value): int { return function_exists('mb_strlen') ? mb_strlen($value) : strlen($value); }
function meeting_lower(string $value): string { return function_exists('mb_strtolower') ? mb_strtolower($value) : strtolower($value); }
function meeting_size(int $bytes): string {
    if ($bytes >= 1048576) return number_format($bytes / 1048576, 1) . ' MB';
    if ($bytes >= 1024) return number_format($bytes / 1024, 0) . ' KB';
    return $bytes . ' B';
}
function meeting_normalize_files($files): array {
    $out = [];
    if (!is_array($files) || !isset($files['name'])) return $out;
    foreach ((array)$files['name'] as $i => $name) {
        $error = (int)($files['error'][$i] ?? UPLOAD_ERR_NO_FILE);
        if ($error === UPLOAD_ERR_NO_FILE) continue;
        $out[] = ['name' => (string)$name, 'tmp_name' => (string)($files['tmp_name'][$i] ?? ''), 'size' => (int)($files['size'][$i] ?? 0), 'error' => $error];
    }
    return $out;
}
function meeting_ext_class(string $ext): string {
    $ext = strtolower($ext);
    if ($ext === 'pdf') return 'ext-pdf';
    if (in_array($ext, ['doc', 'docx', 'txt'], true)) return 'ext-doc';
    if (in_array($ext, ['xls', 'xlsx', 'csv'], true)) return 'ext-xls';
    if (in_array($ext, ['ppt', 'pptx'], true)) return 'ext-ppt';
    if (in_array($ext, ['png', 'jpg', 'jpeg'], true)) return 'ext-img';
    return 'ext-other';
}
function meeting_safe_name(string $name): string {
    $name = preg_replace('/[^\w.\- ()]+/u', '_', basename($name));
    return $name === '' || $name === null ? 'document' : $name;
}
function meeting_ensure_docs_table(PDO $pdo): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `meeting_documents` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `meeting_id` int(11) NOT NULL,
        `original_name` varchar(255) NOT NULL,
        `stored_name` varchar(255) NOT NULL,
        `file_size` int(11) NOT NULL DEFAULT 0,
        `uploaded_by` varchar(150) DEFAULT NULL,
        `uploaded_at` timestamp NULL DEFAULT current_timestamp(),
        PRIMARY KEY (`id`),
        KEY `idx_meeting_id` (`meeting_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}
function meeting_ensure_action_point_links(PDO $pdo): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `meeting_action_points` (
        `meeting_id` int(11) NOT NULL,
        `action_point_id` int(11) NOT NULL,
        `linked_at` timestamp NULL DEFAULT current_timestamp(),
        PRIMARY KEY (`meeting_id`, `action_point_id`),
        KEY `idx_map_action_point_id` (`action_point_id`),
        KEY `idx_map_meeting_id` (`meeting_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}
function meeting_redirect(string $msg): void {
    $self = strtok((string)($_SERVER['REQUEST_URI'] ?? '/modules/meetings.php'), '?');
    header('Location: ' . $self . '?msg=' . rawurlencode($msg));
    exit;
}

$meetings = [];
$meeting_view = [];
$meeting_error = '';
$form_error = '';
$form_old = null;
$flash = (string)($_GET['msg'] ?? '');

if ($db_connected && $pdo) {
    try { meeting_ensure_docs_table($pdo); meeting_ensure_action_point_links($pdo); }
    catch (Throwable $error) { error_log('Meeting support table check failed: ' . $error->getMessage()); }
}

// Secure document download
if ($db_connected && $pdo && isset($_GET['download'])) {
    $key = (string)$_GET['download'];
    $path = '';
    $download_name = '';
    try {
        if (str_starts_with($key, 'legacy-')) {
            $stmt = $pdo->prepare('SELECT document FROM meetings WHERE id = ?');
            $stmt->execute([(int)substr($key, 7)]);
            $legacy = (string)$stmt->fetchColumn();
            if ($legacy !== '') { $path = $upload_dir . '/' . basename($legacy); $download_name = basename($legacy); }
        } else {
            $stmt = $pdo->prepare('SELECT original_name, stored_name FROM meeting_documents WHERE id = ?');
            $stmt->execute([(int)$key]);
            if ($doc = $stmt->fetch(PDO::FETCH_ASSOC)) { $path = $upload_dir . '/' . basename((string)$doc['stored_name']); $download_name = (string)$doc['original_name']; }
        }
    } catch (Throwable $error) { error_log('Meeting document lookup failed: ' . $error->getMessage()); }
    if ($path !== '' && is_file($path)) {
        $ext = strtolower(pathinfo($download_name, PATHINFO_EXTENSION));
        $types = ['pdf' => 'application/pdf', 'png' => 'image/png', 'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'txt' => 'text/plain; charset=utf-8', 'csv' => 'text/csv; charset=utf-8'];
        $inline = !isset($_GET['dl']) && in_array($ext, ['pdf', 'png', 'jpg', 'jpeg'], true);
        header('Content-Type: ' . ($types[$ext] ?? 'application/octet-stream'));
        header('Content-Length: ' . filesize($path));
        header('X-Content-Type-Options: nosniff');
        header('Content-Disposition: ' . ($inline ? 'inline' : 'attachment') . "; filename*=UTF-8''" . rawurlencode($download_name));
        readfile($path);
        exit;
    }
    http_response_code(404);
    echo 'The requested document could not be found.';
    exit;
}

// Create / update / delete
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = (string)($_POST['form_action'] ?? '');
    if (empty($_POST) && (int)($_SERVER['CONTENT_LENGTH'] ?? 0) > 0) {
        $form_error = 'The upload was larger than the server allows (post_max_size is ' . ini_get('post_max_size') . '). Attach fewer or smaller files and try again.';
    } elseif (!$db_connected || !$pdo) {
        $form_error = 'The database connection is unavailable.';
    } elseif (!$can_manage) {
        $form_error = 'You do not have permission to add, edit or delete meetings.';
    } elseif (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $form_error = 'Your session expired. Refresh the page and try again.';
    } elseif ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        try {
            $stmt = $pdo->prepare('SELECT title, document FROM meetings WHERE id = ?');
            $stmt->execute([$id]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$row) {
                $form_error = 'That meeting no longer exists.';
            } else {
                $stmt = $pdo->prepare('SELECT stored_name FROM meeting_documents WHERE meeting_id = ?');
                $stmt->execute([$id]);
                $files_to_remove = $stmt->fetchAll(PDO::FETCH_COLUMN);
                if (!empty($row['document'])) $files_to_remove[] = $row['document'];
                $pdo->beginTransaction();
                $pdo->prepare('DELETE FROM meeting_documents WHERE meeting_id = ?')->execute([$id]);
                $pdo->prepare('DELETE FROM meeting_action_points WHERE meeting_id = ?')->execute([$id]);
                $pdo->prepare('DELETE FROM meetings WHERE id = ?')->execute([$id]);
                $pdo->commit();
                foreach (array_unique($files_to_remove) as $stored) @unlink($upload_dir . '/' . basename((string)$stored));
                log_audit_trail('DELETE', 'Meetings', $id, 'Deleted meeting "' . $row['title'] . '"');
                meeting_redirect('deleted');
            }
        } catch (Throwable $error) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            error_log('Meeting delete failed: ' . $error->getMessage());
            $form_error = 'The meeting could not be deleted.';
        }
    } elseif ($action === 'create' || $action === 'update') {
        $id = $action === 'update' ? (int)($_POST['id'] ?? 0) : 0;
        $input = [];
        foreach (['meeting_date', 'meeting_time', 'title', 'venue', 'description', 'attendees', 'agenda', 'decisions'] as $field) {
            $input[$field] = trim((string)($_POST[$field] ?? ''));
        }
        $selected_action_point_ids = array_values(array_unique(array_filter(array_map('intval', (array)($_POST['action_point_ids'] ?? [])), static fn($v) => $v > 0)));
        $form_old = ['mode' => $action, 'id' => $id, 'fields' => $input, 'action_point_ids' => $selected_action_point_ids];
        $date_parts = explode('-', $input['meeting_date']);
        $files = meeting_normalize_files($_FILES['documents'] ?? null);

        if ($input['meeting_date'] === '' || count($date_parts) !== 3 || !checkdate((int)$date_parts[1], (int)$date_parts[2], (int)$date_parts[0])) {
            $form_error = 'Enter a valid meeting date.';
        } elseif ($input['meeting_time'] !== '' && !preg_match('/^([01]\d|2[0-3]):[0-5]\d(:[0-5]\d)?$/', $input['meeting_time'])) {
            $form_error = 'Enter a valid meeting time.';
        } elseif ($input['title'] === '') {
            $form_error = 'The meeting title is required.';
        } elseif (meeting_strlen($input['title']) > 255) {
            $form_error = 'The title may not be longer than 255 characters.';
        } elseif (meeting_strlen($input['venue']) > 150) {
            $form_error = 'The venue may not be longer than 150 characters.';
        } elseif (count($files) > $max_files) {
            $form_error = 'You can attach up to ' . $max_files . ' documents at a time.';
        } else {
            foreach (['description', 'attendees', 'agenda', 'decisions'] as $long_field) {
                if (meeting_strlen($input[$long_field]) > 20000) { $form_error = 'The ' . $long_field . ' text is too long (20,000 characters maximum).'; break; }
            }
            if ($form_error === '') {
                foreach ($files as $file) {
                    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
                    if ($file['error'] !== UPLOAD_ERR_OK) { $form_error = '"' . meeting_safe_name($file['name']) . '" could not be uploaded (the server limit is ' . ini_get('upload_max_filesize') . ' per file).'; break; }
                    if ($file['size'] > $max_file_bytes) { $form_error = '"' . meeting_safe_name($file['name']) . '" is larger than 10 MB.'; break; }
                    if (!in_array($ext, $allowed_ext, true)) { $form_error = '"' . meeting_safe_name($file['name']) . '" is not an allowed type. Allowed: ' . strtoupper(implode(', ', $allowed_ext)) . '.'; break; }
                }
            }
        }

        if ($form_error === '' && $selected_action_point_ids) {
            try {
                $marks = implode(',', array_fill(0, count($selected_action_point_ids), '?'));
                $check = $pdo->prepare("SELECT id FROM action_points WHERE id IN ($marks)");
                $check->execute($selected_action_point_ids);
                if (count($check->fetchAll(PDO::FETCH_COLUMN)) !== count($selected_action_point_ids)) {
                    $form_error = 'One or more selected action points no longer exist. Refresh and try again.';
                }
            } catch (Throwable $error) {
                error_log('Action point validation failed: ' . $error->getMessage());
                $form_error = 'Action points could not be verified. Please try again.';
            }
        }

        if ($form_error === '') {
            $moved = [];
            $unlink_after = [];
            $time_value = $input['meeting_time'] === '' ? null : substr($input['meeting_time'], 0, 5) . ':00';
            $values = [
                $input['meeting_date'], $time_value, $input['title'],
                $input['description'] !== '' ? $input['description'] : null,
                $input['venue'] !== '' ? $input['venue'] : null,
                $input['attendees'] !== '' ? $input['attendees'] : null,
                $input['agenda'] !== '' ? $input['agenda'] : null,
                $input['decisions'] !== '' ? $input['decisions'] : null,
            ];
            try {
                $pdo->beginTransaction();
                $legacy = null;
                $legacy_is_orphan = false;
                if ($action === 'create') {
                    $pdo->prepare('INSERT INTO meetings (meeting_date, meeting_time, title, description, venue, attendees, agenda, decisions) VALUES (?,?,?,?,?,?,?,?)')->execute($values);
                    $id = (int)$pdo->lastInsertId();
                } else {
                    $stmt = $pdo->prepare('SELECT document FROM meetings WHERE id = ? FOR UPDATE');
                    $stmt->execute([$id]);
                    $existing = $stmt->fetch(PDO::FETCH_ASSOC);
                    if (!$existing) throw new RuntimeException('That meeting no longer exists.');
                    $legacy = (string)($existing['document'] ?? '');
                    $stmt = $pdo->prepare('SELECT stored_name FROM meeting_documents WHERE meeting_id = ?');
                    $stmt->execute([$id]);
                    $legacy_is_orphan = $legacy !== '' && !in_array($legacy, $stmt->fetchAll(PDO::FETCH_COLUMN), true);
                    $pdo->prepare('UPDATE meetings SET meeting_date=?, meeting_time=?, title=?, description=?, venue=?, attendees=?, agenda=?, decisions=? WHERE id=?')->execute(array_merge($values, [$id]));

                    $remove_ids = array_values(array_filter(array_map('intval', (array)($_POST['remove_docs'] ?? []))));
                    if ($remove_ids) {
                        $marks = implode(',', array_fill(0, count($remove_ids), '?'));
                        $stmt = $pdo->prepare("SELECT id, stored_name FROM meeting_documents WHERE meeting_id = ? AND id IN ($marks)");
                        $stmt->execute(array_merge([$id], $remove_ids));
                        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $gone) {
                            $pdo->prepare('DELETE FROM meeting_documents WHERE id = ?')->execute([(int)$gone['id']]);
                            $unlink_after[] = (string)$gone['stored_name'];
                        }
                    }
                }

                // Synchronize this meeting's links without changing other meetings' links.
                $pdo->prepare('DELETE FROM meeting_action_points WHERE meeting_id = ?')->execute([$id]);
                if ($selected_action_point_ids) {
                    $link = $pdo->prepare('INSERT INTO meeting_action_points (meeting_id, action_point_id) VALUES (?, ?)');
                    foreach ($selected_action_point_ids as $apId) $link->execute([$id, $apId]);
                }

                $remove_legacy = $legacy_is_orphan && !empty($_POST['remove_legacy']);
                if ($remove_legacy) $unlink_after[] = $legacy;

                if ($files) {
                    if (!is_dir($upload_dir) && !@mkdir($upload_dir, 0755, true)) throw new RuntimeException('The uploads folder could not be created.');
                    @file_put_contents($upload_dir . '/.htaccess', "Require all denied\nDeny from all\n");
                    $uploader = get_current_user_data()['full_name'] ?? null;
                    foreach ($files as $file) {
                        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
                        $stored = bin2hex(random_bytes(16)) . '.' . $ext;
                        if (!move_uploaded_file($file['tmp_name'], $upload_dir . '/' . $stored)) throw new RuntimeException('The server could not save "' . meeting_safe_name($file['name']) . '". Check that uploads/meetings is writable.');
                        $moved[] = $upload_dir . '/' . $stored;
                        $pdo->prepare('INSERT INTO meeting_documents (meeting_id, original_name, stored_name, file_size, uploaded_by) VALUES (?,?,?,?,?)')
                            ->execute([$id, meeting_safe_name($file['name']), $stored, $file['size'], $uploader]);
                    }
                }

                $stmt = $pdo->prepare('SELECT stored_name FROM meeting_documents WHERE meeting_id = ? ORDER BY id LIMIT 1');
                $stmt->execute([$id]);
                $first = $stmt->fetchColumn();
                if ($legacy_is_orphan && !$remove_legacy) $primary = $legacy;
                elseif ($first) $primary = (string)$first;
                else $primary = null;
                $pdo->prepare('UPDATE meetings SET document = ? WHERE id = ?')->execute([$primary, $id]);

                $pdo->commit();
                foreach ($unlink_after as $stored) @unlink($upload_dir . '/' . basename($stored));
                log_audit_trail($action === 'create' ? 'CREATE' : 'UPDATE', 'Meetings', $id, ($action === 'create' ? 'Added' : 'Edited') . ' meeting "' . $input['title'] . '"' . ($files ? ' with ' . count($files) . ' new document(s)' : ''));
                meeting_redirect($action === 'create' ? 'created' : 'updated');
            } catch (Throwable $error) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                foreach ($moved as $path) @unlink($path);
                error_log('Meeting save failed: ' . $error->getMessage());
                $form_error = $error instanceof RuntimeException ? $error->getMessage() : 'The meeting could not be saved. Please try again.';
            }
        }
    }
}

// Load records
$action_points = [];
$action_points_by_meeting = [];
if ($db_connected && $pdo) {
    try {
        $meetings = $pdo->query('SELECT id, meeting_date, meeting_time, title, description, venue, attendees, agenda, decisions, document FROM meetings ORDER BY meeting_date DESC, meeting_time DESC, id DESC')->fetchAll(PDO::FETCH_ASSOC);
        $action_points = $pdo->query('SELECT id, ref_no, meeting_title, issue, status FROM action_points ORDER BY action_date DESC, id DESC')->fetchAll(PDO::FETCH_ASSOC);
        foreach ($pdo->query('SELECT meeting_id, action_point_id FROM meeting_action_points')->fetchAll(PDO::FETCH_ASSOC) as $linkRow) {
            $action_points_by_meeting[(int)$linkRow['meeting_id']][] = (int)$linkRow['action_point_id'];
        }
        $docs_by_meeting = [];
        try {
            foreach ($pdo->query('SELECT id, meeting_id, original_name, stored_name, file_size FROM meeting_documents ORDER BY id')->fetchAll(PDO::FETCH_ASSOC) as $doc) {
                $docs_by_meeting[(int)$doc['meeting_id']][] = $doc;
            }
        } catch (Throwable $error) { error_log('Meeting documents query failed: ' . $error->getMessage()); }

        foreach ($meetings as $m) {
            $mid = (int)$m['id'];
            $docs = [];
            $stored_names = [];
            foreach ($docs_by_meeting[$mid] ?? [] as $doc) {
                $docs[] = ['key' => (string)$doc['id'], 'id' => (int)$doc['id'], 'name' => (string)$doc['original_name'], 'size' => meeting_size((int)$doc['file_size']), 'ext' => strtoupper(pathinfo((string)$doc['original_name'], PATHINFO_EXTENSION)), 'cls' => meeting_ext_class(pathinfo((string)$doc['original_name'], PATHINFO_EXTENSION))];
                $stored_names[] = (string)$doc['stored_name'];
            }
            $legacy = (string)($m['document'] ?? '');
            if ($legacy !== '' && !in_array($legacy, $stored_names, true)) {
                array_unshift($docs, ['key' => 'legacy-' . $mid, 'id' => 0, 'name' => basename($legacy), 'size' => '', 'legacy' => true, 'ext' => strtoupper(pathinfo($legacy, PATHINFO_EXTENSION)), 'cls' => meeting_ext_class(pathinfo($legacy, PATHINFO_EXTENSION))]);
            }
            $date = (string)($m['meeting_date'] ?? '');
            $time = (string)($m['meeting_time'] ?? '');
            $ts = $date !== '' ? strtotime($date) : false;
            $time_label = $time !== '' ? date('g:i A', strtotime($time)) : '—';
            $haystack = [$m['title'], $m['venue'], $m['description'], $m['attendees'], $m['agenda'], $m['decisions'], $date, $time !== '' ? substr($time, 0, 5) : '', $time !== '' ? $time_label : ''];
            if ($ts) { $haystack[] = date('d F Y', $ts); $haystack[] = date('j M Y', $ts); $haystack[] = date('l', $ts); }
            $linked_ap_ids = $action_points_by_meeting[$mid] ?? [];
            foreach ($action_points as $ap) {
                if (($ap['meeting_title'] ?? '') === (string)$m['title']) $linked_ap_ids[] = (int)$ap['id'];
            }
            $linked_ap_ids = array_values(array_unique($linked_ap_ids));
            foreach ($action_points as $ap) {
                if (in_array((int)$ap['id'], $linked_ap_ids, true)) {
                    $haystack[] = (string)($ap['ref_no'] ?? '');
                    $haystack[] = (string)($ap['issue'] ?? '');
                    $haystack[] = (string)($ap['status'] ?? '');
                }
            }
            foreach ($docs as $d) $haystack[] = $d['name'];
            $meeting_view[] = [
                'id' => $mid, 'date' => $date, 'date_label' => $ts ? date('d M Y', $ts) : '—',
                'year' => $date !== '' ? substr($date, 0, 4) : '', 'month' => $date !== '' ? substr($date, 5, 2) : '',
                'time' => $time !== '' ? substr($time, 0, 5) : '', 'time_label' => $time_label,
                'title' => (string)$m['title'], 'description' => (string)($m['description'] ?? ''), 'venue' => (string)($m['venue'] ?? ''),
                'attendees' => (string)($m['attendees'] ?? ''), 'agenda' => (string)($m['agenda'] ?? ''), 'decisions' => (string)($m['decisions'] ?? ''),
                'action_point_ids' => $linked_ap_ids, 'docs' => $docs, 'search' => meeting_lower(implode(' ', array_map('strval', $haystack))),
            ];
        }
    } catch (Throwable $error) {
        error_log('Meeting minutes query failed: ' . $error->getMessage());
        $meeting_error = 'Meeting records could not be loaded from the database. If you have just updated the code, run meetings_migration.sql to add the meeting_time column.';
    }
} else { $meeting_error = 'The database connection is unavailable.'; }

$json_flags = JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE;
$col_count = 6;
require_once __DIR__ . '/../includes/header.php';
?>
<style>
    .meetings-page{display:flex;flex-direction:column;gap:18px}
    .meetings-head{display:flex;align-items:flex-end;justify-content:space-between;gap:14px;flex-wrap:wrap}
    .meetings-head h2{margin:0;color:#102c53;font-size:1.35rem;font-weight:800}
    .meetings-head p{margin:5px 0 0;color:#64748b;font-size:.84rem}
    .meetings-head-actions{display:flex;align-items:center;gap:10px}
    .meeting-btn{display:inline-flex;align-items:center;gap:6px;padding:9px 15px;border:0;border-radius:7px;background:#0d47a1;color:#fff;font:inherit;font-weight:700;font-size:.85rem;cursor:pointer;transition:.15s}
    .meeting-btn:hover{filter:brightness(1.1);transform:translateY(-1px)}.meeting-btn[disabled]{opacity:.6;cursor:wait;transform:none}
    .meeting-btn.green{background:#10b981}.meeting-btn.secondary{background:#2563eb}.meeting-btn.alt{background:#0369a1}
    .meetings-filter{display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end;padding:14px;background:#fff;border:1px solid #dce4ef;border-radius:8px}
    .meetings-filter label{display:flex;flex-direction:column;gap:4px;font-size:.7rem;font-weight:700;color:#52647c;text-transform:uppercase;letter-spacing:.04em}
    .meetings-filter input,.meetings-filter select{min-height:40px;padding:8px 11px;border:1px solid #dce4ef;border-radius:6px;background:#f8fafc;color:#1e293b;font:inherit;text-transform:none;letter-spacing:0;font-weight:400}
    .meetings-filter .f-search{flex:1 1 280px}.meetings-filter .f-search input{width:100%}
    .meetings-filter input:disabled,.meetings-filter select:disabled{opacity:.55}
    .meetings-filter-meta{display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;margin-top:-8px;color:#64748b;font-size:.76rem}
    .meetings-table-wrap{overflow:auto;background:#fff;border:1px solid #dce4ef;border-radius:8px;box-shadow:0 2px 5px rgba(15,23,42,.04)}
    .meetings-table{width:100%;border-collapse:collapse;min-width:980px;font-size:.84rem}
    .meetings-table th{padding:13px 15px;text-align:left;background:#f8fafc;color:#52647c;border-bottom:1px solid #dce4ef;font-size:.72rem;letter-spacing:.05em;text-transform:uppercase}
    .meetings-table td{padding:14px 15px;border-bottom:1px solid #edf1f6;vertical-align:top;color:#334155}
    .meetings-table tr:last-child td{border-bottom:0}
    .meetings-date{white-space:nowrap;color:#0d47a1!important;font-weight:700}
    .meetings-title{color:#102c53;font-weight:750}.meetings-sub{margin-top:4px;color:#64748b;font-size:.78rem}
    .meeting-details{max-width:380px;line-height:1.5}
    .meeting-read{display:inline-flex;align-items:center;justify-content:center;gap:5px;min-width:96px;padding:7px 12px;border:0;border-radius:6px;background:#1976d2;color:#fff;font:inherit;font-weight:700;font-size:.8rem;cursor:pointer;text-decoration:none;transition:.15s}
    .meeting-read:hover{filter:brightness(1.1);transform:translateY(-1px)}
    .meeting-btn.green,.meeting-btn.green:hover{background:#1976d2}
    .act-menu{display:none;position:fixed;z-index:1000;min-width:130px;flex-direction:column;gap:4px;padding:6px;background:#fff;border:1px solid #dce4ef;border-radius:8px;box-shadow:0 8px 20px rgba(15,23,42,.18)}
    .act-menu.is-open{display:flex}.act-menu .meeting-read{width:100%;justify-content:flex-start}
    .meeting-docs{display:flex;flex-direction:column;gap:5px;margin-bottom:8px}.meeting-docs{gap:6px}
    .meeting-doc{display:flex;align-items:center;gap:8px;max-width:260px;padding:5px 6px 5px 5px;border:1px solid #cfe0fb;border-radius:999px;background:linear-gradient(90deg,#f1f6ff,#fff);color:#0d3b8c;font-size:.78rem;font-weight:600;text-decoration:none;transition:.15s}
    .meeting-doc:hover{border-color:#10b981;box-shadow:0 2px 8px rgba(16,185,129,.22);transform:translateY(-1px)}
    .meeting-doc .nm{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
    .meeting-doc .vw{padding:3px 10px;border-radius:999px;background:#10b981;color:#fff;font-size:.68rem;font-weight:800;letter-spacing:.03em;text-transform:uppercase}
    .ext-badge{display:inline-flex;align-items:center;justify-content:center;min-width:34px;height:22px;padding:0 6px;border-radius:999px;color:#fff;font-size:.6rem;font-weight:800;letter-spacing:.04em;background:#64748b}
    .ext-pdf{background:#e5484d}.ext-doc{background:#1d6fe0}.ext-xls{background:#16a34a}.ext-ppt{background:#f08a24}.ext-img{background:#8b5cf6}.ext-other{background:#64748b}
    dialog.md-dialog{position:fixed;inset:0;margin:auto;width:min(760px,calc(100% - 28px));max-height:calc(100vh - 48px);padding:0;border:0;border-radius:14px;overflow:hidden;background:#fff;box-shadow:0 30px 80px rgba(11,61,145,.35)}
    dialog.md-dialog[open]{display:flex;flex-direction:column;animation:mdPop .2s ease-out}
    dialog.md-dialog::backdrop{background:rgba(15,23,42,.55);backdrop-filter:blur(3px)}
    @keyframes mdPop{from{opacity:0;transform:translateY(12px) scale(.98)}to{opacity:1;transform:none}}
    .md-hero{position:relative;padding:24px 28px 22px;color:#fff;background:#1565c0}
    .md-eyebrow{display:inline-block;padding:3px 11px;border-radius:999px;background:rgba(255,255,255,.2);color:#fff;font-size:.66rem;font-weight:800;letter-spacing:.09em;text-transform:uppercase}
    .md-hero h3{margin:12px 44px 14px 0;color:#fff;font-size:1.4rem;line-height:1.25;font-weight:800}
    .md-chips{display:flex;flex-wrap:wrap;gap:8px}.md-chip{display:inline-flex;align-items:center;gap:6px;padding:6px 13px;border-radius:999px;background:rgba(255,255,255,.16);border:1px solid rgba(255,255,255,.35);font-size:.8rem;font-weight:600}
    .md-chip[hidden]{display:none}
    .md-close{position:absolute;right:16px;top:16px;width:34px;height:34px;border:0;border-radius:50%;background:rgba(255,255,255,.2);color:#fff;font-size:1.4rem;line-height:1;cursor:pointer;transition:.15s}
    .md-close:hover{background:#10b981;transform:rotate(90deg)}
    .md-body{flex:1;overflow:auto;padding:6px 28px 8px;background:#fff}
    .md-card{padding:16px 0;border:0;border-bottom:1px solid #d1d5db;background:transparent;box-shadow:none}.md-card:last-child{border-bottom:0}
    .md-card h4{margin:0 0 7px;display:flex;align-items:center;gap:8px;color:#0b3d91;font-size:.8rem;font-weight:800;letter-spacing:.05em;text-transform:uppercase}
    .md-card p{margin:0;color:#334155;line-height:1.6;white-space:pre-wrap;font-size:.9rem}
    .md-count{margin-left:auto;padding:2px 9px;border-radius:999px;background:#e0efff;color:#0b3d91;font-size:.7rem}
    .md-docs{display:flex;flex-direction:column;gap:9px;margin-top:4px}
    .md-doc{display:flex;align-items:center;gap:12px;padding:10px 12px;border-radius:10px;background:#f8fafc;border:1px solid #e5e7eb;transition:.15s}
    .md-doc:hover{border-color:#10b981;box-shadow:0 3px 10px rgba(16,185,129,.15)}
    .md-doc .ext-badge{min-width:46px;height:40px;border-radius:10px;font-size:.7rem}
    .md-doc-info{flex:1;min-width:0}.md-doc-name{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#0b3d91;font-weight:700;font-size:.88rem}
    .md-doc-size{display:block;margin-top:2px;color:#64748b;font-size:.74rem}
    .md-btn{display:inline-flex;align-items:center;gap:5px;padding:7px 14px;border-radius:8px;font-size:.78rem;font-weight:800;text-decoration:none;white-space:nowrap;color:#fff;transition:.15s}
    .md-btn:hover{filter:brightness(1.1);transform:translateY(-1px)}.md-btn.view{background:#10b981}.md-btn.dl{background:#1565c0}
    .md-none{color:#64748b;font-size:.86rem;font-style:italic}
    .md-foot{display:flex;justify-content:flex-end;padding:12px 28px 16px;background:#fff;border-top:1px solid #d1d5db}
    @media(max-width:560px){.md-doc{flex-wrap:wrap}.md-doc-info{flex-basis:calc(100% - 70px)}.md-hero h3{font-size:1.15rem}}
</style>


<style>
    .meeting-actions{display:flex;flex-direction:column;gap:6px;align-items:flex-start}
    .meeting-empty{padding:25px!important;text-align:center;color:#64748b!important}
    .meetings-alert{padding:12px 14px;border-radius:7px;background:#fff7ed;border:1px solid #fed7aa;color:#9a3412}
    .meetings-ok{padding:12px 14px;border-radius:7px;background:#ecfdf5;border:1px solid #10b981;color:#065f46;font-weight:600}
    .meetings-err{padding:12px 14px;border-radius:7px;background:#fef2f2;border:1px solid #fca5a5;color:#991b1b;font-weight:600}
    dialog.meeting-dialog{width:min(760px,calc(100% - 28px));max-height:calc(100vh - 40px);border:0;border-radius:12px;padding:0;color:#1e293b;box-shadow:0 20px 60px #0f172a44}
    dialog.meeting-dialog::backdrop{background:rgba(15,23,42,.45)}
    .meeting-dialog-body{padding:22px 24px;overflow:auto;max-height:calc(100vh - 40px)}
    .meeting-dialog h3{margin:0 0 4px;color:#102c53}.meeting-dialog h4{margin:16px 0 4px;color:#102c53}
    .meeting-dialog .close-x{float:right;border:0;background:transparent;font-size:1.5rem;line-height:1;cursor:pointer;color:#64748b}
    .mf-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-top:14px}
    .mf-grid .full{grid-column:1/-1}
    .mf-field{display:flex;flex-direction:column;gap:5px;font-size:.78rem;font-weight:700;color:#334155}
    .mf-field input,.mf-field textarea{padding:9px 11px;border:1px solid #cbd5e1;border-radius:6px;font:inherit;font-weight:400;color:#1e293b;background:#fff}
    .mf-field textarea{min-height:88px;resize:vertical}
    .mf-field input:focus,.mf-field textarea:focus{outline:2px solid #bfdbfe;border-color:#0d47a1}
    .mf-req{color:#b91c1c}.mf-hint{font-weight:400;color:#64748b;font-size:.74rem}
    .mf-existing{display:flex;flex-direction:column;gap:6px;margin:0;padding:0;list-style:none}
    .mf-existing li{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:8px 10px;border:1px solid #e2e8f0;border-radius:6px;background:#f8fafc;font-weight:400}
    .mf-existing a{color:#0d47a1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:600;text-decoration:none}
    .mf-existing label{display:flex;align-items:center;gap:5px;color:#b91c1c;font-size:.76rem;white-space:nowrap;font-weight:600}
    .mf-filelist{margin:6px 0 0;padding-left:18px;font-size:.78rem;color:#334155;font-weight:400}
    .mf-filemsg{margin-top:6px;color:#b91c1c;font-size:.78rem;font-weight:600}
    .mf-footer{display:flex;justify-content:flex-end;gap:10px;margin-top:20px}
    .mf-action-point-list{display:grid;grid-template-columns:1fr 1fr;gap:8px;max-height:230px;overflow:auto;padding:10px;border:1px solid #dce4ef;border-radius:7px;background:#f8fafc}
    .mf-action-point{display:flex;align-items:flex-start;gap:8px;padding:9px;border:1px solid #e2e8f0;border-radius:6px;background:#fff;font-size:.78rem;font-weight:400;line-height:1.4}
    .mf-action-point input{margin-top:3px;flex:0 0 auto}.mf-action-point strong{color:#0d47a1}.mf-action-point small{display:block;margin-top:3px;color:#64748b}.mf-action-point[hidden]{display:none}
    @media(max-width:700px){.meetings-table{min-width:820px}.mf-grid{grid-template-columns:1fr}.mf-action-point-list{grid-template-columns:1fr}}
</style>

<div class="meetings-page">
    <header class="meetings-head">
        <div><h2>Meeting Minutes</h2><p>Minutes and decisions from partner and steering committee meetings.</p></div>
        <div class="meetings-head-actions">
            <span class="status-pill"><?= count($meetings) ?> record<?= count($meetings) === 1 ? '' : 's' ?></span>
            <?php if ($can_manage): ?><button type="button" class="meeting-btn green" id="addMeetingBtn">+ Add Meeting</button><?php endif; ?>
        </div>
    </header>

    <?php if ($flash === 'created'): ?><div class="meetings-ok" role="status">The meeting was added.</div><?php endif; ?>
    <?php if ($flash === 'updated'): ?><div class="meetings-ok" role="status">The meeting was updated.</div><?php endif; ?>
    <?php if ($flash === 'deleted'): ?><div class="meetings-ok" role="status">The meeting and its documents were deleted.</div><?php endif; ?>
    <?php if ($form_error !== ''): ?><div class="meetings-err" role="alert"><?= e($form_error) ?></div><?php endif; ?>
    <?php if ($meeting_error !== ''): ?><div class="meetings-alert" role="status"><?= e($meeting_error) ?></div><?php endif; ?>

    <div class="meetings-filter" role="search">
        <label class="f-search">Smart search
            <input id="meetingSearch" type="search" placeholder="e.g. global fund teams  ·  &quot;exact phrase&quot;  ·  -virtual" aria-label="Search meetings" autocomplete="off">
        </label>
        <label>Year
            <select id="meetingYear" aria-label="Filter by year"><option value="">All years</option>
                <?php foreach ($filter_years as $year): ?><option value="<?= $year ?>"><?= $year ?></option><?php endforeach; ?>
            </select>
        </label>
        <label>Month
            <select id="meetingMonth" aria-label="Filter by month"><option value="">All months</option>
                <?php foreach ($month_names as $num => $name): ?><option value="<?= sprintf('%02d', $num) ?>"><?= e($name) ?></option><?php endforeach; ?>
            </select>
        </label>
        <label>Exact date
            <input id="meetingDate" type="date" aria-label="Filter by exact date">
        </label>
        <button type="button" class="meeting-btn secondary" id="meetingClear">Clear filters</button>
    </div>
    <div class="meetings-filter-meta"><span id="meetingCount">&nbsp;</span></div>

    <div class="meetings-table-wrap"><table class="meetings-table">
        <thead><tr><th>Meeting Date</th><th>Time</th><th>Title &amp; Venue</th><th>Linked Action Points</th><th>Minutes</th><th>Actions</th></tr></thead>
        <tbody id="meetingRows">
        <?php foreach ($meeting_view as $m): ?>
            <tr data-id="<?= (int)$m['id'] ?>" data-year="<?= e($m['year']) ?>" data-month="<?= e($m['month']) ?>" data-date="<?= e($m['date']) ?>" data-search="<?= e($m['search']) ?>">
                <td class="meetings-date"><?= e($m['date_label']) ?></td>
                <td class="meetings-date"><?= e($m['time_label']) ?></td>
                <td><div class="meetings-title"><?= e($m['title']) ?></div><div class="meetings-sub">Venue: <?= e($m['venue'] !== '' ? $m['venue'] : 'Not recorded') ?></div></td>
                <td class="meeting-details">
                    <details><summary>View linked action points (<?= count($m['action_point_ids']) ?>)</summary>
                        <div class="meeting-linked-actions">
                        <?php $linkedActions = array_values(array_filter($action_points, static fn($ap) => in_array((int)$ap['id'], $m['action_point_ids'], true))); ?>
                        <?php if ($linkedActions): foreach ($linkedActions as $ap): ?>
                            <div style="padding:6px 0;border-bottom:1px solid #e2e8f0">
                                <strong><?= e($ap['ref_no']) ?></strong> — <?= e($ap['issue']) ?>
                                <a href="/modules/actions.php?q=<?= e(rawurlencode($ap['ref_no'])) ?>">View details</a>
                                <div class="meetings-sub">Status: <?= e($ap['status'] ?? 'Unspecified') ?></div>
                            </div>
                        <?php endforeach; else: ?><span class="meetings-sub">No linked action points.</span><?php endif; ?>
                        </div>
                    </details>
                </td>
                <td><?php if ($m['docs']): ?><div class="meeting-docs"><?php $d = $m['docs'][0]; ?><a class="meeting-doc" href="?download=<?= e(rawurlencode($d['key'])) ?>" title="Download meeting minutes"><span class="vw">Download minutes</span></a></div><?php endif; ?></td>
                <td><div class="meeting-actions">
                    <button class="meeting-read act-toggle" type="button" aria-haspopup="true" aria-expanded="false">Actions ▾</button>
                    <div class="act-menu" role="menu">
                        <button class="meeting-read" type="button" role="menuitem" data-detail="<?= (int)$m['id'] ?>">View</button>
                        <?php if ($can_manage): ?>
                        <button class="meeting-read" type="button" role="menuitem" data-edit="<?= (int)$m['id'] ?>">Edit</button>
                        <button class="meeting-read" type="button" role="menuitem" data-delete="<?= (int)$m['id'] ?>">Delete</button>
                        <?php endif; ?>
                    </div>
                </div></td>
            </tr>
        <?php endforeach; ?>
        <tr id="meetingNoResults"<?= $meetings ? ' hidden' : '' ?>><td class="meeting-empty" colspan="<?= $col_count ?>"><?= $meetings ? 'No meetings match these filters.' : 'No meeting minutes have been recorded.' ?></td></tr>
        </tbody>
    </table></div>
</div>

<dialog id="meetingDetailDialog" class="md-dialog" aria-labelledby="meetingDetailTitle">
    <div class="md-hero">
        <form method="dialog"><button class="md-close" aria-label="Close">×</button></form>
        <span class="md-eyebrow">Meeting Minutes</span>
        <h3 id="meetingDetailTitle"></h3>
        <div class="md-chips"><span class="md-chip" id="mdDate"></span><span class="md-chip" id="mdTime"></span><span class="md-chip" id="mdVenue"></span></div>
    </div>
    <div class="md-body">
        <section class="md-card"><h4>📝 Description</h4><p id="meetingDetailDescription"></p></section>
        <section class="md-card"><h4>📋 Agenda</h4><p id="meetingDetailAgenda"></p></section>
        <section class="md-card"><h4>✅ Decisions and outcomes</h4><p id="meetingDetailDecisions"></p></section>
        <section class="md-card"><h4>👥 Attendees</h4><p id="meetingDetailAttendees"></p></section>
        <section class="md-card"><h4>📎 Documents <span class="md-count" id="mdDocCount">0</span></h4><div id="meetingDetailDocs" class="md-docs"></div></section>
    </div>
    <div class="md-foot"><form method="dialog"><button class="meeting-btn">Close</button></form></div>
</dialog>

<?php if ($can_manage): ?>
<dialog id="meetingFormDialog" class="meeting-dialog"><div class="meeting-dialog-body">
    <button type="button" class="close-x" id="mfClose" aria-label="Close">×</button>
    <h3 id="mfHeading">Add New Meeting</h3>
    <p class="mf-hint" style="margin:0">Fields marked <span class="mf-req">*</span> are required.</p>
    <form method="post" enctype="multipart/form-data" id="meetingForm" autocomplete="off">
        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
        <input type="hidden" name="form_action" id="mfMode" value="create">
        <input type="hidden" name="id" id="mfId" value="">
        <div class="mf-grid">
            <label class="mf-field">Meeting date <span class="mf-req">*</span><input type="date" name="meeting_date" id="mfDate" required></label>
            <label class="mf-field">Meeting time<input type="time" name="meeting_time" id="mfTime"></label>
            <label class="mf-field full">Meeting title <span class="mf-req">*</span><input type="text" name="title" id="mfTitle" maxlength="255" required></label>
            <label class="mf-field full">Venue<input type="text" name="venue" id="mfVenue" maxlength="150"></label>
            <label class="mf-field full">Description<textarea name="description" id="mfDescription" maxlength="20000"></textarea></label>
            <label class="mf-field full">Attendees<textarea name="attendees" id="mfAttendees" maxlength="20000"></textarea></label>
            <label class="mf-field full">Agenda<textarea name="agenda" id="mfAgenda" maxlength="20000"></textarea></label>
            <label class="mf-field full">Decisions and outcomes<textarea name="decisions" id="mfDecisions" maxlength="20000"></textarea></label>
            <div class="mf-field full">
                <label for="mfActionPointSearch">Link to Existing Action Point(s)</label>
                <input type="search" id="mfActionPointSearch" placeholder="Search by reference, issue or status…">
                <span class="mf-hint">Select one or more action points. An action point may be linked to multiple meetings.</span>
                <div class="mf-action-point-list" id="mfActionPointList">
                    <?php foreach ($action_points as $ap): ?>
                    <label class="mf-action-point" data-search="<?= e(meeting_lower(($ap['ref_no'] ?? '') . ' ' . ($ap['issue'] ?? '') . ' ' . ($ap['status'] ?? '') . ' ' . ($ap['meeting_title'] ?? ''))) ?>">
                        <input type="checkbox" name="action_point_ids[]" value="<?= (int)$ap['id'] ?>">
                        <span><strong><?= e($ap['ref_no'] ?: ('Action point #' . $ap['id'])) ?></strong><small><?= e($ap['issue']) ?><br>Status: <?= e($ap['status'] ?? 'Unspecified') ?></small></span>
                    </label>
                    <?php endforeach; ?>
                    <?php if (!$action_points): ?><span class="mf-hint">No action points are available to link.</span><?php endif; ?>
                </div>
            </div>
            <div class="mf-field full" id="mfExistingWrap" hidden>
                <label>Existing documents <span class="mf-hint">Tick Remove to delete a file.</span></label>
                <ul class="mf-existing" id="mfExisting"></ul>
            </div>
            <label class="mf-field full">Attach documents <span class="mf-hint">PDF, Word, Excel, PowerPoint, CSV, TXT, PNG or JPG. Up to 10 files, 10 MB each.</span>
                <input type="file" name="documents[]" id="mfFiles" multiple accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.csv,.txt,.png,.jpg,.jpeg">
                <ul class="mf-filelist" id="mfFileList"></ul><div class="mf-filemsg" id="mfFileMsg"></div>
            </label>
        </div>
        <div class="mf-footer">
            <button type="button" class="meeting-btn secondary" id="mfCancel">Cancel</button>
            <button type="submit" class="meeting-btn green" id="mfSubmit">Save Meeting</button>
        </div>
    </form>
</div></dialog>

<form method="post" id="meetingDeleteForm" hidden>
    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
    <input type="hidden" name="form_action" value="delete">
    <input type="hidden" name="id" id="mdId" value="">
</form>
<?php endif; ?>

<style>
    .meeting-actions{display:flex;flex-direction:column;gap:6px;align-items:flex-start}
    .meeting-empty{padding:25px!important;text-align:center;color:#64748b!important}
    .meetings-alert{padding:12px 14px;border-radius:7px;background:#fff7ed;border:1px solid #fed7aa;color:#9a3412}
    .meetings-ok{padding:12px 14px;border-radius:7px;background:#ecfdf5;border:1px solid #10b981;color:#065f46;font-weight:600}
    .meetings-err{padding:12px 14px;border-radius:7px;background:#fef2f2;border:1px solid #fca5a5;color:#991b1b;font-weight:600}
    dialog.meeting-dialog{width:min(760px,calc(100% - 28px));max-height:calc(100vh - 40px);border:0;border-radius:12px;padding:0;color:#1e293b;box-shadow:0 20px 60px #0f172a44}
    dialog.meeting-dialog::backdrop{background:rgba(15,23,42,.45)}
    .meeting-dialog-body{padding:22px 24px;overflow:auto;max-height:calc(100vh - 40px)}
    .meeting-dialog h3{margin:0 0 4px;color:#102c53}.meeting-dialog h4{margin:16px 0 4px;color:#102c53}
    .meeting-dialog .close-x{float:right;border:0;background:transparent;font-size:1.5rem;line-height:1;cursor:pointer;color:#64748b}
    .mf-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-top:14px}
    .mf-grid .full{grid-column:1/-1}
    .mf-field{display:flex;flex-direction:column;gap:5px;font-size:.78rem;font-weight:700;color:#334155}
    .mf-field input,.mf-field textarea{padding:9px 11px;border:1px solid #cbd5e1;border-radius:6px;font:inherit;font-weight:400;color:#1e293b;background:#fff}
    .mf-field textarea{min-height:88px;resize:vertical}
    .mf-field input:focus,.mf-field textarea:focus{outline:2px solid #bfdbfe;border-color:#0d47a1}
    .mf-req{color:#b91c1c}.mf-hint{font-weight:400;color:#64748b;font-size:.74rem}
    .mf-existing{display:flex;flex-direction:column;gap:6px;margin:0;padding:0;list-style:none}
    .mf-existing li{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:8px 10px;border:1px solid #e2e8f0;border-radius:6px;background:#f8fafc;font-weight:400}
    .mf-existing a{color:#0d47a1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:600;text-decoration:none}
    .mf-existing label{display:flex;align-items:center;gap:5px;color:#b91c1c;font-size:.76rem;white-space:nowrap;font-weight:600}
    .mf-filelist{margin:6px 0 0;padding-left:18px;font-size:.78rem;color:#334155;font-weight:400}
    .mf-filemsg{margin-top:6px;color:#b91c1c;font-size:.78rem;font-weight:600}
    .mf-footer{display:flex;justify-content:flex-end;gap:10px;margin-top:20px}
    .mf-action-point-list{display:grid;grid-template-columns:1fr 1fr;gap:8px;max-height:230px;overflow:auto;padding:10px;border:1px solid #dce4ef;border-radius:7px;background:#f8fafc}
    .mf-action-point{display:flex;align-items:flex-start;gap:8px;padding:9px;border:1px solid #e2e8f0;border-radius:6px;background:#fff;font-size:.78rem;font-weight:400;line-height:1.4}
    .mf-action-point input{margin-top:3px;flex:0 0 auto}.mf-action-point strong{color:#0d47a1}.mf-action-point small{display:block;margin-top:3px;color:#64748b}.mf-action-point[hidden]{display:none}
    @media(max-width:700px){.meetings-table{min-width:820px}.mf-grid{grid-template-columns:1fr}.mf-action-point-list{grid-template-columns:1fr}}
</style>

<div class="meetings-page">
    <header class="meetings-head">
        <div><h2>Meeting Minutes</h2><p>Minutes and decisions from partner and steering committee meetings.</p></div>
        <div class="meetings-head-actions">
            <span class="status-pill"><?= count($meetings) ?> record<?= count($meetings) === 1 ? '' : 's' ?></span>
            <?php if ($can_manage): ?><button type="button" class="meeting-btn green" id="addMeetingBtn">+ Add Meeting</button><?php endif; ?>
        </div>
    </header>

    <?php if ($flash === 'created'): ?><div class="meetings-ok" role="status">The meeting was added.</div><?php endif; ?>
    <?php if ($flash === 'updated'): ?><div class="meetings-ok" role="status">The meeting was updated.</div><?php endif; ?>
    <?php if ($flash === 'deleted'): ?><div class="meetings-ok" role="status">The meeting and its documents were deleted.</div><?php endif; ?>
    <?php if ($form_error !== ''): ?><div class="meetings-err" role="alert"><?= e($form_error) ?></div><?php endif; ?>
    <?php if ($meeting_error !== ''): ?><div class="meetings-alert" role="status"><?= e($meeting_error) ?></div><?php endif; ?>

    <div class="meetings-filter" role="search">
        <label class="f-search">Smart search
            <input id="meetingSearch" type="search" placeholder="e.g. global fund teams  ·  &quot;exact phrase&quot;  ·  -virtual" aria-label="Search meetings" autocomplete="off">
        </label>
        <label>Year
            <select id="meetingYear" aria-label="Filter by year"><option value="">All years</option>
                <?php foreach ($filter_years as $year): ?><option value="<?= $year ?>"><?= $year ?></option><?php endforeach; ?>
            </select>
        </label>
        <label>Month
            <select id="meetingMonth" aria-label="Filter by month"><option value="">All months</option>
                <?php foreach ($month_names as $num => $name): ?><option value="<?= sprintf('%02d', $num) ?>"><?= e($name) ?></option><?php endforeach; ?>
            </select>
        </label>
        <label>Exact date
            <input id="meetingDate" type="date" aria-label="Filter by exact date">
        </label>
        <button type="button" class="meeting-btn secondary" id="meetingClear">Clear filters</button>
    </div>
    <div class="meetings-filter-meta"><span id="meetingCount">&nbsp;</span></div>

    <div class="meetings-table-wrap"><table class="meetings-table">
        <thead><tr><th>Meeting Date</th><th>Time</th><th>Title &amp; Venue</th><th>Linked Action Points</th><th>Minutes</th><th>Actions</th></tr></thead>
        <tbody id="meetingRows">
        <?php foreach ($meeting_view as $m): ?>
            <tr data-id="<?= (int)$m['id'] ?>" data-year="<?= e($m['year']) ?>" data-month="<?= e($m['month']) ?>" data-date="<?= e($m['date']) ?>" data-search="<?= e($m['search']) ?>">
                <td class="meetings-date"><?= e($m['date_label']) ?></td>
                <td class="meetings-date"><?= e($m['time_label']) ?></td>
                <td><div class="meetings-title"><?= e($m['title']) ?></div><div class="meetings-sub">Venue: <?= e($m['venue'] !== '' ? $m['venue'] : 'Not recorded') ?></div></td>
                <td class="meeting-details">
                    <details><summary>View linked action points (<?= count($m['action_point_ids']) ?>)</summary>
                        <div class="meeting-linked-actions">
                        <?php $linkedActions = array_values(array_filter($action_points, static fn($ap) => in_array((int)$ap['id'], $m['action_point_ids'], true))); ?>
                        <?php if ($linkedActions): foreach ($linkedActions as $ap): ?>
                            <div style="padding:6px 0;border-bottom:1px solid #e2e8f0">
                                <strong><?= e($ap['ref_no']) ?></strong> — <?= e($ap['issue']) ?>
                                <a href="/modules/actions.php?q=<?= e(rawurlencode($ap['ref_no'])) ?>">View details</a>
                                <div class="meetings-sub">Status: <?= e($ap['status'] ?? 'Unspecified') ?></div>
                            </div>
                        <?php endforeach; else: ?><span class="meetings-sub">No linked action points.</span><?php endif; ?>
                        </div>
                    </details>
                </td>
                <td><?php if ($m['docs']): ?><div class="meeting-docs"><?php $d = $m['docs'][0]; ?><a class="meeting-doc" href="?download=<?= e(rawurlencode($d['key'])) ?>" title="Download meeting minutes"><span class="vw">Download minutes</span></a></div><?php endif; ?></td>
                <td><div class="meeting-actions">
                    <button class="meeting-read act-toggle" type="button" aria-haspopup="true" aria-expanded="false">Actions ▾</button>
                    <div class="act-menu" role="menu">
                        <button class="meeting-read" type="button" role="menuitem" data-detail="<?= (int)$m['id'] ?>">View</button>
                        <?php if ($can_manage): ?>
                        <button class="meeting-read" type="button" role="menuitem" data-edit="<?= (int)$m['id'] ?>">Edit</button>
                        <button class="meeting-read" type="button" role="menuitem" data-delete="<?= (int)$m['id'] ?>">Delete</button>
                        <?php endif; ?>
                    </div>
                </div></td>
            </tr>
        <?php endforeach; ?>
        <tr id="meetingNoResults"<?= $meetings ? ' hidden' : '' ?>><td class="meeting-empty" colspan="<?= $col_count ?>"><?= $meetings ? 'No meetings match these filters.' : 'No meeting minutes have been recorded.' ?></td></tr>
        </tbody>
    </table></div>
</div>

<dialog id="meetingDetailDialog" class="md-dialog" aria-labelledby="meetingDetailTitle">
    <div class="md-hero">
        <form method="dialog"><button class="md-close" aria-label="Close">×</button></form>
        <span class="md-eyebrow">Meeting Minutes</span>
        <h3 id="meetingDetailTitle"></h3>
        <div class="md-chips"><span class="md-chip" id="mdDate"></span><span class="md-chip" id="mdTime"></span><span class="md-chip" id="mdVenue"></span></div>
    </div>
    <div class="md-body">
        <section class="md-card"><h4>📝 Description</h4><p id="meetingDetailDescription"></p></section>
        <section class="md-card"><h4>📋 Agenda</h4><p id="meetingDetailAgenda"></p></section>
        <section class="md-card"><h4>✅ Decisions and outcomes</h4><p id="meetingDetailDecisions"></p></section>
        <section class="md-card"><h4>👥 Attendees</h4><p id="meetingDetailAttendees"></p></section>
        <section class="md-card"><h4>📎 Documents <span class="md-count" id="mdDocCount">0</span></h4><div id="meetingDetailDocs" class="md-docs"></div></section>
    </div>
    <div class="md-foot"><form method="dialog"><button class="meeting-btn">Close</button></form></div>
</dialog>

<?php if ($can_manage): ?>
<dialog id="meetingFormDialog" class="meeting-dialog"><div class="meeting-dialog-body">
    <button type="button" class="close-x" id="mfClose" aria-label="Close">×</button>
    <h3 id="mfHeading">Add New Meeting</h3>
    <p class="mf-hint" style="margin:0">Fields marked <span class="mf-req">*</span> are required.</p>
    <form method="post" enctype="multipart/form-data" id="meetingForm" autocomplete="off">
        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
        <input type="hidden" name="form_action" id="mfMode" value="create">
        <input type="hidden" name="id" id="mfId" value="">
        <div class="mf-grid">
            <label class="mf-field">Meeting date <span class="mf-req">*</span><input type="date" name="meeting_date" id="mfDate" required></label>
            <label class="mf-field">Meeting time<input type="time" name="meeting_time" id="mfTime"></label>
            <label class="mf-field full">Meeting title <span class="mf-req">*</span><input type="text" name="title" id="mfTitle" maxlength="255" required></label>
            <label class="mf-field full">Venue<input type="text" name="venue" id="mfVenue" maxlength="150"></label>
            <label class="mf-field full">Description<textarea name="description" id="mfDescription" maxlength="20000"></textarea></label>
            <label class="mf-field full">Attendees<textarea name="attendees" id="mfAttendees" maxlength="20000"></textarea></label>
            <label class="mf-field full">Agenda<textarea name="agenda" id="mfAgenda" maxlength="20000"></textarea></label>
            <label class="mf-field full">Decisions and outcomes<textarea name="decisions" id="mfDecisions" maxlength="20000"></textarea></label>
            <div class="mf-field full">
                <label for="mfActionPointSearch">Link to Existing Action Point(s)</label>
                <input type="search" id="mfActionPointSearch" placeholder="Search by reference, issue or status…">
                <span class="mf-hint">Select one or more action points. An action point may be linked to multiple meetings.</span>
                <div class="mf-action-point-list" id="mfActionPointList">
                    <?php foreach ($action_points as $ap): ?>
                    <label class="mf-action-point" data-search="<?= e(meeting_lower(($ap['ref_no'] ?? '') . ' ' . ($ap['issue'] ?? '') . ' ' . ($ap['status'] ?? '') . ' ' . ($ap['meeting_title'] ?? ''))) ?>">
                        <input type="checkbox" name="action_point_ids[]" value="<?= (int)$ap['id'] ?>">
                        <span><strong><?= e($ap['ref_no'] ?: ('Action point #' . $ap['id'])) ?></strong><small><?= e($ap['issue']) ?><br>Status: <?= e($ap['status'] ?? 'Unspecified') ?></small></span>
                    </label>
                    <?php endforeach; ?>
                    <?php if (!$action_points): ?><span class="mf-hint">No action points are available to link.</span><?php endif; ?>
                </div>
            </div>
            <div class="mf-field full" id="mfExistingWrap" hidden>
                <label>Existing documents <span class="mf-hint">Tick Remove to delete a file.</span></label>
                <ul class="mf-existing" id="mfExisting"></ul>
            </div>
            <label class="mf-field full">Attach documents <span class="mf-hint">PDF, Word, Excel, PowerPoint, CSV, TXT, PNG or JPG. Up to 10 files, 10 MB each.</span>
                <input type="file" name="documents[]" id="mfFiles" multiple accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.csv,.txt,.png,.jpg,.jpeg">
                <ul class="mf-filelist" id="mfFileList"></ul><div class="mf-filemsg" id="mfFileMsg"></div>
            </label>
        </div>
        <div class="mf-footer">
            <button type="button" class="meeting-btn secondary" id="mfCancel">Cancel</button>
            <button type="submit" class="meeting-btn green" id="mfSubmit">Save Meeting</button>
        </div>
    </form>
</div></dialog>

<form method="post" id="meetingDeleteForm" hidden>
    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
    <input type="hidden" name="form_action" value="delete">
    <input type="hidden" name="id" id="mdId" value="">
</form>
<?php endif; ?>

<style>
    .meeting-actions{display:flex;flex-direction:column;gap:6px;align-items:flex-start}
    .meeting-empty{padding:25px!important;text-align:center;color:#64748b!important}
    .meetings-alert{padding:12px 14px;border-radius:7px;background:#fff7ed;border:1px solid #fed7aa;color:#9a3412}
    .meetings-ok{padding:12px 14px;border-radius:7px;background:#ecfdf5;border:1px solid #10b981;color:#065f46;font-weight:600}
    .meetings-err{padding:12px 14px;border-radius:7px;background:#fef2f2;border:1px solid #fca5a5;color:#991b1b;font-weight:600}
    dialog.meeting-dialog{width:min(760px,calc(100% - 28px));max-height:calc(100vh - 40px);border:0;border-radius:12px;padding:0;color:#1e293b;box-shadow:0 20px 60px #0f172a44}
    dialog.meeting-dialog::backdrop{background:rgba(15,23,42,.45)}
    .meeting-dialog-body{padding:22px 24px;overflow:auto;max-height:calc(100vh - 40px)}
    .meeting-dialog h3{margin:0 0 4px;color:#102c53}.meeting-dialog h4{margin:16px 0 4px;color:#102c53}
    .meeting-dialog .close-x{float:right;border:0;background:transparent;font-size:1.5rem;line-height:1;cursor:pointer;color:#64748b}
    .mf-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-top:14px}
    .mf-grid .full{grid-column:1/-1}
    .mf-field{display:flex;flex-direction:column;gap:5px;font-size:.78rem;font-weight:700;color:#334155}
    .mf-field input,.mf-field textarea{padding:9px 11px;border:1px solid #cbd5e1;border-radius:6px;font:inherit;font-weight:400;color:#1e293b;background:#fff}
    .mf-field textarea{min-height:88px;resize:vertical}
    .mf-field input:focus,.mf-field textarea:focus{outline:2px solid #bfdbfe;border-color:#0d47a1}
    .mf-req{color:#b91c1c}.mf-hint{font-weight:400;color:#64748b;font-size:.74rem}
    .mf-existing{display:flex;flex-direction:column;gap:6px;margin:0;padding:0;list-style:none}
    .mf-existing li{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:8px 10px;border:1px solid #e2e8f0;border-radius:6px;background:#f8fafc;font-weight:400}
    .mf-existing a{color:#0d47a1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:600;text-decoration:none}
    .mf-existing label{display:flex;align-items:center;gap:5px;color:#b91c1c;font-size:.76rem;white-space:nowrap;font-weight:600}
    .mf-filelist{margin:6px 0 0;padding-left:18px;font-size:.78rem;color:#334155;font-weight:400}
    .mf-filemsg{margin-top:6px;color:#b91c1c;font-size:.78rem;font-weight:600}
    .mf-footer{display:flex;justify-content:flex-end;gap:10px;margin-top:20px}
    .mf-action-point-list{display:grid;grid-template-columns:1fr 1fr;gap:8px;max-height:230px;overflow:auto;padding:10px;border:1px solid #dce4ef;border-radius:7px;background:#f8fafc}
    .mf-action-point{display:flex;align-items:flex-start;gap:8px;padding:9px;border:1px solid #e2e8f0;border-radius:6px;background:#fff;font-size:.78rem;font-weight:400;line-height:1.4}
    .mf-action-point input{margin-top:3px;flex:0 0 auto}.mf-action-point strong{color:#0d47a1}.mf-action-point small{display:block;margin-top:3px;color:#64748b}.mf-action-point[hidden]{display:none}
    @media(max-width:700px){.meetings-table{min-width:820px}.mf-grid{grid-template-columns:1fr}.mf-action-point-list{grid-template-columns:1fr}}
</style>

<div class="meetings-page">
    <header class="meetings-head">
        <div><h2>Meeting Minutes</h2><p>Minutes and decisions from partner and steering committee meetings.</p></div>
        <div class="meetings-head-actions">
            <span class="status-pill"><?= count($meetings) ?> record<?= count($meetings) === 1 ? '' : 's' ?></span>
            <?php if ($can_manage): ?><button type="button" class="meeting-btn green" id="addMeetingBtn">+ Add Meeting</button><?php endif; ?>
        </div>
    </header>

    <?php if ($flash === 'created'): ?><div class="meetings-ok" role="status">The meeting was added.</div><?php endif; ?>
    <?php if ($flash === 'updated'): ?><div class="meetings-ok" role="status">The meeting was updated.</div><?php endif; ?>
    <?php if ($flash === 'deleted'): ?><div class="meetings-ok" role="status">The meeting and its documents were deleted.</div><?php endif; ?>
    <?php if ($form_error !== ''): ?><div class="meetings-err" role="alert"><?= e($form_error) ?></div><?php endif; ?>
    <?php if ($meeting_error !== ''): ?><div class="meetings-alert" role="status"><?= e($meeting_error) ?></div><?php endif; ?>

    <div class="meetings-filter" role="search">
        <label class="f-search">Smart search
            <input id="meetingSearch" type="search" placeholder="e.g. global fund teams  ·  &quot;exact phrase&quot;  ·  -virtual" aria-label="Search meetings" autocomplete="off">
        </label>
        <label>Year
            <select id="meetingYear" aria-label="Filter by year"><option value="">All years</option>
                <?php foreach ($filter_years as $year): ?><option value="<?= $year ?>"><?= $year ?></option><?php endforeach; ?>
            </select>
        </label>
        <label>Month
            <select id="meetingMonth" aria-label="Filter by month"><option value="">All months</option>
                <?php foreach ($month_names as $num => $name): ?><option value="<?= sprintf('%02d', $num) ?>"><?= e($name) ?></option><?php endforeach; ?>
            </select>
        </label>
        <label>Exact date
            <input id="meetingDate" type="date" aria-label="Filter by exact date">
        </label>
        <button type="button" class="meeting-btn secondary" id="meetingClear">Clear filters</button>
    </div>
    <div class="meetings-filter-meta"><span id="meetingCount">&nbsp;</span></div>

    <div class="meetings-table-wrap"><table class="meetings-table">
        <thead><tr><th>Meeting Date</th><th>Time</th><th>Title &amp; Venue</th><th>Linked Action Points</th><th>Minutes</th><th>Actions</th></tr></thead>
        <tbody id="meetingRows">
        <?php foreach ($meeting_view as $m): ?>
            <tr data-id="<?= (int)$m['id'] ?>" data-year="<?= e($m['year']) ?>" data-month="<?= e($m['month']) ?>" data-date="<?= e($m['date']) ?>" data-search="<?= e($m['search']) ?>">
                <td class="meetings-date"><?= e($m['date_label']) ?></td>
                <td class="meetings-date"><?= e($m['time_label']) ?></td>
                <td><div class="meetings-title"><?= e($m['title']) ?></div><div class="meetings-sub">Venue: <?= e($m['venue'] !== '' ? $m['venue'] : 'Not recorded') ?></div></td>
                <td class="meeting-details">
                    <details><summary>View linked action points (<?= count($m['action_point_ids']) ?>)</summary>
                        <div class="meeting-linked-actions">
                        <?php $linkedActions = array_values(array_filter($action_points, static fn($ap) => in_array((int)$ap['id'], $m['action_point_ids'], true))); ?>
                        <?php if ($linkedActions): foreach ($linkedActions as $ap): ?>
                            <div style="padding:6px 0;border-bottom:1px solid #e2e8f0">
                                <strong><?= e($ap['ref_no']) ?></strong> — <?= e($ap['issue']) ?>
                                <a href="/modules/actions.php?q=<?= e(rawurlencode($ap['ref_no'])) ?>">View details</a>
                                <div class="meetings-sub">Status: <?= e($ap['status'] ?? 'Unspecified') ?></div>
                            </div>
                        <?php endforeach; else: ?><span class="meetings-sub">No linked action points.</span><?php endif; ?>
                        </div>
                    </details>
                </td>
                <td><?php if ($m['docs']): ?><div class="meeting-docs"><?php $d = $m['docs'][0]; ?><a class="meeting-doc" href="?download=<?= e(rawurlencode($d['key'])) ?>" title="Download meeting minutes"><span class="vw">Download minutes</span></a></div><?php endif; ?></td>
                <td><div class="meeting-actions">
                    <button class="meeting-read act-toggle" type="button" aria-haspopup="true" aria-expanded="false">Actions ▾</button>
                    <div class="act-menu" role="menu">
                        <button class="meeting-read" type="button" role="menuitem" data-detail="<?= (int)$m['id'] ?>">View</button>
                        <?php if ($can_manage): ?>
                        <button class="meeting-read" type="button" role="menuitem" data-edit="<?= (int)$m['id'] ?>">Edit</button>
                        <button class="meeting-read" type="button" role="menuitem" data-delete="<?= (int)$m['id'] ?>">Delete</button>
                        <?php endif; ?>
                    </div>
                </div></td>
            </tr>
        <?php endforeach; ?>
        <tr id="meetingNoResults"<?= $meetings ? ' hidden' : '' ?>><td class="meeting-empty" colspan="<?= $col_count ?>"><?= $meetings ? 'No meetings match these filters.' : 'No meeting minutes have been recorded.' ?></td></tr>
        </tbody>
    </table></div>
</div>

<dialog id="meetingDetailDialog" class="md-dialog" aria-labelledby="meetingDetailTitle">
    <div class="md-hero">
        <form method="dialog"><button class="md-close" aria-label="Close">×</button></form>
        <span class="md-eyebrow">Meeting Minutes</span>
        <h3 id="meetingDetailTitle"></h3>
        <div class="md-chips"><span class="md-chip" id="mdDate"></span><span class="md-chip" id="mdTime"></span><span class="md-chip" id="mdVenue"></span></div>
    </div>
    <div class="md-body">
        <section class="md-card"><h4>📝 Description</h4><p id="meetingDetailDescription"></p></section>
        <section class="md-card"><h4>📋 Agenda</h4><p id="meetingDetailAgenda"></p></section>
        <section class="md-card"><h4>✅ Decisions and outcomes</h4><p id="meetingDetailDecisions"></p></section>
        <section class="md-card"><h4>👥 Attendees</h4><p id="meetingDetailAttendees"></p></section>
        <section class="md-card"><h4>📎 Documents <span class="md-count" id="mdDocCount">0</span></h4><div id="meetingDetailDocs" class="md-docs"></div></section>
    </div>
    <div class="md-foot"><form method="dialog"><button class="meeting-btn">Close</button></form></div>
</dialog>

<?php if ($can_manage): ?>
<dialog id="meetingFormDialog" class="meeting-dialog"><div class="meeting-dialog-body">
    <button type="button" class="close-x" id="mfClose" aria-label="Close">×</button>
    <h3 id="mfHeading">Add New Meeting</h3>
    <p class="mf-hint" style="margin:0">Fields marked <span class="mf-req">*</span> are required.</p>
    <form method="post" enctype="multipart/form-data" id="meetingForm" autocomplete="off">
        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
        <input type="hidden" name="form_action" id="mfMode" value="create">
        <input type="hidden" name="id" id="mfId" value="">
        <div class="mf-grid">
            <label class="mf-field">Meeting date <span class="mf-req">*</span><input type="date" name="meeting_date" id="mfDate" required></label>
            <label class="mf-field">Meeting time<input type="time" name="meeting_time" id="mfTime"></label>
            <label class="mf-field full">Meeting title <span class="mf-req">*</span><input type="text" name="title" id="mfTitle" maxlength="255" required></label>
            <label class="mf-field full">Venue<input type="text" name="venue" id="mfVenue" maxlength="150"></label>
            <label class="mf-field full">Description<textarea name="description" id="mfDescription" maxlength="20000"></textarea></label>
            <label class="mf-field full">Attendees<textarea name="attendees" id="mfAttendees" maxlength="20000"></textarea></label>
            <label class="mf-field full">Agenda<textarea name="agenda" id="mfAgenda" maxlength="20000"></textarea></label>
            <label class="mf-field full">Decisions and outcomes<textarea name="decisions" id="mfDecisions" maxlength="20000"></textarea></label>
            <div class="mf-field full">
                <label for="mfActionPointSearch">Link to Existing Action Point(s)</label>
                <input type="search" id="mfActionPointSearch" placeholder="Search by reference, issue or status…">
                <span class="mf-hint">Select one or more action points. An action point may be linked to multiple meetings.</span>
                <div class="mf-action-point-list" id="mfActionPointList">
                    <?php foreach ($action_points as $ap): ?>
                    <label class="mf-action-point" data-search="<?= e(meeting_lower(($ap['ref_no'] ?? '') . ' ' . ($ap['issue'] ?? '') . ' ' . ($ap['status'] ?? '') . ' ' . ($ap['meeting_title'] ?? ''))) ?>">
                        <input type="checkbox" name="action_point_ids[]" value="<?= (int)$ap['id'] ?>">
                        <span><strong><?= e($ap['ref_no'] ?: ('Action point #' . $ap['id'])) ?></strong><small><?= e($ap['issue']) ?><br>Status: <?= e($ap['status'] ?? 'Unspecified') ?></small></span>
                    </label>
                    <?php endforeach; ?>
                    <?php if (!$action_points): ?><span class="mf-hint">No action points are available to link.</span><?php endif; ?>
                </div>
            </div>
            <div class="mf-field full" id="mfExistingWrap" hidden>
                <label>Existing documents <span class="mf-hint">Tick Remove to delete a file.</span></label>
                <ul class="mf-existing" id="mfExisting"></ul>
            </div>
            <label class="mf-field full">Attach documents <span class="mf-hint">PDF, Word, Excel, PowerPoint, CSV, TXT, PNG or JPG. Up to 10 files, 10 MB each.</span>
                <input type="file" name="documents[]" id="mfFiles" multiple accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.csv,.txt,.png,.jpg,.jpeg">
                <ul class="mf-filelist" id="mfFileList"></ul><div class="mf-filemsg" id="mfFileMsg"></div>
            </label>
        </div>
        <div class="mf-footer">
            <button type="button" class="meeting-btn secondary" id="mfCancel">Cancel</button>
            <button type="submit" class="meeting-btn green" id="mfSubmit">Save Meeting</button>
        </div>
    </form>
</div></dialog>

<form method="post" id="meetingDeleteForm" hidden>
    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
    <input type="hidden" name="form_action" value="delete">
    <input type="hidden" name="id" id="mdId" value="">
</form>
<?php endif; ?>

<script>
(() => {
    const MEETINGS = <?= json_encode($meeting_view, $json_flags) ?>;
    const REOPEN = <?= json_encode($form_old, $json_flags) ?>;
    const CAN_MANAGE = <?= $can_manage ? 'true' : 'false' ?>;
    const MAX_FILES = <?= (int)$max_files ?>, MAX_BYTES = <?= (int)$max_file_bytes ?>, ALLOWED = <?= json_encode($allowed_ext) ?>;
    const byId = {};
    MEETINGS.forEach(m => byId[m.id] = m);
    const $ = id => document.getElementById(id);
    const norm = s => String(s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');

    // Search and filters
    const search = $('meetingSearch'), year = $('meetingYear'), month = $('meetingMonth'), dateEl = $('meetingDate');
    const rows = [...document.querySelectorAll('#meetingRows tr[data-id]')], empty = $('meetingNoResults'), count = $('meetingCount');
    rows.forEach(r => r._hay = norm(r.dataset.search));

    function parseQuery(q) {
        const inc = [], exc = [];
        (norm(q).match(/-?"[^"]*"|\S+/g) || []).forEach(token => {
            let negate = false;
            if (token.length > 1 && token[0] === '-') {
                negate = true;
                token = token.slice(1);
            }
            token = token.replace(/^"|"$/g, '').trim();
            if (token) (negate ? exc : inc).push(token);
        });
        return { inc, exc };
    }

    function applyFilters() {
        const { inc, exc } = parseQuery(search.value), exact = dateEl.value;
        year.disabled = month.disabled = !!exact;
        let shown = 0;
        rows.forEach(row => {
            const ok = (exact ? row.dataset.date === exact : (!year.value || row.dataset.year === year.value) && (!month.value || row.dataset.month === month.value))
                && inc.every(t => row._hay.includes(t)) && !exc.some(t => row._hay.includes(t));
            row.hidden = !ok;
            if (ok) shown++;
        });
        empty.hidden = rows.length > 0 && shown > 0;
        count.textContent = rows.length ? 'Showing ' + shown + ' of ' + rows.length + ' meeting' + (rows.length === 1 ? '' : 's') : '';
    }

    search.addEventListener('input', applyFilters);
    [year, month, dateEl].forEach(el => el.addEventListener('change', applyFilters));
    $('meetingClear').addEventListener('click', () => {
        search.value = '';
        year.value = '';
        month.value = '';
        dateEl.value = '';
        applyFilters();
    });
    applyFilters();

    // Document helpers
    function docLink(d) {
        const a = document.createElement('a');
        a.className = 'meeting-doc';
        a.href = '?download=' + encodeURIComponent(d.key);
        a.target = '_blank';
        a.rel = 'noopener';
        a.textContent = '📎 ' + d.name + (d.size ? ' (' + d.size + ')' : '');
        return a;
    }

    function docCard(d) {
        const url = '?download=' + encodeURIComponent(d.key);
        const row = document.createElement('div');
        const badge = document.createElement('span');
        const info = document.createElement('div');
        const name = document.createElement('span');
        const size = document.createElement('span');
        const view = document.createElement('a');
        const dl = document.createElement('a');

        row.className = 'md-doc';
        badge.className = 'ext-badge ' + (d.cls || 'ext-other');
        badge.textContent = d.ext || 'FILE';
        info.className = 'md-doc-info';
        name.className = 'md-doc-name';
        name.textContent = d.name;
        name.title = d.name;
        size.className = 'md-doc-size';
        size.textContent = d.size || (d.legacy ? 'Earlier upload' : '');
        info.appendChild(name);
        info.appendChild(size);

        view.className = 'md-btn view';
        view.href = url;
        view.target = '_blank';
        view.rel = 'noopener';
        view.textContent = '👁 View';

        dl.className = 'md-btn dl';
        dl.href = url + '&dl=1';
        dl.textContent = '⬇ Download';

        row.appendChild(badge);
        row.appendChild(info);
        row.appendChild(view);
        row.appendChild(dl);
        return row;
    }

    // Meeting details dialog
    const detail = $('meetingDetailDialog');

    function showDetail(id) {
        const m = byId[id];
        if (!m) return;

        $('meetingDetailTitle').textContent = m.title;
        const chip = (id, text) => {
            const el = $(id);
            el.textContent = text || '';
            el.hidden = !text;
        };

        chip('mdDate', m.date ? '📅 ' + m.date_label : '');
        chip('mdTime', m.time ? '🕒 ' + m.time_label : '');
        chip('mdVenue', m.venue ? '📍 ' + m.venue : '');
        $('meetingDetailDescription').textContent = m.description || 'Not recorded';
        $('meetingDetailAgenda').textContent = m.agenda || 'Not recorded';
        $('meetingDetailDecisions').textContent = m.decisions || 'Not recorded';
        $('meetingDetailAttendees').textContent = m.attendees || 'Not recorded';

        const box = $('meetingDetailDocs');
        box.textContent = '';
        $('mdDocCount').textContent = m.docs.length;

        if (m.docs.length) {
            m.docs.forEach(d => box.appendChild(docCard(d)));
        } else {
            const none = document.createElement('div');
            none.className = 'md-none';
            none.textContent = 'No documents attached to this meeting.';
            box.appendChild(none);
        }
        detail.showModal();
    }

    // Add/edit dialog
    const formDialog = $('meetingFormDialog');

    function setValue(id, value) {
        $(id).value = value || '';
    }

    function openForm(mode, data) {
        data = data || {};
        $('meetingForm').reset();
        $('mfMode').value = mode;
        $('mfId').value = data.id || '';
        $('mfHeading').textContent = mode === 'update' ? 'Edit Meeting' : 'Add New Meeting';
        $('mfSubmit').textContent = mode === 'update' ? 'Save Changes' : 'Save Meeting';

        setValue('mfDate', data.date);
        setValue('mfTime', data.time);
        setValue('mfTitle', data.title);
        setValue('mfVenue', data.venue);
        setValue('mfDescription', data.description);
        setValue('mfAttendees', data.attendees);
        setValue('mfAgenda', data.agenda);
        setValue('mfDecisions', data.decisions);

        const selectedApIds = (data.action_point_ids || []).map(Number);
        document.querySelectorAll('#mfActionPointList input[name="action_point_ids[]"]').forEach(box => {
            box.checked = selectedApIds.includes(Number(box.value));
        });

        $('mfActionPointSearch').value = '';
        document.querySelectorAll('.mf-action-point').forEach(item => { item.hidden = false; });

        const list = $('mfExisting');
        list.textContent = '';
        const docs = mode === 'update' ? (data.docs || []) : [];
        $('mfExistingWrap').hidden = docs.length === 0;

        docs.forEach(d => {
            const li = document.createElement('li');
            const a = docLink(d);
            const label = document.createElement('label');
            const box = document.createElement('input');
            box.type = 'checkbox';
            box.name = d.legacy ? 'remove_legacy' : 'remove_docs[]';
            box.value = d.legacy ? '1' : d.id;
            label.appendChild(box);
            label.appendChild(document.createTextNode('Remove'));
            li.appendChild(a);
            li.appendChild(label);
            list.appendChild(li);
        });

        renderFiles();
        $('mfSubmit').disabled = false;
        formDialog.showModal();
        $('mfTitle').focus();
    }

    function renderFiles() {
        const input = $('mfFiles'), list = $('mfFileList'), msg = $('mfFileMsg');
        list.textContent = '';
        msg.textContent = '';
        const files = [...input.files];
        let problem = '';

        if (files.length > MAX_FILES) problem = 'You can attach up to ' + MAX_FILES + ' documents at a time.';

        files.forEach(f => {
            const ext = f.name.split('.').pop().toLowerCase();
            if (!problem && !ALLOWED.includes(ext)) problem = '“' + f.name + '” is not an allowed file type.';
            if (!problem && f.size > MAX_BYTES) problem = '“' + f.name + '” is larger than 10 MB.';
            const li = document.createElement('li');
            li.textContent = f.name + ' (' + (f.size >= 1048576 ? (f.size / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(f.size / 1024)) + ' KB') + ')';
            list.appendChild(li);
        });

        if (problem) {
            msg.textContent = problem + ' Please choose the files again.';
            input.value = '';
            list.textContent = '';
        }
    }

    function localToday() {
        const d = new Date(), p = n => String(n).padStart(2, '0');
        return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate());
    }

    if (CAN_MANAGE) {
        $('addMeetingBtn').addEventListener('click', () => openForm('create', { date: localToday() }));

        $('mfActionPointSearch').addEventListener('input', () => {
            const q = norm($('mfActionPointSearch').value.trim());
            document.querySelectorAll('.mf-action-point').forEach(item => {
                item.hidden = !norm(item.dataset.search).includes(q);
            });
        });

        $('mfFiles').addEventListener('change', renderFiles);
        $('mfClose').addEventListener('click', () => formDialog.close());
        $('mfCancel').addEventListener('click', () => formDialog.close());
        $('meetingForm').addEventListener('submit', () => {
            $('mfSubmit').disabled = true;
            $('mfSubmit').textContent = 'Saving…';
        });

        if (REOPEN) {
            const f = REOPEN.fields || {};
            openForm(REOPEN.mode, Object.assign({}, byId[REOPEN.id] || {}, {
                id: REOPEN.id,
                date: f.meeting_date,
                time: (f.meeting_time || '').slice(0, 5),
                title: f.title,
                venue: f.venue,
                description: f.description,
                attendees: f.attendees,
                agenda: f.agenda,
                decisions: f.decisions,
                action_point_ids: REOPEN.action_point_ids || []
            }));
        }
    }

    // Row action menus
    const closeMenus = () => document.querySelectorAll('.act-menu.is-open').forEach(m => {
        m.classList.remove('is-open');
        m.previousElementSibling.setAttribute('aria-expanded', 'false');
    });

    document.addEventListener('click', ev => {
        if (!ev.target.closest('.act-toggle')) closeMenus();
    });
    document.addEventListener('keydown', ev => {
        if (ev.key === 'Escape') closeMenus();
    });
    window.addEventListener('resize', closeMenus);
    document.querySelector('.meetings-table-wrap').addEventListener('scroll', closeMenus);
    window.addEventListener('scroll', closeMenus, true);

    $('meetingRows').addEventListener('click', ev => {
        const btn = ev.target.closest('button');
        if (!btn) return;

        if (btn.classList.contains('act-toggle')) {
            const menu = btn.nextElementSibling;
            const open = !menu.classList.contains('is-open');
            closeMenus();

            if (open) {
                const r = btn.getBoundingClientRect();
                menu.classList.add('is-open');
                const h = menu.offsetHeight, w = menu.offsetWidth;
                menu.style.left = Math.max(8, Math.min(r.left, window.innerWidth - w - 8)) + 'px';
                menu.style.top = (r.bottom + h + 8 > window.innerHeight ? r.top - h - 4 : r.bottom + 4) + 'px';
                btn.setAttribute('aria-expanded', 'true');
            }
            return;
        }

        closeMenus();

        if (btn.dataset.detail) {
            showDetail(btn.dataset.detail);
        } else if (CAN_MANAGE && btn.dataset.edit) {
            openForm('update', byId[btn.dataset.edit]);
        } else if (CAN_MANAGE && btn.dataset.delete) {
            const m = byId[btn.dataset.delete];
            if (m && confirm('Delete “' + m.title + '” and all of its attached documents? This cannot be undone.')) {
                $('mdId').value = m.id;
                $('meetingDeleteForm').submit();
            }
        }
    });
})();
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
