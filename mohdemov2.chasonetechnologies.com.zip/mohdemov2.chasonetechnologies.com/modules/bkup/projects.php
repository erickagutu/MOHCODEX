<?php
/**
 * Projects & Programmes Module
 * Ministry of Health — State Department for Medical Services (PP-SDOMS)
 * Native PHP 8.1+ & MySQL (No Node.js)
 */
require_once __DIR__ . '/../config/db.php';
require_auth();

$page_title = 'Projects & Programmes — State Department for Medical Services';
$page_stylesheets = ['/assets/css/projects-nav.css?v=20261024b'];
$active_tab = 'projects';

$flash_msg = '';
$showArchivedProjects = isset($_GET['show_archived']) && $_GET['show_archived'] === '1';
$view_detail_id = (int)($_GET['id'] ?? 0);
$is_detail_view = ($view_detail_id > 0);

// KPI Progress record CRUD — Add / Edit / Delete behind the "Project KPI Progress & Targets" graph.
// Records live in the `project_kpis` table (month name + year, percentages as 0-100 for baseline/target/actual,
// and as fractions for monthly_progress_pct / cumulative_progress_pct, e.g. 0.2000 = 20%).
$kpi_month_names = [1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'];
// Spelling written to project_kpis.month (the existing data uses 'Sept' for September).
$kpi_month_store = $kpi_month_names; $kpi_month_store[9] = 'Sept';
// Month text from the table ('March', 'Sept', 'sep', ...) -> 1..12 (0 = not recognised).
$kpi_month_num = static function ($name) use ($kpi_month_names) {
    $n = strtolower(trim((string)$name));
    if ($n === '') return 0;
    foreach ($kpi_month_names as $i => $full) {
        $f = strtolower($full);
        if ($n === $f || $n === substr($f, 0, 3) || ($i === 9 && $n === 'sept')) return $i;
    }
    return 0;
};
$kpi_month_aliases = static function (int $m) use ($kpi_month_names) {
    $f = $kpi_month_names[$m] ?? '';
    $a = [$f, substr($f, 0, 3)];
    if ($m === 9) $a[] = 'Sept';
    return array_values(array_unique($a));
};
// project_kpis has no year column in the original schema: add it once (existing rows get YEAR(created_at)).
$kpi_ensure_schema = static function (PDO $pdo) {
    if (!$pdo->query("SHOW COLUMNS FROM `project_kpis` LIKE 'year'")->fetch()) {
        $pdo->exec("ALTER TABLE `project_kpis` ADD COLUMN `year` smallint(4) DEFAULT NULL AFTER `id`");
        $pdo->exec("UPDATE `project_kpis` SET `year` = YEAR(`created_at`) WHERE `year` IS NULL");
    }
};

if ($_SERVER['REQUEST_METHOD'] === 'POST' && in_array($_POST['kpi_action'] ?? '', ['kpi_add', 'kpi_edit', 'kpi_delete'], true)) {
    $kpi_pid = (int)($_POST['project_id'] ?? 0);
    $kpi_back = '/modules/projects.php?' . http_build_query(array_filter([
        'id' => $kpi_pid,
        'graph_kpi' => $_POST['graph_kpi'] ?? '', 'graph_year' => $_POST['graph_year'] ?? '', 'graph_month' => $_POST['graph_month'] ?? '',
        'table_kpi' => $_POST['table_kpi'] ?? '', 'table_year' => $_POST['table_year'] ?? '', 'table_month' => $_POST['table_month'] ?? '',
    ], static fn($v) => $v !== '' && $v !== null));
    $kpi_result = static function (string $code) use ($kpi_back) {
        header('Location: ' . $kpi_back . '&kpi_msg=' . urlencode($code) . '#kpiRecords');
        exit;
    };
    if (!can_edit()) $kpi_result('denied');
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) $kpi_result('csrf');
    if (!$db_connected || !$pdo || $kpi_pid <= 0) $kpi_result('dberr');

    $kpi_action = $_POST['kpi_action'];
    $rec_id = (int)($_POST['record_id'] ?? 0);
    try {
        $kpi_ensure_schema($pdo); // DDL auto-commits, so it must run before any transaction starts

        if ($kpi_action === 'kpi_delete') {
            $pdo->beginTransaction();
            $st = $pdo->prepare('SELECT *, COALESCE(`year`, YEAR(created_at)) AS yr FROM project_kpis WHERE id = ? FOR UPDATE');
            $st->execute([$rec_id]);
            $old = $st->fetch(PDO::FETCH_ASSOC);
            if (!$old) { $pdo->rollBack(); $kpi_result('missing'); }
            $pdo->exec("CREATE TABLE IF NOT EXISTS `deleted_items` (
                `id` int(11) NOT NULL AUTO_INCREMENT, `item_type` varchar(50) NOT NULL, `item_id` int(11) NOT NULL,
                `item_title` varchar(255) DEFAULT NULL, `item_data` longtext DEFAULT NULL, `deleted_by` varchar(150) DEFAULT NULL,
                `ip_address` varchar(45) DEFAULT NULL, `deleted_at` timestamp NOT NULL DEFAULT current_timestamp(),
                PRIMARY KEY (`id`), KEY `idx_deleted_type_item` (`item_type`,`item_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
            $u = function_exists('get_current_user_data') ? get_current_user_data() : [];
            $who = is_array($u) ? (string)($u['full_name'] ?? $u['name'] ?? $u['email'] ?? '') : '';
            $pdo->prepare('INSERT INTO deleted_items (item_type, item_id, item_title, item_data, deleted_by, ip_address) VALUES (?,?,?,?,?,?)')
                ->execute(['KPI Progress Record', $rec_id, $old['kpi_name'] . ' — ' . $old['month'] . ' ' . $old['yr'],
                    json_encode($old, JSON_UNESCAPED_UNICODE), $who !== '' ? $who : null, $_SERVER['REMOTE_ADDR'] ?? null]);
            $pdo->prepare('DELETE FROM project_kpis WHERE id = ?')->execute([$rec_id]);
            $pdo->commit();
            log_audit_trail('DELETE', 'KPI Progress', $rec_id, "Deleted KPI record {$old['kpi_name']} {$old['month']} {$old['yr']} (project $kpi_pid)");
            $kpi_result('deleted');
        }

        // add / edit: validate
        $mnum  = (int)($_POST['month_num'] ?? 0);
        $year  = (int)($_POST['year'] ?? 0);
        $kname = trim((string)($_POST['kpi_name'] ?? ''));
        $num = static function ($k) { $v = trim((string)($_POST[$k] ?? '')); return ($v !== '' && is_numeric($v)) ? round((float)$v, 2) : null; };
        $target = $num('target_pct'); $actual = $num('actual_pct'); $baseline = $num('baseline_pct');
        if ($mnum < 1 || $mnum > 12 || $year < 2000 || $year > 2100 || $kname === '' || mb_strlen($kname) > 255) $kpi_result('invalid');
        if ($target === null) $target = 100.00;
        if ($actual === null || $target < 0 || $actual < 0 || $target > 999.99 || $actual > 999.99) $kpi_result('invalid');
        if ($baseline !== null && ($baseline < 0 || $baseline > 999.99)) $kpi_result('invalid');

        if ($kpi_action === 'kpi_edit') {
            $st = $pdo->prepare('SELECT id FROM project_kpis WHERE id = ?');
            $st->execute([$rec_id]);
            if (!$st->fetchColumn()) $kpi_result('missing');
        }

        if ($baseline === null) { // default: the latest earlier cumulative for this KPI
            $st = $pdo->prepare('SELECT id, project_id, COALESCE(`year`, YEAR(created_at)) AS yr, `month`, cumulative_progress_pct FROM project_kpis WHERE kpi_name = ? AND id <> ? AND (project_id = ? OR project_id IS NULL) ORDER BY (project_id = ?) DESC, id DESC');
            $st->execute([$kname, $rec_id, $kpi_pid, $kpi_pid]);
            $best = -1; $baseline = 0.0;
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $pr) {
                $pm = $kpi_month_num($pr['month']);
                $key = (int)$pr['yr'] * 12 + $pm;
                if ($pm > 0 && $key < $year * 12 + $mnum && $key > $best) { $best = $key; $baseline = round((float)$pr['cumulative_progress_pct'] * 100, 2); }
            }
        }
        // Stored as fractions: Monthly = Actual / 100, Cumulative = (Baseline + Actual) / 100 (column max 9.9999).
        $monthly = min(9.9999, round($actual / 100, 4));
        $cumulative = min(9.9999, round(($baseline + $actual) / 100, 4));

        $aliases = $kpi_month_aliases($mnum);
        $in = implode(',', array_fill(0, count($aliases), '?'));
        $st = $pdo->prepare("SELECT id FROM project_kpis WHERE kpi_name = ? AND COALESCE(`year`, YEAR(created_at)) = ? AND `month` IN ($in) AND id <> ? LIMIT 1");
        $st->execute(array_merge([$kname, $year], $aliases, [$rec_id]));
        if ($st->fetchColumn()) $kpi_result('duplicate');

        $month_text = $kpi_month_store[$mnum];
        if ($kpi_action === 'kpi_add') {
            $pdo->prepare('INSERT INTO project_kpis (project_id, `year`, `month`, kpi_name, baseline, target, actual_achieved, monthly_progress_pct, cumulative_progress_pct) VALUES (?,?,?,?,?,?,?,?,?)')
                ->execute([$kpi_pid, $year, $month_text, $kname, $baseline, $target, $actual, $monthly, $cumulative]);
            log_audit_trail('CREATE', 'KPI Progress', $pdo->lastInsertId(), "Added KPI record $kname $month_text $year (project $kpi_pid)");
            $kpi_result('added');
        }
        $pdo->prepare('UPDATE project_kpis SET project_id=?, `year`=?, `month`=?, kpi_name=?, baseline=?, target=?, actual_achieved=?, monthly_progress_pct=?, cumulative_progress_pct=? WHERE id=?')
            ->execute([$kpi_pid, $year, $month_text, $kname, $baseline, $target, $actual, $monthly, $cumulative, $rec_id]);
        log_audit_trail('UPDATE', 'KPI Progress', $rec_id, "Updated KPI record $kname $month_text $year (project $kpi_pid)");
        $kpi_result('updated');
    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        error_log('KPI record CRUD failed: ' . $e->getMessage());
        $kpi_result('dberr');
    }
}

// Project archive / restore. Archiving is a soft-delete; the project data remains stored.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && in_array($_POST['project_action'] ?? '', ['archive_project', 'restore_project'], true)) {
    if (!can_edit() || !verify_csrf_token($_POST['csrf_token'] ?? '')) {
        http_response_code(403);
        exit('You do not have permission to archive this project.');
    }
    $archiveProjectId = (int)($_POST['project_id'] ?? 0);
    if ($archiveProjectId > 0 && $db_connected && $pdo) {
        $archived = $_POST['project_action'] === 'archive_project';
        $st = $pdo->prepare('UPDATE projects SET is_archived = ?, archived_at = ' . ($archived ? 'CURRENT_TIMESTAMP' : 'NULL') . ' WHERE id = ?');
        $st->execute([$archived ? 1 : 0, $archiveProjectId]);
        if (function_exists('log_audit_trail')) log_audit_trail($archived ? 'ARCHIVE' : 'RESTORE', 'Projects', $archiveProjectId, ($archived ? 'Archived' : 'Restored') . ' project #' . $archiveProjectId);
    }
    header('Location: /modules/projects.php' . (!empty($_GET['show_archived']) ? '?show_archived=1' : ''));
    exit;
}

// Edit an existing project's core details from the project detail page.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['project_action'] ?? '') === 'edit_project') {
    if (!can_edit() || !verify_csrf_token($_POST['csrf_token'] ?? '')) { http_response_code(403); exit('You do not have permission to edit this project.'); }
    $pid = (int)($_POST['project_id'] ?? 0);
    $title = trim((string)($_POST['sub_programme'] ?? ''));
    $programmeTitle = trim((string)($_POST['programme_title'] ?? ''));
    $code = trim((string)($_POST['project_code'] ?? ''));
    $description = trim((string)($_POST['description'] ?? ''));
    $start = (string)($_POST['start_date'] ?? '');
    $end = (string)($_POST['end_date'] ?? '');
    $budget = max(0, (float)($_POST['total_budget'] ?? 0));
    if ($pid > 0 && $title !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $start) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $end) && $end >= $start && $db_connected && $pdo) {
        $st = $pdo->prepare('UPDATE projects SET sub_programme=?, programme_title=?, project_code=?, description=?, start_date=?, end_date=?, total_budget=? WHERE id=?');
        $st->execute([$title, $programmeTitle, $code !== '' ? $code : null, $description, $start, $end, $budget, $pid]);
        if (function_exists('log_audit_trail')) log_audit_trail('UPDATE', 'Projects', $pid, 'Updated project details');
        header('Location: /modules/projects.php?id=' . $pid . '&project_saved=1#projectDetailsGrid'); exit;
    }
    header('Location: /modules/projects.php?id=' . $pid . '&project_saved=0#projectDetailsGrid'); exit;
}

// Add Project Form Handler
if ($_SERVER['REQUEST_METHOD'] === 'POST' && can_edit()) {
    $token = $_POST['csrf_token'] ?? '';
    if (verify_csrf_token($token)) {
        $sub_prog = trim($_POST['sub_programme'] ?? '');
        $project_code = trim($_POST['project_code'] ?? '');
        $project_type = trim($_POST['project_type'] ?? 'Project');
        $prog_title = trim($_POST['programme_title'] ?? '');
        $cat = $_POST['category'] ?? 'Directorate';
        $agency = trim($_POST['agency_name'] ?? '');
        $tier = $_POST['priority_tier'] ?? 'Tier 1 - High Priority';
        $total_budget = (float)($_POST['total_budget'] ?? 0);
        $status = $_POST['status'] ?? 'In Progress';
        $start_date = $_POST['start_date'] ?? '';
        $end_date = $_POST['end_date'] ?? '';
        $desc = trim($_POST['description'] ?? '');

        if (!empty($sub_prog)) {
            if ($db_connected && $pdo) {
                try {
                    $stmt = $pdo->prepare("
                        INSERT INTO projects (programme_title, sub_programme, project_code, project_type, category, directorate_name, saga_name, delivery_unit, priority_tier, total_budget, status, start_date, end_date, description, overall_progress_pct)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0)
                    ");
                    $stmt->execute([
                        $prog_title,
                        $sub_prog,
                        $project_code !== '' ? $project_code : null,
                        $project_type,
                        $cat,
                        $cat === 'Directorate' ? $agency : null,
                        $cat === 'Saga' ? $agency : null,
                        $agency,
                        $tier,
                        $total_budget,
                        $status,
                        $start_date,
                        $end_date,
                        $desc
                    ]);
                    log_audit_trail('CREATE', 'Projects', $pdo->lastInsertId(), "Created project: $sub_prog");
                    $flash_msg = 'Project successfully added to portfolio.';
                } catch (Exception $e) {
                    $flash_msg = 'Database error: ' . $e->getMessage();
                }
            } else {
                $flash_msg = 'Database connection unavailable; project was not saved.';
            }
        }
    }
}

// Multi-Filter parameters
$get_filter = static function (string $key): string {
    $value = isset($_GET[$key]) && is_string($_GET[$key]) ? trim($_GET[$key]) : '';
    return $value !== '' ? $value : 'All';
};
$status_chosen = isset($_GET['status']) && is_string($_GET['status']) && trim($_GET['status']) !== '';
$filter_status = $get_filter('status');
$filter_saga = $get_filter('saga');
$filter_dir = $get_filter('dir');
$filter_category = $get_filter('category');
if (!in_array($filter_category, ['Directorate','Saga'], true)) $filter_category = 'All';
$filter_div = $get_filter('div');
$filter_du = $get_filter('du');
$filter_tier = $get_filter('tier');
// Priority levels offered in the filter. Each level matches stored tier values such as "Tier 1 - ..." as well as the plain word.
$priority_levels = [
    'Critical' => ['Tier 1%', 'Critical%'],
    'High'     => ['Tier 2%', 'High'],
    'Medium'   => ['Tier 3%', 'Medium'],
    'Low'      => ['Tier 4%', 'Low'],
];
$search_q = trim($_GET['q'] ?? '');
$gantt_year = (int)($_GET['year'] ?? 0);
$gantt_month = trim((string)($_GET['month'] ?? ''));
if ($gantt_month !== 'all' && (!ctype_digit($gantt_month) || (int)$gantt_month < 1 || (int)$gantt_month > 12)) $gantt_month = '0';
$gantt_year_options = range(2022, 2027);
if (!in_array($gantt_year, $gantt_year_options, true)) $gantt_year = 0;

$year_chosen = $gantt_year > 0;
$month_chosen = $gantt_month !== '0';
$gantt_directorate = $get_filter('gantt_directorate');
$gantt_saga = $get_filter('gantt_saga');

// Graph and Table Specific Filters
$graph_filter_kpi = isset($_GET['graph_kpi']) && is_string($_GET['graph_kpi']) ? trim($_GET['graph_kpi']) : 'All';
$graph_filter_month = isset($_GET['graph_month']) && is_string($_GET['graph_month']) ? trim($_GET['graph_month']) : 'All';
$graph_filter_year = isset($_GET['graph_year']) && is_string($_GET['graph_year']) ? trim($_GET['graph_year']) : 'All';

$table_filter_kpi = isset($_GET['table_kpi']) && is_string($_GET['table_kpi']) ? trim($_GET['table_kpi']) : '';
$table_filter_month = isset($_GET['table_month']) && is_string($_GET['table_month']) ? trim($_GET['table_month']) : '';
$table_filter_year = isset($_GET['table_year']) && is_string($_GET['table_year']) ? trim($_GET['table_year']) : '';

$monthly_gantt = [];
$available_months = [];
$gantt_directorates = [];
$gantt_divisions = [];
$gantt_sagas = [];
$filter_directorates = [];
$filter_divisions = [];
$filter_division_rows = [];
$filter_sagas = [];
$saga_filter_aliases = [];
$dir_filter_aliases = [];
$registered_dir_rows = [];
$nav_divisions_by_dir = [];
$filter_delivery_units = [];
$filter_tiers = [];
$annual_key_output_records = [];
$annual_key_output_groups = [];
$detail_annual_key_outputs = [];
$portfolio_progress_records = [];
$project_key_output_records = [];
$project_total_count = null;
$project_load_error = false;
$registered_directorates = [];
$registered_sagas = [];

if ($db_connected && $pdo) {
    try {
        $registered_directorates = $pdo->query("SELECT name, code FROM directorates ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
        foreach ($registered_directorates as $registered_dir) {
            $name = (string)$registered_dir['name'];
            // Projects store short names (e.g. "Family Health") while the registry holds the full title.
            $short = trim(preg_replace('/\s+Directorate$/iu', '', preg_replace('/^Directorate\s+(for|of)\s+/iu', '', $name)));
            $dir_filter_aliases[$name] = array_values(array_unique(array_filter([$name, $short, (string)$registered_dir['code']], static fn($v) => $v !== '')));
        }
        $registered_dir_rows = $pdo->query("SELECT id, name FROM directorates ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
        $registered_directorates = array_column($registered_directorates, 'name');
    } catch (Exception $e) { $registered_directorates = []; }
    try {
        $registered_sagas = $pdo->query("SELECT name, code FROM sagas ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
        foreach ($registered_sagas as $registered_saga) {
            $name = (string)$registered_saga['name'];
            $aliases = [$name, (string)$registered_saga['code']];
            if (preg_match('/^(.*?)\s*\(([^()]*)\)\s*$/u', $name, $match)) {
                $aliases[] = trim($match[1]);
                $aliases[] = trim($match[2]);
            }
            $saga_filter_aliases[$name] = array_values(array_unique(array_filter($aliases, static fn($v) => $v !== '')));
        }
    } catch (Exception $e) { $registered_sagas = []; }
}

$projects = [];
if ($db_connected && $pdo) {
    try {
        $showArchivedProjects = isset($_GET['show_archived']) && $_GET['show_archived'] === '1';
        $project_total_count = (int)$pdo->query("SELECT COUNT(*) FROM projects WHERE is_archived = " . ($showArchivedProjects ? '1' : '0'))->fetchColumn();
        $sql = "SELECT * FROM projects WHERE is_archived = " . ($showArchivedProjects ? '1' : '0');
        $params = [];
        if ($filter_status !== 'All') {
            $sql .= " AND (status = ? OR LOWER(status) = LOWER(?))";
            $params[] = $filter_status;
            $params[] = $filter_status;
        }
        if ($filter_saga !== 'All') {
            $aliases = $saga_filter_aliases[$filter_saga] ?? [$filter_saga];
            $placeholders = implode(',', array_fill(0, count($aliases), '?'));
            $sql .= " AND (saga_name IN ($placeholders) OR delivery_unit IN ($placeholders))";
            array_push($params, ...$aliases, ...$aliases);
        }
        if ($filter_dir !== 'All') {
            $aliases = $dir_filter_aliases[$filter_dir] ?? [$filter_dir];
            $placeholders = implode(',', array_fill(0, count($aliases), '?'));
            $sql .= " AND directorate_name IN ($placeholders)";
            array_push($params, ...$aliases);
        }
        if ($filter_category !== 'All') {
            if ($filter_category === 'Directorate') $sql .= " AND (category = 'Directorate' OR (directorate_name IS NOT NULL AND TRIM(directorate_name) <> ''))";
            else $sql .= " AND (category = 'Saga' OR (saga_name IS NOT NULL AND TRIM(saga_name) <> ''))";
        }
        if ($filter_div !== 'All') {
            $sql .= " AND division_name = ?";
            $params[] = $filter_div;
        }
        if ($filter_du !== 'All') {
            $sql .= " AND delivery_unit = ?";
            $params[] = $filter_du;
        }
        if ($filter_tier !== 'All') {
            if (isset($priority_levels[$filter_tier])) {
                $sql .= " AND (priority_tier LIKE ? OR priority_tier LIKE ?)";
                $params[] = $priority_levels[$filter_tier][0];
                $params[] = $priority_levels[$filter_tier][1];
            } else {
                $sql .= " AND priority_tier = ?";
                $params[] = $filter_tier;
            }
        }
        if ($search_q !== '') {
            $sql .= " AND (sub_programme LIKE ? OR programme_title LIKE ? OR description LIKE ? OR project_code LIKE ? OR saga_name LIKE ? OR delivery_unit LIKE ? OR directorate_name LIKE ? OR division_name LIKE ?)";
            for ($i = 0; $i < 8; $i++) $params[] = "%$search_q%";
        }
        $sql .= " ORDER BY id ASC";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $projects = $stmt->fetchAll();
    } catch (Exception $e) { $project_load_error = true; }
}

// Counts for the status and priority-tier tabs are calculated independently of the current filters.
$status_project_counts = [];
$tier_project_counts = ['Critical'=>0, 'High'=>0, 'Medium'=>0, 'Low'=>0];
$status_project_total = (int)($project_total_count ?? count($projects));
if ($db_connected && $pdo) {
    try {
        $archivedFlag = !empty($showArchivedProjects) ? 1 : 0;
        $stCount = $pdo->prepare('SELECT LOWER(TRIM(status)) AS status_key, COUNT(*) AS total FROM projects WHERE is_archived=? GROUP BY LOWER(TRIM(status))');
        $stCount->execute([$archivedFlag]);
        foreach ($stCount->fetchAll(PDO::FETCH_ASSOC) as $r) $status_project_counts[(string)$r['status_key']] = (int)$r['total'];
        $tierQueries = [
            'Critical' => "(priority_tier LIKE 'Tier 1%' OR (priority_tier LIKE '%Critical%' AND priority_tier NOT LIKE 'Tier 2%'))",
            'High'     => "(priority_tier LIKE 'Tier 2%' OR (priority_tier LIKE '%High%' AND priority_tier NOT LIKE 'Tier 1%'))",
            'Medium'   => "(priority_tier LIKE 'Tier 3%' OR (priority_tier LIKE '%Medium%' AND priority_tier NOT LIKE 'Tier 2%'))",
            'Low'      => "(priority_tier LIKE 'Tier 4%' OR priority_tier LIKE '%Low%')",
        ];
        foreach ($tierQueries as $tierKey => $tierCondition) {
            $stTier = $pdo->prepare('SELECT COUNT(*) FROM projects WHERE is_archived=? AND ' . $tierCondition);
            $stTier->execute([$archivedFlag]);
            $tier_project_counts[$tierKey] = (int)$stTier->fetchColumn();
        }
    } catch (Throwable $e) { /* Counts fall back to zero if the database does not provide them. */ }
}

// Single Project Detail Selection
$current_project = null;
if ($is_detail_view && $db_connected && $pdo) {
    try {
        $stmt = $pdo->prepare('SELECT * FROM projects WHERE id = ?');
        $stmt->execute([$view_detail_id]);
        $current_project = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    } catch (Exception $e) {
        $current_project = null;
    }
}

if ($db_connected && $pdo) {
    try {
        $project_directorates = $pdo->query("SELECT DISTINCT directorate_name FROM projects WHERE directorate_name IS NOT NULL AND TRIM(directorate_name) <> '' ORDER BY directorate_name")->fetchAll(PDO::FETCH_COLUMN);
        $known_dir_aliases = [];
        foreach ($dir_filter_aliases as $aliases) foreach ($aliases as $alias) $known_dir_aliases[strtolower($alias)] = true;
        $extra_directorates = array_filter($project_directorates, static fn($d) => !isset($known_dir_aliases[strtolower(trim((string)$d))]));
        $gantt_directorates = array_values(array_unique(array_merge($registered_directorates, $extra_directorates)));
        natcasesort($gantt_directorates); $gantt_directorates = array_values($gantt_directorates);
    } catch (Exception $e) { $gantt_directorates = []; }
    try {
        // Navigation dropdown: divisions come straight from the divisions table, keyed by directorate_id.
        foreach ($pdo->query("SELECT directorate_id, name FROM divisions ORDER BY name")->fetchAll(PDO::FETCH_ASSOC) as $nav_div) {
            $nav_divisions_by_dir[(int)$nav_div['directorate_id']][] = $nav_div['name'];
        }
    } catch (Exception $e) { $nav_divisions_by_dir = []; }
    try {
        $gantt_divisions = $pdo->query("SELECT dir.name AS directorate_name, div.name AS division_name
            FROM divisions div INNER JOIN directorates dir ON dir.id = div.directorate_id
            ORDER BY dir.name, div.name")->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) { $gantt_divisions = []; }
    try {
        $project_divisions = $pdo->query("SELECT DISTINCT directorate_name, division_name FROM projects
            WHERE directorate_name IS NOT NULL AND TRIM(directorate_name) <> ''
              AND division_name IS NOT NULL AND TRIM(division_name) <> ''
            ORDER BY directorate_name, division_name")->fetchAll(PDO::FETCH_ASSOC);
        $division_pairs = [];
        foreach (array_merge($gantt_divisions, $project_divisions) as $division) {
            $pair_key = strtolower(trim((string)$division['directorate_name']) . "\0" . trim((string)$division['division_name']));
            if (!isset($division_pairs[$pair_key])) $division_pairs[$pair_key] = $division;
        }
        $gantt_divisions = array_values($division_pairs);
        usort($gantt_divisions, static function($a, $b) {
            return strnatcasecmp($a['directorate_name'], $b['directorate_name']) ?: strnatcasecmp($a['division_name'], $b['division_name']);
        });
    } catch (Exception $e) { }
    try {
        $project_sagas = $pdo->query("SELECT DISTINCT saga_name FROM projects WHERE saga_name IS NOT NULL AND TRIM(saga_name) <> '' ORDER BY saga_name")->fetchAll(PDO::FETCH_COLUMN);
        $gantt_sagas = array_column($registered_sagas, 'name');
        $known_saga_bases = array_map(static function($name) { return strtolower(trim(preg_replace('/\s*\([^()]*\)\s*$/u', '', (string)$name))); }, $gantt_sagas);
        foreach ($project_sagas as $project_saga) {
            $base = strtolower(trim(preg_replace('/\s*\([^()]*\)\s*$/u', '', (string)$project_saga)));
            if (!in_array($base, $known_saga_bases, true)) $gantt_sagas[] = $project_saga;
        }
        natcasesort($gantt_sagas); $gantt_sagas = array_values(array_unique($gantt_sagas));
    } catch (Exception $e) { $gantt_sagas = []; }
    $filter_directorates = $gantt_directorates;
    $filter_divisions = [];
    $filter_division_rows = [];
    try {
        $filter_division_rows = $pdo->query("SELECT dir.name AS directorate_name, div.name AS division_name FROM divisions div INNER JOIN directorates dir ON dir.id = div.directorate_id ORDER BY div.name")->fetchAll(PDO::FETCH_ASSOC);
        $filter_divisions = array_values(array_unique(array_column($filter_division_rows, 'division_name')));
    } catch (Exception $e) { $filter_divisions = []; $filter_division_rows = []; }
    $filter_sagas = $gantt_sagas;
    try { $filter_delivery_units = $pdo->query("SELECT DISTINCT delivery_unit FROM projects WHERE delivery_unit IS NOT NULL AND TRIM(delivery_unit) <> '' ORDER BY delivery_unit")->fetchAll(PDO::FETCH_COLUMN); } catch (Exception $e) { $filter_delivery_units = []; }
    try { $filter_tiers = $pdo->query("SELECT DISTINCT priority_tier FROM projects WHERE priority_tier IS NOT NULL AND TRIM(priority_tier) <> '' ORDER BY priority_tier")->fetchAll(PDO::FETCH_COLUMN); } catch (Exception $e) { $filter_tiers = []; }
}

// Key Output Progress graph + KPI records table: both read from `project_kpis` (one row per month / year / KPI).
// The project tracks exactly five KPIs (see 5_Monthly_KPIs_Updates_with_Graph.xlsx). Only these are charted.
$kpi_order = ['Foundation structure', 'Structural Works', 'Mechanical Works', 'Electrical Works', 'Plumbing Works'];
$kpi_canon = static function ($name) use ($kpi_order) {
    $needle = strtolower(trim((string)$name));
    foreach ($kpi_order as $k) { if (strtolower($k) === $needle) return $k; }
    return null;
};
$available_kpi_names = [];
$available_table_years = [];
$available_graph_months = [];
$graph_db_rows = [];
$graph_has_any_data = false;
$graph_month_names = $kpi_month_names;
$kpi_records = [];
$kpi_all_names = [];
$tbl_kpis = []; $tbl_years = []; $tbl_months = [];
$table_filters_active = ($table_filter_kpi !== '' || $table_filter_year !== '' || $table_filter_month !== '');

if ($db_connected && $pdo && $is_detail_view) {
    try {
        $kpi_ensure_schema($pdo);
        $kpi_rows_all = [];
        $q = "SELECT id, COALESCE(`year`, YEAR(created_at)) AS yr, `month`, kpi_name, baseline, target, actual_achieved, monthly_progress_pct, cumulative_progress_pct FROM project_kpis WHERE kpi_name <> '' AND (project_id = " . (int)$view_detail_id . " OR project_id IS NULL)";
        foreach ($pdo->query($q)->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $mn = $kpi_month_num($r['month']);
            $target = (float)$r['target']; $actual = (float)$r['actual_achieved'];
            $kpi_rows_all[] = [
                'id' => (int)$r['id'], 'yr' => (int)$r['yr'], 'mnum' => $mn,
                'month_label' => $mn ? $kpi_month_names[$mn] : (string)$r['month'],
                'kpi_name' => (string)$r['kpi_name'],
                'baseline' => (float)$r['baseline'], 'target' => $target, 'actual' => $actual,
                'achieved' => $target > 0 ? round($actual / $target * 100, 2) : 0.0,
                'monthly' => round((float)$r['monthly_progress_pct'] * 100, 2),
                'cumulative' => round((float)$r['cumulative_progress_pct'] * 100, 2),
            ];
        }
        $kpi_rank = array_flip($kpi_order);
        $rank = static fn($n) => $kpi_rank[$kpi_canon($n) ?? ''] ?? 99;

        // Filter option lists (only values that actually exist in the data).
        $canon_present = [];
        foreach ($kpi_rows_all as $r) {
            $kpi_all_names[$r['kpi_name']] = true;
            if ($kpi_canon($r['kpi_name']) !== null) $canon_present[$kpi_canon($r['kpi_name'])] = true;
            if ($r['yr'] > 0) $tbl_years[$r['yr']] = $r['yr'];
            if ($r['mnum'] > 0) $tbl_months[$r['mnum']] = $kpi_month_names[$r['mnum']];
        }
        $kpi_all_names = array_keys($kpi_all_names);
        usort($kpi_all_names, static fn($a, $b) => [$rank($a), $a] <=> [$rank($b), $b]);
        $tbl_kpis = $kpi_all_names;
        rsort($tbl_years); ksort($tbl_months);
        $available_kpi_names = array_values(array_filter($kpi_order, static fn($k) => isset($canon_present[$k])));
        $available_table_years = $tbl_years;
        $available_graph_months = $tbl_months;
        $graph_has_any_data = (bool)$available_kpi_names;

        // Graph rows (graph_* filters), oldest first.
        $g_mnum = $graph_filter_month !== 'All' ? array_search($graph_filter_month, $graph_month_names, true) : false;
        $g_year = ($graph_filter_year !== 'All' && preg_match('/^\d{4}$/', $graph_filter_year)) ? (int)$graph_filter_year : 0;
        $g_rows = $kpi_rows_all;
        usort($g_rows, static fn($a, $b) => [$a['yr'], $a['mnum'], $rank($a['kpi_name']), $a['kpi_name']] <=> [$b['yr'], $b['mnum'], $rank($b['kpi_name']), $b['kpi_name']]);
        foreach ($g_rows as $r) {
            if ($r['mnum'] === 0 || $kpi_canon($r['kpi_name']) === null) continue;
            if ($graph_filter_kpi !== 'All' && strcasecmp($r['kpi_name'], $graph_filter_kpi) !== 0) continue;
            if ($g_year && $r['yr'] !== $g_year) continue;
            if ($g_mnum !== false && $r['mnum'] !== $g_mnum) continue;
            $graph_db_rows[] = ['kpi_name' => $r['kpi_name'], 'cumulative_pct' => $r['cumulative'], 'year_month' => sprintf('%04d-%02d', $r['yr'], $r['mnum'])];
        }

        // Table rows (table_* filters), newest month first.
        $t_mnum = $table_filter_month !== '' ? array_search($table_filter_month, $kpi_month_names, true) : false;
        $t_year = preg_match('/^\d{4}$/', $table_filter_year) ? (int)$table_filter_year : 0;
        $t_rows = $kpi_rows_all;
        usort($t_rows, static fn($a, $b) => [$b['yr'], $b['mnum'], $rank($a['kpi_name']), $a['kpi_name'], $a['id']] <=> [$a['yr'], $a['mnum'], $rank($b['kpi_name']), $b['kpi_name'], $b['id']]);
        foreach ($t_rows as $r) {
            if ($table_filter_kpi !== '' && strcasecmp($r['kpi_name'], $table_filter_kpi) !== 0) continue;
            if ($t_year && $r['yr'] !== $t_year) continue;
            if ($t_mnum !== false && $r['mnum'] !== $t_mnum) continue;
            $kpi_records[] = $r;
        }
    } catch (Exception $e) {
        error_log('KPI progress query failed: ' . $e->getMessage());
        $graph_db_rows = []; $kpi_records = []; $kpi_all_names = [];
    }
}
$kpi_form_names = array_values(array_unique(array_merge($kpi_order, $kpi_all_names)));
$kpi_msgs = ['added'=>'KPI record added.','updated'=>'KPI record updated.','deleted'=>'KPI record deleted (archived in deleted_items).',
    'invalid'=>'Invalid input — check the month, year, KPI and percentage values.','duplicate'=>'A record for that KPI, month and year already exists.',
    'missing'=>'That record no longer exists.','denied'=>'You do not have permission to change KPI records.','csrf'=>'Session expired — please try again.','dberr'=>'Database error — the change was not saved.'];
$kpi_msg_code = (string)($_GET['kpi_msg'] ?? '');
$kpi_msg_text = $kpi_msgs[$kpi_msg_code] ?? '';

// ---- KPI records table: rows are loaded 10 at a time (first page rendered here, the rest fetched on scroll / "Load more") ----
$kpi_page_size = 10;
$kpi_can = can_edit();
$kpi_render_row = static function (array $kr) use ($kpi_can, $kpi_canon): string {
    $kr_label = $kr['month_label'] . ($kr['yr'] ? ' ' . $kr['yr'] : '');
    $kr_json = htmlspecialchars(json_encode([
        'id' => $kr['id'], 'year' => $kr['yr'], 'month_num' => $kr['mnum'], 'kpi_name' => $kr['kpi_name'],
        'baseline_pct' => $kr['baseline'], 'target_pct' => $kr['target'], 'actual_pct' => $kr['actual'],
    ], JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT), ENT_QUOTES);
    $h = '<tr>'
        . '<td>' . htmlspecialchars($kr_label) . '</td>'
        . '<td>' . htmlspecialchars($kr['kpi_name']) . ($kpi_canon($kr['kpi_name']) === null ? ' <small style="color:#94a3b8">(not charted)</small>' : '') . '</td>'
        . '<td class="num">' . number_format($kr['baseline'], 2) . '</td>'
        . '<td class="num">' . number_format($kr['target'], 2) . '</td>'
        . '<td class="num">' . number_format($kr['actual'], 2) . '</td>'
        . '<td class="num">' . number_format($kr['achieved'], 2) . '</td>'
        . '<td class="num">' . number_format($kr['monthly'], 2) . '</td>'
        . '<td class="num"><strong>' . number_format($kr['cumulative'], 2) . '</strong></td>';
    if ($kpi_can) {
        $h .= '<td><div class="kpi-act">'
            . '<button type="button" class="kpi-btn kpi-toggle" aria-haspopup="true" aria-expanded="false">Actions ▾</button>'
            . '<div class="kpi-menu" role="menu">'
            . '<button type="button" role="menuitem" data-kpi-edit="' . $kr_json . '">Edit</button>'
            . '<button type="button" role="menuitem" data-kpi-delete="' . (int)$kr['id'] . '" data-kpi-label="' . htmlspecialchars($kr['kpi_name'] . ' — ' . $kr_label, ENT_QUOTES) . '">Delete</button>'
            . '</div></div></td>';
    }
    return $h . '</tr>';
};
$kpi_total_records = count($kpi_records);

// AJAX: next page of rows (same filters as the page, taken from the query string).
if ($is_detail_view && ($_GET['kpi_rows'] ?? '') === '1') {
    $off = max(0, (int)($_GET['offset'] ?? 0));
    $slice = array_slice($kpi_records, $off, $kpi_page_size);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode([
        'html' => implode('', array_map($kpi_render_row, $slice)),
        'count' => count($slice),
        'next' => $off + count($slice),
        'total' => $kpi_total_records,
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// Demo data is shown only when the project has no monthly progress recorded at all.
$default_graph_months = ['March', 'April', 'May', 'June', 'July', 'August', 'Sept', 'October'];
$default_graph_kpis = [
    'Foundation structure' => [20, 45, 65, 80, 90, 95, 98, 100],
    'Structural Works' => [15, 35, 55, 70, 80, 90, 95, 100],
    'Mechanical Works' => [10, 25, 45, 60, 75, 85, 95, 100],
    'Electrical Works' => [12, 30, 50, 65, 80, 90, 95, 100],
    'Plumbing Works' => [8, 23, 43, 58, 73, 85, 95, 100]
];

if ($graph_has_any_data) {
    $graph_months = [];
    $graph_kpis = [];
    $cells = [];
    $years_in_view = [];
    foreach ($graph_db_rows as $row) {
        $years_in_view[substr((string)$row['year_month'], 0, 4)] = true;
    }
    foreach ($graph_db_rows as $row) {
        $kpi_label = $kpi_canon($row['kpi_name']);
        if ($kpi_label === null) continue;
        $ym = (string)$row['year_month'];
        $label = $graph_month_names[(int)substr($ym, 5, 2)] ?? $ym;
        if (count($years_in_view) > 1) $label .= ' ' . substr($ym, 0, 4);
        if (!in_array($label, $graph_months, true)) $graph_months[] = $label;
        $cells[$kpi_label][$label] = (float)($row['cumulative_pct'] ?? 0);
    }
    foreach ($kpi_order as $kName) {
        if (!isset($cells[$kName])) continue;
        $byMonth = $cells[$kName];
        $graph_kpis[$kName] = array_map(static fn($m) => $byMonth[$m] ?? 0, $graph_months);
    }
} else {
    $graph_months = $default_graph_months;
    $graph_kpis = $default_graph_kpis;
    $available_kpi_names = array_keys($default_graph_kpis);
    $demo_month_names = ['March', 'April', 'May', 'June', 'July', 'August', 'September', 'October'];
    $available_graph_months = array_combine(range(1, 8), $demo_month_names);
    $available_table_years = ['2026'];

    // Apply the KPI / Month filters to the sample data as well, so the filter controls still work.
    if ($graph_filter_kpi !== 'All' && isset($default_graph_kpis[$graph_filter_kpi])) {
        $graph_kpis = [$graph_filter_kpi => $default_graph_kpis[$graph_filter_kpi]];
    }
    if ($graph_filter_year !== 'All' && $graph_filter_year !== '2026') { $graph_months = []; $graph_kpis = []; }
    $demo_month_idx = array_search($graph_filter_month, $demo_month_names, true);
    if ($graph_months && $graph_filter_month !== 'All' && $demo_month_idx !== false) {
        $graph_months = [$default_graph_months[$demo_month_idx]];
        foreach ($graph_kpis as $kName => $vals) {
            $graph_kpis[$kName] = [$vals[$demo_month_idx]];
        }
    }
}

$overall_progress_pct = 0.0;
$overall_month_label = 'October';
if (!empty($kpi_rows_all)) {
    $latestByKpi = [];
    foreach ($kpi_rows_all as $kr) {
        if (empty($kr['kpi_name'])) continue;
        $key = (int)$kr['yr'] * 12 + (int)$kr['mnum'];
        $name = strtolower(trim((string)$kr['kpi_name']));
        if (!isset($latestByKpi[$name]) || $key >= $latestByKpi[$name]['key']) {
            $latestByKpi[$name] = ['key'=>$key, 'value'=>(float)$kr['cumulative']];
        }
    }
    if ($latestByKpi) $overall_progress_pct = array_sum(array_column($latestByKpi, 'value')) / count($latestByKpi);
    elseif (isset($current_project['overall_progress_pct'])) $overall_progress_pct = (float)$current_project['overall_progress_pct'];
} elseif (isset($current_project['overall_progress_pct']) && $current_project['overall_progress_pct'] !== null) {
    $overall_progress_pct = (float)$current_project['overall_progress_pct'];
}
$overall_progress_pct = max(0, min(100, $overall_progress_pct));

require_once __DIR__ . '/../includes/header.php';
?>

<div style="display: flex; flex-direction: column; gap: 24px;">

<?php if ($is_detail_view && $current_project): ?>
    <!-- ================= SINGLE PROJECT DETAIL VIEW ================= -->
    <?php
    // Start / end dates and duration shown in the Project Details card (immutable date objects, date-only).
    $pd_parse_date = static function ($value): ?DateTimeImmutable {
        $value = trim((string)$value);
        if ($value === '' || strpos($value, '0000-00-00') === 0) return null;
        try { return (new DateTimeImmutable($value))->setTime(0, 0); } catch (Exception $e) { return null; }
    };
    $pd_start = $pd_parse_date($current_project['start_date'] ?? '');
    $pd_end   = $pd_parse_date($current_project['end_date'] ?? '');
    $pd_duration = '';
    if ($pd_start && $pd_end && $pd_end >= $pd_start) {
        $pd_diff = $pd_start->diff($pd_end);
        $pd_parts = [];
        if ($pd_diff->y > 0) $pd_parts[] = $pd_diff->y . ' year' . ($pd_diff->y === 1 ? '' : 's');
        if ($pd_diff->m > 0) $pd_parts[] = $pd_diff->m . ' month' . ($pd_diff->m === 1 ? '' : 's');
        if (!$pd_parts) $pd_parts[] = $pd_diff->d . ' day' . ($pd_diff->d === 1 ? '' : 's');
        $pd_duration = implode(' ', $pd_parts);
    }
    $pd_label = 'font-size:.68rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.02em;';
    $pd_value = 'font-weight:800;color:#1d4ed8;margin-top:5px;font-size:.82rem;';
    $pd_card  = 'background:#fff;border:1px solid #e2e8f0;border-radius:12px;padding:20px 22px;box-shadow:0 1px 3px rgba(0,0,0,.05);';
    $pd_select = 'padding:6px 9px;border:1px solid #cbd5e1;border-radius:4px;font-size:.75rem;background:#fff;min-width:110px;';
    ?>
    <style>
        .pd-fields { display: grid; grid-template-columns: repeat(6, minmax(0, 1fr)); gap: 16px 20px; }
        .pd-row2 { display: grid; grid-template-columns: 1.15fr 1fr; gap: 20px; align-items: start; }
        .pd-stack { display: flex; flex-direction: column; gap: 20px; }
        .pd-page { display: flex; flex-direction: column; gap: 20px; padding: 0 50px; box-sizing: border-box; }
        @media (max-width: 600px) { .pd-page { padding: 0 16px; } }
        @media (max-width: 1000px) { .pd-fields { grid-template-columns: repeat(3, minmax(0, 1fr)); } .pd-row2 { grid-template-columns: 1fr; } }
        @media (max-width: 560px) { .pd-fields { grid-template-columns: repeat(2, minmax(0, 1fr)); } }
    </style>
    <div class="pd-page">

        <!-- Back navigation -->
        <div>
            <a href="/modules/projects.php" style="background:#fff;border:1px solid #cbd5e1;color:#1e293b;padding:7px 14px;border-radius:6px;text-decoration:none;font-size:.8rem;font-weight:700;display:inline-flex;align-items:center;gap:6px;">
                &larr; Back to Projects Portfolio
            </a>
        </div>

        <!-- Project title and badges -->
        <div style="<?= $pd_card ?>padding:24px 26px;">
            <h1 style="font-size:1.4rem;font-weight:800;color:#0f172a;margin:0 0 12px;"><?= htmlspecialchars($current_project['sub_programme']) ?></h1>
            <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
                <span style="background:#16a34a;color:#fff;padding:4px 12px;border-radius:6px;font-size:.75rem;font-weight:800;"><?= htmlspecialchars($current_project['status']) ?></span>
                <?php $detailTier = (string)($current_project['priority_tier'] ?? 'Tier 1 - Critical Priority'); $detailTierLower = strtolower($detailTier); $detailTierStyle = (strpos($detailTierLower, 'critical') !== false || strpos($detailTierLower, 'tier 1') !== false) ? ['#fee2e2','#b91c1c','#ef4444'] : ((strpos($detailTierLower, 'tier 2') !== false || strpos($detailTierLower, 'high') !== false) ? ['#ffedd5','#c2410c','#f97316'] : ((strpos($detailTierLower, 'tier 3') !== false || strpos($detailTierLower, 'medium') !== false || strpos($detailTierLower, 'standard') !== false) ? ['#fef3c7','#92400e','#f59e0b'] : ['#dcfce7','#166534','#22c55e'])); ?>
                <span style="background:<?= $detailTierStyle[0] ?>;color:<?= $detailTierStyle[1] ?>;border:1px solid <?= $detailTierStyle[2] ?>;padding:4px 12px;border-radius:6px;font-size:.75rem;font-weight:800;">Priority Tier: <?= htmlspecialchars(preg_replace('/^Tier\s*\d+\s*-\s*/i', '', $detailTier)) ?> (<?= htmlspecialchars($detailTier) ?>)</span>
            </div>
            <?php if (can_edit()): ?><div style="margin-top:14px;display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
                <button type="button" class="module-btn" id="editProjectToggle" aria-expanded="false" aria-controls="editProjectForm">EDIT Project Details</button>
                <form method="post" action="/modules/projects.php<?= !empty($_GET['show_archived']) ? '?show_archived=1' : '' ?>" style="display:flex;gap:8px;">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(get_csrf_token()) ?>"><input type="hidden" name="project_id" value="<?= (int)$current_project['id'] ?>">
                <?php if (!empty($current_project['is_archived'])): ?><button class="module-btn" name="project_action" value="restore_project" type="submit">Restore Project</button><?php else: ?><button class="module-btn" name="project_action" value="archive_project" type="submit" onclick="return confirm('Archive this project? It will be hidden from the active portfolio but its data will be retained.');">Archive Project</button><?php endif; ?>
                </form></div><?php endif; ?>
        </div>

        <!-- Project details -->
        <div id="projectDetailsGrid" style="<?= $pd_card ?>background:#f8fafc;">
            <h3 style="font-size:.9rem;font-weight:800;color:#0f172a;margin:0 0 14px;">PROJECT DETAILS</h3>
            <div class="pd-fields">
                <div><div style="<?= $pd_label ?>">Title</div><div style="<?= $pd_value ?>"><?= htmlspecialchars((string)$current_project['sub_programme']) ?></div></div>
                <div><div style="<?= $pd_label ?>">Code</div><div style="<?= $pd_value ?>"><?= htmlspecialchars((string)($current_project['project_code'] ?? '')) ?: 'None' ?></div></div>
                <div><div style="<?= $pd_label ?>">Delivery Unit</div><div style="<?= $pd_value ?>"><?= htmlspecialchars((string)($current_project['delivery_unit'] ?? 'Ministry of Health')) ?></div></div>
                <div><div style="<?= $pd_label ?>">Total Budget</div><div style="<?= $pd_value ?>font-family:'JetBrains Mono',monospace;"><?= format_kes($current_project['total_budget']) ?></div></div>
                <div><div style="<?= $pd_label ?>">Start Date</div><div style="<?= $pd_value ?>"><?= $pd_start ? $pd_start->format('Y-m-d') : '&mdash;' ?></div></div>
                <div><div style="<?= $pd_label ?>">End Date</div><div style="<?= $pd_value ?>"><?= $pd_end ? $pd_end->format('Y-m-d') : '&mdash;' ?></div></div>
                <div><div style="<?= $pd_label ?>">Duration</div><div style="<?= $pd_value ?>"><?= $pd_duration !== '' ? htmlspecialchars($pd_duration) : '&mdash;' ?></div></div>
            </div>
        </div>
        <?php if (can_edit()): ?>
        <form id="editProjectForm" hidden method="POST" action="/modules/projects.php?id=<?= (int)$view_detail_id ?>#projectDetailsGrid" style="<?= $pd_card ?>display:none;">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(get_csrf_token()) ?>"><input type="hidden" name="project_action" value="edit_project"><input type="hidden" name="project_id" value="<?= (int)$view_detail_id ?>">
            <h3 style="font-size:.9rem;font-weight:800;color:#0f172a;margin:0 0 12px;">EDIT PROJECT DETAILS</h3>
            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;">
                <label style="font-size:.72rem;font-weight:700;color:#475569;">Title<input required name="sub_programme" value="<?= htmlspecialchars((string)$current_project['sub_programme']) ?>" style="display:block;width:100%;box-sizing:border-box;padding:7px;border:1px solid #cbd5e1;border-radius:5px;"></label>
                <label style="font-size:.72rem;font-weight:700;color:#475569;">Programme Title<input name="programme_title" value="<?= htmlspecialchars((string)$current_project['programme_title']) ?>" style="display:block;width:100%;box-sizing:border-box;padding:7px;border:1px solid #cbd5e1;border-radius:5px;"></label>
                <label style="font-size:.72rem;font-weight:700;color:#475569;">Code<input name="project_code" value="<?= htmlspecialchars((string)($current_project['project_code'] ?? '')) ?>" style="display:block;width:100%;box-sizing:border-box;padding:7px;border:1px solid #cbd5e1;border-radius:5px;"></label>
                <label style="font-size:.72rem;font-weight:700;color:#475569;">Start Date<input type="date" required name="start_date" value="<?= htmlspecialchars((string)$current_project['start_date']) ?>" style="display:block;width:100%;box-sizing:border-box;padding:7px;border:1px solid #cbd5e1;border-radius:5px;"></label>
                <label style="font-size:.72rem;font-weight:700;color:#475569;">End Date<input type="date" required name="end_date" value="<?= htmlspecialchars((string)$current_project['end_date']) ?>" style="display:block;width:100%;box-sizing:border-box;padding:7px;border:1px solid #cbd5e1;border-radius:5px;"></label>
                <label style="font-size:.72rem;font-weight:700;color:#475569;">Total Budget<input type="number" min="0" step="0.01" name="total_budget" value="<?= htmlspecialchars((string)$current_project['total_budget']) ?>" style="display:block;width:100%;box-sizing:border-box;padding:7px;border:1px solid #cbd5e1;border-radius:5px;"></label>
                <label style="font-size:.72rem;font-weight:700;color:#475569;grid-column:1/-1;">Action / Description<textarea name="description" rows="3" style="display:block;width:100%;box-sizing:border-box;padding:7px;border:1px solid #cbd5e1;border-radius:5px;"><?= htmlspecialchars((string)($current_project['description'] ?? '')) ?></textarea></label>
            </div>
            <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:12px;"><button type="button" class="module-btn" id="cancelEditProject">Cancel</button><button type="submit" class="module-btn">Save Details</button></div>
        </form>
        <script>(()=>{const b=document.getElementById('editProjectToggle'),f=document.getElementById('editProjectForm'),c=document.getElementById('cancelEditProject');const set=v=>{f.hidden=!v;f.style.display=v?'block':'none';b.setAttribute('aria-expanded',v?'true':'false');if(v)f.scrollIntoView({behavior:'smooth',block:'center'});};b?.addEventListener('click',()=>set(f.hidden));c?.addEventListener('click',()=>set(false));})();</script>
        <?php endif; ?>

        <?php
        $finance_total = isset($current_project['total_budget']) ? (float)$current_project['total_budget'] : null;
        $finance_utilized = isset($current_project['funds_utilized']) ? (float)$current_project['funds_utilized'] : null;
        $finance_gok = isset($current_project['gok_financing']) ? (float)$current_project['gok_financing'] : null;
        $finance_foreign = isset($current_project['foreign_financing']) ? (float)$current_project['foreign_financing'] : null;
        $finance_outstanding = isset($current_project['funds_outstanding']) && $current_project['funds_outstanding'] !== null
            ? (float)$current_project['funds_outstanding']
            : (($finance_total !== null && $finance_utilized !== null) ? max(0, $finance_total - $finance_utilized) : null);
        $finance_chart_data = [
            'Total Budget' => $finance_total,
            'GOK Financing' => $finance_gok,
            'Foreign Financing' => $finance_foreign,
            'Funds Utilized' => $finance_utilized,
            'Funds Outstanding' => $finance_outstanding,
        ];
        $finance_has_data = count(array_filter($finance_chart_data, static fn($value) => $value !== null)) > 0;
        ?>

        <!-- Financial chart (left) + Action & Progress / Remarks (right) -->
        <div class="pd-row2">
            <div style="<?= $pd_card ?>">
                <h3 style="font-size:.9rem;font-weight:800;color:#0f172a;margin:0;">Financial Data (Amount in Millions)</h3>
                <span style="display:block;font-size:.7rem;color:#64748b;margin:4px 0 12px;">Project financial values.</span>
                <?php if ($finance_has_data): ?>
                    <div style="height:300px;position:relative;"><canvas id="projectFinanceChart" aria-label="Project financial data in KES millions"></canvas></div>
                <?php else: ?>
                    <div style="padding:24px;text-align:center;color:#64748b;background:#f8fafc;border-radius:6px;">No financial records are available for this project.</div>
                <?php endif; ?>
            </div>

            <div class="pd-stack">
                <div style="<?= $pd_card ?>">
                    <h3 style="font-size:.85rem;font-weight:800;color:#0f172a;margin:0 0 12px;">Action &amp; Progress:</h3>
                    <div style="background:#f8fafc;border:1px solid #e2e8f0;padding:12px;border-radius:6px;font-size:.8rem;color:#334155;line-height:1.6;min-height:110px;">
                        <?= nl2br(htmlspecialchars((string)$current_project['description'])) ?>
                    </div>
                    <div style="margin-top:16px;">
                        <div style="font-size:.8rem;font-weight:800;color:#0f172a;">Overall Project Progress: <?= number_format($overall_progress_pct, 1) . '%' ?></div>
                        <div style="background:#e2e8f0;height:10px;border-radius:5px;overflow:hidden;margin-top:8px;">
                            <div style="background:#2563eb;height:100%;width:<?= min(100, $overall_progress_pct) ?>%;"></div>
                        </div>
                    </div>
                </div>

                <div style="<?= $pd_card ?>padding:18px 20px;">
                    <h3 style="font-size:.85rem;font-weight:800;color:#0f172a;margin:0 0 10px;">Remarks:</h3>
                    <div style="background:#f8fafc;border:1px solid #e2e8f0;padding:12px;border-radius:6px;font-size:.8rem;color:#334155;line-height:1.6;">
                        Structural fitouts and medical gas telemetry testing proceeding according to revised quarterly milestone timelines.
                    </div>
                </div>
            </div>
        </div>

        <!-- Project Key Output Progress & Targets (full width) -->
        <div id="projectKpiGraphCard" style="<?= $pd_card ?>scroll-margin-top:16px;">
            <h3 style="font-size:.9rem;font-weight:800;color:#0f172a;margin:0;">Project KPI Progress &amp; Targets</h3>
            <span style="display:block;font-size:.72rem;color:#64748b;margin:4px 0 14px;">Cumulative Progress (%) vs Target Lines</span>

            <form method="GET" action="/modules/projects.php#projectKpiGraphCard" style="display:flex;gap:10px;align-items:flex-end;margin-bottom:16px;flex-wrap:wrap;font-size:.75rem;">
                <input type="hidden" name="id" value="<?= $view_detail_id ?>">
                <?php foreach (['table_kpi' => $table_filter_kpi, 'table_year' => $table_filter_year, 'table_month' => $table_filter_month] as $tk => $tv): if ($tv !== ''): ?>
                    <input type="hidden" name="<?= $tk ?>" value="<?= htmlspecialchars($tv) ?>">
                <?php endif; endforeach; ?>
                <div>
                    <label style="display:block;font-weight:700;color:#64748b;margin-bottom:3px;">Filter KPI</label>
                    <select name="graph_kpi" style="<?= $pd_select ?>">
                        <option value="All">All KPIs</option>
                        <?php foreach ($available_kpi_names as $kname): ?>
                            <option value="<?= htmlspecialchars($kname) ?>" <?= $graph_filter_kpi === $kname ? 'selected' : '' ?>><?= htmlspecialchars($kname) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label style="display:block;font-weight:700;color:#64748b;margin-bottom:3px;">Filter Year</label>
                    <select name="graph_year" style="<?= $pd_select ?>">
                        <option value="All">All Years</option>
                        <?php foreach (range(2022, 2030) as $ty): ?>
                            <option value="<?= $ty ?>" <?= $graph_filter_year === (string)$ty ? 'selected' : '' ?>><?= $ty ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label style="display:block;font-weight:700;color:#64748b;margin-bottom:3px;">Filter Month</label>
                    <select name="graph_month" style="<?= $pd_select ?>">
                        <option value="All">All Months</option>
                        <?php foreach ($available_graph_months as $m): ?>
                            <option value="<?= htmlspecialchars($m) ?>" <?= $graph_filter_month === $m ? 'selected' : '' ?>><?= htmlspecialchars($m) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <button type="submit" style="background:#0d47a1;color:#fff;border:none;padding:7px 14px;border-radius:4px;font-weight:700;font-size:.75rem;cursor:pointer;">Filter Graph</button>
                </div>
            </form>

            <?php if (empty($graph_months)): ?><div style="text-align:center;color:#64748b;font-size:.8rem;padding:6px 0 10px;">No KPI progress data for the selected filters.</div><?php endif; ?>
            <div style="height:380px;position:relative;">
                <canvas id="projectKeyOutputProgressChart" aria-label="Cumulative Progress (%) per KPI with Target Line"></canvas>
            </div>

            <!-- ===== KPI records (CRUD) ===== -->
            <?php $kpi_can = can_edit(); $kpi_csrf = get_csrf_token(); ?>
            <style>
                .kpi-crud{margin-top:22px;border-top:1px solid #e2e8f0;padding-top:16px}
                [hidden]{display:none!important}
                .kpi-crud-head{display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:10px}
                .kpi-btn{background:#1976d2;color:#fff;border:none;padding:7px 14px;border-radius:4px;font-weight:700;font-size:.75rem;cursor:pointer;font-family:inherit}
                .kpi-btn:hover{background:#1565c0}
                .kpi-btn.ghost{background:#fff;color:#1976d2;border:1px solid #1976d2}
                .kpi-table-wrap{overflow-x:auto;border:1px solid #e2e8f0;border-radius:8px}
                .kpi-table{width:100%;border-collapse:collapse;font-size:.75rem;min-width:760px}
                .kpi-table th{background:#f1f5f9;color:#475569;text-transform:uppercase;letter-spacing:.02em;font-size:.66rem;text-align:left;padding:9px 10px;white-space:nowrap}
                .kpi-table td{padding:8px 10px;border-top:1px solid #eef2f7;color:#0f172a;vertical-align:middle}
                .kpi-table td.num{text-align:right;font-variant-numeric:tabular-nums}
                .kpi-flash{padding:9px 12px;border-radius:6px;font-size:.78rem;font-weight:600;margin-bottom:10px;background:#e3f2fd;color:#0d47a1;border:1px solid #bbdefb}
                .kpi-flash.err{background:#fef2f2;color:#991b1b;border-color:#fecaca}
                .kpi-act{position:relative;display:inline-block}
                .kpi-menu{display:none;position:fixed;z-index:1000;min-width:120px;background:#fff;border:1px solid #cbd5e1;border-radius:6px;box-shadow:0 6px 18px rgba(0,0,0,.15);padding:4px}
                .kpi-menu.is-open{display:block}
                .kpi-menu button{display:block;width:100%;text-align:left;background:#1976d2;color:#fff;border:none;border-radius:4px;padding:7px 10px;margin:2px 0;font-size:.75rem;font-weight:700;cursor:pointer;font-family:inherit}
                .kpi-menu button:hover{background:#1565c0}
                .kpi-modal{display:none;position:fixed;inset:0;background:rgba(15,23,42,.55);z-index:1100;align-items:center;justify-content:center;padding:16px}
                .kpi-modal.is-open{display:flex}
                .kpi-dialog{background:#fff;border-radius:12px;width:100%;max-width:520px;max-height:92vh;overflow:auto;padding:20px 22px;box-shadow:0 20px 50px rgba(0,0,0,.3)}
                .kpi-dialog h4{margin:0 0 12px;font-size:.95rem;color:#0f172a}
                .kpi-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}
                .kpi-grid .full{grid-column:1/-1}
                .kpi-dialog label{display:block;font-size:.68rem;font-weight:700;color:#64748b;text-transform:uppercase;margin-bottom:3px}
                .kpi-dialog input,.kpi-dialog select,.kpi-dialog textarea{width:100%;box-sizing:border-box;padding:7px 9px;border:1px solid #cbd5e1;border-radius:4px;font-size:.8rem;font-family:inherit}
                .kpi-hint{font-size:.68rem;color:#64748b;margin-top:3px}
                .kpi-foot{display:flex;justify-content:flex-end;gap:8px;margin-top:16px}
            </style>
            <div class="kpi-crud" id="kpiRecords">
                <div class="kpi-crud-head">
                    <div>
                        <h4 id="kpiRecordsTitle" style="display:none;margin:0;font-size:.85rem;font-weight:800;color:#0f172a;">KPI Progress Records</h4>
                        <span id="kpiRecordsDescription" style="display:none;font-size:.7rem;color:#64748b;">The data behind the graph<?= $graph_has_any_data ? '' : ' — none recorded yet; the graph above shows sample data until the first record is added' ?>.</span>
                    </div>
                    <div style="display:flex;gap:8px;flex-wrap:wrap;">
                        <button type="button" class="kpi-btn" id="kpiToggleBtn" aria-expanded="false" aria-controls="kpiTableBox">VIEW or EDIT Graph Data</button>
                        <?php if ($kpi_can): ?><button type="button" class="kpi-btn" id="kpiAddBtn">+ Add Record</button><?php endif; ?>
                    </div>
                </div>
                <?php if ($kpi_msg_text): ?><div class="kpi-flash<?= in_array($kpi_msg_code, ['added','updated','deleted'], true) ? '' : ' err' ?>"><?= htmlspecialchars($kpi_msg_text) ?></div><?php endif; ?>
                <div id="kpiTableBox" data-total="<?= $kpi_total_records ?>" data-page="<?= $kpi_page_size ?>" hidden>
                <form method="GET" action="/modules/projects.php#kpiRecords" style="display:flex;gap:10px;align-items:flex-end;margin-bottom:10px;flex-wrap:wrap;font-size:.75rem;">
                    <input type="hidden" name="id" value="<?= $view_detail_id ?>">
                    <?php foreach (['graph_kpi' => $graph_filter_kpi, 'graph_year' => $graph_filter_year, 'graph_month' => $graph_filter_month] as $gk => $gv): if ($gv !== '' && $gv !== 'All'): ?>
                        <input type="hidden" name="<?= $gk ?>" value="<?= htmlspecialchars($gv) ?>">
                    <?php endif; endforeach; ?>
                    <div>
                        <label for="tblKpi" style="display:block;font-weight:700;color:#64748b;margin-bottom:3px;">KPI</label>
                        <select id="tblKpi" name="table_kpi" style="<?= $pd_select ?>">
                            <option value="">All KPIs</option>
                            <?php foreach ($tbl_kpis as $tk): ?>
                                <option value="<?= htmlspecialchars($tk) ?>" <?= strcasecmp($table_filter_kpi, $tk) === 0 ? 'selected' : '' ?>><?= htmlspecialchars($tk) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label for="tblMonth" style="display:block;font-weight:700;color:#64748b;margin-bottom:3px;">Month</label>
                        <select id="tblMonth" name="table_month" style="<?= $pd_select ?>">
                            <option value="">All Months</option>
                            <?php foreach ($tbl_months as $tm): ?>
                                <option value="<?= htmlspecialchars($tm) ?>" <?= $table_filter_month === $tm ? 'selected' : '' ?>><?= htmlspecialchars($tm) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label for="tblYear" style="display:block;font-weight:700;color:#64748b;margin-bottom:3px;">Year</label>
                        <select id="tblYear" name="table_year" style="<?= $pd_select ?>">
                            <option value="">All Years</option>
                            <?php foreach ($tbl_years as $ty): ?>
                                <option value="<?= (int)$ty ?>" <?= $table_filter_year === (string)$ty ? 'selected' : '' ?>><?= (int)$ty ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div style="display:flex;gap:8px;align-items:center;">
                        <button type="submit" class="kpi-btn">Filter Table</button>
                        <?php if ($table_filters_active): ?>
                            <a href="/modules/projects.php?<?= htmlspecialchars(http_build_query(array_filter(['id' => $view_detail_id, 'graph_kpi' => $graph_filter_kpi === 'All' ? '' : $graph_filter_kpi, 'graph_year' => $graph_filter_year === 'All' ? '' : $graph_filter_year, 'graph_month' => $graph_filter_month === 'All' ? '' : $graph_filter_month], static fn($v) => $v !== ''))) ?>#kpiRecords" style="color:#1976d2;font-weight:700;text-decoration:none;">Reset</a>
                        <?php endif; ?>
                    </div>
                </form>
                <div class="kpi-table-wrap" id="kpiScroll">
                <table class="kpi-table">
                    <thead><tr><th>Month</th><th>KPI</th><th style="text-align:right">Baseline %</th><th style="text-align:right">Target %</th><th style="text-align:right">Actual %</th><th style="text-align:right">Achieved %</th><th style="text-align:right">Monthly %</th><th style="text-align:right">Cumulative %</th><?php if ($kpi_can): ?><th>Actions</th><?php endif; ?></tr></thead>
                    <tbody>
                    <?php if (!$kpi_records): ?>
                        <tr class="kpi-empty"><td colspan="<?= $kpi_can ? 9 : 8 ?>" style="text-align:center;color:#64748b;padding:16px;">No KPI records for the selected filters.</td></tr>
                    <?php endif; ?>
                    <?php foreach (array_slice($kpi_records, 0, $kpi_page_size) as $kr) echo $kpi_render_row($kr); ?>
                    </tbody>
                </table>
                </div>
                <div style="display:flex;justify-content:space-between;align-items:center;margin-top:8px;font-size:.72rem;color:#64748b;">
                    <span id="kpiCount"></span>
                    <button type="button" class="kpi-btn ghost" id="kpiMoreBtn" hidden>Load more</button>
                </div>
                </div>
            </div>

            <script>
            (() => {
                const box = document.getElementById('kpiTableBox'), tbtn = document.getElementById('kpiToggleBtn'),
                      more = document.getElementById('kpiMoreBtn'), cnt = document.getElementById('kpiCount'), title = document.getElementById('kpiRecordsTitle'), desc = document.getElementById('kpiRecordsDescription');
                if (!box || !tbtn) return;
                const body = box.querySelector('tbody');
                const total = parseInt(box.dataset.total || '0', 10);
                let loaded = body.querySelectorAll('tr:not(.kpi-empty)').length, loading = false, failed = false;

                const paint = () => {
                    cnt.textContent = failed ? 'Could not load more records.' : (total ? `Showing ${loaded} of ${total} records` : '');
                    more.hidden = loaded >= total && !failed;
                    more.textContent = failed ? 'Retry' : (loading ? 'Loading…' : 'Load more');
                    more.disabled = loading;
                };
                // Lazy loading: 10 rows per request, fetched from the server with the table's current filters.
                const loadMore = async () => {
                    if (loading || loaded >= total) return;
                    loading = true; failed = false; paint();
                    try {
                        const q = new URLSearchParams(location.search);
                        q.set('kpi_rows', '1'); q.set('offset', String(loaded)); q.delete('kpi_msg');
                        const res = await fetch(location.pathname + '?' + q.toString(), {headers: {'Accept': 'application/json'}, credentials: 'same-origin'});
                        if (!res.ok) throw new Error('HTTP ' + res.status);
                        const data = await res.json();
                        if (data.html) body.insertAdjacentHTML('beforeend', data.html);
                        loaded += data.count || 0;
                        if (!data.count) loaded = total; // nothing more on the server
                    } catch (e) { failed = true; }
                    loading = false; paint();
                };
                more.addEventListener('click', loadMore);
                // No scroll bar inside the table: the next 10 rows load as the page is scrolled to the end of the table.
                const foot = cnt.parentNode; let ticking = false;
                const check = () => {
                    ticking = false;
                    if (box.hidden || loading || failed || loaded >= total) return;
                    if (foot.getBoundingClientRect().top <= window.innerHeight + 60) loadMore();
                };
                window.addEventListener('scroll', () => { if (!ticking) { ticking = true; requestAnimationFrame(check); } }, {passive: true});

                const setTable = on => { box.hidden = !on; if (title) title.style.display = on ? '' : 'none'; if (desc) desc.style.display = on ? '' : 'none'; tbtn.setAttribute('aria-expanded', on ? 'true' : 'false'); tbtn.textContent = on ? 'HIDE Graph Data' : 'VIEW or EDIT Graph Data'; };
                tbtn.addEventListener('click', () => setTable(box.hidden));
                setTable(!box.hidden);
                paint();
            })();
            </script>

            <?php if ($kpi_can): ?>
            <?php $kpi_hidden = '<input type="hidden" name="csrf_token" value="' . htmlspecialchars($kpi_csrf) . '"><input type="hidden" name="project_id" value="' . $view_detail_id . '">'
                . '<input type="hidden" name="graph_kpi" value="' . htmlspecialchars($graph_filter_kpi === 'All' ? '' : $graph_filter_kpi) . '">'
                . '<input type="hidden" name="graph_year" value="' . htmlspecialchars($graph_filter_year === 'All' ? '' : $graph_filter_year) . '">'
                . '<input type="hidden" name="graph_month" value="' . htmlspecialchars($graph_filter_month === 'All' ? '' : $graph_filter_month) . '">'
                . '<input type="hidden" name="table_kpi" value="' . htmlspecialchars($table_filter_kpi) . '">'
                . '<input type="hidden" name="table_year" value="' . htmlspecialchars($table_filter_year) . '">'
                . '<input type="hidden" name="table_month" value="' . htmlspecialchars($table_filter_month) . '">'; ?>
            <div class="kpi-modal" id="kpiFormModal" role="dialog" aria-modal="true" aria-labelledby="kpiFormTitle">
                <form class="kpi-dialog" method="POST" action="/modules/projects.php?id=<?= $view_detail_id ?>#kpiRecords">
                    <?= $kpi_hidden ?>
                    <input type="hidden" name="kpi_action" id="kpiFormAction" value="kpi_add">
                    <input type="hidden" name="record_id" id="kpiFormId" value="0">
                    <h4 id="kpiFormTitle">Add KPI Record</h4>
                    <div class="kpi-grid">
                        <div><label for="kpiFMonth">Month</label>
                            <select id="kpiFMonth" name="month_num" required>
                                <option value="">Select month</option>
                                <?php foreach ($kpi_month_names as $mi => $mn): ?><option value="<?= $mi ?>"><?= htmlspecialchars($mn) ?></option><?php endforeach; ?>
                            </select></div>
                        <div><label for="kpiFYear">Year</label><input type="number" id="kpiFYear" name="year" min="2000" max="2100" step="1" required data-default="<?= (int)($table_filter_year !== '' ? $table_filter_year : date('Y')) ?>"></div>
                        <div class="full"><label for="kpiFName">KPI</label>
                            <select id="kpiFName" name="kpi_name" required>
                                <?php foreach ($kpi_form_names as $kn): ?><option value="<?= htmlspecialchars($kn) ?>"><?= htmlspecialchars($kn) ?></option><?php endforeach; ?>
                            </select></div>
                        <div><label for="kpiFBase">Baseline %</label><input type="number" step="0.01" min="0" max="999.99" id="kpiFBase" name="baseline_pct" placeholder="Auto" readonly style="background:#f1f5f9;">
                            <div class="kpi-hint">Blank = the KPI's previous cumulative.</div></div>
                        <div><label for="kpiFTarget">Target %</label><input type="number" step="0.01" min="0" max="999.99" id="kpiFTarget" name="target_pct" value="100" readonly style="background:#f1f5f9;"></div>
                        <div class="full"><label for="kpiFActual">Actual achieved % (this month)</label><input type="number" step="0.01" min="0" max="999.99" id="kpiFActual" name="actual_pct" required>
                            <div class="kpi-hint">Monthly progress = Actual; Cumulative = Baseline + Actual; Achieved % is calculated automatically.</div></div>
                    </div>
                    <div class="kpi-foot"><button type="button" class="kpi-btn ghost" data-kpi-close>Cancel</button><button type="submit" class="kpi-btn">Save Record</button></div>
                </form>
            </div>
            <div class="kpi-modal" id="kpiDeleteModal" role="dialog" aria-modal="true">
                <form class="kpi-dialog" method="POST" action="/modules/projects.php?id=<?= $view_detail_id ?>#kpiRecords" style="max-width:420px">
                    <?= $kpi_hidden ?>
                    <input type="hidden" name="kpi_action" value="kpi_delete">
                    <input type="hidden" name="record_id" id="kpiDelId" value="0">
                    <h4>Delete KPI record?</h4>
                    <p style="font-size:.8rem;color:#334155;margin:0">This will remove <strong id="kpiDelLabel"></strong> from the graph. A copy is kept in the deleted items archive.</p>
                    <div class="kpi-foot"><button type="button" class="kpi-btn ghost" data-kpi-close>Cancel</button><button type="submit" class="kpi-btn">Delete</button></div>
                </form>
            </div>
            <script>
            (() => {
                const $ = s => document.querySelector(s);
                const fm = $('#kpiFormModal'), dm = $('#kpiDeleteModal');
                const closeMenus = () => document.querySelectorAll('.kpi-menu.is-open').forEach(m => { m.classList.remove('is-open'); const t = m.parentNode.querySelector('.kpi-toggle'); if (t) t.setAttribute('aria-expanded', 'false'); });
                const closeAll = () => { fm.classList.remove('is-open'); dm.classList.remove('is-open'); };
                const openForm = (d) => {
                    closeMenus();
                    $('#kpiFormTitle').textContent = d ? 'Edit KPI Record' : 'Add KPI Record';
                    $('#kpiFormAction').value = d ? 'kpi_edit' : 'kpi_add';
                    $('#kpiFormId').value = d ? d.id : 0;
                    $('#kpiFMonth').value = d ? d.month_num : '';
                    $('#kpiFYear').value = d ? d.year : $('#kpiFYear').getAttribute('data-default');
                    const sel = $('#kpiFName'); sel.value = d ? d.kpi_name : sel.options[0].value;
                    $('#kpiFBase').value = ''; // always derive baseline from the KPI's previous cumulative month
                    $('#kpiFTarget').value = d ? d.target_pct : 100;
                    $('#kpiFActual').value = d ? d.actual_pct : '';
                    fm.classList.add('is-open');
                };
                const add = $('#kpiAddBtn'); if (add) add.addEventListener('click', () => openForm(null));
                document.addEventListener('click', e => {
                    const tg = e.target.closest('.kpi-toggle');
                    if (tg) {
                        const menu = tg.parentNode.querySelector('.kpi-menu'), was = menu.classList.contains('is-open');
                        closeMenus();
                        if (!was) {
                            menu.classList.add('is-open'); tg.setAttribute('aria-expanded', 'true');
                            const r = tg.getBoundingClientRect(), h = menu.offsetHeight;
                            menu.style.left = Math.max(8, Math.min(r.left, innerWidth - menu.offsetWidth - 8)) + 'px';
                            menu.style.top = (r.bottom + h + 8 > innerHeight ? r.top - h - 4 : r.bottom + 4) + 'px';
                        }
                        return;
                    }
                    const ed = e.target.closest('[data-kpi-edit]');
                    if (ed) { openForm(JSON.parse(ed.getAttribute('data-kpi-edit'))); return; }
                    const del = e.target.closest('[data-kpi-delete]');
                    if (del) { closeMenus(); $('#kpiDelId').value = del.getAttribute('data-kpi-delete'); $('#kpiDelLabel').textContent = del.getAttribute('data-kpi-label'); dm.classList.add('is-open'); return; }
                    if (e.target.closest('[data-kpi-close]') || e.target === fm || e.target === dm) { closeAll(); return; }
                    if (!e.target.closest('.kpi-menu')) closeMenus();
                });
                document.addEventListener('keydown', e => { if (e.key === 'Escape') { closeMenus(); closeAll(); } });
                ['resize', 'scroll'].forEach(ev => window.addEventListener(ev, closeMenus, true));
            })();
            </script>
            <?php endif; ?>
        </div>
    </div>

    <script src="/assets/js/chart.min.js"></script>
    <script>
    (() => {
        if (typeof Chart === 'undefined') return;

        // ---- Financial data chart ----
        const financeCanvas = document.getElementById('projectFinanceChart');
        if (financeCanvas) {
            const labels = <?= json_encode(array_keys($finance_chart_data), JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_AMP|JSON_HEX_QUOT) ?>;
            const values = <?= json_encode(array_values($finance_chart_data), JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_AMP|JSON_HEX_QUOT) ?>.map(v => v === null ? null : Number(v) / 1000000);
            const colors = ['#245789','#4f8fc2','#72b6d8','#70ad5a','#ed8b24'];
            const valueLabels = {
                id: 'projectFinanceValueLabels',
                afterDatasetsDraw(chart) {
                    const {ctx} = chart;
                    ctx.save();
                    ctx.font = '700 11px Arial';
                    ctx.fillStyle = '#111827';
                    ctx.textAlign = 'center';
                    chart.getDatasetMeta(0).data.forEach((bar, index) => {
                        if (values[index] === null) return;
                        ctx.fillText(values[index].toLocaleString(undefined, {maximumFractionDigits: 0}), bar.x, bar.y - 7);
                    });
                    ctx.restore();
                }
            };
            const finiteValues = values.filter(v => v !== null);
            new Chart(financeCanvas, {
                type: 'bar',
                data: {labels, datasets: [{label: 'KES millions', data: values, backgroundColor: colors, borderColor: colors, borderWidth: 1, borderRadius: 2, maxBarThickness: 58}]},
                plugins: [valueLabels],
                options: {
                    responsive: true, maintainAspectRatio: false,
                    plugins: {legend: {display: false}, tooltip: {callbacks: {label: c => `KES ${Number(c.raw).toLocaleString(undefined,{maximumFractionDigits:2})}M`}}},
                    scales: {
                        y: {beginAtZero: true, suggestedMax: Math.max(1, Math.ceil(Math.max(0, ...finiteValues) / 200) * 200), title: {display: true, text: 'Amount'}, grid: {color: '#e5e7eb'}},
                        x: {grid: {display: false}, ticks: {maxRotation: 0, minRotation: 0, font: {size: 11}}}
                    }
                }
            });
        }

        // ---- Key output progress chart ----
        const progressCanvas = document.getElementById('projectKeyOutputProgressChart');
        if (progressCanvas) {
            const months = <?= json_encode(array_values($graph_months)) ?>;
            const kpiData = <?= json_encode($graph_kpis) ?>;
            const colorPalette = {
                'Electrical Works': '#4f8fc2',
                'Foundation structure': '#ed8b24',
                'Mechanical Works': '#a5a5a5',
                'Plumbing Works': '#ffc000',
                'Structural Works': '#245789'
            };
            const barDatasets = Object.keys(kpiData).map(kpi => ({
                type: 'bar',
                label: kpi,
                data: kpiData[kpi],
                backgroundColor: colorPalette[kpi] || '#64748b',
                borderColor: colorPalette[kpi] || '#64748b',
                borderWidth: 1,
                borderRadius: 3,
                order: 2
            }));
            const targetLineDataset = {
                type: 'line',
                label: 'Target (100%)',
                data: months.map(() => 100),
                borderColor: '#1e40af',
                backgroundColor: '#1e40af',
                borderWidth: 2,
                borderDash: [6, 4],
                pointRadius: 3,
                pointHoverRadius: 4,
                fill: false,
                order: 1
            };
            new Chart(progressCanvas, {
                data: {labels: months, datasets: [...barDatasets, targetLineDataset]},
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    interaction: {mode: 'index', intersect: false},
                    plugins: {
                        legend: {position: 'bottom', labels: {font: {size: 11, weight: '600'}, usePointStyle: true, boxWidth: 10}},
                        tooltip: {callbacks: {label: c => `${c.dataset.label}: ${c.raw}%`}}
                    },
                    scales: {
                        y: {beginAtZero: true, max: 110, title: {display: true, text: 'Progress & Target (%)'}, ticks: {callback: v => v + '%'}, grid: {color: '#e2e8f0'}},
                        x: {grid: {display: false}, ticks: {font: {weight: '600'}}}
                    }
                }
            });
        }

        // After Filter Graph is submitted, bring the graph into view.
        if (/[?&](graph_(kpi|month|year)|kpi_msg)=/.test(location.search) || location.hash === '#projectKpiGraphCard') {
            const target = document.getElementById('projectKpiGraphCard');
            if (target) {
                const go = () => target.scrollIntoView({behavior: 'auto', block: 'start'});
                if (document.readyState === 'complete') go(); else window.addEventListener('load', go);
            }
        }
    })();
    </script>

<?php else: ?>
    <!-- ================= MAIN PROJECTS PORTFOLIO VIEW ================= -->

    <?php
    $nav_keep = array_filter([
        'status' => $status_chosen ? $filter_status : '',
        'tier' => $filter_tier !== 'All' ? $filter_tier : '',
        'q' => $search_q,
        'year' => $year_chosen ? $gantt_year : '',
        'month' => $month_chosen ? $gantt_month : '',
    ], static fn($v) => $v !== '' && $v !== null);
    $nav_url = static fn(array $extra) => '/modules/projects.php?' . htmlspecialchars(http_build_query($extra + $nav_keep));
    $nav_directorates = [];
    foreach ($registered_dir_rows as $r) $nav_directorates[] = ['name' => $r['name'], 'divisions' => $nav_divisions_by_dir[(int)$r['id']] ?? []];
    foreach ($gantt_directorates as $d) if (!in_array($d, array_column($nav_directorates, 'name'), true)) $nav_directorates[] = ['name' => $d, 'divisions' => []];
    $dir_tab_active = $filter_category === 'Directorate' || ($filter_dir !== 'All' && $filter_saga === 'All');
    $saga_tab_active = $filter_category === 'Saga' || $filter_saga !== 'All';
    ?>
    <nav class="project-nav-tabs" id="projectNavTabs" aria-label="Browse projects by directorate or SAGA">
        <div class="project-nav-item<?= $dir_tab_active ? ' is-active' : '' ?>">
            <a class="project-nav-tab project-nav-blue" href="<?= $nav_url(['category' => 'Directorate']) ?>" aria-haspopup="true" aria-expanded="false">
                <span class="project-nav-icon" aria-hidden="true">▣</span><span>Directorates</span><small><?= count($nav_directorates) ?></small><b aria-hidden="true">⌄</b>
            </a>
            <div class="project-nav-menu">
                <?php if (!$nav_directorates): ?><span class="project-browse-empty">No directorates are registered.</span><?php endif; ?>
                <?php foreach ($nav_directorates as $nav_dir): ?>
                    <?php $directorate = $nav_dir['name']; $directorate_divisions = $nav_dir['divisions']; ?>
                    <div class="project-nav-row<?= $directorate_divisions ? ' has-sub' : '' ?>">
                        <a class="project-nav-link<?= $filter_dir === $directorate && $filter_div === 'All' ? ' is-current' : '' ?>" href="<?= $nav_url(['dir' => $directorate]) ?>"><span><?= htmlspecialchars($directorate) ?></span><?php if ($directorate_divisions): ?><i aria-hidden="true">›</i><?php endif; ?></a>
                        <?php if ($directorate_divisions): ?>
                        <div class="project-nav-submenu">
                            <a class="project-nav-link project-nav-all" href="<?= $nav_url(['dir' => $directorate]) ?>">All divisions</a>
                            <?php foreach ($directorate_divisions as $division_name): ?>
                                <a class="project-nav-link<?= $filter_dir === $directorate && $filter_div === $division_name ? ' is-current' : '' ?>" href="<?= $nav_url(['dir' => $directorate, 'div' => $division_name]) ?>"><?= htmlspecialchars($division_name) ?></a>
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <div class="project-nav-item<?= $saga_tab_active ? ' is-active' : '' ?>">
            <a class="project-nav-tab project-nav-green" href="<?= $nav_url(['category' => 'Saga']) ?>" aria-haspopup="true" aria-expanded="false">
                <span class="project-nav-icon" aria-hidden="true">⬡</span><span>SAGAs</span><small><?= count($gantt_sagas) ?></small><b aria-hidden="true">⌄</b>
            </a>
            <div class="project-nav-menu">
                <?php if (!$gantt_sagas): ?><span class="project-browse-empty">No SAGAs are registered.</span><?php endif; ?>
                <?php foreach ($gantt_sagas as $saga): ?>
                    <div class="project-nav-row"><a class="project-nav-link<?= $filter_saga === $saga ? ' is-current' : '' ?>" href="<?= $nav_url(['saga' => $saga]) ?>"><span><?= htmlspecialchars($saga) ?></span></a></div>
                <?php endforeach; ?>
            </div>
        </div>
    </nav>
    <script>
    (() => {
        const nav = document.getElementById('projectNavTabs');
        if (!nav) return;
        nav.classList.add("js-ready");
        const items = [...nav.querySelectorAll('.project-nav-item')];
        const setOpen = (item) => items.forEach(i => {
            const on = i === item;
            i.classList.toggle('is-open', on);
            i.querySelector('.project-nav-tab').setAttribute('aria-expanded', on ? 'true' : 'false');
        });
        items.forEach(item => {
            item.addEventListener('mouseenter', () => setOpen(item));
            item.addEventListener('focusin', () => setOpen(item));
            // Touch devices: first tap opens the menu, second tap follows the tab link.
            item.querySelector('.project-nav-tab').addEventListener('click', e => {
                if (window.matchMedia('(hover: none)').matches && !item.classList.contains('is-open')) { e.preventDefault(); setOpen(item); }
            });
        });
        nav.addEventListener('mouseleave', () => setOpen(null));
        document.addEventListener('click', e => { if (!nav.contains(e.target)) setOpen(null); });
        document.addEventListener('keydown', e => { if (e.key === 'Escape') setOpen(null); });
    })();
    </script>

    <!-- Status and Priority Tier filters on separate rows to prevent horizontal scrolling -->
    <div style="background: white; padding: 10px 14px; border-radius: 12px; border: 1px solid #e2e8f0; display: flex; flex-direction: column; align-items: stretch; gap: 12px; overflow: visible; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
        <div style="display:flex; flex-wrap:wrap; align-items:center; justify-content:flex-start; gap:6px 8px; white-space:normal;">
            <span style="font-size: 0.75rem; font-weight: 800; color: #475569; margin-right: 4px;">Status:</span>
            <?php
            $statuses = ['All', 'In Progress', 'On Hold', 'Completed', 'Planning', 'Delayed', 'Overdue', 'Cancelled'];
            foreach ($statuses as $st):
                $isActive = $status_chosen && (strtolower($filter_status) === strtolower($st));
                $status_colors = ['All'=>['#0d47a1','#ffffff'],'In Progress'=>['#d1fae5','#047857'],'On Hold'=>['#fef3c7','#92400e'],'Completed'=>['#dbeafe','#1d4ed8'],'Planning'=>['#ede9fe','#6d28d9'],'Delayed'=>['#ffedd5','#c2410c'],'Overdue'=>['#fee2e2','#b91c1c'],'Cancelled'=>['#e2e8f0','#475569']];
                $status_color = $status_colors[$st] ?? ['#f1f5f9','#334155'];
            ?>
                <a href="/modules/projects.php?status=<?= urlencode($st) ?>&saga=<?= urlencode($filter_saga) ?>&dir=<?= urlencode($filter_dir) ?>&div=<?= urlencode($filter_div) ?>&du=<?= urlencode($filter_du) ?>&tier=<?= urlencode($filter_tier) ?>&q=<?= urlencode($search_q) ?>&year=<?= $year_chosen ? $gantt_year : '' ?>&month=<?= $month_chosen ? $gantt_month : '' ?>&gantt_directorate=<?= urlencode($gantt_directorate) ?>&gantt_saga=<?= urlencode($gantt_saga) ?>#allProjectsPanel" 
                   aria-label="Filter projects by <?= htmlspecialchars($st) ?>" <?= $isActive ? 'aria-current="true"' : '' ?>
                   style="padding: 5px 12px; border-radius: 20px; font-size: 0.75rem; font-weight: 700; text-decoration: none; transition: all 0.2s; background: <?= $status_color[0] ?>; color: <?= $status_color[1] ?>; border:<?= $isActive ? '2px' : '1px' ?> solid <?= $status_color[1] ?>; box-shadow:<?= $isActive ? '0 0 0 2px '.$status_color[0] : 'none' ?>;">
                    <?= htmlspecialchars($st) ?> <small style="opacity:.85">(<?= $st === 'All' ? (int)$status_project_total : (int)($status_project_counts[strtolower($st)] ?? 0) ?>)</small>
                </a>
            <?php endforeach; ?>
        </div>

        <div style="display:flex;align-items:center;gap:7px;flex-wrap:wrap;white-space:normal;border-top:1px solid #e2e8f0;padding-top:10px;">
            <span style="font-size:.72rem;font-weight:800;color:#475569;margin-right:2px;">Priority Tier:</span>
            <?php
            $tier_tab_labels = ['Critical'=>'Tier 1 · Critical','High'=>'Tier 2 · High','Medium'=>'Tier 3 · Medium','Low'=>'Tier 4 · Low'];
            $tier_tab_colors = ['Critical'=>['#fee2e2','#b91c1c','#ef4444'],'High'=>['#ffedd5','#c2410c','#f97316'],'Medium'=>['#fef3c7','#92400e','#f59e0b'],'Low'=>['#dcfce7','#166534','#22c55e']];
            foreach ($tier_tab_labels as $tierKey => $tierLabel): $tierActive = $filter_tier === $tierKey; $tierColor = $tier_tab_colors[$tierKey]; ?>
                <a href="/modules/projects.php?tier=<?= urlencode($tierKey) ?>&status=<?= urlencode($status_chosen ? $filter_status : '') ?>&saga=<?= urlencode($filter_saga) ?>&dir=<?= urlencode($filter_dir) ?>&div=<?= urlencode($filter_div) ?>&du=<?= urlencode($filter_du) ?>&q=<?= urlencode($search_q) ?>#allProjectsPanel" style="display:inline-flex;align-items:center;gap:4px;padding:6px 11px;border-radius:18px;border:1px solid <?= $tierColor[2] ?>;background:<?= $tierActive ? $tierColor[2] : $tierColor[0] ?>;color:<?= $tierActive ? '#ffffff' : $tierColor[1] ?>;font-size:.72rem;font-weight:800;text-decoration:none;white-space:nowrap;box-shadow:<?= $tierActive ? '0 0 0 2px '.$tierColor[0] : 'none' ?>;">
                    <?= htmlspecialchars($tierLabel) ?> <small>(<?= (int)($tier_project_counts[$tierKey] ?? 0) ?>)</small>
                </a>
            <?php endforeach; ?>
        </div>
        <div>
            <a href="/modules/projects.php" style="background: #e2e8f0; color: #1e293b; padding: 6px 14px; border-radius: 20px; font-size: 0.75rem; font-weight: 800; text-decoration: none;">
                &#x21bb; Reset Filters
            </a>
        </div>
    </div>

    <!-- Search and Filters -->
    <div style="background: white; padding: 20px; border-radius: 12px; border: 1px solid #e2e8f0; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
        <form method="GET" action="/modules/projects.php" id="projectFilterForm" autocomplete="off" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(170px, 1fr)); gap: 14px; align-items: flex-end;">
            <input type="hidden" name="status" value="<?= $status_chosen ? htmlspecialchars($filter_status) : '' ?>">
            <input type="hidden" name="gantt_directorate" value="<?= $gantt_directorate === 'All' ? '' : htmlspecialchars($gantt_directorate) ?>">
            <input type="hidden" name="gantt_saga" value="<?= $gantt_saga === 'All' ? '' : htmlspecialchars($gantt_saga) ?>">

            <div><label style="display:block;font-size:.72rem;font-weight:700;color:#64748b;text-transform:uppercase;margin-bottom:4px;">Year</label><select name="year" style="width:100%;padding:4px 7px;border:1px solid #cbd5e1;border-radius:6px;font-size:.76rem;"><option value="" <?= !$year_chosen ? 'selected' : '' ?>>Select year</option><?php foreach ($gantt_year_options as $fy): ?><option value="<?= $fy ?>" <?= $year_chosen && $fy === $gantt_year ? 'selected' : '' ?>><?= $fy ?></option><?php endforeach; ?></select></div>
            <div><label style="display:block;font-size:.72rem;font-weight:700;color:#64748b;text-transform:uppercase;margin-bottom:4px;">Month</label><select name="month" style="width:100%;padding:4px 7px;border:1px solid #cbd5e1;border-radius:6px;font-size:.76rem;"><option value="" <?= !$month_chosen ? 'selected' : '' ?>>Select month</option><option value="all" <?= $gantt_month === 'all' ? 'selected' : '' ?>>All Months</option><?php foreach (range(1, 12) as $fm): ?><option value="<?= $fm ?>" <?= $month_chosen && (string)$fm === $gantt_month ? 'selected' : '' ?>><?= date('F', mktime(0, 0, 0, $fm, 1)) ?></option><?php endforeach; ?></select></div>

            <!-- SAGA Filter -->
            <div>
                <label style="display: block; font-size: 0.72rem; font-weight: 700; color: #64748b; text-transform: uppercase; margin-bottom: 4px;">Filter by SAGA</label>
                <select name="saga" style="width: 100%; padding: 4px 7px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.76rem;">
                    <option value="" <?= $filter_saga === 'All' ? 'selected' : '' ?>>Select SAGA</option>
                    <?php foreach ($filter_sagas as $saga): ?><option value="<?= htmlspecialchars($saga) ?>" <?= $filter_saga === $saga ? 'selected' : '' ?>><?= htmlspecialchars($saga) ?></option><?php endforeach; ?>
                </select>
            </div>

            <!-- Directorate Filter -->
            <div>
                <label style="display: block; font-size: 0.72rem; font-weight: 700; color: #64748b; text-transform: uppercase; margin-bottom: 4px;">Filter by Directorate</label>
                <select name="dir" id="filterDirectorateSelect" style="width: 100%; padding: 4px 7px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.76rem;">
                    <option value="" <?= $filter_dir === 'All' ? 'selected' : '' ?>>Select directorate</option>
                    <?php foreach ($filter_directorates as $directorate): ?><option value="<?= htmlspecialchars($directorate) ?>" <?= $filter_dir === $directorate ? 'selected' : '' ?>><?= htmlspecialchars($directorate) ?></option><?php endforeach; ?>
                </select>
            </div>

            <!-- Division Filter -->
            <div>
                <label style="display: block; font-size: 0.72rem; font-weight: 700; color: #64748b; text-transform: uppercase; margin-bottom: 4px;">Filter by Division</label>
                <select name="div" id="filterDivisionSelect" style="width: 100%; padding: 4px 7px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.76rem;">
                    <option value="" <?= $filter_div === 'All' ? 'selected' : '' ?>>Select division</option>
                    <?php $seen_division_options = []; foreach ($filter_division_rows as $division_row):
                        $division_label = (string)$division_row['division_name'];
                        $division_key = strtolower((string)$division_row['directorate_name'] . "\0" . $division_label);
                        if (isset($seen_division_options[$division_key])) continue; $seen_division_options[$division_key] = true; ?>
                        <option value="<?= htmlspecialchars($division_label) ?>" data-directorate="<?= htmlspecialchars((string)$division_row['directorate_name']) ?>" <?= $filter_div === $division_label ? 'selected' : '' ?>><?= htmlspecialchars($division_label) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Delivery Unit Filter -->
            <div>
                <label style="display: block; font-size: 0.72rem; font-weight: 700; color: #64748b; text-transform: uppercase; margin-bottom: 4px;">Filter by Delivery Unit</label>
                <select name="du" style="width: 100%; padding: 4px 7px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.76rem;">
                    <option value="" <?= $filter_du === 'All' ? 'selected' : '' ?>>Select delivery unit</option>
                    <?php foreach ($filter_delivery_units as $delivery_unit): ?><option value="<?= htmlspecialchars($delivery_unit) ?>" <?= $filter_du === $delivery_unit ? 'selected' : '' ?>><?= htmlspecialchars($delivery_unit) ?></option><?php endforeach; ?>
                </select>
            </div>

            <!-- Priority Tier Filter -->
            <div>
                <label style="display: block; font-size: 0.72rem; font-weight: 700; color: #64748b; text-transform: uppercase; margin-bottom: 4px;">Priority Tier</label>
                <select name="tier" style="width: 100%; padding: 4px 7px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.76rem;">
                    <option value="" <?= $filter_tier === 'All' ? 'selected' : '' ?>>Select priority tier</option>
                    <?php foreach (array_keys($priority_levels) as $level): ?><option value="<?= htmlspecialchars($level) ?>" <?= $filter_tier === $level ? 'selected' : '' ?>><?= htmlspecialchars($level) ?></option><?php endforeach; ?>
                    <?php foreach ($filter_tiers as $tier): if (isset($priority_levels[$tier])) continue; ?><option value="<?= htmlspecialchars($tier) ?>" <?= $filter_tier === $tier ? 'selected' : '' ?>><?= htmlspecialchars($tier) ?></option><?php endforeach; ?>
                </select>
            </div>

            <!-- Search Projects -->
            <div>
                <label style="display: block; font-size: 0.72rem; font-weight: 700; color: #64748b; text-transform: uppercase; margin-bottom: 4px;">Search Projects</label>
                <input type="text" name="q" autocomplete="off" value="<?= htmlspecialchars($search_q) ?>" placeholder="Search title, keyword..." style="width: 100%; padding: 4px 7px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.76rem;">
            </div>

            <!-- Filter Buttons -->
            <div style="display: flex; gap: 8px;">
                <button type="submit" style="background: #0d47a1; color: white; border: none; padding: 8px 16px; border-radius: 6px; font-weight: 700; font-size: 0.78rem; cursor: pointer;">
                    Apply Filters
                </button>
                <a href="/modules/projects.php" style="background: #f1f5f9; color: #334155; border: 1px solid #cbd5e1; padding: 7px 12px; border-radius: 6px; font-weight: 700; font-size: 0.78rem; text-decoration: none; text-align: center;">
                    Reset
                </a>
            </div>
        </form>
    </div>

    <script>
    (() => {
        const form = document.getElementById('projectFilterForm');
        const dir = document.getElementById('filterDirectorateSelect');
        const div = document.getElementById('filterDivisionSelect');
        if (!form || !dir || !div) return;
        const syncDivisions = (resetInvalid) => {
            [...div.options].forEach(option => {
                const belongs = !option.dataset.directorate || !dir.value || dir.value === 'All' || option.dataset.directorate === dir.value;
                option.hidden = !belongs; option.disabled = !belongs;
            });
            if (resetInvalid && div.selectedOptions[0]?.disabled) div.value = '';
        };
        syncDivisions(false);
        dir.addEventListener('change', () => { syncDivisions(true); form.requestSubmit(); });
        form.querySelectorAll('select').forEach(select => { if (select !== dir) select.addEventListener('change', () => form.requestSubmit()); });
    })();
    </script>

    <?php
    $ft_progress_map = $monthly_progress_by_project ?? [];
    $ft_progress = static function(array $p) use ($ft_progress_map) {
        if (isset($ft_progress_map[(int)$p['id']])) return (float)$ft_progress_map[(int)$p['id']];
        if (isset($p['overall_progress_pct']) && $p['overall_progress_pct'] !== null) return (float)$p['overall_progress_pct'];
        if (preg_match('/^\s*(\d+(?:\.\d+)?)\s*%?\s*$/', (string)($p['progress_status'] ?? ''), $m)) return (float)$m[1];
        return 0.0;
    };
    $ft_types = array_values(array_unique(array_filter(array_map(static fn($p) => (string)($p['project_type'] ?? ''), $projects))));
    $ft_cats = array_values(array_unique(array_filter(array_map(static fn($p) => (string)($p['category'] ?? ''), $projects))));
    $ft_statuses = array_values(array_unique(array_filter(array_map(static fn($p) => (string)($p['status'] ?? ''), $projects))));
    sort($ft_types); sort($ft_cats); sort($ft_statuses);
    ?>
    <?php
    $ft_agency = static fn($p) => (string)(($p['directorate_name'] ?? '') !== '' && $p['directorate_name'] !== null ? $p['directorate_name'] : ($p['saga_name'] ?? ''));
    $ft_uniq = static function(callable $fn) use ($projects) { $v = array_values(array_unique(array_filter(array_map($fn, $projects), static fn($x) => trim((string)$x) !== ''))); natcasesort($v); return array_values($v); };
    $ft_agencies = $ft_uniq($ft_agency);
    $ft_divs = $ft_uniq(static fn($p) => (string)($p['division_name'] ?? ''));
    $ft_dus = $ft_uniq(static fn($p) => (string)($p['delivery_unit'] ?? ''));
    $ft_row_tint = ['in progress'=>'#f0fdf4','completed'=>'#f0fdf4','overdue'=>'#fef2f2','delayed'=>'#fff7ed','on hold'=>'#fffbeb','planning'=>'#f5f3ff','cancelled'=>'#f1f5f9'];
    ?>
    
    
    <script>
    (() => {
        const root = document.getElementById('projectFilterTable'); if (!root) return;
        const rows = [...root.querySelectorAll('tbody tr[data-budget]')], empty = root.querySelector('.ft-empty');
        const filters = [...root.querySelectorAll('[data-filter]')], search = root.querySelector('#ftSearch');
        const count = root.querySelector('#ftCount'), shownLbl = root.querySelector('#ftShown'), more = root.querySelector('#ftMore');
        const STEP = 10; let limit = STEP, sortKey = null, sortDir = 1;
        const toggle = document.getElementById('ftToggle');
        toggle.addEventListener('click', () => {
            const open = root.hidden;
            root.hidden = !open; toggle.setAttribute('aria-expanded', open ? 'true' : 'false'); toggle.classList.toggle('is-open', open);
            if (open) { root.classList.add('ft-reveal'); root.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); }
        });
        const numTest = (expr, val) => {
            const m = expr.trim().match(/^(>=|<=|>|<|=)?\s*([\d.,]+)$/); if (!m) return true;
            const n = parseFloat(m[2].replace(/,/g, '')); switch (m[1]) { case '>': return val > n; case '>=': return val >= n; case '<': return val < n; case '<=': return val <= n; default: return val === n; }
        };
        const apply = () => {
            const q = search.value.trim().toLowerCase();
            const match = rows.filter(r => {
                if (q && !r.dataset.title.includes(q)) return false;
                return filters.every(f => {
                    const v = f.value.trim(), k = f.dataset.filter; if (!v) return true;
                    if (k === 'budget' || k === 'progress') return numTest(v, +r.dataset[k]);
                    return r.dataset[k] === v;
                });
            });
            if (sortKey) match.sort((a, b) => {
                const num = sortKey === 'budget' || sortKey === 'progress';
                const x = num ? +a.dataset[sortKey] : (a.dataset[sortKey] || '').toLowerCase(), y = num ? +b.dataset[sortKey] : (b.dataset[sortKey] || '').toLowerCase();
                return (x > y ? 1 : x < y ? -1 : 0) * sortDir;
            });
            const shown = new Set(match.slice(0, limit));
            if (rows.length) match.forEach(r => empty.parentNode.insertBefore(r, empty));
            rows.forEach(r => { r.hidden = !shown.has(r); });
            empty.hidden = match.length > 0;
            count.textContent = match.length + ' of ' + rows.length + ' projects match';
            const left = match.length - shown.size;
            shownLbl.textContent = 'Showing ' + shown.size + ' of ' + match.length;
            more.hidden = left <= 0; more.textContent = 'View ' + Math.min(STEP, left) + ' next row' + (Math.min(STEP, left) === 1 ? '' : 's') + ' \u2193';
        };
        [search, ...filters].forEach(el => el.addEventListener(el.tagName === 'SELECT' ? 'change' : 'input', () => { limit = STEP; apply(); }));
        more.addEventListener('click', () => { limit += STEP; apply(); });
        root.querySelector('#ftClear').addEventListener('click', () => { search.value = ''; filters.forEach(f => f.value = ''); limit = STEP; apply(); });
        root.querySelectorAll('th[data-sort]').forEach(th => th.addEventListener('click', () => { const k = th.dataset.sort; sortDir = sortKey === k ? -sortDir : 1; sortKey = k; limit = STEP; apply(); }));
        apply();
    })();
    </script>

    <script>
    (() => {
        const form = document.getElementById('projectFilterForm');
        if (form) form.addEventListener('submit', () => { form.action = '/modules/projects.php#allProjectsPanel'; });
    })();
    </script>

    <!-- Projects Table -->
    <div id="allProjectsPanel" role="tabpanel" aria-labelledby="allProjectsTab" style="background: #ffffff; border-radius: 12px; border: 1px solid #e2e8f0; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.05); margin-top: 20px;">
        <div style="background: #0d47a1; color: white; padding: 14px 20px; font-size: 0.85rem; font-weight: 800; display: flex; justify-content: space-between; align-items: center;">
            <span>Priority Projects &amp; Programmes (<?= count($projects) ?> Projects)</span>
            <button onclick="document.getElementById('addProjectModal').style.display='flex';" style="background: #10b981; color: white; border: none; padding: 6px 14px; border-radius: 6px; font-size: 0.75rem; font-weight: 700; cursor: pointer;">
                + Add Project
            </button>
            <a href="/modules/projects.php<?= !empty($showArchivedProjects) ? '' : '?show_archived=1' ?>" style="display:inline-flex;align-items:center;padding:8px 12px;border:1px solid #cbd5e1;border-radius:8px;background:#fff;color:#334155;text-decoration:none;font-size:.8rem;font-weight:700;">
                <?= !empty($showArchivedProjects) ? 'View Active Projects' : 'View Archived Projects' ?>
            </a>
        </div>
        <div style="overflow-x: auto;">
            <table class="priority-table" data-lazy-table data-page-size="10" style="width: 100%; border-collapse: collapse; font-size: 0.8rem; text-align: left;">
                <thead>
                    <tr style="background: #f8fafc; color: #475569; font-weight: 700; border-bottom: 2px solid #e2e8f0; text-transform: uppercase; font-size: 0.7rem;">
                        <th style="padding: 12px 16px;">Title &amp; Delivery Unit</th>
                        <th style="padding: 12px 16px;">Type</th>
                        <th style="padding: 12px 16px;">Category</th>
                        <th style="padding: 12px 16px;">Status</th>
                        <th style="padding: 12px 16px;">Start Date</th>
                        <th style="padding: 12px 16px;">End Date</th>
                        <th style="padding: 12px 16px;">Duration</th>
                        <th style="padding: 12px 16px; text-align: center;">Total Budget (KES)</th>
                        <th style="padding: 12px 16px; width: 140px;">Progress</th>
                        <th style="padding: 12px 16px; text-align: center;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($projects)): ?>
                        <tr>
                            <td colspan="10" style="padding: 30px; text-align: center; color: #64748b;">
                                <?php if (!$db_connected): ?>The projects database connection is unavailable.
                                <?php elseif ($project_load_error): ?>Project records could not be loaded. Check the live database schema and application connection.
                                <?php elseif ($project_total_count === 0): ?>No project rows are present in the database. Import <code>seed_knh_ten_sample_projects.sql</code> to add the KNH sample projects.
                                <?php else: ?>No projects match the selected filters. Use Reset Filters to show all database records.
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($projects as $p):
                            $statusKey = strtolower(trim((string)($p['status'] ?? '')));
                            $rowStatusClass = ['in progress'=>'status-in-progress','on hold'=>'status-on-hold','completed'=>'status-completed','planning'=>'status-planning','delayed'=>'status-delayed','overdue'=>'status-overdue','cancelled'=>'status-cancelled'][$statusKey] ?? 'status-default';
                            $progressValue = null;
                            if (isset($monthly_progress_by_project[(int)$p['id']])) $progressValue = (float)$monthly_progress_by_project[(int)$p['id']];
                            elseif (isset($p['overall_progress_pct']) && $p['overall_progress_pct'] !== null) $progressValue = (float)$p['overall_progress_pct'];
                            elseif (preg_match('/^\s*(\d+(?:\.\d+)?)\s*%?\s*$/', (string)($p['progress_status'] ?? ''), $progressMatch)) $progressValue = (float)$progressMatch[1];
                            else $progressValue = 0.0;
                            $progressValue = max(0, $progressValue);
                            $durationLabel = '—';
                            $durationStart = !empty($p['start_date']) ? DateTimeImmutable::createFromFormat('!Y-m-d', (string)$p['start_date']) : false;
                            $durationEnd = !empty($p['end_date']) ? DateTimeImmutable::createFromFormat('!Y-m-d', (string)$p['end_date']) : false;
                            if ($durationStart && $durationEnd && $durationEnd >= $durationStart) {
                                $duration = $durationStart->diff($durationEnd);
                                $durationParts = [];
                                if ($duration->y) $durationParts[] = $duration->y . ' ' . ($duration->y === 1 ? 'year' : 'years');
                                if ($duration->m) $durationParts[] = $duration->m . ' ' . ($duration->m === 1 ? 'month' : 'months');
                                if (!$durationParts && $duration->d) $durationParts[] = $duration->d . ' ' . ($duration->d === 1 ? 'day' : 'days');
                                $durationLabel = $durationParts ? implode(' ', $durationParts) : 'Under 1 month';
                            }
                            $statusStyle = ['in progress'=>['#047857','#ffffff'],'on hold'=>['#92400e','#ffffff'],'completed'=>['#1d4ed8','#ffffff'],'planning'=>['#6d28d9','#ffffff'],'delayed'=>['#c2410c','#ffffff'],'overdue'=>['#b91c1c','#ffffff'],'cancelled'=>['#475569','#ffffff']][$statusKey] ?? ['#64748b','#ffffff'];
                        ?>
                            <tr class="project-status-row <?= $rowStatusClass ?>" data-lazy-row data-search="<?= htmlspecialchars(strtolower((string)$p['sub_programme'] . ' ' . (string)($p['project_code'] ?? '')), ENT_QUOTES) ?>">
                                <td style="padding: 12px 16px;">
                                    <strong style="color: #0f172a; font-size: 0.82rem;"><?= htmlspecialchars($p['sub_programme']) ?></strong>
                                    <div style="font-size:.68rem;color:#64748b;margin-top:2px;">Code: <?= !empty($p['project_code']) ? htmlspecialchars($p['project_code']) : 'None' ?></div>
                                    <div style="font-size: 0.72rem; color: #64748b; margin-top: 2px;">Delivery Unit:
                                        <?= htmlspecialchars($p['delivery_unit'] ?? $p['saga_name'] ?? $p['directorate_name'] ?? 'Ministry of Health') ?>
                                    </div>
                                </td>
                                <td style="padding:12px 16px;"><span style="background:#f1f5f9;color:#475569;border:1px solid #cbd5e1;padding:3px 7px;border-radius:4px;font-size:.7rem;font-weight:700;"><?= htmlspecialchars($p['project_type'] ?? 'Project') ?></span></td>
                                <td style="padding: 12px 16px;">
                                    <span style="background: #dbeafe; color: #1e40af; font-weight: 800; font-size: 0.68rem; padding: 2px 6px; border-radius: 4px;"><?= strtoupper((string)$p['category']) ?></span><div style="font-size:.7rem;color:#64748b;margin-top:4px"><?= htmlspecialchars(strtolower((string)($p['category'] ?? '')) === 'saga' ? (string)($p['saga_name'] ?? '') : (strtolower((string)($p['category'] ?? '')) === 'directorate' ? (string)($p['directorate_name'] ?? '') : (string)($p['division_name'] ?? ''))) ?></div>
                                </td>
                                <td style="padding: 12px 16px;">
                                    <span style="background: <?= $statusStyle[0] ?>; color: <?= $statusStyle[1] ?>; padding: 4px 10px; border-radius: 6px; font-size: 0.7rem; font-weight: 800;">
                                        <?= htmlspecialchars($p['status']) ?>
                                    </span>
                                </td>
                                <td style="padding: 12px 16px; white-space: nowrap; color: #334155;"><?= $durationStart ? htmlspecialchars($durationStart->format('d M Y')) : '—' ?></td>
                                <td style="padding: 12px 16px; white-space: nowrap; color: #334155;"><?= $durationEnd ? htmlspecialchars($durationEnd->format('d M Y')) : '—' ?></td>
                                <td style="padding: 12px 16px; white-space: nowrap; font-weight: 700; color: #334155;">
                                    <?= htmlspecialchars($durationLabel) ?>
                                </td>
                                <td style="padding: 12px 16px; text-align: right; font-family: 'JetBrains Mono', monospace; font-weight: 700; color: #0d47a1;">
                                    <?= number_format((float)$p['total_budget'], 0, '.', ',') ?>
                                </td>
                                <td style="padding: 12px 16px;">
                                    <div style="font-size: 0.75rem; font-weight: 800; color: #334155; margin-bottom: 4px;"><?= number_format($progressValue, 1) ?>%</div>
                                    <div style="background: #e2e8f0; height: 8px; border-radius: 4px; overflow: hidden;">
                                        <div style="background: <?= htmlspecialchars($p['color'] ?? '#0d47a1') ?>; height: 100%; width: <?= min(100, $progressValue) ?>%;"></div>
                                    </div>
                                </td>
                                <td style="padding: 12px 16px; text-align: center;">
                                    <a href="/modules/projects.php?id=<?= $p['id'] ?>" style="background: #1d4ed8; color: #ffffff; text-decoration: none; padding: 5px 12px; border-radius: 6px; font-size: 0.72rem; font-weight: 800; display: inline-block; white-space: nowrap;">
                                        View Detail &rarr;
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
            <div style="display:flex;justify-content:space-between;align-items:center;padding:10px 12px;color:#64748b;font-size:.78rem"><span id="lazyCount"></span><button type="button" id="lazyMore" class="module-btn module-btn-small">Load more</button><span id="lazySentinel"></span></div>
        </div>
    </div>
    <script src="/assets/js/lazy-table.js"></script>

<?php endif; ?>

</div>

<!-- Modal: Add Project -->
<?php if (!($is_detail_view && $current_project)): ?>
<div id="addProjectModal" style="display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 9999; align-items: center; justify-content: center; padding: 20px;">
    <div style="background: white; border-radius: 12px; max-width: 600px; width: 100%; padding: 24px; box-shadow: 0 20px 40px rgba(0,0,0,0.3);">
        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #e2e8f0; padding-bottom: 12px; margin-bottom: 16px;">
            <h3 style="margin: 0; font-size: 1.05rem; font-weight: 800; color: #0f172a;">Register Project to Portfolio</h3>
            <button onclick="document.getElementById('addProjectModal').style.display='none';" style="background: none; border: none; font-size: 1.3rem; cursor: pointer; color: #64748b;">&times;</button>
        </div>

        <form method="POST" action="/modules/projects.php">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(get_csrf_token()) ?>">
            <input type="hidden" name="action_type" value="add_project">

            <div style="margin-bottom: 12px;">
                <label style="display: block; font-size: 0.75rem; font-weight: 700; margin-bottom: 4px;">Sub-Programme / Project Name</label>
                <input type="text" name="sub_programme" required style="width: 100%; padding: 8px 12px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.82rem;" placeholder="e.g. Modern Burns ICU Center">
            </div>

            <div style="margin-bottom: 12px;">
                <label style="display: block; font-size: 0.75rem; font-weight: 700; margin-bottom: 4px;">Strategic Programme Title</label>
                <input type="text" name="programme_title" required style="width: 100%; padding: 8px 12px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.82rem;" placeholder="e.g. Specialized Hospital Infrastructure">
            </div>

            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px;">
                <div><label style="display:block;font-size:.75rem;font-weight:700;margin-bottom:4px;">Project Code</label><input type="text" name="project_code" maxlength="50" style="width:100%;padding:8px 12px;border:1px solid #cbd5e1;border-radius:6px;font-size:.82rem;"></div>
                <div><label style="display:block;font-size:.75rem;font-weight:700;margin-bottom:4px;">Type</label><select name="project_type" style="width:100%;padding:8px 12px;border:1px solid #cbd5e1;border-radius:6px;font-size:.82rem;"><option>Project</option><option>Programme</option></select></div>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 2fr; gap: 12px; margin-bottom: 12px;">
                <div>
                    <label style="display: block; font-size: 0.75rem; font-weight: 700; margin-bottom: 4px;">Category</label>
                    <select name="category" style="width: 100%; padding: 8px 12px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.82rem;">
                        <option value="Saga">SAGA (Referral Hospital)</option>
                        <option value="Directorate">Directorate</option>
                        <option value="Division">Division</option>
                    </select>
                </div>
                <div>
                    <label style="display: block; font-size: 0.75rem; font-weight: 700; margin-bottom: 4px;">Agency / Directorate / SAGA Name</label>
                    <input type="text" name="agency_name" list="projectAgencyOptions" required style="width: 100%; padding: 8px 12px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.82rem;" placeholder="Select or enter an agency, directorate, or division">
                    <datalist id="projectAgencyOptions">
                        <?php foreach ($gantt_sagas as $agencyOption): ?><option value="<?= htmlspecialchars($agencyOption) ?>"></option><?php endforeach; ?>
                        <?php foreach ($gantt_directorates as $agencyOption): ?><option value="<?= htmlspecialchars($agencyOption) ?>"></option><?php endforeach; ?>
                        <?php foreach ($filter_divisions as $agencyOption): ?><option value="<?= htmlspecialchars($agencyOption) ?>"></option><?php endforeach; ?>
                    </datalist>
                </div>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 12px;">
                <div>
                    <label style="display: block; font-size: 0.75rem; font-weight: 700; margin-bottom: 4px;">Priority Tier</label>
                    <select name="priority_tier" style="width: 100%; padding: 8px 12px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.82rem;">
                        <option value="Tier 1 - High Priority">Tier 1 - Critical Priority</option>
                        <option value="Tier 2 - Medium Priority">Tier 2 - High Priority</option>
                        <option value="Tier 3 - Standard Priority">Tier 3 - Medium Priority</option>
                        <option value="Tier 4 - Low Priority">Tier 4 - Low Priority</option>
                    </select>
                </div>
                <div>
                    <label style="display: block; font-size: 0.75rem; font-weight: 700; margin-bottom: 4px;">Total Budget (KES)</label>
                    <input type="number" step="100000" name="total_budget" min="0" required style="width: 100%; padding: 8px 12px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.82rem;">
                </div>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 12px;">
                <div>
                    <label style="display: block; font-size: 0.75rem; font-weight: 700; margin-bottom: 4px;">Status</label>
                    <select name="status" style="width: 100%; padding: 8px 12px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.82rem;">
                        <option value="In Progress">In Progress</option>
                        <option value="Completed">Completed</option>
                        <option value="On Hold">On Hold</option>
                        <option value="Delayed">Delayed</option>
                    </select>
                </div>
                <div>
                    <label style="display: block; font-size: 0.75rem; font-weight: 700; margin-bottom: 4px;">Start Date</label>
                    <input type="date" name="start_date" id="projectStartDate" required style="width: 100%; padding: 8px 12px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.82rem;">
                </div>
            </div>

            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px;"><div><label style="display:block;font-size:.75rem;font-weight:700;margin-bottom:4px;">End Date</label><input type="date" name="end_date" id="projectEndDate" required style="width:100%;padding:8px 12px;border:1px solid #cbd5e1;border-radius:6px;font-size:.82rem;"></div><div><label style="display:block;font-size:.75rem;font-weight:700;margin-bottom:4px;">Duration</label><input type="text" id="projectDuration" readonly placeholder="Calculated from dates" style="width:100%;padding:8px 12px;border:1px solid #cbd5e1;border-radius:6px;font-size:.82rem;background:#f8fafc;"></div></div>
            <div style="margin-bottom:12px;"><label style="display:block;font-size:.75rem;font-weight:700;margin-bottom:4px;">Action / Project Description</label><textarea name="description" rows="3" style="width:100%;padding:8px 12px;border:1px solid #cbd5e1;border-radius:6px;font-size:.82rem;"></textarea></div>
            <input type="hidden" name="progress_pct" value="0">
            <div style="display: flex; justify-content: flex-end; gap: 10px; margin-top: 16px;">
                <button type="button" onclick="document.getElementById('addProjectModal').style.display='none';" style="padding: 8px 16px; border: 1px solid #cbd5e1; background: white; border-radius: 6px; font-weight: 600; font-size: 0.8rem; cursor: pointer;">Cancel</button>
                <button type="submit" style="padding: 8px 18px; background: #0d47a1; color: white; border: none; border-radius: 6px; font-weight: 700; font-size: 0.8rem; cursor: pointer;">Save Project</button>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>
<script>
(() => { const start=document.getElementById('projectStartDate'), end=document.getElementById('projectEndDate'), out=document.getElementById('projectDuration'); if(!start||!end||!out)return; const calc=()=>{if(!start.value||!end.value){out.value='';return;} const a=new Date(start.value+'T00:00:00'),b=new Date(end.value+'T00:00:00');if(b<a){out.value='End date must follow start date';return;}let months=(b.getFullYear()-a.getFullYear())*12+b.getMonth()-a.getMonth();const days=b.getDate()-a.getDate();if(days<0)months--;out.value=Math.max(0,months)+' month(s)';};start.addEventListener('change',calc);end.addEventListener('change',calc); })();
</script>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>