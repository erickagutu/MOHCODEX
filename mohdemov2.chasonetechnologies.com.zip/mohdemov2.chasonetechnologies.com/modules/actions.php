<?php
/**
 * Action Points Tracker — full details, editing and printable PDF export.
 */
require_once __DIR__ . '/../config/db.php';
require_auth();
if (!function_exists('e')) { function e($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); } }
if (!function_exists('url')) { function url(string $path = ''): string { return '/modules/' . ltrim($path, '/'); } }
if (!function_exists('getDBConnection')) { function getDBConnection(): PDO { global $pdo; if (!$pdo) throw new RuntimeException('Database connection is unavailable.'); return $pdo; } }
if (!function_exists('getCurrentUser')) { function getCurrentUser(): array { return get_current_user_data(); } }
if (!function_exists('requireAuth')) { function requireAuth(): void { require_auth(); } }
if (!function_exists('getCSRFToken')) { function getCSRFToken(): string { return get_csrf_token(); } }
if (!function_exists('verifyCSRFToken')) { function verifyCSRFToken(?string $token): bool { return verify_csrf_token($token); } }
if (!function_exists('recordAuditEvent')) { function recordAuditEvent(string $action, string $module, string $details = '', ?int $id = null): void { log_audit_trail(strtoupper($action), $module, $id, $details); } }
if (!function_exists('auditChangedFields')) { function auditChangedFields(array $before, array $after, array $fields): array { $changed=[]; foreach ($fields as $field) if (($before[$field] ?? null) != ($after[$field] ?? null)) $changed[]=$field; return $changed; } }

requireAuth();
$db = getDBConnection();
$currentUser = getCurrentUser();
$canEdit = !empty($currentUser['can_edit']) || !empty($currentUser['is_admin']);
$isAdmin = !empty($currentUser['is_admin']) || strcasecmp((string)($currentUser['role'] ?? ''), 'Administrator') === 0;
$canDownload = !empty($currentUser['can_download']) || !empty($currentUser['can_edit']) || !empty($currentUser['is_admin']);
$statuses = ['NOT STARTED', 'ON TRACK', 'DELAYED', 'STALLED', 'COMPLETED', 'CANCELLED'];
$actionsHasArchive = true;
try {
    if (!$db->query("SHOW COLUMNS FROM action_points LIKE 'archived_at'")->fetch()) {
        $db->exec('ALTER TABLE action_points ADD COLUMN archived_at TIMESTAMP NULL DEFAULT NULL');
    }
    $actionsHasArchive = (bool)$db->query("SHOW COLUMNS FROM action_points LIKE 'archived_at'")->fetch();
} catch (Throwable $e) {
    $actionsHasArchive = false;
}
// Public path of the Government of Kenya coat of arms image used on printouts (add the file here).
$coatOfArmsUrl = '/assets/images/gok-coat-of-arms.png';

if (isset($_GET['export']) && $_GET['export'] === 'print-log') {
    if ($canDownload) recordAuditEvent('export', 'action_points', 'Printed action points (filtered view)');
    http_response_code(204);
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    if (!$canEdit) {
        http_response_code(403);
        exit('You do not have permission to change action points.');
    }
    $submittedToken = $_POST['csrf_token'] ?? null;
    if (!verifyCSRFToken(is_string($submittedToken) ? $submittedToken : null)) {
        http_response_code(419);
        exit('Your session has expired. Refresh the page and try again.');
    }
    $formAction = $_POST['form_action'] ?? '';
    $id = (int)($_POST['id'] ?? 0);
    if ($formAction === 'archive') {
        if ($id > 0) {
            $db->prepare('UPDATE action_points SET archived_at = CURRENT_TIMESTAMP WHERE id = ?')->execute([$id]);
            recordAuditEvent('archive', 'action_points', 'Archived action point #' . $id, $id);
        }
        header('Location: ' . url('actions.php?notice=archived'));
        exit;
    }
    if ($formAction === 'restore') {
        if ($id > 0) {
            $db->prepare('UPDATE action_points SET archived_at = NULL WHERE id = ?')->execute([$id]);
            recordAuditEvent('restore', 'action_points', 'Restored action point #' . $id, $id);
        }
        header('Location: ' . url('actions.php?show_archived=1&notice=restored'));
        exit;
    }
    if ($formAction === 'delete') {
        $target = $id > 0 ? $db->prepare('SELECT archived_at FROM action_points WHERE id=?') : null;
        if ($target) $target->execute([$id]);
        $archivedAt = $target ? $target->fetchColumn() : false;
        if (!$isAdmin || !$actionsHasArchive || $archivedAt === false || $archivedAt === null) {
            http_response_code(403);
            exit('Only administrators can permanently delete action points after they have been archived.');
        }
        if ($id > 0) {
            $deleteStmt = $db->prepare('DELETE FROM action_points WHERE id = ?');
            $deleteStmt->execute([$id]);
            if ($deleteStmt->rowCount() > 0) {
                recordAuditEvent('delete', 'action_points', 'Deleted action point #' . $id, $id);
            }
        }
        header('Location: ' . url('actions.php?notice=deleted'));
        exit;
    }
    if ($formAction === 'save') {
        $refNo = trim((string)($_POST['ref_no'] ?? ''));
        if ($refNo === '') $refNo = 'APT-' . date('Ymd') . '-' . random_int(100, 999);
        $date = trim((string)($_POST['date'] ?? ''));
        $meeting = trim((string)($_POST['meeting_title'] ?? ''));
        $meetingId = null;
        if ($meeting !== '') {
            $meetingLookup = $db->prepare('SELECT id FROM meetings WHERE title = ? ORDER BY id DESC LIMIT 1');
            $meetingLookup->execute([$meeting]);
            $foundMeetingId = $meetingLookup->fetchColumn();
            if ($foundMeetingId !== false) $meetingId = (int)$foundMeetingId;
        }
        $issue = trim((string)($_POST['issue'] ?? ''));
        $responsible = trim((string)($_POST['person_responsible'] ?? ''));
        $timeline = trim((string)($_POST['timeline'] ?? ''));
        $status = strtoupper(trim((string)($_POST['status'] ?? 'NOT STARTED')));
        $actionNotes = trim((string)($_POST['action'] ?? ''));
        $resolution = trim((string)($_POST['resolution_notes'] ?? ''));

        if ($issue === '' || $meeting === '' || $date === '' || $responsible === '') {
            header('Location: ' . url('actions.php?notice=missing'));
            exit;
        }
        if (!in_array($status, $statuses, true)) $status = 'NOT STARTED';

        if ($id > 0) {
            $beforeStmt = $db->prepare('SELECT ref_no, action_date AS date, meeting_title, issue, person_responsible, timeline, status, action, resolution_notes FROM action_points WHERE id = ?');
            $beforeStmt->execute([$id]);
            $before = $beforeStmt->fetch() ?: [];
            $after = [
                'ref_no' => $refNo,
                'date' => $date,
                'meeting_title' => $meeting,
                'issue' => $issue,
                'person_responsible' => $responsible,
                'timeline' => $timeline,
                'status' => $status,
                'action' => $actionNotes,
                'resolution_notes' => $resolution,
            ];
            $changedFields = auditChangedFields($before, $after, array_keys($after));
            $archiveSql = $status === 'COMPLETED' ? ', archived_at = COALESCE(archived_at, CURRENT_TIMESTAMP)' : '';
            $sql = 'UPDATE action_points SET ref_no=?, action_date=?, meeting_title=?, meeting_id=?, issue=?, person_responsible=?, timeline=?, status=?, action=?, resolution_notes=?' . $archiveSql . ' WHERE id=?';
            $db->prepare($sql)->execute([$refNo, $date, $meeting, $meetingId, $issue, $responsible, $timeline, $status, $actionNotes, $resolution, $id]);
            if ($before) audit_log_change('Action Points',$id,$before,$after,'Updated action point #'.$id,['severity'=>'INFO']);
            header('Location: ' . url('actions.php?notice=updated'));
        } else {
            $sql = 'INSERT INTO action_points (ref_no, action_date, meeting_title, meeting_id, issue, person_responsible, timeline, status, action, resolution_notes, archived_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ' . ($status === 'COMPLETED' ? 'CURRENT_TIMESTAMP' : 'NULL') . ')';
            $db->prepare($sql)->execute([$refNo, $date, $meeting, $meetingId, $issue, $responsible, $timeline, $status, $actionNotes, $resolution]);
            $createdId = (int)$db->lastInsertId();
            recordAuditEvent('create', 'action_points', 'Created action point #' . $createdId . ' (fields: ref_no, date, meeting_title, issue, person_responsible, timeline, status, action, resolution_notes)', $createdId);
            header('Location: ' . url('actions.php?notice=created'));
        }
        exit;
    }
}

$showArchived = isset($_GET['show_archived']) && $_GET['show_archived'] === '1';
$actionsSql = 'SELECT action_points.*, action_date AS date FROM action_points' . ($actionsHasArchive ? (' WHERE ' . ($showArchived ? 'archived_at IS NOT NULL' : 'archived_at IS NULL')) : '') . ' ORDER BY action_date DESC, id DESC';
$actionsStmt = $db->prepare($actionsSql);
$actionsStmt->execute();
$actions = $actionsStmt->fetchAll();
$totalCount = count($actions);
$completedCount = count(array_filter($actions, static fn($row) => strtoupper((string)$row['status']) === 'COMPLETED'));
$activeCount = count(array_filter($actions, static fn($row) => in_array(strtoupper((string)$row['status']), ['ON TRACK', 'IN PROGRESS'], true)));
$riskCount = count(array_filter($actions, static fn($row) => in_array(strtoupper((string)$row['status']), ['DELAYED', 'STALLED'], true)));
$csrfToken = getCSRFToken();

$page_title = 'Action Points Tracker';
$active_tab = 'actions';
require_once __DIR__ . '/../includes/header.php';
?>

<main class="module-page">
  <div class="module-page-head">
    <div>
      <h2 class="module-page-title">Action Points Tracker</h2>
      <p class="module-page-description">Follow through on ministerial directives, meeting decisions and agreed resolutions.</p>
    </div>
    <div class="module-page-actions">
      <?php if ($canEdit): ?><button type="button" class="module-btn module-btn-primary" id="actionAddButton">+ Add Action Point</button><?php endif; ?>
    </div>
  </div>

  <?php if (isset($_GET['notice'])): ?>
    <div class="module-notice" role="status"><?php echo $_GET['notice'] === 'missing' ? 'Please complete the required fields.' : 'Action point changes saved.'; ?></div>
  <?php endif; ?>

  <?php
    // Each key-statistic card links to the list filtered to the statuses it counts.
    $statGroups = [
      'all'       => ['label' => 'Total action points', 'value' => $totalCount,     'statuses' => [],                          'hint' => 'View all action points'],
      'active'    => ['label' => 'On track',            'value' => $activeCount,    'statuses' => ['ON TRACK', 'IN PROGRESS'], 'hint' => 'View on-track action points'],
      'risk'      => ['label' => 'At risk / delayed',   'value' => $riskCount,      'statuses' => ['DELAYED', 'STALLED'],      'hint' => 'View delayed / stalled action points'],
      'completed' => ['label' => 'Completed',           'value' => $completedCount, 'statuses' => ['COMPLETED'],               'hint' => 'View completed action points'],
    ];
    $activeGroup = (string)($_GET['group'] ?? 'all');
    if (!isset($statGroups[$activeGroup])) $activeGroup = 'all';
  ?>
  <section class="module-summary-grid" aria-label="Action point summary">
    <?php foreach ($statGroups as $groupKey => $group): ?>
      <a class="module-summary-card<?php echo $groupKey === $activeGroup ? ' is-active' : ''; ?>" href="<?php echo e(url('actions.php' . ($groupKey === 'all' ? '' : '?group=' . $groupKey) . '#actionList')); ?>" data-stat-group="<?php echo e($groupKey); ?>" data-statuses="<?php echo e(implode('|', $group['statuses'])); ?>" title="<?php echo e($group['hint']); ?>">
        <div class="module-summary-label"><?php echo e($group['label']); ?></div>
        <div class="module-summary-value"><?php echo (int)$group['value']; ?></div>
        <div class="module-summary-hint"><?php echo e($group['hint']); ?> &rarr;</div>
      </a>
    <?php endforeach; ?>
  </section>

  <section class="module-panel" id="actionList">
    <div class="module-toolbar">
      <div class="module-toolbar-group">
        <input class="module-search" type="search" id="actionSearch" placeholder="Search reference, issue or owner…" aria-label="Search action points">
        <select class="module-select" id="actionStatus" aria-label="Filter action points by status">
          <option value="">All statuses</option>
          <?php foreach ($statuses as $status): ?><option value="<?php echo e($status); ?>"><?php echo e($status); ?></option><?php endforeach; ?>
        </select>
        <label class="event-month-label" for="actionDateFrom">From</label>
        <input class="module-select" type="date" id="actionDateFrom" aria-label="Show action points raised from this date">
        <label class="event-month-label" for="actionDateTo">To</label>
        <input class="module-select" type="date" id="actionDateTo" aria-label="Show action points raised up to this date">
        <button type="button" class="module-btn module-btn-small" id="actionDateClear" hidden>Clear dates</button>
      </div>
      <div class="module-inline-note"><span id="actionVisibleCount"><?php echo $totalCount; ?></span> action points <button type="button" class="module-btn module-btn-small" id="actionFilterReset" hidden>Clear filters</button></div>
    </div>
    <style>
      /* Row colours by status (options from the Add action point status dropdown) */
      #actionTable tbody tr.action-row-not-started td{background:#f1f5f9}
      #actionTable tbody tr.action-row-on-track td{background:#ecfdf5}
      #actionTable tbody tr.action-row-delayed td{background:#fff7ed}
      #actionTable tbody tr.action-row-stalled td{background:#fef2f2}
      #actionTable tbody tr.action-row-completed td{background:#eff6ff}
      #actionTable tbody tr.action-row-cancelled td{background:#e5e7eb;color:#64748b}
      #actionTable tbody tr.action-row-not-started td:first-child{box-shadow:inset 4px 0 0 #94a3b8}
      #actionTable tbody tr.action-row-on-track td:first-child{box-shadow:inset 4px 0 0 #16a34a}
      #actionTable tbody tr.action-row-delayed td:first-child{box-shadow:inset 4px 0 0 #f59e0b}
      #actionTable tbody tr.action-row-stalled td:first-child{box-shadow:inset 4px 0 0 #dc2626}
      #actionTable tbody tr.action-row-completed td:first-child{box-shadow:inset 4px 0 0 #2563eb}
      #actionTable tbody tr.action-row-cancelled td:first-child{box-shadow:inset 4px 0 0 #64748b}
      /* Download PDF button (sits just above the table) */
      .action-table-tools{display:flex;justify-content:flex-end;margin:0 0 10px}
      .action-download-button{background:#16a34a;border-color:#16a34a;color:#fff}
      .action-download-button:hover,.action-download-button:focus-visible{background:#15803d;border-color:#15803d;color:#fff}
      /* View / Edit / Delete buttons */
      .action-manage-dropdown{position:relative;display:inline-block}.action-manage-dropdown>summary{list-style:none;cursor:pointer}.action-manage-dropdown>summary::-webkit-details-marker{display:none}.action-manage-menu{position:absolute;right:0;top:100%;z-index:20;display:flex;flex-direction:column;gap:4px;padding:8px;background:#fff;border:1px solid #dbe3ef;border-radius:8px;box-shadow:0 8px 20px rgba(15,23,42,.14);min-width:100px}.action-manage-dropdown:not([open]) .action-manage-menu{display:none}
      #actionTable .module-table-actions .module-btn{background:#2563eb;border-color:#2563eb;color:#fff}
      #actionTable .module-table-actions .module-btn:hover,#actionTable .module-table-actions .module-btn:focus-visible{background:#1d4ed8;border-color:#1d4ed8;color:#fff}
      .action-archive-toggle{background:#2563eb!important;border-color:#2563eb!important;color:#fff!important;font-family:Consolas,monospace!important}
      .action-archive-toggle:hover,.action-archive-toggle:focus-visible{background:#1d4ed8!important;border-color:#1d4ed8!important;color:#fff!important}
      .action-archive-toggle-wrap{display:flex;justify-content:flex-end;margin-top:14px}
    </style>
    <?php if ($canDownload): ?>
    <div class="action-table-tools"><button type="button" class="module-btn action-download-button" id="actionPrintButton">Download PDF</button></div>
    <?php endif; ?>
    <div class="module-table-wrap">
      <table class="module-table" id="actionTable">
        <thead>
          <tr><th>Reference / date</th><th>Meeting / source</th><th>Issue</th><th>Person responsible</th><th>Timeline</th><th>Status</th><th>Action / resolution</th><th>Manage</th></tr>
        </thead>
        <tbody>
          <?php foreach ($actions as $row): ?>
            <?php
              $rowJson = htmlspecialchars(json_encode($row, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?: '{}', ENT_QUOTES, 'UTF-8');
              $searchText = strtolower(implode(' ', [(string)$row['ref_no'], (string)$row['meeting_title'], (string)$row['issue'], (string)$row['person_responsible']]));
              $statusClass = strtoupper((string)$row['status']) === 'COMPLETED' ? 'is-done' : (in_array(strtoupper((string)$row['status']), ['DELAYED', 'STALLED'], true) ? 'is-risk' : '');
            ?>
            <tr class="action-row-<?php echo e(strtolower(str_replace(' ', '-', trim((string)$row['status'])))); ?>" data-lazy-row data-status="<?php echo e(strtoupper((string)$row['status'])); ?>" data-search="<?php echo e($searchText); ?>" data-date="<?php echo e(substr((string)$row['date'], 0, 10)); ?>">
              <td><strong class="pc-code"><?php echo e($row['ref_no']); ?></strong><br><small><?php $actionDateTs = strtotime((string)$row['date']); echo e($actionDateTs ? date('d M Y', $actionDateTs) : $row['date']); ?></small></td>
              <td><?php echo e($row['meeting_title']); ?></td>
              <td class="action-issue"><?php echo e($row['issue']); ?></td>
              <td><?php echo e($row['person_responsible']); ?></td>
              <td><?php $timelineValue = (string)$row['timeline']; $timelineTs = preg_match('/^\d{4}-\d{2}-\d{2}(?:\s|$)/', $timelineValue) ? strtotime($timelineValue) : false; echo e($timelineTs ? date('d M Y', $timelineTs) : $timelineValue); ?></td>
              <td><span class="module-status <?php echo $statusClass; ?>"><?php echo e($row['status']); ?></span></td>
              <td><div><?php echo e($row['action']); ?></div><?php if ($row['resolution_notes']): ?><small>Resolution: <?php echo e($row['resolution_notes']); ?></small><?php endif; ?></td>
              <td>
                <details class="action-manage-dropdown"><summary class="module-btn module-btn-small">Actions ▾</summary><div class="module-table-actions action-manage-menu">
                  <button type="button" class="module-btn module-btn-small action-view-button" data-row="<?php echo $rowJson; ?>">View</button>
                  <?php if ($canEdit): ?>
                    <button type="button" class="module-btn module-btn-small action-edit-button" data-row="<?php echo $rowJson; ?>">Edit</button>
                    <?php if (!empty($row['archived_at'])): ?><form method="post"><input type="hidden" name="csrf_token" value="<?php echo e($csrfToken); ?>"><input type="hidden" name="form_action" value="restore"><input type="hidden" name="id" value="<?php echo (int)$row['id']; ?>"><button type="submit" class="module-btn module-btn-small">Restore</button></form><?php else: ?><form method="post"><input type="hidden" name="csrf_token" value="<?php echo e($csrfToken); ?>"><input type="hidden" name="form_action" value="archive"><input type="hidden" name="id" value="<?php echo (int)$row['id']; ?>"><button type="submit" class="module-btn module-btn-small">Archive</button></form><?php endif; ?>
                    <?php if ($isAdmin && !empty($row['archived_at'])): ?><form method="post" class="action-delete-form" onsubmit="return confirm('Permanently delete this archived action point? This cannot be undone.');">
                      <input type="hidden" name="csrf_token" value="<?php echo e($csrfToken); ?>"><input type="hidden" name="form_action" value="delete"><input type="hidden" name="id" value="<?php echo (int)$row['id']; ?>">
                      <button type="submit" class="module-btn module-btn-small module-btn-danger">Delete permanently</button>
                    </form><?php endif; ?>
                  <?php endif; ?>
                </div></details>
              </td>
            </tr>
          <?php endforeach; ?>
          <?php if (!$actions): ?><tr><td colspan="8" class="module-empty">No action points have been recorded.</td></tr><?php endif; ?>
        </tbody>
      </table>
      <div class="module-empty" id="actionNoResults" hidden>No action points match these filters.</div>
    </div>
    <div class="action-archive-toggle-wrap">
      <a class="module-btn module-btn-primary action-archive-toggle" href="/modules/actions.php<?= $showArchived ? '' : '?show_archived=1' ?>"><?= $showArchived ? 'View active action points' : 'View archived action points' ?></a>
    </div>
  </section>
</main>

<div class="module-modal-overlay" id="actionModal" role="dialog" aria-modal="true" aria-labelledby="actionModalTitle">
  <div class="module-modal-card action-modal-card">
    <div class="module-modal-head"><h3 id="actionModalTitle">Action point details</h3><button type="button" class="module-btn module-btn-small" id="actionCloseButton">Close</button></div>
    <div class="module-modal-body" id="actionReadView"></div>
    <?php if ($canEdit): ?>
      <form method="post" id="actionForm">
        <input type="hidden" name="csrf_token" value="<?php echo e($csrfToken); ?>">
        <input type="hidden" name="form_action" value="save">
        <input type="hidden" name="id" value="">
        <div class="module-modal-body" id="actionEditView" hidden>
          <div class="module-form-grid">
            <div class="module-form-field"><label for="actionRef">Reference No.</label><input class="module-input" id="actionRef" name="ref_no"></div>
            <div class="module-form-field"><label for="actionDate">Date raised *</label><input class="module-input" type="date" id="actionDate" name="date" required></div>
            <div class="module-form-field full"><label for="actionMeeting">Meeting / source *</label><input class="module-input" id="actionMeeting" name="meeting_title" required></div>
            <div class="module-form-field full"><label for="actionIssue">The issue *</label><textarea class="module-textarea" id="actionIssue" name="issue" required></textarea></div>
            <div class="module-form-field"><label for="actionOwner">Person responsible *</label><input class="module-input" id="actionOwner" name="person_responsible" required></div>
            <div class="module-form-field"><label for="actionTimeline">Timeline / deadline</label><input class="module-input" id="actionTimeline" name="timeline"></div>
            <div class="module-form-field"><label for="actionStatusInput">Status</label><select class="module-select" id="actionStatusInput" name="status"><?php foreach ($statuses as $status): ?><option value="<?php echo e($status); ?>"><?php echo e($status); ?></option><?php endforeach; ?></select></div>
            <div class="module-form-field full"><label for="actionProgress">Progress / action made</label><textarea class="module-textarea" id="actionProgress" name="action"></textarea></div>
            <div class="module-form-field full"><label for="actionResolution">Resolution notes</label><textarea class="module-textarea" id="actionResolution" name="resolution_notes"></textarea></div>
          </div>
        </div>
        <div class="module-modal-footer" id="actionReadActions">
          <?php if ($canEdit): ?><button type="button" class="module-btn module-btn-primary" id="actionReadEditButton">Edit Action Point</button><?php endif; ?>
        </div>
        <div class="module-modal-footer" id="actionEditActions" hidden><button type="button" class="module-btn" id="actionCancelButton">Cancel</button><button type="submit" class="module-btn module-btn-primary">Save Action Point</button></div>
      </form>
    <?php endif; ?>
  </div>
</div>

<script>
(() => {
  const modal = document.getElementById('actionModal');
  const form = document.getElementById('actionForm');
  const readView = document.getElementById('actionReadView');
  const editView = document.getElementById('actionEditView');
  const readActions = document.getElementById('actionReadActions');
  const editActions = document.getElementById('actionEditActions');
  let selected = null;
  const escapeHtml = (value) => String(value ?? '').replace(/[&<>"']/g, (char) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[char]));
  const setField = (name, value) => { if (form?.elements[name]) form.elements[name].value = value ?? ''; };
  const item = (label, value) => `<div class="pc-detail-item"><div class="pc-detail-label">${escapeHtml(label)}</div><div class="pc-detail-value">${escapeHtml(value || '—')}</div></div>`;

  function showDetails(row) {
    selected = row;
    document.getElementById('actionModalTitle').textContent = `${row.ref_no || 'Action point'} · Details`;
    readView.innerHTML = `<div class="pc-detail-grid">
      ${item('Reference number', row.ref_no)}${item('Date raised', (() => { const d = new Date(String(row.date || '').slice(0,10) + 'T00:00:00'); return Number.isNaN(d.getTime()) ? row.date : d.toLocaleDateString('en-GB', {day:'2-digit',month:'short',year:'numeric'}); })())}
      ${item('Meeting / source', row.meeting_title)}${item('Person responsible', row.person_responsible)}
      ${item('Timeline / deadline', (() => { const value = String(row.timeline || ''); if (!/^\d{4}-\d{2}-\d{2}(?:\s|$)/.test(value)) return value; const d = new Date(value.slice(0,10) + 'T00:00:00'); return Number.isNaN(d.getTime()) ? value : d.toLocaleDateString('en-GB', {day:'2-digit',month:'short',year:'numeric'}); })())}${item('Status', row.status)}
      ${item('The issue', row.issue)}${item('Progress / action made', row.action)}
      ${item('Resolution notes', row.resolution_notes)}
    </div>`;
    if (form) {
      editView.hidden = true; readView.hidden = false;
      readActions.hidden = false; editActions.hidden = true;
      setField('id', row.id);
    }
    modal.classList.add('active');
  }
  function editAction(row, isNew = false) {
    selected = row || {};
    ['id','ref_no','date','meeting_title','issue','person_responsible','timeline','status','action','resolution_notes'].forEach((name) => setField(name, selected[name] ?? ''));
    if (isNew) {
      setField('date', new Date().toISOString().slice(0,10));
      setField('status', 'NOT STARTED');
    }
    document.getElementById('actionModalTitle').textContent = isNew ? 'Add action point' : `Edit ${selected.ref_no || 'action point'}`;
    editView.hidden = false; readView.hidden = true;
    readActions.hidden = true; editActions.hidden = false;
    modal.classList.add('active');
  }
  function closeModal() { modal.classList.remove('active'); selected = null; }

  document.getElementById('actionAddButton')?.addEventListener('click', () => editAction(null, true));
  document.querySelectorAll('.action-view-button').forEach((button) => button.addEventListener('click', () => {
    try { showDetails(JSON.parse(button.dataset.row || '{}')); } catch (error) { alert('Unable to open this action point.'); }
  }));
  document.querySelectorAll('.action-edit-button').forEach((button) => button.addEventListener('click', () => {
    try { editAction(JSON.parse(button.dataset.row || '{}')); } catch (error) { alert('Unable to edit this action point.'); }
  }));
  document.getElementById('actionReadEditButton')?.addEventListener('click', () => editAction(selected));
  document.getElementById('actionCancelButton')?.addEventListener('click', () => {
    if (selected?.id) showDetails(selected); else closeModal();
  });
  document.getElementById('actionCloseButton').addEventListener('click', closeModal);
  modal.addEventListener('click', (event) => { if (event.target === modal) closeModal(); });
  document.addEventListener('keydown', (event) => { if (event.key === 'Escape') closeModal(); });

  const rows = [...document.querySelectorAll('#actionTable tbody tr[data-status]')];
  const search = document.getElementById('actionSearch');
  const status = document.getElementById('actionStatus');
  const dateFrom = document.getElementById('actionDateFrom');
  const dateTo = document.getElementById('actionDateTo');
  const dateClear = document.getElementById('actionDateClear');
  const params = new URLSearchParams(window.location.search);
  const statCards = [...document.querySelectorAll('[data-stat-group]')];
  const resetButton = document.getElementById('actionFilterReset');
  let activeGroup = params.get('group') || 'all';
  let groupStatuses = (statCards.find(card => card.dataset.statGroup === activeGroup)?.dataset.statuses || '').split('|').filter(Boolean);
  if (params.get('q')) search.value = params.get('q');
  if (params.get('status')) { const wanted = params.get('status').toUpperCase(); const opt = [...status.options].find(o => o.value === wanted); if (opt) status.value = opt.value; }
  if (params.get('from')) dateFrom.value = params.get('from');
  if (params.get('to')) dateTo.value = params.get('to');

  function filterRows() {
    const query = (search.value || '').trim().toLowerCase();
    let count = 0;
    rows.forEach((row) => {
      const visible = (!query || (row.dataset.search || '').includes(query))
        && (!status.value || row.dataset.status === status.value)
        && (!groupStatuses.length || groupStatuses.includes(row.dataset.status))
        && (!dateFrom.value || (row.dataset.date && row.dataset.date >= dateFrom.value))
        && (!dateTo.value || (row.dataset.date && row.dataset.date <= dateTo.value));
      row.hidden = !visible;
      if (visible) count++;
    });
    dateClear.hidden = !(dateFrom.value || dateTo.value);
    document.getElementById('actionVisibleCount').textContent = count;
    document.getElementById('actionNoResults').hidden = count > 0 || rows.length === 0;
    const next = new URLSearchParams();
    if (activeGroup !== 'all') next.set('group', activeGroup);
    if (query) next.set('q', search.value.trim());
    if (status.value) next.set('status', status.value);
    if (dateFrom.value) next.set('from', dateFrom.value);
    if (dateTo.value) next.set('to', dateTo.value);
    const qs = next.toString();
    history.replaceState(null, '', window.location.pathname + (qs ? '?' + qs : '') + window.location.hash);
    if (resetButton) resetButton.hidden = !qs;
    statCards.forEach(card => card.classList.toggle('is-active', card.dataset.statGroup === activeGroup && !query && !status.value && !dateFrom.value && !dateTo.value));
  }
  // The group card and the status drop-down overlap, so picking a status drops the group.
  status.addEventListener('change', () => { if (status.value) { activeGroup = 'all'; groupStatuses = []; } filterRows(); });
  search.addEventListener('input', filterRows);
  dateFrom.addEventListener('change', filterRows);
  dateTo.addEventListener('change', filterRows);
  dateClear.addEventListener('click', () => { dateFrom.value = ''; dateTo.value = ''; filterRows(); });
  resetButton?.addEventListener('click', () => { search.value = ''; status.value = ''; dateFrom.value = ''; dateTo.value = ''; activeGroup = 'all'; groupStatuses = []; filterRows(); });
  filterRows();
})();
</script>
<script>
// Print / save as PDF: prints the rows currently shown in the filtered table (Manage column excluded)
(function () {
  const button = document.getElementById('actionPrintButton');
  const table = document.getElementById('actionTable');
  if (!button || !table) return;
  const cfg = <?php echo json_encode([
      'coatOfArms' => $coatOfArmsUrl,
      'republic'   => 'REPUBLIC OF KENYA',
      'ministry'   => 'MINISTRY OF HEALTH',
      'department' => 'State Department for Medical Services',
      'address'    => 'Afya House, Cathedral Road, P.O. Box 30016-00100, Nairobi, Kenya',
      'website'    => 'www.health.go.ke',
      'user'       => (string)($currentUser['name'] ?? $currentUser['full_name'] ?? $currentUser['email'] ?? ''),
      'logUrl'     => url('actions.php?export=print-log'),
  ], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_SLASHES); ?>;
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

  function filterSummary() {
    const parts = [];
    const groupLabels = { active: 'On track', risk: 'At risk / delayed', completed: 'Completed' };
    const activeCard = document.querySelector('.module-summary-card.is-active');
    const group = activeCard ? activeCard.dataset.statGroup : 'all';
    if (groupLabels[group]) parts.push('Group: ' + groupLabels[group]);
    const q = document.getElementById('actionSearch')?.value.trim();
    const st = document.getElementById('actionStatus')?.value;
    const from = document.getElementById('actionDateFrom')?.value;
    const to = document.getElementById('actionDateTo')?.value;
    if (q) parts.push('Search: "' + q + '"');
    if (st) parts.push('Status: ' + st);
    if (from) parts.push('From: ' + from);
    if (to) parts.push('To: ' + to);
    return parts.length ? parts.join('  |  ') : 'All action points';
  }

  const slug = (v, max) => String(v).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, max || 40).replace(/-+$/g, '');

  // e.g. action-points_status-delayed_from-2026-01-01_to-2026-03-31_2026-10-26
  function buildFileName(now) {
    const parts = ['action-points'];
    const groupSlugs = { active: 'on-track', risk: 'at-risk', completed: 'completed' };
    const activeCard = document.querySelector('.module-summary-card.is-active');
    const group = activeCard ? activeCard.dataset.statGroup : 'all';
    if (groupSlugs[group]) parts.push('group-' + groupSlugs[group]);
    const st = document.getElementById('actionStatus')?.value;
    const q = document.getElementById('actionSearch')?.value.trim();
    const from = document.getElementById('actionDateFrom')?.value;
    const to = document.getElementById('actionDateTo')?.value;
    if (st) parts.push('status-' + slug(st));
    if (q && slug(q)) parts.push('search-' + slug(q, 30));
    if (from) parts.push('from-' + from);
    if (to) parts.push('to-' + to);
    if (parts.length === 1) parts.push('all');
    parts.push(now.getFullYear() + '-' + String(now.getMonth() + 1).padStart(2, '0') + '-' + String(now.getDate()).padStart(2, '0'));
    return parts.join('_');
  }

  // Computed properties copied onto every element so the PDF does not depend on any stylesheet
  const STYLE_PROPS = ['display','color','background-color','background-image','font-family','font-size','font-weight','font-style','line-height','letter-spacing','text-align','text-transform','text-decoration-line','text-decoration-color','white-space','word-break','overflow-wrap','vertical-align','padding-top','padding-right','padding-bottom','padding-left','margin-top','margin-right','margin-bottom','margin-left','border-top-width','border-top-style','border-top-color','border-right-width','border-right-style','border-right-color','border-bottom-width','border-bottom-style','border-bottom-color','border-left-width','border-left-style','border-left-color','border-top-left-radius','border-top-right-radius','border-bottom-right-radius','border-bottom-left-radius','box-shadow','flex-direction','flex-wrap','align-items','justify-content','gap','border-collapse','border-spacing','opacity','min-width'];
  function inlineComputedStyles(src, dst) {
    if (src.nodeType !== 1) return;
    const cs = getComputedStyle(src);
    if (cs.display === 'none') return;
    let css = '';
    for (const p of STYLE_PROPS) { const v = cs.getPropertyValue(p); if (v) css += p + ':' + v + ';'; }
    dst.setAttribute('style', css);
    dst.removeAttribute('class');
    const sc = src.children, dc = dst.children;
    for (let i = 0; i < sc.length && i < dc.length; i++) inlineComputedStyles(sc[i], dc[i]);
  }

  button.addEventListener('click', () => {
    const tableWidth = Math.ceil(table.getBoundingClientRect().width);
    const clone = table.cloneNode(true);
    inlineComputedStyles(table, clone);          // must run before rows/cells are removed (trees stay parallel)
    clone.removeAttribute('id');
    clone.style.width = tableWidth + 'px';
    const headCells = [...table.tHead.rows[0].cells];
    const manageIndex = headCells.findIndex((th) => th.textContent.trim().toLowerCase() === 'manage');
    clone.querySelectorAll('tr').forEach((tr) => {
      if (tr.hidden) { tr.remove(); return; }
      if (manageIndex > -1 && tr.cells[manageIndex]) tr.deleteCell(manageIndex);
    });
    const rowCount = clone.tBodies[0] ? clone.tBodies[0].rows.length : 0;
    const now = new Date();
    const fileName = buildFileName(now);
    const printedOn = now.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) + ' ' + now.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
    const arms = cfg.coatOfArms ? '<img class="gok-arms" src="' + esc(location.origin + cfg.coatOfArms) + '" alt="Coat of arms of Kenya" onerror="this.style.display=\'none\'">' : '';

    // A4 portrait with 10mm side margins gives ~718px of width: scale the table to fit it exactly
    const zoom = Math.min(1.25, 718 / tableWidth);

    // Stylesheets are included only so web fonts load; every element already carries its own inline style
    const base = '<base href="' + esc(location.href) + '">';
    const links = [...document.querySelectorAll('link[rel~="stylesheet"]')].map((l) => '<link rel="stylesheet" href="' + esc(l.href) + '">').join('');

    const printCss = `
      @page { size: A4 portrait; margin: 12mm 10mm 20mm; @bottom-right { content: "Page " counter(page) " of " counter(pages); font-size: 8pt; color: #475569; } }
      * { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
      html, body { margin: 0; padding: 0; background: #fff; }
      .gok-letterhead { text-align: center; border-bottom: 2px solid #0d47a1; padding-bottom: 8px; margin-bottom: 10px; font-family: Arial, Helvetica, sans-serif; color: #0f172a; }
      .gok-arms { height: 70px; width: auto; display: block; margin: 0 auto 6px; }
      .gok-republic { font-size: 9pt; font-weight: 700; letter-spacing: .08em; }
      .gok-ministry { font-size: 14pt; font-weight: 800; color: #0d47a1; margin-top: 2px; }
      .gok-dept { font-size: 10pt; font-weight: 700; margin-top: 2px; }
      .gok-title { font-size: 13pt; font-weight: 800; margin: 10px 0 4px; text-align: center; font-family: Arial, Helvetica, sans-serif; }
      .gok-meta { display: flex; justify-content: space-between; gap: 12px; font-size: 8pt; color: #475569; margin-bottom: 8px; font-family: Arial, Helvetica, sans-serif; }
      .gok-footer { position: fixed; left: 0; right: 0; bottom: 0; border-top: 1px solid #94a3b8; padding-top: 4px; font-size: 7.5pt; color: #475569; display: flex; justify-content: space-between; gap: 12px; font-family: Arial, Helvetica, sans-serif; background: #fff; }
      thead { display: table-header-group; }
      tr { break-inside: avoid; page-break-inside: avoid; }
    `;

    const html = '<!doctype html><html><head><meta charset="utf-8">' + base + '<title>' + esc(fileName) + '</title>' + links + '<style>' + printCss + '</style></head><body>'
      + '<div class="gok-letterhead">' + arms
      + '<div class="gok-republic">' + esc(cfg.republic) + '</div>'
      + '<div class="gok-ministry">' + esc(cfg.ministry) + '</div>'
      + '<div class="gok-dept">' + esc(cfg.department) + '</div></div>'
      + '<div class="gok-title">Action Points Tracker</div>'
      + '<div class="gok-meta"><span>' + esc(filterSummary()) + '</span><span>' + rowCount + ' action point' + (rowCount === 1 ? '' : 's') + '  |  Printed ' + esc(printedOn) + (cfg.user ? ' by ' + esc(cfg.user) : '') + '</span></div>'
      + '<div style="zoom:' + zoom.toFixed(4) + '">' + clone.outerHTML + '</div>'
      + '<div class="gok-footer"><span>Ministry of Health  |  ' + esc(cfg.address) + '  |  ' + esc(cfg.website) + '</span><span>Performance Management Dashboard</span></div>'
      + '</body></html>';

    const frame = document.createElement('iframe');
    frame.setAttribute('aria-hidden', 'true');
    frame.style.cssText = 'position:fixed;left:-10000px;top:0;height:800px;border:0;width:1100px;';
    document.body.appendChild(frame);
    const doc = frame.contentWindow.document;
    doc.open(); doc.write(html); doc.close();

    const waits = [...doc.querySelectorAll('link[rel~="stylesheet"]')].map((l) => new Promise((r) => { if (l.sheet) r(); else { l.onload = l.onerror = r; } }));
    waits.push(...[...doc.images].map((img) => img.complete ? Promise.resolve() : new Promise((r) => { img.onload = img.onerror = r; })));
    const ready = Promise.all(waits).then(() => (doc.fonts && doc.fonts.ready) ? doc.fonts.ready : null);
    Promise.race([ready, new Promise((r) => setTimeout(r, 4000))]).then(() => {
      const originalTitle = document.title;
      const restore = () => { document.title = originalTitle; };
      document.title = fileName;
      window.addEventListener('afterprint', restore, { once: true });
      frame.contentWindow.focus();
      frame.contentWindow.print();
      setTimeout(() => { restore(); frame.remove(); }, 1500);
    });
    if (cfg.logUrl) fetch(cfg.logUrl, { credentials: 'same-origin', keepalive: true }).catch(() => {});
  });
})();
</script>


<?php require_once __DIR__ . '/../includes/footer.php'; ?>
