<?php
/** Priority flagship detail and associated project portfolio. */
require_once __DIR__ . '/../config/db.php';
require_auth();

$flagship_id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT) ?: 0;
$flagship = null;
$linked_projects = [];
if ($db_connected && $pdo && $flagship_id > 0) {
    try {
        $stmt = $pdo->prepare('SELECT * FROM flagships WHERE id = ?');
        $stmt->execute([$flagship_id]);
        $flagship = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
        if ($flagship) {
            $stmt = $pdo->prepare("SELECT p.id, p.project_code, p.project_type, p.category, p.color, p.programme_title, p.sub_programme, p.directorate_name, p.saga_name, p.division_name, p.delivery_unit, p.status, p.progress_status, p.overall_progress_pct AS progress_pct, p.total_budget, p.funds_disbursed, p.funds_utilized, p.start_date, p.end_date FROM projects p WHERE p.flagship_id = ? ORDER BY p.id DESC");
            $stmt->execute([$flagship_id]);
            $linked_projects = $stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach ($linked_projects as &$lp) {
                if (isset($monthly_progress_by_project[(int)$lp['id']])) $lp['progress_pct'] = (float)$monthly_progress_by_project[(int)$lp['id']];
                elseif ($lp['progress_pct'] !== null) $lp['progress_pct'] = (float)$lp['progress_pct'];
                elseif (preg_match('/^\s*(\d+(?:\.\d+)?)\s*%?\s*$/', (string)($lp['progress_status'] ?? ''), $pm)) $lp['progress_pct'] = (float)$pm[1];
                else $lp['progress_pct'] = 0.0;
                $lp['progress_pct'] = max(0, $lp['progress_pct']);
            }
            unset($lp);
        }
    } catch (Throwable $error) {
        error_log('Priority flagship detail query failed: ' . $error->getMessage());
    }
}
$is_archived = $flagship && !empty($flagship['is_archived']);
$flash_codes = ['updated' => 'Flagship successfully updated.', 'restored' => 'Flagship restored.'];
$flash_msg = $flash_codes[$_GET['msg'] ?? ''] ?? '';
$page_title = $flagship ? ($flagship['title'] . ' — Priority Flagship') : 'Priority Flagship Details';
$active_tab = 'flagships';

/** Shared colour maps (same palette as the projects page). */
$status_fg = ['in progress'=>'#047857','on hold'=>'#92400e','completed'=>'#1d4ed8','planning'=>'#6d28d9','delayed'=>'#c2410c','overdue'=>'#b91c1c','cancelled'=>'#475569'];
$status_bg = ['in progress'=>'#ecfdf5','on hold'=>'#fffbeb','completed'=>'#eff6ff','planning'=>'#f5f3ff','delayed'=>'#fff7ed','overdue'=>'#fef2f2','cancelled'=>'#f1f5f9'];

require_once __DIR__ . '/../includes/header.php';
?>
<style>
.flagship-detail{display:flex;flex-direction:column;gap:18px}.flagship-detail-head,.flagship-detail-card,.flagship-project-wrap{background:#fff;border:1px solid #dce4ef;border-radius:10px;box-shadow:0 3px 10px rgba(15,23,42,.04)}.flagship-detail-head{padding:22px}.flagship-back{font-size:.8rem;font-weight:750;color:#1d4ed8;text-decoration:none}.flagship-detail h2{color:#102c53;margin:12px 0 7px;font-size:1.45rem}.flagship-description{color:#64748b;line-height:1.6;margin:0;max-width:900px}.flagship-metrics{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px}.flagship-detail-card{padding:17px}.flagship-metric-label{color:#64748b;font-size:.72rem;font-weight:800;text-transform:uppercase}.flagship-metric-value{margin-top:7px;color:#102c53;font-size:1.2rem;font-weight:800}.flagship-project-wrap{overflow:auto}.flagship-project-table{border-collapse:collapse;width:100%;min-width:1100px;font-size:.82rem}.flagship-project-table th{padding:12px 14px;text-align:left;color:#52647c;background:#f8fafc;font-size:.7rem;letter-spacing:.04em;text-transform:uppercase}.flagship-project-table td{padding:13px 14px;border-top:1px solid #e9eef5;color:#334155}.flagship-project-table a{color:#0d47a1;font-weight:750;text-decoration:none}.flagship-metric-link{display:block;color:inherit;text-decoration:none;transition:transform .15s,box-shadow .15s}.flagship-metric-link:hover{transform:translateY(-2px);box-shadow:0 6px 14px rgba(16,44,83,.12)}.flagship-project-wrap:target{box-shadow:0 0 0 2px rgba(13,71,161,.3)}.flagship-empty{padding:24px!important;text-align:center;color:#64748b!important}.flagship-progress{height:8px;width:110px;background:#e2e8f0;border-radius:10px;overflow:hidden}.flagship-progress span{display:block;height:100%;background:#2563eb;border-radius:inherit}@media(max-width:760px){.flagship-metrics{grid-template-columns:repeat(2,minmax(0,1fr))}}
/* Linked projects section */
.lp-head{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;background:#0d47a1;color:#fff;padding:14px 20px}
.lp-head-title{font-size:.85rem;font-weight:800}
.lp-toggle{display:inline-flex;align-items:center;gap:8px;background:#fff;color:#0d47a1;border:0;border-radius:999px;padding:7px 14px;font-size:.75rem;font-weight:800;cursor:pointer;transition:background .15s}
.lp-toggle:hover{background:#e0e9fb}
.lp-toggle:focus-visible{outline:2px solid #fff;outline-offset:2px}
.lp-cards{display:grid;grid-template-columns:repeat(auto-fill,minmax(270px,1fr));gap:16px;padding:20px;background:#f8fafc}
.lp-card{position:relative;display:flex;flex-direction:column;gap:10px;background:#fff;border:1px solid #e2e8f0;border-left:5px solid var(--lp-colour,#0d47a1);border-radius:10px;padding:16px 16px 14px;transition:transform .15s,box-shadow .15s}
.lp-card:hover{transform:translateY(-2px);box-shadow:0 8px 18px rgba(15,23,42,.1)}
.lp-card-top{display:flex;justify-content:space-between;align-items:flex-start;gap:8px}
.lp-pill{font-size:.66rem;font-weight:800;padding:3px 9px;border-radius:999px;color:#fff;white-space:nowrap}
.lp-code{font-size:.68rem;color:#1d4ed8;font-family:'JetBrains Mono',monospace}
.lp-title{margin:0;font-size:.92rem;font-weight:800;line-height:1.35;color:#0f172a}
.lp-unit{font-size:.74rem;color:#64748b}
.lp-bar{height:7px;background:#e2e8f0;border-radius:999px;overflow:hidden}
.lp-bar span{display:block;height:100%;border-radius:inherit}
.lp-meta{display:flex;justify-content:space-between;font-size:.74rem;color:#334155}
.lp-meta strong{color:#0d47a1}
.lp-link{margin-top:auto;align-self:flex-start;background:#1d4ed8;color:#fff;text-decoration:none;padding:5px 12px;border-radius:6px;font-size:.72rem;font-weight:800}
.lp-link:hover{background:#1e40af}
.lp-table-view[hidden],.lp-cards[hidden]{display:none}
</style>
<div class="flagship-detail">
<?php if (!$flagship): ?>
    <section class="flagship-detail-head"><a class="flagship-back" href="/modules/flagships.php">← Priority Flagships</a><h2>Flagship not found</h2><p class="flagship-description">Select a flagship from the portfolio to view its details.</p></section>
<?php else:
    $budget = array_sum(array_map(static fn($p)=>(float)($p['total_budget'] ?? 0), $linked_projects));
    $average = $linked_projects ? array_sum(array_map(static fn($p)=>(float)($p['progress_pct'] ?? 0), $linked_projects)) / count($linked_projects) : 0.0;
    $tier_text = (string)($flagship['priority_tier'] ?? '—');
    $tier_colour = match ($tier_text) { 'Critical' => '#dc2626', 'High' => '#f59e0b', 'Medium' => '#16a34a', 'Low' => '#2563eb', default => '#64748b' };
?>
    <?php if ($flash_msg): ?><div role="status" style="background:#ecfdf5;border:1px solid #10b981;color:#065f46;padding:12px;border-radius:6px;font-size:.85rem"><?= htmlspecialchars($flash_msg) ?></div><?php endif; ?>
    <?php if ($is_archived): ?><div role="status" style="background:#fffbeb;border:1px solid #f59e0b;color:#92400e;padding:12px;border-radius:6px;font-size:.85rem"><strong>This flagship is archived.</strong> It is hidden from the active list<?= !empty($flagship['archived_at']) ? ' (since ' . htmlspecialchars(date('d M Y', strtotime((string)$flagship['archived_at']))) . ')' : '' ?>. Restore it to make changes.</div><?php endif; ?>
    <section class="flagship-detail-head"><a class="flagship-back" href="/modules/flagships.php<?= $is_archived ? '?archived=1' : '' ?>">← Priority Flagships</a><h2><?= htmlspecialchars((string)$flagship['title']) ?></h2><p class="flagship-description"><?= nl2br(htmlspecialchars((string)($flagship['description'] ?? ''))) ?></p><div class="meetings-sub" style="margin-top:12px;color:#64748b">Priority: <strong style="color:<?= $tier_colour ?>"><?= htmlspecialchars($tier_text) ?></strong></div><?php if (can_edit()): ?><div style="margin-top:14px;display:flex;gap:8px;align-items:center;flex-wrap:wrap">
        <?php if (!$is_archived): ?>
            <a href="/modules/flagships.php?edit=<?= (int)$flagship['id'] ?>" style="display:inline-block;background:#eff6ff;color:#1d4ed8;padding:8px 14px;border-radius:6px;font-size:.8rem;font-weight:700;text-decoration:none">&#9998; Edit Flagship</a>
            <form method="post" action="/modules/flagships.php" onsubmit="return confirm('Archive this flagship?\n\nIt will be hidden from the active list. Its linked projects stay linked, and you can restore it later from the Archived view.');"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars(get_csrf_token()) ?>"><input type="hidden" name="action" value="archive"><input type="hidden" name="id" value="<?= (int)$flagship['id'] ?>"><button type="submit" style="border:0;border-radius:6px;padding:8px 14px;background:#fef3c7;color:#92400e;font-size:.8rem;font-weight:700;cursor:pointer">&#128451; Archive Flagship</button></form>
        <?php else: ?>
            <form method="post" action="/modules/flagships.php"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars(get_csrf_token()) ?>"><input type="hidden" name="action" value="restore"><input type="hidden" name="id" value="<?= (int)$flagship['id'] ?>"><button type="submit" style="border:0;border-radius:6px;padding:8px 14px;background:#dcfce7;color:#166534;font-size:.8rem;font-weight:700;cursor:pointer">&#8634; Restore Flagship</button></form>
        <?php endif; ?>
        </div><?php endif; ?></section>
    <section class="flagship-metrics" aria-label="Flagship summary">
        <?php foreach ([
            ['Linked Projects', (string)count($linked_projects), '', 'flagshipProjects', 'See linked projects'],
            ['Portfolio Progress', number_format($average,1) . '%', '', 'flagshipProjects', 'See progress per project'],
            ['Total Project Budget', format_kes($budget), 'font-size:1rem', 'flagshipProjects', 'See budget per project'],
        ] as [$metric_label, $metric_value, $metric_style, $metric_target, $metric_hint]): ?>
        <a class="flagship-detail-card flagship-metric-link" href="#<?= $metric_target ?>" data-highlight="<?= htmlspecialchars($metric_label, ENT_QUOTES) ?>" title="<?= htmlspecialchars($metric_hint, ENT_QUOTES) ?>"><div class="flagship-metric-label"><?= htmlspecialchars($metric_label) ?></div><div class="flagship-metric-value"<?= $metric_style ? ' style="' . $metric_style . '"' : '' ?>><?= htmlspecialchars($metric_value) ?></div><div class="module-summary-hint"><?= htmlspecialchars($metric_hint) ?> &rarr;</div></a>
        <?php endforeach; ?>
    </section>

    <!-- Linked projects (bottom of page): cards by default, full table on toggle -->
    <section class="flagship-project-wrap" id="flagshipProjects" style="overflow:hidden">
        <div class="lp-head">
            <span class="lp-head-title">Linked Projects &amp; Programmes (<?= count($linked_projects) ?> <?= count($linked_projects) === 1 ? 'Project' : 'Projects' ?>)</span>
            <?php if ($linked_projects): ?>
            <button type="button" class="lp-toggle" id="lpToggle" aria-pressed="false" aria-controls="lpCards lpTable">
                <span id="lpToggleIcon" aria-hidden="true">▦</span><span id="lpToggleLabel">Show all fields</span>
            </button>
            <?php endif; ?>
        </div>

        <?php if (!$linked_projects): ?>
            <div class="flagship-empty">No projects are linked to this flagship yet.</div>
        <?php else: ?>

        <!-- Card view: project titles -->
        <div class="lp-cards" id="lpCards">
            <?php foreach ($linked_projects as $project):
                $progressValue = (float)$project['progress_pct'];
                $statusKey = strtolower(trim((string)($project['status'] ?? '')));
                $pillColour = $status_fg[$statusKey] ?? '#64748b';
                $colour = (string)($project['color'] ?? '#0d47a1');
                if (!preg_match('/^#[0-9a-fA-F]{3,8}$/', $colour)) $colour = '#0d47a1';
            ?>
            <article class="lp-card" style="--lp-colour:<?= $colour ?>">
                <div class="lp-card-top">
                    <span class="lp-code"><?= !empty($project['project_code']) ? htmlspecialchars((string)$project['project_code']) : 'ID ' . (int)$project['id'] ?></span>
                    <span class="lp-pill" style="background:<?= $pillColour ?>"><?= htmlspecialchars((string)($project['status'] ?? '—')) ?></span>
                </div>
                <h4 class="lp-title"><?= htmlspecialchars((string)$project['sub_programme']) ?></h4>
                <div class="lp-unit"><?= htmlspecialchars((string)($project['delivery_unit'] ?? $project['saga_name'] ?? $project['directorate_name'] ?? 'Ministry of Health')) ?></div>
                <div>
                    <div class="lp-meta"><span>Progress</span><strong><?= number_format($progressValue, 1) ?>%</strong></div>
                    <div class="lp-bar" style="margin-top:5px" role="progressbar" aria-valuenow="<?= round(min(100, $progressValue)) ?>" aria-valuemin="0" aria-valuemax="100"><span style="width:<?= min(100, $progressValue) ?>%;background:<?= $colour ?>"></span></div>
                </div>
                <div class="lp-meta"><span>Budget</span><strong><?= format_kes($project['total_budget'] ?? 0) ?></strong></div>
                <a class="lp-link" href="/modules/projects.php?id=<?= (int)$project['id'] ?>">View Detail &rarr;</a>
            </article>
            <?php endforeach; ?>
        </div>

        <!-- Table view: every field shown on the main Projects page -->
        <div class="lp-table-view" id="lpTable" hidden style="overflow-x:auto">
        <table class="flagship-project-table">
            <thead>
                <tr style="background:#f8fafc;color:#475569;font-weight:700;border-bottom:2px solid #e2e8f0;text-transform:uppercase;font-size:.7rem;">
                    <th>Title &amp; Delivery Unit</th>
                    <th>Type</th>
                    <th>Category</th>
                    <th>Status</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                    <th>Duration</th>
                    <th style="text-align:center">Total Budget (KES)</th>
                    <th style="width:140px">Progress</th>
                    <th style="text-align:center">Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($linked_projects as $project):
                $progressValue = (float)$project['progress_pct'];
                $statusKey = strtolower(trim((string)($project['status'] ?? '')));
                $statusStyle = $status_fg[$statusKey] ?? '#64748b';
                $rowBg = $status_bg[$statusKey] ?? '#ffffff';
                $durationLabel = '—';
                $durationStart = !empty($project['start_date']) ? DateTimeImmutable::createFromFormat('!Y-m-d', (string)$project['start_date']) : false;
                $durationEnd   = !empty($project['end_date'])   ? DateTimeImmutable::createFromFormat('!Y-m-d', (string)$project['end_date'])   : false;
                if ($durationStart && $durationEnd && $durationEnd >= $durationStart) {
                    $duration = $durationStart->diff($durationEnd);
                    $durationParts = [];
                    if ($duration->y) $durationParts[] = $duration->y . ' ' . ($duration->y === 1 ? 'year' : 'years');
                    if ($duration->m) $durationParts[] = $duration->m . ' ' . ($duration->m === 1 ? 'month' : 'months');
                    if (!$durationParts && $duration->d) $durationParts[] = $duration->d . ' ' . ($duration->d === 1 ? 'day' : 'days');
                    $durationLabel = $durationParts ? implode(' ', $durationParts) : 'Under 1 month';
                }
            ?>
                <tr style="background:<?= $rowBg ?>">
                    <td>
                        <strong style="color:#0f172a;font-size:.82rem;"><?= htmlspecialchars((string)$project['sub_programme']) ?></strong>
                        <?php if (!empty($project['project_code'])): ?><div style="font-size:.68rem;color:#1d4ed8;margin-top:2px;">Code: <?= htmlspecialchars((string)$project['project_code']) ?></div><?php endif; ?>
                        <div style="font-size:.72rem;color:#64748b;margin-top:2px;">Delivery Unit: <?= htmlspecialchars((string)($project['delivery_unit'] ?? $project['saga_name'] ?? $project['directorate_name'] ?? 'Ministry of Health')) ?></div>
                    </td>
                    <td><span style="background:#f1f5f9;color:#475569;border:1px solid #cbd5e1;padding:3px 7px;border-radius:4px;font-size:.7rem;font-weight:700;"><?= htmlspecialchars((string)($project['project_type'] ?? 'Project')) ?></span></td>
                    <td><span style="background:#dbeafe;color:#1e40af;font-weight:800;font-size:.68rem;padding:2px 6px;border-radius:4px;"><?= htmlspecialchars((string)$project['category']) ?></span></td>
                    <td><span style="background:<?= $statusStyle ?>;color:#fff;padding:4px 10px;border-radius:6px;font-size:.7rem;font-weight:800;white-space:nowrap;"><?= htmlspecialchars((string)($project['status'] ?? '—')) ?></span></td>
                    <td style="white-space:nowrap"><?= $durationStart ? htmlspecialchars($durationStart->format('d M Y')) : '—' ?></td>
                    <td style="white-space:nowrap"><?= $durationEnd ? htmlspecialchars($durationEnd->format('d M Y')) : '—' ?></td>
                    <td style="white-space:nowrap;font-weight:700"><?= htmlspecialchars($durationLabel) ?></td>
                    <td style="text-align:right;font-family:'JetBrains Mono',monospace;font-weight:700;color:#0d47a1"><?= number_format((float)($project['total_budget'] ?? 0), 0, '.', ',') ?></td>
                    <td>
                        <div style="font-size:.75rem;font-weight:800;color:#334155;margin-bottom:4px;"><?= number_format($progressValue, 1) ?>%</div>
                        <div style="background:#e2e8f0;height:8px;border-radius:4px;overflow:hidden;"><div style="background:<?= htmlspecialchars((string)($project['color'] ?? '#0d47a1')) ?>;height:100%;width:<?= min(100, $progressValue) ?>%;"></div></div>
                    </td>
                    <td style="text-align:center"><a href="/modules/projects.php?id=<?= (int)$project['id'] ?>" style="background:#1d4ed8;color:#fff;text-decoration:none;padding:5px 12px;border-radius:6px;font-size:.72rem;font-weight:800;display:inline-block;white-space:nowrap;">View Detail &rarr;</a></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
        <?php endif; ?>
    </section>
    <script>
    (() => {
        const btn = document.getElementById('lpToggle');
        if (!btn) return;
        const cards = document.getElementById('lpCards'), table = document.getElementById('lpTable');
        btn.addEventListener('click', () => {
            const showTable = table.hidden;
            table.hidden = !showTable; cards.hidden = showTable;
            btn.setAttribute('aria-pressed', showTable ? 'true' : 'false');
            document.getElementById('lpToggleLabel').textContent = showTable ? 'Show cards' : 'Show all fields';
            document.getElementById('lpToggleIcon').textContent = showTable ? '▤' : '▦';
        });
    })();
    </script>
<?php endif; ?>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
