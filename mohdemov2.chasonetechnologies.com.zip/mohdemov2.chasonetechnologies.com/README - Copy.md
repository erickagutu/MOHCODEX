# PP-SDOMS Performance Management Dashboard

PHP and MySQL/MariaDB application for the State Department for Medical Services.

## Requirements

- PHP 8.1 or later
- PDO with `pdo_mysql` for MySQL/MariaDB, or `pdo_sqlite` for a local SQLite preview
- MySQL 8.0+ or MariaDB 10.6+ for production
- Apache with `.htaccess` support, or PHP's built-in development server

## Configure the database

1. Copy `.env.example` to `.env` and set `DB_DRIVER=mysql`, `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, and `DB_PASS` for your database.
2. Import `database/schema.sql` into the selected MySQL/MariaDB database for a fresh installation.
3. For an existing installation, apply both `database/migrations/2026_10_07_notification_lookup_index.sql` and `database/migrations/2026_10_07_audit_logs_index.sql`; both are safe to run again.
4. Keep `.env` private and outside source control. The application no longer falls back to SQLite when a configured MySQL connection fails.

If `DB_DRIVER` is not configured and no MySQL host/user is supplied, the local preview uses `database/ppsdms.sqlite`.

## Run locally

From this directory, run:

```sh
php -S 127.0.0.1:8000 router.php
```

Then open `http://127.0.0.1:8000/`. The application requires an active account in the `users` table; sign in with its username or email and password. An unauthenticated visit is redirected to the login screen.

## Included features

- Session-based login and logout
- Activity/event creation, card and agenda layouts, and filtering by activity type, status, and month
- Notification drawer with unread counts and read-state actions
- Admin-only audit-log page with module views, successful logins/logouts, recorded data changes, date/time, actor, record ID, and request IP
- Audit descriptions list changed field names but do not copy submitted values or passwords
- MySQL import schema and idempotent lookup-index migrations
