<?php
/**
 * Database Connection & Core Security Configuration
 * Ministry of Health — State Department for Medical Services (PP-SDOMS)
 * Native PHP 8.1+ & PDO MySQL (Zero Node.js Dependencies)
 */

if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', '1');
    ini_set('session.use_only_cookies', '1');
    ini_set('session.cookie_samesite', 'Lax');
    session_start();
}

// Load environment variables if .env exists
function load_env($filePath = __DIR__ . '/../.env') {
    if (!file_exists($filePath)) {
        $filePath = __DIR__ . '/../.env.example';
    }
    if (file_exists($filePath)) {
        $lines = file($filePath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) {
            $line = trim($line);
            if (empty($line) || str_starts_with($line, '#')) continue;
            if (strpos($line, '=') !== false) {
                list($key, $val) = explode('=', $line, 2);
                $key = trim($key);
                $val = trim($val, " \t\n\r\0\x0B\"'");
                if (!isset($_ENV[$key])) {
                    $_ENV[$key] = $val;
                    putenv("$key=$val");
                }
            }
        }
    }
}
load_env();

// Database credentials
$db_host = $_ENV['DB_HOST'] ?? getenv('DB_HOST') ?: 'localhost';
$db_port = $_ENV['DB_PORT'] ?? getenv('DB_PORT') ?: '3306';
$db_name = $_ENV['DB_NAME'] ?? getenv('DB_NAME') ?: 'chasonet_mohsys';
$db_user = $_ENV['DB_USER'] ?? getenv('DB_USER') ?: 'chasonet_moh';
$db_pass = $_ENV['DB_PASS'] ?? getenv('DB_PASS') ?: 'cognito.88';

$pdo = null;
$db_connected = false;

try {
    $dsn = "mysql:host={$db_host};port={$db_port};dbname={$db_name};charset=utf8mb4";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    $pdo = new PDO($dsn, $db_user, $db_pass, $options);
    $db_connected = true;
} catch (PDOException $e) {
    $db_connected = false;
    $db_error = $e->getMessage();
    $connectionLog = 'PP-SDOMS database connection failed: ' . $db_error;
    error_log($connectionLog);
    @error_log(date('[Y-m-d H:i:s] ') . $connectionLog . PHP_EOL, 3, __DIR__ . '/../error_log');
}

/**
 * Global CSRF Protection
 */
function get_csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verify_csrf_token($token): bool {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], (string)$token);
}

function send_email_verification_code(string $email, string $fullName, string $code): bool {
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || !function_exists('mail')) return false;
    $host = preg_replace('/[^A-Za-z0-9.-]/', '', (string)($_SERVER['HTTP_HOST'] ?? 'localhost'));
    $from = trim((string)($_ENV['MAIL_FROM'] ?? ''));
    if ($from === '') $from = trim((string)(getenv('MAIL_FROM') ?: ''));
    if ($from === '') $from = 'noreply@' . ($host ?: 'localhost');
    if (!filter_var($from, FILTER_VALIDATE_EMAIL)) return false;
    $subject = 'Your PP-SDOMS sign-in verification code';
    $name = trim(preg_replace('/[\r\n]+/', ' ', $fullName));
    $body = "Hello {$name},\n\nYour PP-SDOMS sign-in verification code is: {$code}\n\nThis code expires in 10 minutes. If you did not request it, you can ignore this email.\n\nState Department for Medical Services";
    $headers = "From: PP-SDOMS <{$from}>\r\n" . "Content-Type: text/plain; charset=UTF-8\r\n";
    return @mail($email, $subject, $body, $headers);
}

/**
 * Authentication & RBAC Helpers
 */
function get_current_user_data(): array {
    if (!empty($_SESSION['user'])) {
        return $_SESSION['user'];
    }
    return [];
}

function require_auth() {
    if (empty($_SESSION['user'])) {
        header('Location: /index.php');
        exit;
    }
    global $pdo, $db_connected;
    $user = get_current_user_data();
    $isAdminUser = !empty($user['is_admin']) || strcasecmp((string)($user['role'] ?? ''), 'Administrator') === 0;
    if (!$isAdminUser && $db_connected && $pdo) {
        $path = basename((string)($_SERVER['SCRIPT_NAME'] ?? ''));
        $moduleByPage = [
            'dashboard.php' => 'dashboard', 'pj.php' => 'projects', 'flagships.php' => 'flagships',
            'flagship_view.php' => 'flagships', 'events.php' => 'events', 'actions.php' => 'actions',
            'meetings.php' => 'meetings', 'projects.php' => 'projects', 'zprojects.php' => 'projects',
            'reports.php' => 'reports', 'diary.php' => 'diary', 'pc.php' => 'pc',
            'audit_logs.php' => 'administration', 'users.php' => 'administration', 'system_security.php' => 'administration', 'backup.php' => 'administration', 'archive.php' => 'administration', 'project_registries.php' => 'projects',
            'document_rights.php' => 'reports', 'monthly_progress.php' => 'pc', 'divisions.php' => 'projects',
            'diary-events.php' => 'diary',
        ];
        $isOwnSecurityTab = $path === 'users.php' && (($_GET['tab'] ?? '') === 'security');
        if (isset($moduleByPage[$path]) && !$isOwnSecurityTab) {
            try {
                $check = $pdo->prepare('SELECT 1 FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ?');
                $check->execute(['user_module_permissions']);
                if ($check->fetchColumn()) {
                    $grant = $pdo->prepare('SELECT 1 FROM user_module_permissions WHERE user_id = ? AND module_key = ? LIMIT 1');
                    $grant->execute([(int)($user['id'] ?? 0), $moduleByPage[$path]]);
                    $hasGrant = (bool)$grant->fetchColumn();
                    if (!$hasGrant && $moduleByPage[$path] === 'administration') {
                        $legacyAdminKey = $path === 'audit_logs.php' ? 'audit_logs' : 'users';
                        $grant->execute([(int)($user['id'] ?? 0), $legacyAdminKey]);
                        $hasGrant = (bool)$grant->fetchColumn();
                    }
                    if (!$hasGrant) {
                        log_audit_trail('UNAUTHORIZED_ACCESS','Security',null,'Blocked access to '.$path,['severity'=>'WARNING','metadata'=>['path'=>$path,'required_module'=>$moduleByPage[$path]]]);
                        http_response_code(403);
                        exit('Access denied. Your account does not have permission to open this module. Contact an administrator.');
                    }
                }
            } catch (PDOException $e) {
                http_response_code(503);
                exit('Unable to verify module access. Please try again later.');
            }
        }
    }
}

function is_admin(): bool {
    $u = get_current_user_data();
    return !empty($u['is_admin']) || strcasecmp((string)($u['role'] ?? ''), 'Administrator') === 0;
}

function can_edit(): bool {
    $u = get_current_user_data();
    return !empty($u['can_edit']) || is_admin();
}

/**
 * Formatting & Audit Trail
 */
function format_kes($amount): string {
    return 'KES ' . number_format((float)$amount, 2);
}

function ensure_audit_log_schema(PDO $pdo): void {
    static $checked = false;
    if ($checked) return;
    $columns = $pdo->query('SHOW COLUMNS FROM audit_logs')->fetchAll(PDO::FETCH_COLUMN);
    $needed = [
        'user_id' => 'INT NULL',
        'user_role' => 'VARCHAR(100) NULL',
        'user_agent' => 'VARCHAR(255) NULL',
        'severity' => "VARCHAR(20) NOT NULL DEFAULT 'INFO'",
        'project_id' => 'INT NULL',
        'reason' => 'TEXT NULL',
        'metadata' => 'LONGTEXT NULL',
    ];
    foreach ($needed as $name => $definition) {
        if (!in_array($name, $columns, true)) $pdo->exec('ALTER TABLE audit_logs ADD COLUMN ' . $name . ' ' . $definition);
    }
    $indexes = $pdo->query('SHOW INDEX FROM audit_logs')->fetchAll(PDO::FETCH_COLUMN, 2);
    if (!in_array('idx_audit_created_at', $indexes, true)) $pdo->exec('ALTER TABLE audit_logs ADD INDEX idx_audit_created_at (created_at)');
    if (!in_array('idx_audit_project_severity', $indexes, true)) $pdo->exec('ALTER TABLE audit_logs ADD INDEX idx_audit_project_severity (project_id,severity)');
    $checked = true;
}

function log_audit_trail($action, $module, $record_id = null, $details = '', array $context = []) {
    global $pdo, $db_connected;
    $u = get_current_user_data();
    $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';

    if ($db_connected && $pdo) {
        try {
            ensure_audit_log_schema($pdo);
            $actionUpper = strtoupper((string)$action);
            $severity = strtoupper((string)($context['severity'] ?? (
                str_contains($actionUpper, 'UNAUTHORIZED') || str_contains($actionUpper, 'FAILED') ? 'WARNING' :
                (str_contains($actionUpper, 'DELETE') || str_contains($actionUpper, 'ARCHIVE') || str_contains($actionUpper, 'PERMISSION') || str_contains($actionUpper, 'ROLE') ? 'WARNING' : 'INFO')
            )));
            if (!in_array($severity, ['INFO','WARNING','CRITICAL'], true)) $severity = 'INFO';
            $metadata = $context['metadata'] ?? [];
            if (!is_array($metadata)) $metadata = ['value' => $metadata];
            $stmt = $pdo->prepare("
                INSERT INTO audit_logs
                    (user_name,user_email,action,module,record_id,details,ip_address,created_at,user_id,user_role,user_agent,severity,project_id,reason,metadata)
                VALUES (?,?,?,?,?,?,?,NOW(),?,?,?,?,?,?,?)
            ");
            $stmt->execute([
                (string)($u['full_name'] ?? $u['name'] ?? 'Unknown / unauthenticated'),
                (string)($u['email'] ?? ''),
                $action,
                $module,
                $record_id,
                $details,
                $ip,
                isset($u['id']) ? (int)$u['id'] : null,
                (string)($u['role'] ?? ''),
                substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255) ?: null,
                $severity,
                isset($context['project_id']) ? (int)$context['project_id'] : null,
                isset($context['reason']) ? (string)$context['reason'] : null,
                $metadata ? json_encode($metadata, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE) : null,
            ]);
        } catch (Exception $e) {
            error_log('Audit trail write failed: ' . $e->getMessage());
        }
    }
}

function audit_log_change(string $module, $recordId, array $before, array $after, string $details, array $context = []): void {
    $keys = array_unique(array_merge(array_keys($before), array_keys($after)));
    $diff = [];
    foreach ($keys as $key) {
        if (in_array(strtolower((string)$key), ['password','password_hash','token','csrf_token','secret','totp_secret'], true)) continue;
        $old = $before[$key] ?? null;
        $new = $after[$key] ?? null;
        if ($old !== $new) $diff[$key] = ['old' => $old, 'new' => $new];
    }
    $context['metadata'] = array_merge((array)($context['metadata'] ?? []), ['diff' => $diff]);
    log_audit_trail('UPDATE', $module, $recordId, $details, $context);
}
