# State Department for Medical Services (PP-SDOMS)
## cPanel & Production Server Installation Guide

This deployment guide describes how to configure and deploy the Project Performance, Service Delivery & Operational Management System (PP-SDOMS) on cPanel / LAMP hosting environments.

---

### 1. Prerequisites
- **cPanel Account** with MySQL / MariaDB and phpMyAdmin access.
- **PHP Version:** PHP 8.1 or 8.2 (with `pdo_mysql`, `mbstring`, `json`, `openssl`, `curl` extensions enabled).
- **Web Server:** Apache 2.4+ (with `mod_rewrite` enabled) or Nginx with PHP-FPM.
- **SSL Certificate:** Free cPanel AutoSSL or Let's Encrypt enabled for HTTPS.

---

### 2. Database Setup via cPanel
1. Log into your **cPanel Dashboard**.
2. Navigate to **Databases &rarr; MySQL Databases**.
3. Create a new database, e.g. `cpaneluser_mohsdms`.
4. Create a MySQL user, e.g. `cpaneluser_mohadmin`, with a strong password.
5. Add the user to the database with **ALL PRIVILEGES**.
6. Open **phpMyAdmin**, select the newly created database `cpaneluser_mohsdms`, and click the **Import** tab.
7. Choose the file `database/schema.sql` (or `public/database/schema.sql`) and click **Go**.

---

### 3. File Upload & Directory Structure
1. In cPanel, open **File Manager** and browse to `public_html/`.
2. Upload the application archive (`moh_project_files.zip`) or Git clone the repository.
3. Extract files into `public_html/`.
4. Ensure standard permissions:
   - Folders: `755`
   - Files: `644`
   - Assets / Uploads cache directory: `775` (writable by web server process)

---

### 4. Environment Configuration
1. In the root directory, create a `.env` file based on `.env.example`:
   ```ini
   DB_DRIVER=mysql
   DB_HOST=localhost
   DB_PORT=3306
   DB_NAME=cpaneluser_mohsdms
   DB_USER=cpaneluser_mohadmin
   DB_PASS=YourStrongPasswordHere
   HOST=0.0.0.0
   MAIL_FROM=noreply@your-domain.go.ke
   ```
2. Set `MAIL_FROM` to an address on your domain that cPanel is allowed to send from. Email 2FA uses PHP's configured `mail()` transport; ask your host to enable it if code emails are not delivered.
3. Verify that `.htaccess` restricts access to `.env` and sensitive directories.

---

### 5. Default Credentials & Initial Verification
- **Administrator Email:** `admin@health.go.ke`
- **Initial Password:** `ChangeMe@2026`
- **Security Action:** Immediately upon first login, navigate to the **Users** module and update the default password.

---

### 6. Automated Backup Setup (Cron Job)
In cPanel &rarr; **Cron Jobs**, set up a nightly database backup:
```bash
mysqldump -u cpaneluser_mohadmin -p'YourStrongPasswordHere' cpaneluser_mohsdms | gzip > /home/cpaneluser/backups/mohsdms_$(date +\%F).sql.gz
```
Schedule: `0 2 * * *` (Daily at 2:00 AM).
