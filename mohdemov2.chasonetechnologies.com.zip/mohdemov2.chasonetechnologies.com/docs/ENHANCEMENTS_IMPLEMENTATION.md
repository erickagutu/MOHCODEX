# PP-SDOMS Enhancement Package — 2 November 2026

## Compatibility and safety
- Native PHP 8.4 / PDO MySQL and MariaDB 10.11 compatible.
- The supplied SQL dump is the source schema; the enhancement migration is separate and should be applied after a verified backup.
- Do not overwrite the live database with the supplied dump.
- Runtime configuration is now read only from a private `.env` file. `.env.example` is a template, not a live configuration source.

## Deployment steps
1. Back up the live website files and database from cPanel.
2. Upload the updated application files, preserving the existing `uploads/` and `assets/uploads/` data directories.
3. Copy `.env.example` to `.env` in the application root. Enter the actual cPanel DB host/name/user/password.
4. Set `APP_KEY` to a unique random secret of at least 32 characters. Keep the same key permanently; changing it makes existing encrypted 2FA secrets unreadable. Do not commit or share `.env`.
5. In phpMyAdmin, select the existing application database and import `database/20261102_enhancements.sql`. This migration adds 2FA, notifications, action history, repository, diary attendance, priority history, review remarks, and missing Reports-module metadata.
6. Check `uploads/repository/` is writable by PHP; the application creates a deny-all `.htaccess` there and serves documents through an authenticated PHP download handler.
7. Sign in, open **Account Security**, select **Set up 2FA**, add the displayed secret to an authenticator app, and verify a six-digit code. 2FA is enabled per user; existing users are not locked out until they opt in.
8. Add the daily event notification cron job in cPanel (use your actual account path):

   `php -q /home/CPANEL_USERNAME/public_html/cron/event_notifications.php`

   Set it to run once daily, preferably around 06:00 Africa/Nairobi. The script creates day-before and event-day notifications, and uses a unique source key to avoid duplicate reminders.
9. Test on a staging copy before switching production traffic.

## Priority scoring algorithm
The project priority score is recalculated on the Projects & Programmes page from six signals (0–100 risk values):
- Schedule gap: 30% (difference between expected progress based on elapsed project dates and recorded progress).
- Timeline/overdue risk: 20% (twice the schedule gap, capped at 100; overdue unfinished projects receive 100).
- Target achievement gap: 20% (shortfall against expected progress based on elapsed project dates).
- Financial utilisation risk: 15% (utilisation percentage materially ahead of elapsed schedule).
- Milestone risk: 10% (uncompleted milestones as a share of total milestones, where milestones are recorded).
- Delivery status risk: 5% (Delayed, Stalled, On Hold, or Overdue statuses increase risk; overdue unfinished projects receive the maximum).

Tier thresholds: **Low** 0–19.99 (generally on track); **Medium** 20–44.99 (lagging slightly); **High** 45–69.99 (progressing but requires attention); **Critical** 70–100 (urgent attention / targets and timelines materially missed). The calculated tier is stored in `projects.priority_tier`; tier changes are written to `project_priority_history`. These are initial operating thresholds and should be reviewed against the department's approved performance-management policy.

## Implemented in this package
- Sticky shared header/navigation and global responsive rules.
- Authenticator-based TOTP 2FA login step and Account Security setup page.
- Persistent user notifications API, event create/update notices, action-point notices, diary notices, and daily event reminders.
- Activities & Events action dropdowns, restricted activity types, and automatic event status rollover.
- Action-point permanent deletion limited to administrators and archived records.
- Meeting search placeholder cleanup and linked-action-point popup styling.
- Normalized project priority tiers, filter-aware status/tier counts, dynamic table heading, clickable KPI progress bars, action-progress log, editable remarks, and downstream KPI baseline/overall progress recalculation.
- General Repository upload/download and System Uploads catalogue for Reports, Performance Contract uploads, and Meeting Minutes, with filters.
- Diary standalone Meeting / Corporate Business entries, attendee invitation/response flow, and CEO notification on response.
- Performance Contract remarks field and View Remarks popup, upload timestamp/uploader metadata, and requested page title.

## Notes / assumptions
- Diary attendee matching uses the exact user `full_name` typed in the attendees field, with comma-separated names. A matching user account is required for the invitation/response workflow.
- The General Repository starts empty; administrators/editors must upload the department's approved charters, policies, mandates, guidelines, and reference reports. System Uploads lists records found in the existing Reports, Performance Contract, and Meeting Minutes tables.
- Event reminder cron execution is required for day-before and event-day reminders.
- The supplied SQL dump has older `reports` columns than the PHP Reports module expects; the enhancement migration adds the missing module, file-size, uploader-email and summary metadata columns.
- This is a code-level integration pass. Database-backed end-to-end verification still requires applying the migration to a staging database with the actual cPanel `.env` values and testing with representative user roles.
