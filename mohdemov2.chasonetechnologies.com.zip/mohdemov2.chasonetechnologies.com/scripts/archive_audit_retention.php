<?php
// CLI-only maintenance: preserve full audit history while keeping the hot table smaller.
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require_once __DIR__ . '/../config/db.php';
if (!$db_connected || !$pdo) { fwrite(STDERR, "Database connection unavailable.\n"); exit(1); }
try {
    ensure_audit_log_schema($pdo);
    $pdo->exec('CREATE TABLE IF NOT EXISTS audit_logs_archive LIKE audit_logs');
    $cutoff = (new DateTimeImmutable('now', new DateTimeZone('Africa/Nairobi')))->modify('-1 year')->format('Y-m-d H:i:s');
    $pdo->beginTransaction();
    $move = $pdo->prepare('INSERT IGNORE INTO audit_logs_archive SELECT * FROM audit_logs WHERE created_at < ?');
    $move->execute([$cutoff]);
    $moved = $move->rowCount();
    $pdo->prepare('DELETE FROM audit_logs WHERE created_at < ? AND id IN (SELECT id FROM audit_logs_archive)')->execute([$cutoff]);
    $pdo->commit();
    fwrite(STDOUT, 'Moved '.$moved.' audit entries before '.$cutoff." into audit_logs_archive.\n");
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    error_log('Audit retention job failed: '.$e->getMessage());
    fwrite(STDERR, "Audit retention job failed. See the application error log.\n");
    exit(1);
}
