<?php
// CLI-only weekly audit summary, intended for a scheduled cron entry.
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require_once __DIR__ . '/../config/db.php';
if (!$db_connected || !$pdo) { fwrite(STDERR, "Database connection unavailable.\n"); exit(1); }
try {
    $recipients = $pdo->query("SELECT DISTINCT email,full_name FROM users WHERE (is_admin=1 OR role='Administrator') AND email<>''")->fetchAll(PDO::FETCH_ASSOC);
    if (!$recipients) { fwrite(STDOUT, "No administrator recipients configured.\n"); exit(0); }
    $count = (int)$pdo->query('SELECT COUNT(*) FROM audit_logs WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)')->fetchColumn();
    $critical = (int)$pdo->query("SELECT COUNT(*) FROM audit_logs WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) AND severity='CRITICAL'")->fetchColumn();
    $warnings = (int)$pdo->query("SELECT COUNT(*) FROM audit_logs WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) AND severity='WARNING'")->fetchColumn();
    $rows = $pdo->query("SELECT action,module,COUNT(*) AS total FROM audit_logs WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) GROUP BY action,module ORDER BY total DESC LIMIT 15")->fetchAll(PDO::FETCH_ASSOC);
    $body = "PP-SDOMS weekly audit summary\nPeriod: last 7 days\nTotal events: {$count}\nWarnings: {$warnings}\nCritical events: {$critical}\n\nTop activity:\n";
    foreach ($rows as $row) $body .= '- '.$row['action'].' / '.$row['module'].': '.$row['total']."\n";
    $host = preg_replace('/[^A-Za-z0-9.-]/','',(string)($_SERVER['HTTP_HOST']??'localhost'));
    $from = trim((string)($_ENV['MAIL_FROM'] ?? ''));
    if ($from === '') $from = trim((string)(getenv('MAIL_FROM') ?: ''));
    if ($from === '') $from = 'noreply@'.($host?:'localhost');
    $subject = 'PP-SDOMS weekly audit summary';
    foreach ($recipients as $recipient) {
        $to = filter_var($recipient['email'],FILTER_VALIDATE_EMAIL);
        if (!$to) continue;
        $headers = 'From: PP-SDOMS <'.$from.'>' . "\r\nContent-Type: text/plain; charset=UTF-8\r\n";
        if (!mail($to,$subject,$body,$headers)) throw new RuntimeException('Email delivery failed for an administrator recipient.');
    }
    fwrite(STDOUT, 'Weekly audit summary sent to configured administrators.'.$PHP_EOL);
} catch (Throwable $e) {
    error_log('Audit digest job failed: '.$e->getMessage());
    fwrite(STDERR, "Audit digest failed. Check mail configuration and application logs.\n");
    exit(1);
}
