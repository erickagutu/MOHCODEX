import fs from 'fs';
import path from 'path';
import JSZip from 'jszip';

const rootDir = process.cwd();
const zip = new JSZip();

// Files and folders to package for pure native PHP cPanel deployment
const includeItems = [
  '.htaccess',
  '.env.example',
  'CPANEL_DEPLOYMENT_GUIDE.md',
  'README.md',
  'index.php',
  'dashboard.php',
  'install.php',
  'logout.php',
  'config',
  'includes',
  'modules',
  'api',
  'database',
  'assets',
  'docs'
];

function addFileOrDir(relPath) {
  const fullPath = path.join(rootDir, relPath);
  if (!fs.existsSync(fullPath)) return;

  const stat = fs.statSync(fullPath);
  if (stat.isDirectory()) {
    const files = fs.readdirSync(fullPath);
    for (const file of files) {
      if (file === 'node_modules' || file === '.git' || file === '.DS_Store') continue;
      addFileOrDir(path.join(relPath, file));
    }
  } else {
    const content = fs.readFileSync(fullPath);
    zip.file(relPath.replace(/\\/g, '/'), content);
  }
}

for (const item of includeItems) {
  addFileOrDir(item);
}

// Generate ZIP
const outputDir = path.join(rootDir, 'public');
if (!fs.existsSync(outputDir)) fs.mkdirSync(outputDir, { recursive: true });

const cpanelZipPath = path.join(outputDir, 'moh_sdms_native_php_cpanel.zip');
const generalZipPath = path.join(outputDir, 'moh_project_files.zip');

zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' }).then((buffer) => {
  fs.writeFileSync(cpanelZipPath, buffer);
  fs.writeFileSync(generalZipPath, buffer);
  console.log(`Successfully generated cPanel ZIP archive (${(buffer.length / 1024 / 1024).toFixed(2)} MB)`);
});
