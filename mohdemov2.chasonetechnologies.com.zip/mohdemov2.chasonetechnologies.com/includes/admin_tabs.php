<?php
$adminCurrentTab = $adminCurrentTab ?? 'users';
$adminTabs = [
    'users' => ['label' => 'Users & Access Management', 'href' => 'users.php'],
    'audit' => ['label' => 'Audit Logs', 'href' => 'audit_logs.php'],
    'security' => ['label' => 'System Security', 'href' => 'system_security.php'],
    'backup' => ['label' => 'Backup & Restore', 'href' => 'backup.php'],
];
?>
<nav class="admin-tabs" aria-label="Administration and security">
    <?php foreach ($adminTabs as $key => $item): $selected = $adminCurrentTab === $key; ?>
        <a href="<?= htmlspecialchars($item['href'], ENT_QUOTES, 'UTF-8') ?>" class="<?= $selected ? 'active' : '' ?>" <?= $selected ? 'aria-current="page"' : '' ?>><?= htmlspecialchars($item['label'], ENT_QUOTES, 'UTF-8') ?></a>
    <?php endforeach; ?>
</nav>
<?php if (function_exists('is_admin') && is_admin()): ?>
<p style="margin:-12px 0 20px;"><a class="admin-archive-link" href="archive.php">View Archived Data &amp; Restore</a></p>
<?php endif; ?>
<style>
.admin-tabs{display:flex;gap:8px;flex-wrap:wrap;margin:0 0 22px;padding:0 0 10px;border-bottom:1px solid #dbe3ed}
.admin-tabs a{display:inline-flex;align-items:center;padding:9px 13px;border-radius:7px;background:#f1f5f9;color:#334155;text-decoration:none;font-size:.78rem;font-weight:800}
.admin-tabs a.active{background:#0f766e;color:#fff}
.admin-tabs a:focus-visible{outline:2px solid #14b8a6;outline-offset:2px}
.admin-archive-link{display:inline-flex;padding:7px 10px;border-radius:6px;background:#ecfdf5;color:#047857;text-decoration:none;font-weight:800;font-size:.76rem}
</style>
