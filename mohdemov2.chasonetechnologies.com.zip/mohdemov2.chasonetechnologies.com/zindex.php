<?php
/**
 * Ministerial System Login Portal
 * Ministry of Health — State Department for Medical Services (PP-SDOMS)
 * Native PHP 8.1+ & MySQL (No Node.js)
 */
require_once __DIR__ . '/config/db.php';

$error = '';
$message = '';
$two_factor_pending = !empty($_SESSION['two_factor_pending_user_id']);

if (!empty($_SESSION['user'])) {
    header('Location: /dashboard.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    if (!verify_csrf_token($token)) {
        $error = 'Invalid security token. Please refresh and try again.';
    } elseif (isset($_POST['two_factor_code'])) {
        $pendingId = (int)($_SESSION['two_factor_pending_user_id'] ?? 0);
        $expires = (int)($_SESSION['two_factor_pending_expires'] ?? 0);
        $code = trim((string)($_POST['two_factor_code'] ?? ''));
        if (!$pendingId || $expires < time() || !$db_connected || !$pdo) {
            unset($_SESSION['two_factor_pending_user_id'], $_SESSION['two_factor_pending_expires']);
            $error = 'Your two-factor login session expired. Please sign in again.';
        } else {
            $st = $pdo->prepare('SELECT * FROM users WHERE id = ? AND two_factor_enabled = 1 LIMIT 1');
            $st->execute([$pendingId]); $user = $st->fetch(PDO::FETCH_ASSOC);
            try { $secret = $user && !empty($user['two_factor_secret']) ? app_decrypt_secret((string)$user['two_factor_secret']) : ''; }
            catch (Throwable $e) { $secret = ''; error_log('2FA secret error: '.$e->getMessage()); }
            if ($user && $secret !== '' && totp_verify($secret, $code)) {
                $prev = null;
                try { $pl=$pdo->prepare("SELECT created_at FROM audit_logs WHERE user_email=? AND action='LOGIN' ORDER BY created_at DESC,id DESC LIMIT 1"); $pl->execute([$user['email']]); $prev=$pl->fetchColumn() ?: null; } catch(Throwable $e) {}
                session_regenerate_id(true); unset($_SESSION['two_factor_pending_user_id'], $_SESSION['two_factor_pending_expires']);
                unset($user['password_hash'],$user['two_factor_secret']); $_SESSION['user']=$user; $_SESSION['last_login_prev']=$prev;
                log_audit_trail('LOGIN','Auth',(int)$user['id'],'Successful password and two-factor authentication');
                header('Location: /dashboard.php'); exit;
            }
            $error = 'The authentication code is invalid. Check your authenticator app and try again.';
            $two_factor_pending = true;
        }
    } else {
        $email = trim($_POST['email'] ?? ''); $password = (string)($_POST['password'] ?? '');
        if ($email === '' || $password === '') $error = 'Please enter both your email address and password.';
        elseif ($db_connected && $pdo) {
            try {
                $stmt=$pdo->prepare('SELECT * FROM users WHERE email=? LIMIT 1'); $stmt->execute([$email]); $user=$stmt->fetch(PDO::FETCH_ASSOC);
                if ($user && password_verify($password,(string)$user['password_hash'])) {
                    if (!empty($user['two_factor_enabled'])) {
                        $_SESSION['two_factor_pending_user_id']=(int)$user['id']; $_SESSION['two_factor_pending_expires']=time()+300; $two_factor_pending=true;
                    } else {
                        $prev=null; try {$pl=$pdo->prepare("SELECT created_at FROM audit_logs WHERE user_email=? AND action='LOGIN' ORDER BY created_at DESC,id DESC LIMIT 1");$pl->execute([$user['email']]);$prev=$pl->fetchColumn()?:null;}catch(Throwable $e){}
                        session_regenerate_id(true); unset($user['password_hash'],$user['two_factor_secret']); $_SESSION['user']=$user; $_SESSION['last_login_prev']=$prev;
                        log_audit_trail('LOGIN','Auth',(int)$user['id'],'User logged into PP-SDOMS from cPanel web portal'); header('Location: /dashboard.php'); exit;
                    }
                } else $error='Invalid email address or password.';
            } catch (Throwable $e) { error_log('Login verification failed: '.$e->getMessage()); $error='Unable to verify credentials against the database.'; }
        } else $error='The database connection is unavailable. Please contact the system administrator.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login — State Department for Medical Services (PP-SDOMS)</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/assets/css/stylelogin.css">
    <style>
        .login-wrapper {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(110deg, #f2f5fb 0%, #dfe6f1 48%, #cbd6e7 100%);
            padding: 24px 16px;
        }
        .login-shell { width: min(450px, 100%); }
    </style>
</head>
<body>

<div class="login-wrapper">
    <div class="login-shell">
        <div class="login-card">
            <header class="login-brand">
                <img src="/assets/images/kenya_coat_arms.png" alt="Coat of Arms of Kenya" onerror="this.src='/public/assets/images/kenya_coat_arms.png';">
                <h1>State Department for Medical Services</h1>
                <p>Performance Management Dashboard</p>
            </header>

            <?php if (!empty($error)): ?>
                <div class="login-error"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>

            <?php if ($two_factor_pending): ?>
            <form method="POST" action="/index.php" class="login-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(get_csrf_token()) ?>">
                <p style="color:#475569;font-size:.86rem;margin:0 0 8px;">Enter the 6-digit code from your authenticator app to complete sign in.</p>
                <label for="two-factor-code">Authenticator code</label>
                <div class="login-input-group"><input id="two-factor-code" type="text" name="two_factor_code" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" autocomplete="one-time-code" required autofocus placeholder="000000"></div>
                <button type="submit" class="login-submit">Verify and Login</button>
            </form>
            <?php else: ?>
            <form method="POST" action="/index.php" class="login-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(get_csrf_token()) ?>">

                <label for="login-email">Email Address</label>
                <div class="login-input-group">
                    <span class="login-input-icon" aria-hidden="true">
                        <svg viewBox="0 0 24 24"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>
                    </span>
                    <input id="login-email" type="email" name="email" required value="" placeholder="name@health.go.ke" autocomplete="username">
                </div>

                <label for="login-password">Password</label>
                <div class="login-input-group">
                    <span class="login-input-icon" aria-hidden="true">
                        <svg viewBox="0 0 24 24"><path d="M18 8h-1V6a5 5 0 0 0-10 0v2H6a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V10a2 2 0 0 0-2-2zM9 6a3 3 0 0 1 6 0v2H9zm3 11a2 2 0 1 1 0-4 2 2 0 0 1 0 4z"/></svg>
                    </span>
                    <input id="login-password" type="password" name="password" required placeholder="Enter your password" autocomplete="current-password">
                </div>

                <button type="submit" class="login-submit">
                    <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M10.09 15.59 11.5 17l5-5-5-5-1.41 1.41L12.67 11H3v2h9.67zM19 3h-8a2 2 0 0 0-2 2v3h2V5h8v14h-8v-3H9v3a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2z"/></svg>
                    Login
                </button>
            </form>
            <?php endif; ?>

            <p class="login-help">For account access, contact your system administrator.</p>
            <footer class="login-footer">
                &copy; <?= date('Y') ?> Government of Kenya.<br>All Rights Reserved.
                <div style="margin-top:8px;font-size:.68rem;"><a href="/install.php" style="color:#8a94a3;text-decoration:underline;">System setup</a></div>
            </footer>
        </div>
    </div>
</div>

</body>
</html>
