<?php
/**
 * Executive Management Dashboard
 * Ministry of Health — State Department for Medical Services (PP-SDOMS)
 * Native PHP 8.1+ & MySQL (No Node.js)
 */
require_once __DIR__ . '/config/db.php';
require_auth();

$page_title = 'Executive Dashboard — State Department for Medical Services';
$active_tab = 'dashboard';

$total_budget = 0.0;
$total_disbursed = 0.0;
$flagships_count = 0;
$projects_count = 0;
$action_points_count = 0;
$pending_reports_count = 0;
$average_kpi_achievement = 0.0;
$projects = [];
$flagships = [];
$latest_project_progress = [];

if ($db_connected && $pdo) {
    try {
        $projects = $pdo->query("SELECT * FROM projects ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
        try {
            $progress_rows = $pdo->query("SELECT mp.project_id, SUM(mp.progress_pct) AS progress_pct
                FROM monthly_progress mp
                INNER JOIN (
                    SELECT project_id, MAX(`year_month`) AS latest_month
                    FROM monthly_progress GROUP BY project_id
                ) latest ON latest.project_id = mp.project_id AND latest.latest_month = mp.`year_month`
                GROUP BY mp.project_id")->fetchAll(PDO::FETCH_ASSOC);
            foreach ($progress_rows as $progress_row) {
                $latest_project_progress[(int)$progress_row['project_id']] = (float)$progress_row['progress_pct'];
            }
        } catch (Exception $e) {
            $latest_project_progress = [];
        }
        $projects_count = (int)$pdo->query("SELECT COUNT(*) FROM projects")->fetchColumn();
        $flagships = $pdo->query("SELECT * FROM flagships ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);
        $flagships_count = (int)$pdo->query("SELECT COUNT(*) FROM flagships")->fetchColumn();
        $action_points_count = (int)$pdo->query("SELECT COUNT(*) FROM action_points WHERE status <> 'COMPLETED'")->fetchColumn();
        try {
            $pending_reports_count = (int)$pdo->query("SELECT COUNT(*) FROM reports WHERE status = 'Pending'")->fetchColumn();
        } catch (Exception $e) {
            $pending_reports_count = 0;
        }
        $budget_totals = $pdo->query("SELECT COALESCE(SUM(total_budget), 0) AS total_budget, COALESCE(SUM(funds_disbursed), 0) AS total_disbursed FROM projects")->fetch(PDO::FETCH_ASSOC);
        $total_budget = (float)($budget_totals['total_budget'] ?? 0);
        $total_disbursed = (float)($budget_totals['total_disbursed'] ?? 0);
        $average_kpi_achievement = (float)($pdo->query("SELECT COALESCE(AVG(current_achievement), 0) FROM performance_kpis")->fetchColumn() ?: 0);
    } catch (Exception $e) {
        $projects = [];
        $flagships = [];
    }
}
$exchequer_release_pct = $total_budget > 0 ? min(100, ($total_disbursed / $total_budget) * 100) : 0;
$project_filter_options = ['saga' => [], 'directorate' => [], 'delivery_unit' => [], 'division' => []];
foreach ($projects as $project) {
    foreach (['saga' => 'saga_name', 'directorate' => 'directorate_name', 'delivery_unit' => 'delivery_unit', 'division' => 'division_name'] as $option_key => $field_name) {
        $option_value = trim((string)($project[$field_name] ?? ''));
        if ($option_value !== '') $project_filter_options[$option_key][$option_value] = $option_value;
    }
}
foreach ($project_filter_options as &$option_values) { natcasesort($option_values); $option_values = array_values($option_values); }
unset($option_values);
require_once __DIR__ . '/includes/header.php';
?>

<style>
    .dashboard-page { display:flex; flex-direction:column; gap:24px; }
    .dashboard-title-banner { background:#5b92e5; color:#fff; padding:13px 20px; border-radius:4px; box-shadow:0 2px 6px rgba(91,146,229,.2); }
    .dashboard-title-banner h2 { margin:0; font-size:1.15rem; font-weight:800; letter-spacing:.5px; text-transform:uppercase; }
    .dashboard-quick-heading { display:flex; align-items:center; gap:9px; margin:0 0 15px; color:#1e293b; font-size:.95rem; font-weight:800; text-transform:uppercase; }
    .dashboard-quick-heading svg { width:18px; height:18px; fill:none; stroke:currentColor; stroke-width:2; }
    .dashboard-quick-links { display:grid; grid-template-columns:repeat(3,minmax(0,1fr)); gap:20px; }
    .dashboard-quick-link { min-height:174px; padding:24px 18px; border-radius:10px; background:linear-gradient(135deg,#2165c4,#174f9d); color:#fff; text-decoration:none; text-align:center; display:flex; flex-direction:column; align-items:center; justify-content:center; gap:11px; box-shadow:0 5px 12px rgba(22,78,150,.2); transition:transform .15s,box-shadow .15s; }
    .dashboard-quick-link:hover { transform:translateY(-2px); box-shadow:0 8px 17px rgba(22,78,150,.26); }
    .dashboard-quick-icon { width:32px; height:32px; display:flex; align-items:center; justify-content:center; color:#fff; }
    .dashboard-quick-icon svg { width:30px; height:30px; fill:none; stroke:currentColor; stroke-width:2.6; stroke-linecap:round; stroke-linejoin:round; }
    .dashboard-quick-link strong { font-size:1.03rem; font-weight:700; line-height:1.25; }
    .dashboard-quick-link > span:last-child { color:#dbeafe; font-size:.8rem; }
    .priority-heading { display:flex; align-items:center; justify-content:space-between; gap:14px; margin-bottom:15px; }
    .priority-heading h2 { margin:0; color:#102c53; font-size:1.25rem; font-weight:800; }
    .priority-heading p { margin:3px 0 0; color:#64748b; font-size:.8rem; }
    .priority-explore { flex:0 0 auto; padding:8px 12px; border:1px solid #dce4ef; border-radius:6px; background:#fff; color:#1e293b; font-size:.78rem; font-weight:700; text-decoration:none; }
    .priority-status-filters { display:flex; flex-wrap:wrap; gap:8px; margin-bottom:16px; }
    .priority-status-filter { display:inline-flex; align-items:center; gap:7px; padding:7px 11px; border:1px solid #dce4ef; border-radius:6px; background:#fff; color:#1e293b; font:inherit; font-size:.76rem; font-weight:700; cursor:pointer; }
    .priority-status-filter[aria-pressed="true"] { background:#102c53; border-color:#102c53; color:#fff; }
    .status-dot { width:8px; height:8px; border-radius:50%; background:var(--status-color); }
    .priority-filters { display:grid; grid-template-columns:1.2fr 1fr; gap:14px; padding:16px 18px; margin-bottom:18px; border:1px solid #dce4ef; border-radius:8px; background:#fff; }
    .priority-filter-field { display:flex; flex-direction:column; gap:5px; color:#334155; font-size:.82rem; }
    .priority-filter-field input,.priority-filter-field select { width:100%; min-height:38px; padding:8px 12px; border:1px solid #dce4ef; border-radius:6px; background:#f8fafc; color:#1e293b; font:inherit; font-size:.8rem; }
    .priority-table-wrap { overflow-x:auto; border:1px solid #dce4ef; border-radius:8px; background:#fff; box-shadow:0 1px 3px rgba(0,0,0,.03); }
    .priority-table { width:100%; border-collapse:collapse; text-align:left; font-size:.96rem; }
    .priority-table thead { background:#f8fafc; color:#64748b; }
    .priority-table th { padding:14px 16px; border-bottom:1px solid #dce4ef; font-size:.86rem; font-weight:800; text-transform:uppercase; letter-spacing:.35px; white-space:nowrap; }
    .priority-table td { padding:15px 16px; border-bottom:1px solid #eef2f7; color:#334155; vertical-align:middle; }
    .priority-table .priority-explore { font-size:.9rem; }
    .priority-table tbody tr:hover { background:#f8fbff; }
    .priority-project-name { color:#0f172a; font-weight:750; }
    .priority-project-meta { margin-top:3px; color:#64748b; font-size:.864rem; font-weight:400; }
    .priority-status-badge { display:inline-block; padding:5px 10px; border-radius:12px; color:#fff; font-size:.84rem; font-weight:750; white-space:nowrap; }
    .priority-progress { min-width:120px; }
    .priority-progress-track { height:8px; margin-bottom:4px; overflow:hidden; border-radius:6px; background:#e7edf5; }
    .priority-progress-track span { display:block; height:100%; border-radius:inherit; background:#2c68c5; }
    .priority-empty { padding:26px!important; text-align:center; color:#64748b!important; }
    @media(max-width:960px) { .dashboard-quick-links { grid-template-columns:repeat(2,minmax(0,1fr)); } }
    @media(max-width:640px) { .dashboard-quick-links { grid-template-columns:1fr; } .priority-filters { grid-template-columns:1fr; } .priority-heading { align-items:flex-start; flex-direction:column; } }
</style>

<div class="dashboard-page">
    <div class="dashboard-title-banner"><h2>Performance Management Dashboard</h2></div>

    <!-- Quick Access Hub -->
    <section aria-labelledby="quickAccessHeading" style="padding-bottom:50px;">
        <h3 id="quickAccessHeading" class="dashboard-quick-heading"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>Quick Access</h3>
        <div class="dashboard-quick-links">
            <?php
            $quick_links = [
                ['title' => 'Priority Flagships', 'desc' => 'Track Priority Flagships', 'url' => '/modules/flagships.php', 'icon' => '<path d="M5 21V4m0 1h12l-2 4 2 4H5"/>'],
                ['title' => 'Projects & Programmes', 'desc' => 'Manage all projects and programmes', 'url' => '/modules/projects.php', 'icon' => '<path d="M3 8a2 2 0 0 1 2-2h5l2 2h7a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><circle cx="12" cy="13" r="3"/>'],
                ['title' => 'Upcoming Key Activities & Events', 'desc' => 'Manage activities and events', 'url' => '/modules/events.php', 'icon' => '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18M8 15l2 2 4-4"/>'],
                ['title' => 'Action Points Tracker', 'desc' => 'View Action Points', 'url' => '/modules/actions.php', 'icon' => '<rect x="5" y="4" width="14" height="17" rx="2"/><path d="M9 4V2h6v2m-6 8 2 2 4-4"/>'],
                ['title' => 'Meeting Minutes', 'desc' => 'View meeting minutes and decisions', 'url' => '/modules/meetings.php', 'icon' => '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/><path d="M9 7h7M9 11h7"/>'],
                ['title' => 'Performance Contract', 'desc' => 'View performance indicators and KPIs', 'url' => '/modules/pc.php', 'icon' => '<path d="M7 3h8l5 5v13H7zM15 3v5h5M10 13h7m-7 4h7"/>'],
                ['title' => 'Reports', 'desc' => 'View System Data', 'url' => '/modules/reports.php', 'icon' => '<circle cx="9" cy="8" r="3"/><path d="M3 20v-1a6 6 0 0 1 12 0v1m2-12a3 3 0 0 1 0 6m1 2a5 5 0 0 1 3 4v1"/>'],
                ['title' => 'Diary', 'desc' => 'View Diary Entries', 'url' => '/modules/diary.php', 'icon' => '<path d="M6 4h12v17l-6-4-6 4z"/><circle cx="12" cy="9" r="2"/>'],
                
            ];
            foreach ($quick_links as $ql): ?>
                <a href="<?= $ql['url'] ?>" class="dashboard-quick-link">
                    <span class="dashboard-quick-icon"><svg viewBox="0 0 24 24" aria-hidden="true"><?= $ql['icon'] ?></svg></span>
                    <strong><?= htmlspecialchars($ql['title']) ?></strong>
                    <span><?= htmlspecialchars($ql['desc']) ?></span>
                </a>
            <?php endforeach; ?>
        </div>
    </section>

    
    

</div>

<script>
(() => {
    const body = document.getElementById('priorityProjectsBody');
    if (!body) return;
    const rows = [...body.querySelectorAll('[data-project-row]')];
    const search = document.getElementById('priorityProjectSearch');
    const filters = {
        saga: document.getElementById('priorityProjectSaga'),
        directorate: document.getElementById('priorityProjectDirectorate'),
        deliveryUnit: document.getElementById('priorityProjectDeliveryUnit'),
        division: document.getElementById('priorityProjectDivision')
    };
    const empty = document.getElementById('priorityProjectsEmpty');
    let activeStatus = '';
    const applyFilters = () => {
        const query = (search.value || '').trim().toLowerCase();
        let visible = 0;
        rows.forEach(row => {
            const matches = row.dataset.search.includes(query)
                && (!activeStatus || row.dataset.status === activeStatus)
                && (!filters.saga.value || row.dataset.saga === filters.saga.value)
                && (!filters.directorate.value || row.dataset.directorate === filters.directorate.value)
                && (!filters.deliveryUnit.value || row.dataset.deliveryUnit === filters.deliveryUnit.value)
                && (!filters.division.value || row.dataset.division === filters.division.value);
            row.hidden = !matches;
            if (matches) visible++;
        });
        empty.hidden = visible > 0;
        if (visible === 0 && rows.length) empty.querySelector('td').textContent = 'No projects match the current filters.';
    };
    // Divisions belong to a directorate: only offer divisions that exist under the chosen directorate.
    const divisionOptions = [...filters.division.options];
    const syncDivisionOptions = () => {
        const chosen = filters.directorate.value;
        const allowed = new Set(rows.filter(row => !chosen || row.dataset.directorate === chosen).map(row => row.dataset.division));
        divisionOptions.forEach(option => { const ok = !option.value || allowed.has(option.value); option.hidden = !ok; option.disabled = !ok; });
        if (filters.division.selectedOptions[0]?.disabled) filters.division.value = '';
    };
    filters.directorate.addEventListener('change', syncDivisionOptions);
    document.getElementById('priorityProjectReset')?.addEventListener('click', () => {
        search.value = ''; Object.values(filters).forEach(filter => { filter.value = ''; }); activeStatus = '';
        document.querySelectorAll('[data-status-filter]').forEach(item => item.setAttribute('aria-pressed', String(item.dataset.statusFilter === '')));
        syncDivisionOptions(); applyFilters();
    });
    search.addEventListener('input', applyFilters);
    Object.values(filters).forEach(filter => filter.addEventListener('change', applyFilters));
    document.querySelectorAll('[data-status-filter]').forEach(button => button.addEventListener('click', () => {
        activeStatus = button.dataset.statusFilter;
        document.querySelectorAll('[data-status-filter]').forEach(item => item.setAttribute('aria-pressed', String(item === button)));
        applyFilters();
    }));
})();
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
